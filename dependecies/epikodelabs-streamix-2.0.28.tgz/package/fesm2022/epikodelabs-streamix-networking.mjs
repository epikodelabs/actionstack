import { createReplaySubject, createStream, isPromiseLike } from '@epikodelabs/streamix';

/**
 * Creates a middleware function that sets a custom fetch function within a context object.
 *
 * This is useful for mocking HTTP requests in tests or for using a different
 * fetch implementation, such as `node-fetch` in a server environment.
 */
const useCustom = (customFetch) => {
    return (next) => async (context) => {
        context.fetch = customFetch;
        return await next(context);
    };
};
/**
 * Resolves relative URLs against a base URL.
 *
 * This middleware is useful for making API requests without repeating the
 * base URL for every call. It will resolve relative paths like `/users/1`
 * against the provided `baseUrl`.
 */
const useBase = (baseUrl) => {
    return (next) => async (context) => {
        const url = context.url.startsWith('http://') || context.url.startsWith('https://')
            ? context.url
            : new URL(context.url, baseUrl).toString();
        context.url = url;
        return await next(context);
    };
};
/**
 * Sets the `Accept` header for the request.
 *
 * This middleware ensures that the request specifies the desired content
 * type for the response, such as `application/json`.
 */
const useAccept = (contentType) => {
    return (next) => async (context) => {
        context.headers['Accept'] = contentType;
        return await next(context);
    };
};
/**
 * Handles OAuth 2.0 authentication and token refresh.
 *
 * This middleware automatically adds an `Authorization` header to the request
 * with a bearer token. If a 401 Unauthorized response is received, it attempts
 * to refresh the token and retry the request.
 */
const useOauth = ({ getToken, refreshToken, shouldRetry = () => true, // Default to always retry
 }) => {
    return (next) => async (context) => {
        // Set the initial token in the Authorization header
        context.headers["Authorization"] = `Bearer ${await getToken()}`;
        // Attempt the request
        const newContext = await next(context);
        // If unauthorized and shouldRetry allows, refresh the token and retry
        if (newContext.status === 401 && shouldRetry(newContext)) {
            newContext.headers["Authorization"] = `Bearer ${await refreshToken()}`;
            return await next(context); // Retry with the new token
        }
        return newContext;
    };
};
/**
 * Retry middleware for handling transient errors.
 *
 * This middleware automatically retries a failed request, with an exponential
 * backoff delay between attempts. This is useful for handling temporary network
 * failures or flaky API services.
 */
const useRetry = (maxRetries = 3, backoffBase = 1000, shouldRetry = () => true) => {
    return (next) => async (context) => {
        let retryCount = 0;
        while (retryCount <= maxRetries) {
            try {
                return await next(context); // Attempt the request
            }
            catch (error) {
                if (!shouldRetry(error, context)) {
                    throw error; // Do not retry if the error is not retryable
                }
                if (retryCount === maxRetries) {
                    throw error; // Max retries reached, rethrow the error
                }
                // Calculate exponential backoff delay
                const delay = backoffBase * Math.pow(2, retryCount);
                console.warn(`[http retry] attempt=${retryCount + 1}/${maxRetries} delay=${delay}ms`, {
                    message: error?.message ?? String(error),
                    url: context.url,
                    method: context.method,
                });
                // Wait for the delay before retrying
                await new Promise((resolve) => setTimeout(resolve, delay));
                retryCount++;
            }
        }
        // This line should never be reached, but TypeScript requires a return statement
        throw new Error('Retry middleware failed unexpectedly');
    };
};
/**
 * Handles HTTP redirects.
 *
 * This middleware automatically follows 3xx redirect responses up to a
 * specified maximum number of times. It updates the URL in the context and
 * handles the change in HTTP method for a 303 See Other redirect.
 */
const useRedirect = (maxRedirects = 5) => {
    return (next) => async (initialContext) => {
        let context = initialContext;
        let redirects = 0;
        while (true) {
            const result = await next(context);
            // No redirect ??? finished
            if (result.redirectTo === undefined) {
                return result;
            }
            redirects++;
            if (redirects > maxRedirects) {
                throw new Error('Too many redirects');
            }
            const location = result.redirectTo;
            if (!location) {
                throw new Error('Redirect response missing Location header');
            }
            // Resolve new URL
            const nextUrl = new URL(location, result.url).toString();
            context = {
                ...result,
                url: nextUrl,
                redirectTo: undefined,
            };
            // RFC 7231: 303 ??? GET + drop body
            if (result.status === 303) {
                context.method = 'GET';
                context.body = undefined;
            }
        }
    };
};
/**
 * Sets a custom header for the request.
 */
const useHeader = (name, value) => {
    return (next) => async (context) => {
        context.headers[name] = value;
        return await next(context);
    };
};
/**
 * Appends query parameters to the request URL.
 */
const useParams = (data) => {
    return (next) => async (context) => {
        context.params = { ...data, ...context.params };
        return await next(context);
    };
};
/**
 * Handles errors thrown by the next middleware in the chain.
 *
 * This middleware provides a way to gracefully handle errors without
 * breaking the entire chain. It catches errors and allows you to
 * define a custom fallback behavior.
 */
const useFallback = (handler) => {
    return (next) => async (context) => {
        try {
            return await next(context);
        }
        catch (error) {
            return handler(error, context);
        }
    };
};
/**
 * Logs request and response information.
 */
const useLogger = (logger = console.log) => {
    return (next) => async (context) => {
        logger(`Request: ${context.method} ${context.url}`);
        context = await next(context);
        logger(`Response: ${context.status || 'No Response'} ${context.url}`);
        return context;
    };
};
/**
 * Sets a timeout for the request.
 *
 * This middleware adds a timeout to the request, automatically aborting it
 * if it takes longer than the specified number of milliseconds.
 */
const useTimeout = (ms) => {
    return (next) => async (context) => {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), ms);
        const combinedSignal = context['signal']
            ? AbortSignal.any([context['signal'], controller.signal])
            : controller.signal;
        context['signal'] = combinedSignal;
        try {
            context = await next(context);
            clearTimeout(timeoutId);
            return context;
        }
        catch (error) {
            clearTimeout(timeoutId);
            if (error.name === 'AbortError') {
                throw new Error('Request timed out');
            }
            throw error;
        }
    };
};
/**
 * Creates an HTTP client with middleware support and streaming capabilities.
 *
 * The client is a factory for creating request streams. Middleware can be
 * configured globally for the client using `withDefaults`.
 *
 * @returns {HttpClient} An instance of the HTTP client.
 *
 * @example
 * ```typescript
 * async function fetchData() {
 *   const client = createHttpClient().withDefaults(
 *     useBase("https://api.example.com"),
 *     useAccept("application/json"),
 *     useLogger(),
 *     useTimeout(5000),
 *     useFallback((error, context) => {
 *       console.error("Request failed:", error);
 *       return context;
 *     })
 *   );
 *
 *   const responseStream = client.get("/data", readJson);
 *
 *   try {
 *     for await (const value of responseStream) {
 *       console.log("Received data:", value);
 *     }
 *   } catch (error) {
 *     console.error("Unexpected error:", error);
 *   }
 * }
 *
 * fetchData();
 *
 * async function postData() {
 *   const client = createHttpClient().use(
 *     useBase("https://api.example.com"),
 *     useLogger(),
 *     useFallback((error, context) => {
 *       console.error("Post request failed:", error);
 *       return context;
 *     })
 *   );
 *
 *   const responseStream = client.post("/items");
 *
 *   try {
 *     for await (const value of responseStream) {
 *       console.log("Post response:", value);
 *     }
 *   } catch (error) {
 *     console.error("Post request error:", error);
 *   }
 * }
 *
 * postData();
 * ```
 */
const createHttpClient = () => {
    const defaultHeaders = { 'Content-Type': 'application/json' };
    const middlewares = [];
    /**
     * Resolves the final request URL, adding query parameters if provided.
     */
    const resolveUrl = (url, params) => {
        const fullUrl = url.startsWith('http://') || url.startsWith('https://')
            ? url
            : new URL(url).toString();
        if (params) {
            const urlObj = new URL(fullUrl);
            Object.entries(params).forEach(([key, value]) => urlObj.searchParams.append(key, value));
            return urlObj.toString();
        }
        return fullUrl;
    };
    /**
     * Chains middlewares to process the request context before making the request.
     */
    const chainMiddleware = (middlewares) => {
        return middlewares.reduceRight((nextMiddleware, middleware) => (next) => (ctx) => middleware(nextMiddleware(next))(ctx), () => async (context) => {
            let body = context.body;
            if (typeof body === 'object' && body !== null) {
                if (!(body instanceof FormData || body instanceof URLSearchParams)) {
                    if (context.headers['Content-Type'] === 'application/json') {
                        body = JSON.stringify(body);
                    }
                }
            }
            const url = resolveUrl(context.url, context.params);
            const { method, parser } = context;
            const request = new Request(url, {
                method,
                headers: context.headers,
                body,
                credentials: context['credentials'],
                signal: context['signal'],
            });
            const response = await context.fetch(request);
            // Update context with response details
            context.ok = response.ok;
            context.status = response.status;
            context.statusText = response.statusText;
            // Handle redirects
            if ([301, 302, 303, 307, 308].includes(response.status)) {
                context.redirectTo = response.headers.get('Location') || undefined;
                return context;
            }
            // **Handle errors before processing response**
            if (!response.ok) {
                throw new Error(`HTTP Error: ${response.status} ${response.statusText}`);
            }
            const data = createReplaySubject();
            (async () => {
                try {
                    for await (const item of parser(response)) {
                        data.next(item);
                    }
                }
                catch (error) {
                    data.error(error);
                }
                finally {
                    data.complete();
                }
            })();
            context.data = data;
            return context;
        });
    };
    /**
     * Performs an HTTP request using the configured middlewares and streaming.
     */
    const request = (method, url, optionsOrParser, maybeParser) => {
        const abortController = new AbortController();
        // Determine whether optionsOrParser is the parser or options
        const isParser = typeof optionsOrParser === 'function';
        const options = isParser ? {} : optionsOrParser || {};
        const parser = isParser
            ? optionsOrParser
            : (maybeParser ?? readStatus);
        const context = {
            url,
            method,
            headers: { ...defaultHeaders, ...options.headers },
            body: options.body,
            params: options.params,
            credentials: options.withCredentials ? 'include' : 'same-origin',
            signal: abortController.signal,
            fetch: globalThis.fetch.bind(globalThis),
            parser,
        };
        const promise = chainMiddleware(middlewares)(async (ctx) => ctx)(context);
        const stream = createStream('httpData', async function* () {
            const ctx = await promise;
            yield* ctx.data;
        });
        stream.abort = () => abortController.abort();
        return stream;
    };
    return {
        withDefaults: function (...newMiddlewares) {
            middlewares.push(...newMiddlewares);
            return this;
        },
        get: (url, options, parser) => request('GET', url, options, parser),
        post: (url, options, parser) => request('POST', url, options, parser),
        put: (url, options, parser) => request('PUT', url, options, parser),
        patch: (url, options, parser) => request('PATCH', url, options, parser),
        delete: (url, options, parser) => request('DELETE', url, options, parser),
    };
};
/**
 * Yields the response status and status text as a single object.
 *
 * This parser ignores the response body and emits the HTTP status metadata only.
 */
const readStatus = async function* (response) {
    const headers = {};
    response.headers.forEach((value, key) => {
        headers[key] = value;
    });
    yield {
        status: response.status,
        statusText: response.statusText,
        headers,
    };
};
/**
 * Parses a Response object as JSON.
 *
 * This is a standard parser function that reads the entire response body,
 * parses it as a JSON object, and then emits that single object.
 */
const readJson = async function* (response) {
    const data = await response.json();
    yield data;
};
/**
 **
 * Parses a Response object as text.
 *
 * This parser reads the entire response body as a text string and emits
 * that string as a single value.
 */
const readText = async function* (response) {
    const data = await response.text();
    yield data;
};
/**
 * Parses a Response object as an ArrayBuffer.
 *
 * This parser reads the entire response body into an `ArrayBuffer` and
 * emits it as a single value. This is useful for handling binary data.
 */
const readArrayBuffer = async function* (response) {
    const data = await response.arrayBuffer();
    yield data;
};
/**
 * Parses a Response object as a Blob.
 *
 * This parser reads the entire response body into a `Blob` object and
 * emits it as a single value. This is useful for working with files or images.
 */
const readBlob = async function* (response) {
    const data = await response.blob();
    yield data;
};
/**
 * Reads and processes streamed response chunks based on Content-Type.
 *
 * This is a versatile parser that can handle a variety of streaming formats,
 * including binary data and line-delimited JSON (NDJSON). It emits chunks
 * as they arrive, along with progress information.
 */
const readChunks = (chunkParser = (chunk) => chunk) => async function* (response) {
    if (!response.body) {
        throw new Error("Response body is not readable");
    }
    const contentLength = response.headers.get("Content-Length");
    const totalSize = contentLength ? parseInt(contentLength, 10) : null;
    let loaded = 0;
    const reader = response.body.getReader();
    const contentType = response.headers.get("Content-Type") || "";
    let buffer = "";
    const decoder = new TextDecoder(getEncoding(contentType));
    while (true) {
        const { value, done } = await reader.read();
        if (done)
            break;
        if (value) {
            loaded += value.length;
            const progress = totalSize ? loaded / totalSize : 0.5;
            let parsedChunk;
            if (contentType.includes("text") || contentType.includes("json")) {
                // Convert binary to text
                const chunkText = decoder.decode(value, { stream: true });
                if (contentType.includes("x-ndjson")) {
                    // NDJSON: Process line by line
                    buffer += chunkText;
                    const lines = buffer.split("\n");
                    buffer = lines.pop() || "";
                    for (const line of lines) {
                        if (line.trim()) {
                            try {
                                parsedChunk = chunkParser(line);
                                yield { chunk: parsedChunk, progress, done: false };
                            }
                            catch (error) {
                                console.warn("Invalid NDJSON line:", line, error);
                            }
                        }
                    }
                    continue; // Skip standard yield for NDJSON
                }
                parsedChunk = chunkParser(chunkText);
            }
            else {
                // Binary/Base64/Other formats
                parsedChunk = chunkParser(value);
            }
            yield {
                chunk: parsedChunk,
                progress,
                done: false,
            };
        }
    }
    // Emit final completion signal
    yield {
        chunk: null,
        progress: 1,
        done: true,
    };
};
/**
 * Parses raw binary chunks (returns Uint8Array as-is).
 */
const readBinaryChunk = (chunk) => chunk;
/**
 * Decodes a binary chunk into a text string.
 */
const readTextChunk = (chunk, encoding = "utf-8") => new TextDecoder(encoding).decode(chunk);
/**
 * Parses a binary chunk as JSON.
 */
const readJsonChunk = (chunk) => {
    try {
        return JSON.parse(chunk);
    }
    catch {
        console.warn("Invalid JSON chunk:", chunk);
        return null;
    }
};
/**
 * Parses a single NDJSON line.
 */
const readNdjsonChunk = (line) => {
    try {
        return JSON.parse(line);
    }
    catch {
        console.warn("Invalid NDJSON line:", line);
        return null;
    }
};
/**
 * Converts a binary chunk to a Base64 string.
 */
const readBase64Chunk = (chunk) => btoa(String.fromCharCode(...chunk));
/**
 * Parses a text chunk as CSV data.
 */
const readCsvChunk = (chunk) => {
    return chunk.split("\n").map((line) => line.split(","));
};
/**
 * Gets the encoding from a Content-Type header.
 *
 * This utility function extracts the character set from a content-type
 * string, defaulting to `utf-8` if no charset is specified.
 */
function getEncoding(contentType) {
    const match = contentType.match(/charset=([^;]+)/);
    return match ? match[1].trim().toLowerCase() : 'utf-8';
}
/**
 * Reads and collects the entire response body from a `ReadableStream`.
 *
 * This function returns a stream that yields the full data as it's read.
 * It's useful for scenarios where you need the complete response body
 * before processing the data, such as for images or complete files.
 */
const readFull = async function* (response) {
    if (!response.body) {
        throw new Error("Response body is not readable");
    }
    const reader = response.body.getReader();
    let accumulatedData = new Uint8Array();
    while (true) {
        const { value, done } = await reader.read();
        if (done)
            break;
        if (value) {
            // Concatenate the new chunk with the accumulated data
            const newData = new Uint8Array(accumulatedData.length + value.length);
            newData.set(accumulatedData);
            newData.set(value, accumulatedData.length);
            accumulatedData = newData;
        }
    }
    // Once all data is collected, yield the full response body as a single chunk
    yield accumulatedData;
};

/**
 * Creates a stream that performs a JSONP request and emits the resulting data once.
 *
 * This function provides a reactive way to handle JSONP requests, which are
 * often used to bypass the same-origin policy for loading data from a different
 * domain. It dynamically creates a `<script>` tag, handles the response via a
 * global callback, and then cleans up after itself. The stream emits a single
 * value and then completes.
 *
 * @template T The type of the JSONP data to be emitted.
 * @param {MaybePromise<string>} url The URL to make the JSONP request to.
 * @param {MaybePromise<string>} [callbackParam='callback'] The name of the query parameter for the callback function.
 * @returns {Stream<T>} A new stream that emits the JSONP data and then completes.
 */
function jsonp(url, callbackParam = 'callback') {
    return createStream('jsonp', async function* () {
        const resolvedUrl = isPromiseLike(url) ? await url : url;
        const resolvedCallbackParam = isPromiseLike(callbackParam) ? await callbackParam : callbackParam;
        const uniqueCallbackName = `${resolvedCallbackParam}_${Math.random().toString(36).slice(2)}`;
        const script = document.createElement('script');
        const fullUrl = `${resolvedUrl}${resolvedUrl.includes('?') ? '&' : '?'}${resolvedCallbackParam}=${encodeURIComponent(uniqueCallbackName)}`;
        // Promise that resolves when JSONP callback fires or rejects on error
        const dataPromise = new Promise((resolve, reject) => {
            window[uniqueCallbackName] = (data) => resolve(data);
            script.onerror = () => reject(new Error(`JSONP request failed: ${fullUrl}`));
        });
        script.src = fullUrl;
        document.head.appendChild(script);
        // Helper to cleanup
        const cleanup = () => {
            delete window[uniqueCallbackName];
            if (script.parentNode) {
                script.parentNode.removeChild(script);
            }
        };
        try {
            // Race the dataPromise against abort signal
            yield await dataPromise;
        }
        finally {
            cleanup();
        }
    });
}

/**
 * Creates a WebSocket stream for bidirectional communication with a server.
 *
 * Incoming messages from the WebSocket are emitted as stream values.
 * Outgoing messages are sent via the `.send()` method.
 * Messages sent before the connection is open are queued automatically.
 *
 * @template T - Type of messages to send and receive.
 * @param url The WebSocket URL (can be a Promise).
 * @param factory Optional WebSocket factory for dependency injection (useful for testing, can be a Promise).
 * @returns {WebSocketStream<T>} A WebSocketStream that can be used to
 * send and receive messages of type T.
 */
function webSocket(url, factory = (u) => new WebSocket(u)) {
    const messageQueue = [];
    const sendQueue = [];
    let resolveNext = null;
    let rejectNext = null;
    let isOpen = false;
    let done = false;
    let socket = null;
    // Helper to initialize the WebSocket
    const initWebSocket = async () => {
        try {
            const resolvedUrl = isPromise(url) ? await url : url;
            const created = factory(resolvedUrl);
            socket = isPromise(created) ? await created : created;
            setupSocketHandlers();
        }
        catch (error) {
            done = true;
            if (rejectNext) {
                rejectNext(error);
                resolveNext = rejectNext = null;
            }
        }
    };
    const isPromise = (v) => v && typeof v.then === "function";
    const setupSocketHandlers = () => {
        if (!socket)
            return;
        const onOpen = () => {
            isOpen = true;
            while (sendQueue.length) {
                try {
                    socket.send(JSON.stringify(sendQueue.shift()));
                }
                catch (error) {
                    console.warn("Failed to send queued message:", error);
                }
            }
        };
        const onMessage = (ev) => {
            try {
                const data = JSON.parse(ev.data);
                messageQueue.push(data);
                if (resolveNext) {
                    resolveNext(messageQueue.shift());
                    resolveNext = rejectNext = null;
                }
            }
            catch (err) {
                if (rejectNext) {
                    rejectNext(err);
                    resolveNext = rejectNext = null;
                }
            }
        };
        const closeWithError = (err) => {
            done = true;
            isOpen = false;
            if (rejectNext) {
                rejectNext(err);
                resolveNext = rejectNext = null;
            }
        };
        const onClose = () => closeWithError(new Error("WebSocket closed"));
        const onError = () => closeWithError(new Error("WebSocket error"));
        socket.addEventListener("open", onOpen);
        socket.addEventListener("message", onMessage);
        socket.addEventListener("close", onClose);
        socket.addEventListener("error", onError);
        // Cleanup helper
        cleanupHandlers = () => {
            socket?.removeEventListener("open", onOpen);
            socket?.removeEventListener("message", onMessage);
            socket?.removeEventListener("close", onClose);
            socket?.removeEventListener("error", onError);
        };
    };
    let cleanupHandlers = null;
    // Start initialization (sync or async)
    initWebSocket();
    async function* generator() {
        try {
            // Wait for socket initialization if it's happening asynchronously
            if (!socket && !done) {
                await new Promise((resolve) => {
                    const checkSocket = () => {
                        if (socket || done) {
                            resolve();
                        }
                        else {
                            setTimeout(checkSocket, 0);
                        }
                    };
                    checkSocket();
                });
            }
            if (done) {
                throw new Error("WebSocket failed to initialize");
            }
            while (!done) {
                if (messageQueue.length) {
                    yield messageQueue.shift();
                }
                else {
                    yield await new Promise((resolve, reject) => {
                        resolveNext = resolve;
                        rejectNext = reject;
                    });
                }
            }
        }
        finally {
            cleanupHandlers?.();
            if (socket && socket.readyState === WebSocket.OPEN) {
                socket.close();
            }
        }
    }
    ;
    const stream = createStream("webSocket", generator);
    // Send method
    stream.send = (msg) => {
        if (done) {
            return;
        }
        if (isOpen && socket) {
            try {
                socket.send(JSON.stringify(msg));
            }
            catch (error) {
                console.warn("Failed to send message:", error);
            }
        }
        else if (socket && socket.readyState === WebSocket.CONNECTING) {
            sendQueue.push(msg);
        }
        else if (!socket) {
            // Socket not initialized yet - queue the message
            sendQueue.push(msg);
        }
        else {
            console.warn("Cannot send message: WebSocket is not open");
        }
    };
    stream.close = () => {
        done = true;
        isOpen = false;
        if (socket && socket.readyState === WebSocket.OPEN) {
            socket.close();
        }
        if (rejectNext) {
            rejectNext(new Error("WebSocket closed"));
            resolveNext = rejectNext = null;
        }
    };
    return stream;
}

/*
 * Public API Surface of actionstack
 */

/**
 * Generated bundle index. Do not edit.
 */

export { createHttpClient, jsonp, readArrayBuffer, readBase64Chunk, readBinaryChunk, readBlob, readChunks, readCsvChunk, readFull, readJson, readJsonChunk, readNdjsonChunk, readStatus, readText, readTextChunk, useAccept, useBase, useCustom, useFallback, useHeader, useLogger, useOauth, useParams, useRedirect, useRetry, useTimeout, webSocket };
//# sourceMappingURL=epikodelabs-streamix-networking.mjs.map
