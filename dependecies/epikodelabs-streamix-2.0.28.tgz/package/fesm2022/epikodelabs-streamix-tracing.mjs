import { registerRuntimeHooks, createOperator } from '@epikodelabs/streamix';

/**
 * STREAMIX TRACING SYSTEM
 * * A comprehensive tracing system for Streamix reactive streams.
 * * Features:
 * - Tracks value lifecycle from emission to delivery.
 * - Supports filter / collapse / expand / error semantics.
 * - Preserves type safety by wrapping primitives.
 * - Provides public subscription API for observers.
 */
/* ============================================================================
 * ID GENERATION
 * ========================================================================== */
const IDS_KEY = "__STREAMIX_TRACE_IDS__";
/**
 * Retrieves the global counter for IDs.
 */
function getIds() {
    const g = globalThis;
    if (!g[IDS_KEY])
        g[IDS_KEY] = { value: 0 };
    return g[IDS_KEY];
}
/** * Generates a unique trace value identifier.
 */
function generateValueId() {
    return `val_${++getIds().value}`;
}
/**
 * Creates a new tracer instance with isolated internal state.
 */
function createValueTracer(options = {}) {
    const traces = new Map();
    const subscribers = [];
    const subscriptionSubscribers = new Map();
    const { maxTraces = 10000, onTraceUpdate } = options;
    const notifySubscribers = (event, trace) => {
        subscribers.forEach(s => s[event]?.(trace));
        subscriptionSubscribers.get(trace.subscriptionId)?.forEach(s => s[event]?.(trace));
    };
    return {
        subscribe: (handlers) => {
            subscribers.push(handlers);
            return () => {
                const idx = subscribers.indexOf(handlers);
                if (idx > -1)
                    subscribers.splice(idx, 1);
            };
        },
        observeSubscription: (subscriptionId, handlers) => {
            if (!subscriptionSubscribers.has(subscriptionId)) {
                subscriptionSubscribers.set(subscriptionId, new Set());
            }
            subscriptionSubscribers.get(subscriptionId).add(handlers);
            return () => {
                subscriptionSubscribers.get(subscriptionId)?.delete(handlers);
            };
        },
        completeSubscription: (subscriptionId) => {
            const set = subscriptionSubscribers.get(subscriptionId);
            if (set) {
                set.forEach(s => s.complete?.());
                subscriptionSubscribers.delete(subscriptionId);
            }
        },
        startTrace: (valueId, streamId, streamName, subscriptionId, value) => {
            const trace = {
                valueId,
                streamId,
                streamName,
                subscriptionId,
                emittedAt: Date.now(),
                state: "emitted",
                sourceValue: value,
                operatorSteps: [],
                operatorDurations: new Map(),
            };
            traces.set(valueId, trace);
            if (traces.size > maxTraces)
                traces.delete(traces.keys().next().value);
            onTraceUpdate?.(trace);
            return trace;
        },
        createExpandedTrace: (baseValueId, operatorIndex, operatorName, expandedValue) => {
            const base = traces.get(baseValueId);
            const valueId = generateValueId();
            const now = Date.now();
            const trace = {
                valueId,
                streamId: base?.streamId ?? "unknown",
                streamName: base?.streamName,
                subscriptionId: base?.subscriptionId ?? "unknown",
                emittedAt: base?.emittedAt ?? now,
                state: "expanded",
                sourceValue: base?.sourceValue ?? expandedValue,
                finalValue: expandedValue,
                operatorSteps: base ? [...base.operatorSteps.map(s => ({ ...s }))] : [],
                operatorDurations: new Map(base?.operatorDurations || []),
            };
            const step = {
                operatorIndex,
                operatorName,
                enteredAt: now,
                exitedAt: now,
                outcome: "expanded",
                inputValue: base?.finalValue ?? base?.sourceValue,
                outputValue: expandedValue
            };
            trace.operatorSteps.push(step);
            traces.set(valueId, trace);
            onTraceUpdate?.(trace, step);
            return valueId;
        },
        enterOperator: (valueId, operatorIndex, operatorName, inputValue) => {
            const trace = traces.get(valueId);
            if (!trace)
                return;
            const step = { operatorIndex, operatorName, enteredAt: Date.now(), inputValue };
            trace.operatorSteps.push(step);
            onTraceUpdate?.(trace, step);
        },
        exitOperator: (valueId, operatorIndex, outputValue, filtered = false, outcome = "transformed") => {
            const trace = traces.get(valueId);
            const step = trace?.operatorSteps.find(s => s.operatorIndex === operatorIndex && !s.exitedAt);
            if (!trace || !step)
                return null;
            step.exitedAt = Date.now();
            step.outcome = filtered ? "filtered" : outcome;
            step.outputValue = outputValue;
            trace.state = filtered ? "filtered" : "transformed";
            trace.finalValue = outputValue;
            trace.operatorDurations.set(step.operatorName, step.exitedAt - step.enteredAt);
            if (filtered) {
                trace.droppedReason = { operatorIndex, operatorName: step.operatorName, reason: "filtered" };
                notifySubscribers("filtered", trace);
            }
            onTraceUpdate?.(trace, step);
            return valueId;
        },
        collapseValue: (valueId, operatorIndex, operatorName, targetValueId, outputValue) => {
            const trace = traces.get(valueId);
            const step = trace?.operatorSteps.find(s => s.operatorIndex === operatorIndex && !s.exitedAt);
            if (!trace)
                return;
            if (step) {
                step.exitedAt = Date.now();
                step.outcome = "collapsed";
                step.outputValue = outputValue;
            }
            trace.state = "collapsed";
            trace.collapsedInto = { operatorIndex, operatorName, targetValueId };
            trace.droppedReason = { operatorIndex, operatorName, reason: "collapsed" };
            notifySubscribers("collapsed", trace);
        },
        errorInOperator: (valueId, operatorIndex, error) => {
            const trace = traces.get(valueId);
            const step = trace?.operatorSteps.find(s => s.operatorIndex === operatorIndex && !s.exitedAt);
            if (!trace)
                return;
            if (step) {
                step.exitedAt = Date.now();
                step.outcome = "errored";
                step.error = error;
            }
            trace.state = "errored";
            trace.droppedReason = {
                operatorIndex,
                operatorName: step?.operatorName ?? "unknown",
                reason: "errored",
                error
            };
            notifySubscribers("dropped", trace);
        },
        markDelivered: (valueId) => {
            const trace = traces.get(valueId);
            if (!trace)
                return;
            trace.state = "delivered";
            trace.deliveredAt = Date.now();
            trace.totalDuration = trace.deliveredAt - trace.emittedAt;
            notifySubscribers("delivered", trace);
        },
        getAllTraces: () => Array.from(traces.values()),
        getStats: () => ({ total: traces.size }),
        clear: () => {
            traces.clear();
            subscriptionSubscribers.clear();
        }
    };
}
/**
 * Creates a lightweight tracer that only captures terminal value states.
 */
function createTerminalTracer(options = {}) {
    const traces = new Map();
    const subscribers = [];
    const subscriptionSubscribers = new Map();
    const lastOperator = new Map();
    const { maxTraces = 10000, onTraceUpdate } = options;
    const notifySubscribers = (event, trace) => {
        subscribers.forEach(s => s[event]?.(trace));
        subscriptionSubscribers.get(trace.subscriptionId)?.forEach(s => s[event]?.(trace));
    };
    const getOperatorName = (valueId, operatorIndex) => lastOperator.get(valueId)?.name ?? `op${operatorIndex}`;
    return {
        subscribe: (handlers) => {
            subscribers.push(handlers);
            return () => { const idx = subscribers.indexOf(handlers); if (idx > -1)
                subscribers.splice(idx, 1); };
        },
        observeSubscription: (subscriptionId, handlers) => {
            if (!subscriptionSubscribers.has(subscriptionId))
                subscriptionSubscribers.set(subscriptionId, new Set());
            subscriptionSubscribers.get(subscriptionId).add(handlers);
            return () => { subscriptionSubscribers.get(subscriptionId)?.delete(handlers); };
        },
        completeSubscription: (subscriptionId) => {
            subscriptionSubscribers.get(subscriptionId)?.forEach(s => s.complete?.());
            subscriptionSubscribers.delete(subscriptionId);
        },
        startTrace: (valueId, streamId, streamName, subscriptionId, value) => {
            const trace = {
                valueId, streamId, streamName, subscriptionId,
                emittedAt: Date.now(), state: "emitted", sourceValue: value,
                operatorSteps: [], operatorDurations: new Map(),
            };
            traces.set(valueId, trace);
            if (traces.size > maxTraces)
                traces.delete(traces.keys().next().value);
            onTraceUpdate?.(trace);
            return trace;
        },
        createExpandedTrace: (baseValueId, operatorIndex, operatorName, expandedValue) => {
            const base = traces.get(baseValueId);
            const valueId = generateValueId();
            const now = Date.now();
            const trace = {
                valueId,
                streamId: base?.streamId ?? "unknown",
                streamName: base?.streamName,
                subscriptionId: base?.subscriptionId ?? "unknown",
                emittedAt: base?.emittedAt ?? now,
                state: "expanded",
                sourceValue: base?.sourceValue ?? expandedValue,
                finalValue: expandedValue,
                operatorSteps: [],
                operatorDurations: new Map(),
            };
            traces.set(valueId, trace);
            lastOperator.set(valueId, { index: operatorIndex, name: operatorName });
            onTraceUpdate?.(trace);
            return valueId;
        },
        enterOperator: (valueId, operatorIndex, operatorName) => {
            lastOperator.set(valueId, { index: operatorIndex, name: operatorName });
        },
        exitOperator: (valueId, operatorIndex, outputValue, filtered = false) => {
            const trace = traces.get(valueId);
            if (!trace)
                return null;
            trace.finalValue = outputValue;
            if (filtered) {
                const operatorName = getOperatorName(valueId, operatorIndex);
                trace.state = "filtered";
                trace.droppedReason = { operatorIndex, operatorName, reason: "filtered" };
                notifySubscribers("filtered", trace);
                onTraceUpdate?.(trace);
            }
            return valueId;
        },
        collapseValue: (valueId, operatorIndex, operatorName, targetValueId, outputValue) => {
            const trace = traces.get(valueId);
            if (!trace)
                return;
            trace.state = "collapsed";
            trace.finalValue = outputValue;
            trace.collapsedInto = { operatorIndex, operatorName, targetValueId };
            trace.droppedReason = { operatorIndex, operatorName, reason: "collapsed" };
            notifySubscribers("collapsed", trace);
            onTraceUpdate?.(trace);
        },
        errorInOperator: (valueId, operatorIndex, error) => {
            const trace = traces.get(valueId);
            if (!trace)
                return;
            const operatorName = getOperatorName(valueId, operatorIndex);
            trace.state = "errored";
            trace.droppedReason = { operatorIndex, operatorName, reason: "errored", error };
            notifySubscribers("dropped", trace);
            onTraceUpdate?.(trace);
        },
        markDelivered: (valueId) => {
            const trace = traces.get(valueId);
            if (!trace)
                return;
            trace.state = "delivered";
            trace.deliveredAt = Date.now();
            trace.totalDuration = trace.deliveredAt - trace.emittedAt;
            notifySubscribers("delivered", trace);
            onTraceUpdate?.(trace);
        },
        getAllTraces: () => Array.from(traces.values()),
        getStats: () => ({ total: traces.size }),
        clear: () => {
            traces.clear();
            subscriptionSubscribers.clear();
            lastOperator.clear();
        }
    };
}
/* ============================================================================
 * RUNTIME INTERNALS & GLOBALS
 * ========================================================================== */
const tracedValueBrand = Symbol("__streamix_traced__");
const TRACER_KEY = "__STREAMIX_GLOBAL_TRACER__";
const wrap = (value, meta) => ({ [tracedValueBrand]: true, value, meta });
const unwrap = (v) => (v && v[tracedValueBrand]) ? v.value : v;
/** * Returns the current global tracer, if one is registered.
 */
const getGlobalTracer = () => globalThis[TRACER_KEY] ?? null;
/** * Enables tracing by registering a global tracer instance.
 */
function enableTracing(tracer) {
    globalThis[TRACER_KEY] = tracer;
}
/** * Disables tracing by clearing the global tracer instance.
 */
function disableTracing() {
    globalThis[TRACER_KEY] = null;
}
/* ============================================================================
 * RUNTIME HOOK REGISTRATION
 * ========================================================================== */
registerRuntimeHooks({
    onPipeStream({ streamId, streamName, subscriptionId, source, operators }) {
        const tracer = getGlobalTracer();
        if (!tracer)
            return;
        return {
            source: {
                async next() {
                    const r = await source.next();
                    if (r.done)
                        return r;
                    const id = generateValueId();
                    tracer.startTrace(id, streamId, streamName, subscriptionId, r.value);
                    return {
                        done: false,
                        value: wrap(r.value, { valueId: id, streamId, subscriptionId })
                    };
                },
                return: source.return?.bind(source),
                throw: source.throw?.bind(source),
            },
            operators: operators.map((op, i) => {
                const opName = op.name ?? `op${i}`;
                return createOperator(`traced_${opName}`, (src) => {
                    const inputQueue = [];
                    let lastSeenMeta = null;
                    const rawSource = {
                        async next() {
                            const r = await src.next();
                            if (r.done)
                                return r;
                            const wrapped = r.value;
                            inputQueue.push(wrapped);
                            lastSeenMeta = wrapped.meta;
                            tracer.enterOperator(wrapped.meta.valueId, i, opName, wrapped.value);
                            return { done: false, value: wrapped.value };
                        },
                        return: src.return?.bind(src),
                        throw: src.throw?.bind(src),
                    };
                    const inner = op.apply(rawSource);
                    return {
                        async next() {
                            try {
                                const out = await inner.next();
                                if (out.done) {
                                    if (opName === "filter" && inputQueue.length > 0) {
                                        while (inputQueue.length > 0) {
                                            const filteredEntry = inputQueue.shift();
                                            tracer.exitOperator(filteredEntry.meta.valueId, i, filteredEntry.value, true);
                                        }
                                    }
                                    return out;
                                }
                                if (opName === "filter" && inputQueue.length > 1) {
                                    while (inputQueue.length > 1) {
                                        const filteredEntry = inputQueue.shift();
                                        tracer.exitOperator(filteredEntry.meta.valueId, i, filteredEntry.value, true);
                                    }
                                }
                                const entry = inputQueue.shift();
                                // If the operator produces more outputs than inputs (expanded state)
                                if (!entry && lastSeenMeta) {
                                    const expandedId = tracer.createExpandedTrace(lastSeenMeta.valueId, i, opName, out.value);
                                    return {
                                        done: false,
                                        value: wrap(out.value, { ...lastSeenMeta, valueId: expandedId })
                                    };
                                }
                                // Default transformation
                                if (entry) {
                                    tracer.exitOperator(entry.meta.valueId, i, out.value);
                                    return { done: false, value: wrap(out.value, entry.meta) };
                                }
                                return { done: false, value: out.value };
                            }
                            catch (e) {
                                if (inputQueue.length > 0) {
                                    tracer.errorInOperator(inputQueue[0].meta.valueId, i, e);
                                }
                                throw e;
                            }
                        },
                        return: inner.return?.bind(inner),
                        throw: inner.throw?.bind(inner),
                    };
                });
            }),
            final: it => ({
                async next() {
                    const r = await it.next();
                    if (!r.done) {
                        tracer.markDelivered(r.value.meta.valueId);
                    }
                    else {
                        tracer.completeSubscription(subscriptionId);
                    }
                    return r.done ? r : { done: false, value: unwrap(r.value) };
                },
                async return(v) {
                    tracer.completeSubscription(subscriptionId);
                    return it.return ? await it.return(v) : { done: true, value: v };
                },
                async throw(e) {
                    tracer.completeSubscription(subscriptionId);
                    if (it.throw)
                        return await it.throw(e);
                    throw e;
                }
            })
        };
    }
});

/*
 * Public API Surface of actionstack
 */

/**
 * Generated bundle index. Do not edit.
 */

export { createTerminalTracer, createValueTracer, disableTracing, enableTracing, generateValueId, getGlobalTracer };
//# sourceMappingURL=epikodelabs-streamix-tracing.mjs.map
