import { createOperator, DONE, NEXT, createStream, isPromiseLike } from '@epikodelabs/streamix';

/**
 * Chains multiple coroutine tasks sequentially, creating a single `CoroutineLike` operator.
 *
 * Each coroutine in the sequence processes the output of the previous coroutine,
 * forming a data processing pipeline. This function is useful for composing
 * complex asynchronous operations from simpler, reusable building blocks.
 *
 * The final output type of the cascade is the output type of the last coroutine in the chain.
 *
 * @template T The input type of the first coroutine.
 * @template R The output type of the last coroutine.
 * @param tasks Coroutines to chain.
 * @returns {CoroutineLike<T, R>} A `CoroutineLike` operator representing the entire cascaded pipeline.
 */
function cascade(...tasks) {
    const getTasks = () => tasks;
    const operator = createOperator("cascade", function (source) {
        let completed = false;
        return {
            async next() {
                while (true) {
                    if (completed) {
                        return DONE;
                    }
                    const result = await source.next();
                    if (result.done) {
                        completed = true;
                        return DONE;
                    }
                    let taskResult = result.value;
                    const resolvedTasks = getTasks();
                    for (const task of resolvedTasks) {
                        taskResult = await task.processTask(taskResult);
                    }
                    return NEXT(taskResult);
                }
            },
            async return() {
                completed = true;
                return DONE;
            },
            async throw(err) {
                completed = true;
                throw err;
            }
        };
    });
    const coroutineLike = Object.assign(operator, {
        async processTask(data) {
            let result = data;
            const tasksList = getTasks();
            for (const task of tasksList) {
                result = await task.processTask(result);
            }
            return result;
        },
        async finalize() {
            const tasksList = getTasks();
            for (const task of tasksList) {
                await task.finalize();
            }
        }
    });
    return coroutineLike;
}

/**
 * Default worker script template with placeholders.
 */
const DEFAULT_WORKER_TEMPLATE = `
{GLOBALS}
{HELPERS}
{DEPENDENCIES}
{INIT_CODE}
const __mainTask = {MAIN_TASK};

// A map to store promises for pending data requests from the worker
const __pendingWorkerRequests = new Map();

// A helper function for the worker to request data from the main thread
const __requestData = (workerId, taskId, payload) => {
  return new Promise(resolve => {
    __pendingWorkerRequests.set(taskId, resolve);
    postMessage({ workerId, taskId, type: 'request', payload });
  });
};

const __reportProgress = (workerId, taskId) => (progressData) => {
  postMessage({ workerId, taskId, payload: progressData, type: 'progress' });
};

onmessage = async (event) => {
  const { workerId, taskId, payload, type } = event.data;

  // If this is a response to a data request from the worker
  if (type === 'data') {
    const resolve = __pendingWorkerRequests.get(taskId);
    if (resolve) {
      __pendingWorkerRequests.delete(taskId);
      resolve(payload);
    }
    return;
  }

  // This is the initial task from the main thread
  if (type === 'task') {
    try {
      const utils = {
        requestData: (requestPayload) => __requestData(workerId, taskId, requestPayload),
        reportProgress: __reportProgress(workerId, taskId)
      };
      
      // Always call with both parameters - JavaScript will ignore extra parameters
      const result = await __mainTask(payload, utils);
      
      postMessage({ workerId, taskId, payload: result, type: 'response' });
    } catch (error) {
      postMessage({ workerId, taskId, error: error.message, type: 'error' });
    }
  }
};`;
/**
 * Minified helper script used inside Web Worker blobs.
 */
const HELPER_SCRIPT = `var __defProp=Object.defineProperty,__defProps=Object.defineProperties,__getOwnPropDescs=Object.getOwnPropertyDescriptors,__getOwnPropSymbols=Object.getOwnPropertySymbols,__hasOwnProp=Object.prototype.hasOwnProperty,__propIsEnum=Object.prototype.propertyIsEnumerable,__knownSymbol=(r,e)=>(e=Symbol[r])?e:Symbol.for("Symbol."+r),__defNormalProp=(r,e,o)=>e in r?__defProp(r,e,{enumerable:!0,configurable:!0,writable:!0,value:o}):r[e]=o,__spreadValues=(r,e)=>{for(var o in e||={})__hasOwnProp.call(e,o)&&__defNormalProp(r,o,e[o]);if(__getOwnPropSymbols)for(var o of __getOwnPropSymbols(e))__propIsEnum.call(e,o)&&__defNormalProp(r,o,e[o]);return r},__spreadProps=(r,e)=>__defProps(r,__getOwnPropDescs(e)),__async=(r,e,o)=>new Promise((t,n)=>{var a=r=>{try{s(o.next(r))}catch(e){n(e)}},p=r=>{try{s(o.throw(r))}catch(e){n(e)}},s=r=>r.done?t(r.value):Promise.resolve(r.value).then(a,p);s((o=o.apply(r,e)).next())}),__await=function(r,e){this[0]=r,this[1]=e},__asyncGenerator=(r,e,o)=>{var t=(r,e,n,a)=>{try{var p=o[r](e),s=(e=p.value)instanceof __await,l=p.done;Promise.resolve(s?e[0]:e).then(o=>s?t("return"===r?r:"next",e[1]?{done:o.done,value:o.value}:o,n,a):n({value:o,done:l})).catch(r=>t("throw",r,n,a))}catch(y){a(y)}},n=r=>a[r]=e=>new Promise((o,n)=>t(r,e,o,n)),a={};return o=o.apply(r,e),a[__knownSymbol("asyncIterator")]=()=>a,n("next"),n("throw"),n("return"),a};`;
/**
 * Unique worker identifier counter
 */
let workerIdentifierCounter = 0;
/**
 * Function coroutine.
 */
function coroutine(arg1, ...rest) {
    // This is the implementation function that does the heavy lifting
    const implementCoroutine = (config, main, functions) => {
        const maxWorkers = navigator.hardwareConcurrency || 4;
        const customMessageHandler = config?.customMessageHandler; // Use optional chaining
        const workerPool = [];
        const waitingQueue = [];
        const activeWorkers = new Map();
        const pendingMessages = new Map();
        let createdWorkersCount = 0;
        let blobUrlCache = null;
        let isFinalizing = false;
        const generateWorkerScript = (config) => {
            // Provide default empty config if config is undefined
            const safeConfig = config || {};
            const template = safeConfig.template || DEFAULT_WORKER_TEMPLATE;
            const globals = safeConfig.globals || '';
            const helpers = ([HELPER_SCRIPT, ...(safeConfig.helpers || [])]).join('\n');
            const dependencies = functions
                .map((fn) => fn.toString().replace(/function[\s]*\(/, `function ${fn.name || ""}(`))
                .join(';\n');
            const initCode = safeConfig.initCode || '';
            // Ensure the main task is properly stringified as a function
            const mainTaskBody = main.toString().replace(/function[\s]*\(/, `function ${main.name || ""}(`);
            return template
                .replace('{GLOBALS}', globals)
                .replace('{HELPERS}', helpers)
                .replace('{DEPENDENCIES}', dependencies)
                .replace('{INIT_CODE}', initCode)
                .replace('{MAIN_TASK}', mainTaskBody);
        };
        const defaultMessageHandler = (event, worker, pendingTasks) => {
            const msg = event.data;
            const { taskId, payload, error, type, workerId } = msg;
            const pending = pendingTasks.get(taskId);
            switch (type) {
                case 'response':
                    if (pending) {
                        pendingTasks.delete(taskId);
                        pending.resolve(payload);
                    }
                    break;
                case 'error':
                    console.warn(`Error received from worker ${workerId} for task ${taskId}:`, error);
                    if (pending) {
                        pendingTasks.delete(taskId);
                        pending.reject(new Error(error ?? 'Unknown worker error'));
                    }
                    break;
                case 'request':
                    console.warn(`Worker with ID ${workerId} requested data for taskId ${taskId}:`, payload);
                    // Send dummy data back to the worker to prevent it from hanging
                    worker.postMessage({ workerId, taskId, type: 'data', payload: { message: "This is dummy data from the main thread." } });
                    break;
                case 'progress':
                    console.warn(`Worker with ID ${workerId} progress update for taskId ${taskId}:`, payload);
                    break;
                default:
                    console.warn('Unknown message type from worker:', msg);
                    break;
            }
        };
        const createWorker = async () => {
            const workerId = ++workerIdentifierCounter;
            const workerBody = generateWorkerScript(config); // Pass config (which might be undefined)
            if (!blobUrlCache) {
                const blob = new Blob([workerBody], { type: "application/javascript" });
                blobUrlCache = URL.createObjectURL(blob);
            }
            const worker = new Worker(blobUrlCache, { type: "module" });
            const messageHandler = customMessageHandler
                ? (event) => customMessageHandler(event, worker, pendingMessages)
                : (event) => defaultMessageHandler(event, worker, pendingMessages);
            worker.addEventListener("message", messageHandler);
            worker.__id = workerId;
            activeWorkers.set(workerId, worker);
            return { worker, workerId };
        };
        const getIdleWorker = async () => {
            if (workerPool.length > 0)
                return workerPool.shift();
            if (createdWorkersCount < maxWorkers) {
                createdWorkersCount++;
                return await createWorker();
            }
            return new Promise((resolve) => waitingQueue.push(resolve));
        };
        const returnWorker = (workerId) => {
            const worker = activeWorkers.get(workerId);
            if (!worker) {
                console.warn(`Worker with id ${workerId} not found.`);
                return;
            }
            if (isFinalizing) {
                activeWorkers.delete(workerId);
                worker.terminate();
                return;
            }
            if (waitingQueue.length > 0) {
                const resolve = waitingQueue.shift();
                resolve({ worker, workerId });
            }
            else {
                workerPool.push({ worker, workerId });
            }
        };
        const assignTask = async (workerId, data) => {
            const worker = activeWorkers.get(workerId);
            if (!worker) {
                throw new Error(`Worker ${workerId} not found or is not active`);
            }
            const taskId = crypto.randomUUID();
            return new Promise((resolve, reject) => {
                pendingMessages.set(taskId, { resolve, reject });
                worker.postMessage({ workerId, taskId, payload: data, type: 'task' });
            });
        };
        const processTask = async (value) => {
            const { worker, workerId } = await getIdleWorker();
            const taskId = crypto.randomUUID();
            try {
                return await new Promise((resolve, reject) => {
                    pendingMessages.set(taskId, { resolve, reject });
                    worker.postMessage({ workerId, taskId, payload: value, type: 'task' });
                });
            }
            finally {
                returnWorker(workerId);
            }
        };
        const finalize = async () => {
            if (isFinalizing)
                return;
            isFinalizing = true;
            pendingMessages.clear();
            activeWorkers.forEach((worker) => worker.terminate());
            activeWorkers.clear();
            while (workerPool.length > 0) {
                const { worker } = workerPool.pop();
                worker.terminate();
            }
            waitingQueue.length = 0;
            if (blobUrlCache) {
                URL.revokeObjectURL(blobUrlCache);
                blobUrlCache = null;
            }
        };
        const operator = createOperator("coroutine", function (source) {
            let completed = false;
            return {
                next: async () => {
                    while (true) {
                        if (completed || isFinalizing) {
                            return DONE;
                        }
                        const result = await source.next();
                        if (result.done) {
                            completed = true;
                            await finalize();
                            return DONE;
                        }
                        const taskResult = await processTask(result.value);
                        return NEXT(taskResult);
                    }
                },
                async return() {
                    completed = true;
                    await finalize();
                    return DONE;
                },
                async throw(err) {
                    completed = true;
                    await finalize();
                    throw err;
                }
            };
        });
        return {
            ...operator,
            finalize,
            assignTask,
            processTask,
            getIdleWorker,
            returnWorker,
        };
    };
    // --- Overloaded function implementation logic
    if (typeof arg1 === 'function') {
        // Direct invocation: createCoroutine(mainTask, helper1, ...)
        const main = arg1;
        const functions = rest;
        const config = {}; // Provide empty config
        return implementCoroutine(config, main, functions);
    }
    else {
        // Higher-order function: createCoroutine(config)(mainTask, helper1, ...)
        const config = arg1;
        return (main, ...functions) => implementCoroutine(config, main, functions);
    }
}

/**
 * Creates a stream that runs a computation task on a worker from a Coroutine pool,
 * yielding the result once the computation completes.
 *
 * This operator is designed for offloading CPU-intensive tasks to a background
 * thread, preventing the main thread from being blocked and keeping the UI
 * responsive. It uses a `Coroutine` to manage a pool of web workers.
 * The stream will emit a single value and then complete.
 *
 * @template T The type of the result from the computation.
 * @param {Coroutine | PromiseLike<Coroutine>} task The coroutine instance managing the worker pool.
 * @param {any | PromiseLike<any>} params The data to send to the worker for computation.
 * @returns {Stream<T>} A new stream that emits the result of the computation.
 */
function compute(task, params) {
    return createStream("compute", async function* () {
        const resolvedTask = isPromiseLike(task) ? await task : task;
        const resolvedParams = isPromiseLike(params) ? await params : params;
        // Use processTask to handle worker acquisition, messaging, and releasing automatically
        const result = await resolvedTask.processTask(resolvedParams);
        yield result;
    });
}

/**
 * Creates a stream that "seizes" a single worker from the coroutine pool,
 * providing a persistent, manually-controlled communication channel.
 *
 * This operator is ideal for scenarios where you need to perform multiple,
 * sequential tasks on a specific, stateful worker. The worker remains
 * dedicated to the returned stream until the `release()` method is called
 * on the `SeizedWorker` object.
 *
 * The stream itself will only emit a single `SeizedWorker` object and then complete
 * after the worker has been released.
 *
 * @template T The type of data sent to the worker.
 * @template R The type of data returned from the worker.
 * @param {MaybePromise<Coroutine<T, R>>} task The coroutine instance managing the worker pool.
 * @param {(message: CoroutineMessage) => MaybePromise<void>} onMessage A callback function to handle messages received from the seized worker.
 * @param {(error: Error) => MaybePromise<void>} onError A callback function to handle errors originating from the seized worker.
 * @returns {Stream<SeizedWorker<T, R>>} A stream that yields a single `SeizedWorker` object.
 */
function seize(task, onMessage, onError) {
    return createStream("seize", async function* () {
        const { worker, workerId } = await task.getIdleWorker();
        let disposed = false;
        const ac = new AbortController();
        const signal = ac.signal;
        const messageHandler = async (event) => {
            if (event.data.workerId === workerId) {
                await onMessage(event.data);
            }
        };
        const errorHandler = async (event) => {
            await onError(event.error);
            if (!disposed) {
                ac.abort();
            }
        };
        const cleanup = () => {
            if (!disposed) {
                disposed = true;
                worker.removeEventListener("message", messageHandler);
                worker.removeEventListener("error", errorHandler);
                task.returnWorker(workerId);
                ac.abort();
            }
        };
        worker.addEventListener("message", messageHandler);
        worker.addEventListener("error", errorHandler);
        const seizedWorker = {
            workerId,
            sendTask: (data) => task.assignTask(workerId, data),
            release: cleanup,
        };
        try {
            yield seizedWorker;
            // Wait until release or iterator is abandoned
            await new Promise((resolve) => signal.addEventListener("abort", () => resolve(), { once: true }));
        }
        finally {
            cleanup();
        }
    });
}

/*
 * Public API Surface of actionstack
 */

/**
 * Generated bundle index. Do not edit.
 */

export { cascade, compute, coroutine, seize };
//# sourceMappingURL=epikodelabs-streamix-coroutines.mjs.map
