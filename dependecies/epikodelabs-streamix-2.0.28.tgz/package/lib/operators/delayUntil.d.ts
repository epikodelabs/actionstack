import { type Operator, type Stream } from "../abstractions";
/**
 * Creates a stream operator that delays the emission of values from the source stream
 * until a separate `notifier` stream emits at least one value.
 *
 * This operator acts as a gate. It buffers all values from the source stream
 * until the `notifier` stream emits its first value. Once the notifier emits,
 * the operator immediately flushes all buffered values and then passes through
 * all subsequent values from the source without delay.
 *
 * If the `notifier` stream completes without ever emitting a value, the buffered
 * values are DISCARDED, and the operator simply waits for the source to complete.
 *
 * @template T The type of the values in the source and output streams.
 * @param notifier The stream or promise that acts as a gatekeeper.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare function delayUntil<T = any, R = T>(notifier: Stream<R> | Promise<R>): Operator<T, T>;
