/**
 * Functional Scheduler
 *
 * Guarantees:
 * - FIFO execution (one task at a time)
 * - Supports synchronous and asynchronous tasks
 * - Errors reject the task promise but do NOT stop the queue
 * - `flush()` is microtask-stable:
 *   it resolves only after the queue stays empty
 *   across a microtask turn (prevents "flush lies")
 *
 * Performance optimizations:
 * - Parallel arrays instead of per-task objects
 * - At most one pump in flight
 * - Compact storage for flush waiters
 * - Explicit yielding mechanism for non-blocking awaits
 */
export type Scheduler = {
    /**
     * Enqueue a task for serialized execution.
     *
     * The task may return a value or a promise.
     * The returned promise resolves or rejects with the task result.
     */
    enqueue: <T>(fn: () => Promise<T> | T) => Promise<T>;
    /**
     * Resolves when the scheduler becomes idle and
     * remains idle across a microtask boundary.
     */
    flush: () => Promise<void>;
    /**
     * Awaits a promise without blocking the queue.
     *
     * Designed for use within async tasks. When awaited,
     * it allows the queue to continue processing other tasks
     * while waiting for the promise to resolve.
     *
     * @example
     * scheduler.enqueue(async () => {
     *   const data = await scheduler.await(fetch('/api'));
     *   // Queue was not blocked during fetch
     * });
     */
    await: <T>(promise: Promise<T>) => Promise<T>;
    /**
     * Waits for the specified duration without blocking the queue.
     *
     * Useful for throttling or spacing work in async flows
     * while allowing other queued tasks to continue running.
     *
     * @example
     * scheduler.enqueue(async () => {
     *   await scheduler.delay(100);
     *   // Queue kept processing during the delay
     * });
     */
    delay: (ms: number) => Promise<void>;
};
/**
 * Function createScheduler.
 */
export declare function createScheduler(): Scheduler;
/**
 * Global scheduler instance used by Streamix.
 */
export declare const scheduler: Scheduler;
