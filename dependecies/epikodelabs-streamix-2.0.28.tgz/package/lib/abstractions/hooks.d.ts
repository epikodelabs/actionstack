import { type Operator } from "./operator";
/**
 * Context object passed to `onPipeStream` runtime hook.
 *
 * Describes the stream being piped, its subscription,
 * the original source iterator, and the operator chain.
 */
export type PipeStreamHookContext = {
    /** Unique identifier of the stream instance */
    streamId: string;
    /** Optional human-readable stream name */
    streamName?: string;
    /** Unique identifier of the subscription */
    subscriptionId: string;
    /** Traced outer value id associated with an inner stream */
    parentValueId?: string;
    /** Source async iterator before operators are applied */
    source: AsyncIterator<any>;
    /** List of operators applied to the stream */
    operators: Operator<any, any>[];
};
/**
 * Result returned from `onPipeStream` runtime hook.
 *
 * Allows intercepting and replacing parts of the stream pipeline.
 */
export type PipeStreamHookResult = {
    /** Optionally replace the source iterator */
    source?: AsyncIterator<any>;
    /** Optionally replace or mutate the operator list */
    operators?: any[];
    /**
     * Optional final wrapper applied after operators
     * but before the stream is consumed.
     */
    final?: (iterator: AsyncIterator<any>) => AsyncIterator<any>;
};
/**
 * Runtime hooks for Streamix internal lifecycle events.
 *
 * These hooks are intended for tracing, debugging,
 * profiling, and developer tooling.
 */
export type StreamRuntimeHooks = {
    /**
     * Called when a stream is created.
     *
     * Useful for registering stream metadata
     * or initializing tracing structures.
     */
    onCreateStream?: (info: {
        /** Generated stream identifier */
        id: string;
        /** Optional stream name */
        name?: string;
    }) => void;
    /**
     * Called when a stream is piped.
     *
     * Allows observing or modifying the pipeline,
     * including source, operators, or final iterator.
     */
    onPipeStream?: (ctx: PipeStreamHookContext) => PipeStreamHookResult | void;
};
/**
 * Generates a unique stream identifier.
 *
 * IDs are stable within a single runtime session
 * and deterministic for tracing purposes.
 */
export declare function generateStreamId(): string;
/**
 * Generates a unique subscription identifier.
 *
 * Used to correlate subscriptions with
 * emitted values and lifecycle events.
 */
export declare function generateSubscriptionId(): string;
/**
 * Registers runtime hooks globally.
 *
 * Calling this function replaces any previously
 * registered hooks.
 */
export declare function registerRuntimeHooks(hooks: StreamRuntimeHooks): void;
/**
 * Retrieves the currently registered runtime hooks.
 *
 * Returns `null` if no hooks are registered.
 */
export declare function getRuntimeHooks(): StreamRuntimeHooks | null;
/**
 * Associates the latest traced metadata with an iterator.
 *
 * Used to connect operator execution with outer values
 * without mutating iterator results.
 */
export declare function setIteratorMeta(iterator: AsyncIterator<any>, meta: {
    valueId: string;
}, operatorIndex: number, operatorName: string): void;
/**
 * Retrieves the latest traced metadata for an iterator.
 */
export declare function getIteratorMeta(iterator: AsyncIterator<any>): {
    valueId: string;
    operatorIndex: number;
    operatorName: string;
} | undefined;
/**
 * Applies any registered `onPipeStream` patch to an iterator pipeline.
 *
 * This helper is useful for wrapping inner streams that are consumed
 * via async iterators and do not automatically trigger `onPipeStream`.
 */
export declare function applyPipeStreamHooks(ctx: PipeStreamHookContext): AsyncIterator<any>;
