import { type MaybePromise } from "../abstractions";
export interface CyclicBuffer<T = any> {
    write(value: T): Promise<void>;
    error(err: Error): Promise<void>;
    read(readerId: number): Promise<IteratorResult<T | undefined, void>>;
    peek(readerId: number): Promise<IteratorResult<T | undefined, void>>;
    complete(): Promise<void>;
    attachReader(): Promise<number>;
    detachReader(readerId: number): Promise<void>;
    completed(readerId: number): boolean;
}
export interface SubjectBuffer<T = any> extends CyclicBuffer<T> {
    readonly value: T | undefined;
}
export interface ReplayBuffer<T = any> extends CyclicBuffer<T> {
    readonly buffer: T[];
}
export declare function createSubjectBuffer<T = any>(): CyclicBuffer<T>;
export declare function createBehaviorSubjectBuffer<T = any>(initialValue?: MaybePromise<T>): SubjectBuffer<T>;
export declare function createReplayBuffer<T = any>(capacity: MaybePromise<number>): ReplayBuffer<T>;
