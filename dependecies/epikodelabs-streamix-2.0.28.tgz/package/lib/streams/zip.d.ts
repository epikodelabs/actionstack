import { type MaybePromise, type Stream } from '../abstractions';
/**
 * Combines multiple streams by emitting an array of values (a tuple),
 * only when all streams have a value ready (one-by-one, synchronized).
 *
 * It waits for the next value from all streams to form the next tuple.
 * The stream completes when any of the input streams complete.
 * Errors from any stream propagate immediately.
 *
 * @template T - A tuple type representing the combined values from the streams.
 * @param sources Streams or values (including promises) to combine.
 * @returns {Stream<T>} A new stream that emits a synchronized tuple of values.
 */
export declare function zip<T extends readonly unknown[] = any[]>(...sources: Array<Stream<T[number]> | MaybePromise<T[number]>>): Stream<T>;
