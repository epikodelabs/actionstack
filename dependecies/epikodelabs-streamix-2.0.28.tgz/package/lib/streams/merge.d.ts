import { type MaybePromise, type Stream } from "../abstractions";
/**
 * Merges multiple source streams into a single stream, emitting values as they arrive from any source.
 *
 * This is useful for combining data from multiple independent sources into a single,
 * unified stream of events. Unlike `zip`, it does not wait for a value from every
 * stream before emitting; it emits values on a first-come, first-served basis.
 *
 * The merged stream completes only after all source streams have completed. If any source stream
 * errors, the merged stream immediately errors.
 *
 * @template T The type of the values in the streams.
 * @param sources Streams or values (including promises) to merge.
 * @returns {Stream<T>} A new stream that emits values from all input streams.
 */
type MergeSource<T> = Stream<T> | MaybePromise<T>;
export declare function merge<T = any>(...sources: MergeSource<T>[]): Stream<T>;
export {};
