/**
 * STREAMIX TRACING SYSTEM
 * A comprehensive tracing system for Streamix reactive streams.
 * Instrumentation sits on runtime hooks so it can observe every stream value.
 * Features:
 * - Tracks value lifecycle from emission to delivery
 * - Supports filter / collapse / expand / error semantics
 * - Preserves type safety by wrapping primitives
 * - Provides public subscription API for observers
 */
/** Lifecycle state for a traced value */
export type ValueState = "emitted" | "transformed" | "filtered" | "collapsed" | "expanded" | "errored" | "delivered";
/** Outcome for an operator step */
export type OperatorOutcome = "transformed" | "filtered" | "expanded" | "collapsed" | "errored";
/** Operator execution metadata within a trace */
export interface OperatorStep {
    operatorIndex: number;
    operatorName: string;
    enteredAt: number;
    exitedAt?: number;
    outcome?: OperatorOutcome;
    inputValue: any;
    outputValue?: any;
    error?: Error;
}
/** Full trace record for a single value */
export interface ValueTrace {
    valueId: string;
    streamId: string;
    streamName?: string;
    subscriptionId: string;
    emittedAt: number;
    deliveredAt?: number;
    state: ValueState;
    sourceValue: any;
    finalValue?: any;
    operatorSteps: OperatorStep[];
    droppedReason?: {
        operatorIndex: number;
        operatorName: string;
        reason: "filtered" | "collapsed" | "errored";
        error?: Error;
    };
    collapsedInto?: {
        operatorIndex: number;
        operatorName: string;
        targetValueId: string;
    };
    totalDuration?: number;
    operatorDurations: Map<string, number>;
}
/** Generates a unique trace value identifier */
export declare function generateValueId(): string;
export type TracerEventHandlers = {
    delivered?: (trace: ValueTrace) => void;
    filtered?: (trace: ValueTrace) => void;
    collapsed?: (trace: ValueTrace) => void;
    dropped?: (trace: ValueTrace) => void;
};
export type TracerSubscriptionEventHandlers = TracerEventHandlers & {
    complete?: () => void;
};
export interface ValueTracerOptions {
    maxTraces?: number;
    devMode?: boolean;
    onTraceUpdate?: (trace: ValueTrace, step?: OperatorStep) => void;
}
/** Functional tracer API with state stored in a closure */
export interface ValueTracer {
    subscribe: (handlers: TracerEventHandlers) => () => void;
    observeSubscription: (subscriptionId: string, handlers: TracerSubscriptionEventHandlers) => () => void;
    completeSubscription: (subscriptionId: string) => void;
    startTrace: (valueId: string, streamId: string, streamName: string | undefined, subscriptionId: string, value: any) => ValueTrace;
    createExpandedTrace: (baseValueId: string, operatorIndex: number, operatorName: string, expandedValue: any) => string;
    enterOperator: (valueId: string, operatorIndex: number, operatorName: string, inputValue: any) => void;
    exitOperator: (valueId: string, operatorIndex: number, outputValue: any, filtered?: boolean, outcome?: OperatorOutcome) => string | null;
    collapseValue: (valueId: string, operatorIndex: number, operatorName: string, targetValueId: string, outputValue?: any) => void;
    errorInOperator: (valueId: string, operatorIndex: number, error: Error) => void;
    markDelivered: (valueId: string) => void;
    getAllTraces: () => ValueTrace[];
    getStats: () => {
        total: number;
    };
    clear: () => void;
}
/**
 * Creates a new tracer instance with isolated internal state.
 */
export declare function createValueTracer(options?: ValueTracerOptions): ValueTracer;
/**
 * Creates a lightweight tracer that only captures terminal value states.
 */
export declare function createTerminalTracer(options?: ValueTracerOptions): ValueTracer;
declare const tracedValueBrand: unique symbol;
export interface TracedWrapper<T> {
    [tracedValueBrand]: true;
    value: T;
    meta: {
        valueId: string;
        streamId: string;
        subscriptionId: string;
    };
}
export declare const wrapTracedValue: <T>(value: T, meta: TracedWrapper<T>["meta"]) => TracedWrapper<T>;
export declare const unwrapTracedValue: <T>(v: any) => T;
/**
 * Checks if a value is a traced wrapper.
 */
export declare const isTracedValue: (v: any) => v is TracedWrapper<any>;
/**
 * Extracts the valueId from a traced value, or returns undefined.
 * This is useful for operators that need to link inner streams to parent values.
 */
export declare const getValueId: (v: any) => string | undefined;
/** Returns the current global tracer, if one is registered */
export declare const getGlobalTracer: () => ValueTracer | null;
/** Enables tracing by registering a global tracer instance */
export declare function enableTracing(tracer: ValueTracer): void;
/** Disables tracing by clearing the global tracer instance */
export declare function disableTracing(): void;
export {};
