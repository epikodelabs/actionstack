#!/usr/bin/env node
import { spawnSync } from "child_process";
import fs from "fs";
import os from "os";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const platform = os.platform();
const arch = os.arch();

// -------------------- Utility --------------------
function run(cmd, cwd = __dirname, env = process.env) {
  console.log(`> ${cmd}`);
  const result = spawnSync(cmd, {
    shell: true,
    stdio: "inherit",
    cwd,
    env,
  });

  if (result.error) {
    console.error("[postinstall] Command failed:", result.error);
    process.exit(1);
  }

  if (result.status !== 0) {
    console.error(`[postinstall] Exited with code ${result.status}`);
    process.exit(result.status);
  }

  return result;
}

function getPackageVersion(pkgName) {
  const pkgPath = path.join(__dirname, "package.json");

  if (!fs.existsSync(pkgPath)) {
    throw new Error("package.json not found in postinstall directory");
  }

  const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf8"));
  const version =
    pkg.dependencies?.[pkgName] || pkg.devDependencies?.[pkgName];

  if (!version) {
    throw new Error(`Cannot find version for ${pkgName}`);
  }

  return version.replace(/^[^0-9]*/, "");
}

// -------------------- DEPENDENCIES --------------------
function installBundleDependencies() {
  const pkgPath = path.join(__dirname, "package.json");
  const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf8"));
  const bundleDeps = pkg.bundleDependencies?.length
    ? pkg.bundleDependencies
    : Object.keys(pkg.dependencies || {});

  if (!bundleDeps.length) {
    console.log("[postinstall] No bundle dependencies declared, skipping.");
    return bundleDeps;
  }

  const specs = bundleDeps.map((name) => `${name}@${getPackageVersion(name)}`);
  run(`npm install --no-save ${specs.join(" ")}`);
  return bundleDeps;
}

// -------------------- ESBUILD --------------------
function installEsbuild() {
  const version = getPackageVersion("esbuild");
  let pkg;

  switch (platform) {
    case "win32":
      pkg = `@esbuild/win32-x64@${version}`;
      break;
    case "linux":
      pkg = arch === "x64"
        ? `@esbuild/linux-x64@${version}`
        : `@esbuild/linux-arm64@${version}`;
      break;
    case "darwin":
      pkg = arch === "arm64"
        ? `@esbuild/darwin-arm64@${version}`
        : `@esbuild/darwin-x64@${version}`;
      break;
    default:
      console.warn("[postinstall] Unsupported platform for esbuild");
      return;
  }

  run(`npm install ${pkg} --no-save`);
}

// -------------------- ROLLUP --------------------
function installRollup() {
  let pkg;

  switch (platform) {
    case "win32":
      pkg = "@rollup/rollup-win32-x64-msvc";
      break;
    case "linux":
      pkg = arch === "x64"
        ? "@rollup/rollup-linux-x64-gnu"
        : "@rollup/rollup-linux-arm64-gnu";
      break;
    case "darwin":
      pkg = arch === "arm64"
        ? "@rollup/rollup-darwin-arm64"
        : "@rollup/rollup-darwin-x64";
      break;
    default:
      console.warn("[postinstall] Unsupported platform for rollup");
      return;
  }

  run(`npm install ${pkg} --no-save`);
}

// -------------------- PLAYWRIGHT --------------------
function installPlaywright() {
  const useBundled = process.env.PLAYWRIGHT_BROWSERS_PATH === "0";

  console.log(
    `[postinstall] Installing Playwright browsers (${useBundled ? "bundled" : "global"} mode)`
  );

  // Install browsers
  if (useBundled) {
    run("PLAYWRIGHT_BROWSERS_PATH=0 npx playwright install");
  } else {
    run("npx playwright install");
  }
}

// -------------------- MAIN --------------------
try {
  const bundleDeps = installBundleDependencies();

  if (bundleDeps.includes("esbuild")) {
    installEsbuild();
  }

  if (bundleDeps.includes("rollup")) {
    installRollup();
  }

  if (bundleDeps.includes("playwright")) {
    installPlaywright();
  }

  console.log("[postinstall] Completed successfully.");
} catch (e) {
  console.error("[postinstall] ERROR:", e);
  process.exit(1);
}
