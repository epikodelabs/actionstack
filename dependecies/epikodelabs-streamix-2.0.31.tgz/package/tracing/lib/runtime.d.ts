/**
 * Registers runtime hooks that integrate tracing with Streamix's pipe execution.
 *
 * This should be called once when the tracing module is imported. The hooks will
 * automatically wrap values and operator chains when a global tracer is enabled.
 */
export declare function installTracingHooks(): void;
