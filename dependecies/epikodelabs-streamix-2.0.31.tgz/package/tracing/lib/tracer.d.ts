import type { ValueTrace, ValueTracer } from "./core";
export type TracerEventHandlers = {
    /** Invoked when a new value is emitted from a stream (before any operators). */
    emitted?: (trace: ValueTrace) => void;
    /** Invoked when a trace is marked as delivered. */
    delivered?: (trace: ValueTrace) => void;
    /** Invoked when a trace becomes terminal due to filtering. */
    filtered?: (trace: ValueTrace) => void;
    /** Invoked when a trace becomes terminal due to collapsing. */
    collapsed?: (trace: ValueTrace) => void;
    /** Invoked when a trace becomes terminal for reasons other than filtering/collapsing. */
    dropped?: (trace: ValueTrace) => void;
};
export type TracerSubscriptionEventHandlers = TracerEventHandlers & {
    /** Invoked when a subscription is completed (via `final` iterator completion/return/throw). */
    complete?: () => void;
};
/**
 * Extended tracer interface that includes subscription and utility methods.
 */
export interface ExtendedValueTracer extends ValueTracer {
    /** Subscribes to value-level events across all subscriptions. Returns an unsubscribe function. */
    subscribe: (handlers: TracerEventHandlers) => () => void;
    /** Subscribes to value-level events for a specific subscription id. Returns an unsubscribe function. */
    observeSubscription: (subId: string, handlers: TracerSubscriptionEventHandlers) => () => void;
    /** Returns the current in-memory traces (subject to LRU eviction). */
    getAllTraces: () => ValueTrace[];
    /** Returns basic tracer stats. */
    getStats: () => {
        total: number;
    };
    /** Clears all in-memory traces and subscription observers. */
    clear: () => void;
}
export declare const createTraceStore: <T>(maxTraces: number) => {
    traces: Map<string, T>;
    retainTrace: (valueId: string, trace: T) => void;
    clearTraces: () => void;
};
export declare const createTracerSubscriptions: () => {
    subscribe: (handlers: TracerEventHandlers) => () => void;
    observeSubscription: (subId: string, handlers: TracerSubscriptionEventHandlers) => () => void;
    completeSubscription: (subId: string) => void;
    ensureActive: (subId: string) => void;
    isCompleted: (subId: string) => boolean;
    notify: (event: keyof TracerEventHandlers, trace: ValueTrace) => void;
    clearSubscriptions: () => void;
};
import type { TerminalReason, ValueState } from "./core";
/**
 * Generates a default operator name from its index.
 */
export declare const defaultOpName: (opIdx: number) => string;
/**
 * Unwraps traced values and primitives for export.
 */
export declare const unwrapForExport: (value: any) => any;
/**
 * Converts trace status and terminal reason into a ValueState.
 */
export declare const toValueState: (params: {
    status: "active" | "delivered" | "terminal";
    terminalReason?: TerminalReason;
    parentTraceId?: string;
    hasOperatorSteps?: boolean;
    hasFinalValue?: boolean;
    expandedFrom?: any;
    expandedInto?: any;
}) => ValueState;
