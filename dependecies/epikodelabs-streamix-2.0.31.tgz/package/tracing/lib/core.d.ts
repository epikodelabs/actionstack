/**
 * Streamix tracing core abstractions.
 *
 * This module defines the tracer contract, trace model, and helper utilities.
 * It is framework/runtime-agnostic and does not wire into Streamix execution.
 */
/**
 * High-level lifecycle state of a traced value.
 */
export type ValueState = "emitted" | "transformed" | "filtered" | "collapsed" | "expanded" | "errored" | "delivered" | "dropped";
/**
 * The outcome recorded for a single operator pass over an input value.
 */
export type OperatorOutcome = "transformed" | "filtered" | "expanded" | "collapsed" | "errored";
/** One operator invocation within a value's lifecycle. */
export interface OperatorStep {
    operatorIndex: number;
    operatorName: string;
    enteredAt: number;
    exitedAt?: number;
    outcome?: OperatorOutcome;
    inputValue: any;
    outputValue?: any;
    error?: Error;
}
/**
 * Why a value's trace ended without being delivered downstream.
 */
export type TerminalReason = "filtered" | "collapsed" | "errored" | "late";
/**
 * Public snapshot of a value's trace at a moment in time.
 */
export interface ValueTrace {
    valueId: string;
    parentTraceId?: string;
    streamId: string;
    streamName?: string;
    subscriptionId: string;
    emittedAt: number;
    deliveredAt?: number;
    state: ValueState;
    sourceValue: any;
    finalValue?: any;
    operatorSteps: OperatorStep[];
    droppedReason?: {
        operatorIndex: number;
        operatorName: string;
        reason: TerminalReason;
        error?: Error;
    };
    collapsedInto?: {
        operatorIndex: number;
        operatorName: string;
        targetValueId: string;
    };
    expandedFrom?: {
        operatorIndex: number;
        operatorName: string;
        baseValueId: string;
    };
    totalDuration?: number;
    operatorDurations: Map<string, number>;
}
/**
 * Normalized events emitted by the tracing runtime for tracer implementations.
 */
export type TraceEvent = {
    type: "emitted";
    valueId: string;
    streamId: string;
    streamName?: string;
    subscriptionId: string;
    timestamp: number;
    sourceValue: any;
    parentTraceId?: string;
} | {
    type: "transformed";
    valueId: string;
    operatorIndex: number;
    operatorName: string;
    inputValue: any;
    outputValue: any;
    timestamp: number;
    duration?: number;
} | {
    type: "expanded";
    valueId: string;
    baseValueId: string;
    operatorIndex: number;
    operatorName: string;
    streamId: string;
    streamName?: string;
    subscriptionId: string;
    timestamp: number;
    sourceValue: any;
    expandedValue: any;
} | {
    type: "collapsed";
    valueId: string;
    operatorIndex: number;
    operatorName: string;
    targetValueId: string;
    timestamp: number;
} | {
    type: "filtered";
    valueId: string;
    operatorIndex: number;
    operatorName: string;
    timestamp: number;
    sourceValue: any;
    filteredValue: any;
} | {
    type: "errored";
    valueId: string;
    operatorIndex: number;
    operatorName: string;
    timestamp: number;
    error: Error;
} | {
    type: "delivered";
    valueId: string;
    timestamp: number;
    deliveredValue: any;
} | {
    type: "dropped";
    valueId: string;
    timestamp: number;
    reason: TerminalReason;
};
/**
 * Tracer interface used by the runtime hooks to record value lifecycles.
 *
 * Implementations can choose to track full operator steps, minimal terminal states,
 * or anything in between.
 */
export interface ValueTracer {
    /** Begins a new trace record for a value id. */
    startTrace: (vId: string, sId: string, sName: string | undefined, subId: string, val: any) => ValueTrace;
    /** Creates a new trace id that is treated as expanded from `baseId`. */
    createExpandedTrace: (baseId: string, opIdx: number, opName: string, val: any) => string;
    /** Records entering an operator (tracer can choose to ignore if not tracking steps). */
    enterOperator: (vId: string, opIdx: number, opName: string, val: any) => void;
    /**
     * Records an operator exit and (optionally) marks the trace terminal when filtered/errored.
     * Returns the value id on success, or `null` when no update was applied.
     */
    exitOperator: (vId: string, opIdx: number, val: any, filtered?: boolean, outcome?: OperatorOutcome) => string | null;
    /** Marks a value as collapsed into another value id and terminalizes it as `collapsed`. */
    collapseValue: (vId: string, opIdx: number, opName: string, targetId: string, val?: any) => void;
    /** Marks a value as errored in an operator and terminalizes it as `errored`. */
    errorInOperator: (vId: string, opIdx: number, error: Error) => void;
    /** Marks a value trace as delivered (unless already terminal). */
    markDelivered: (vId: string) => void;
    /** Marks the subscription as completed and notifies any per-subscription observers. */
    completeSubscription: (subId: string) => void;
}
declare const tracedValueBrand: unique symbol;
export interface TracedWrapper<T> {
    [tracedValueBrand]: true;
    value: T;
    meta: {
        valueId: string;
        streamId: string;
        subscriptionId: string;
    };
}
/** Wraps a value with tracing metadata for internal runtime propagation. */
export declare const wrapTracedValue: <T>(value: T, meta: TracedWrapper<T>["meta"]) => TracedWrapper<T>;
/** Unwraps a traced wrapper back to the raw value (or returns the input if it's not traced). */
export declare const unwrapTracedValue: <T>(v: any) => T;
/** Type guard for `TracedWrapper`. */
export declare const isTracedValue: (v: any) => v is TracedWrapper<any>;
/** Extracts the `valueId` from a traced wrapper (if present). */
export declare const getValueId: (v: any) => string | undefined;
/** Returns the currently enabled global tracer, if any. */
export declare const getGlobalTracer: () => ValueTracer | null;
/** Installs the tracer into `globalThis` so the Streamix runtime hooks can record traces. */
export declare function enableTracing(t: ValueTracer): void;
/** Disables tracing by clearing the global tracer reference. */
export declare function disableTracing(): void;
/** Generates a unique value id for the current JS realm (stored on `globalThis`). */
export declare const generateValueId: () => string;
export {};
