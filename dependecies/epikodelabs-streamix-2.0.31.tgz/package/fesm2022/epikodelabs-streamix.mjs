const ITERATOR_EMISSION_STAMP = new WeakMap();
let lastEmissionStamp = 0;
let currentEmissionStamp = null;
const hasPerfNow = typeof globalThis !== "undefined" &&
    typeof globalThis.performance !== "undefined" &&
    typeof globalThis.performance.now === "function";
const perfNow = hasPerfNow ? globalThis.performance.now.bind(globalThis.performance) : null;
const getMicros = perfNow
    ? () => Math.floor(perfNow() * 1000)
    : () => Date.now() * 1000;
/**
 * Generate and return the next unique emission stamp (monotonically increasing number).
 * Used to order emissions in streams and subjects.
 * @returns {number} The next emission stamp.
 */
function nextEmissionStamp() {
    // Use a monotonic performance counter when available for higher-resolution
    // and to avoid clock skew issues with Date.now().
    const micros = getMicros();
    if (micros > lastEmissionStamp) {
        lastEmissionStamp = micros;
    }
    else {
        lastEmissionStamp += 1;
    }
    return lastEmissionStamp;
}
/**
 * Get the current emission stamp from the context, if any.
 * Returns null if not inside an emission context.
 * @returns {number | null} The current emission stamp or null.
 */
function getCurrentEmissionStamp() {
    return currentEmissionStamp;
}
/**
 * Run a function within a specific emission stamp context.
 * Temporarily sets the emission stamp for the duration of the function.
 * @template T
 * @param {number} stamp - The emission stamp to set.
 * @param {() => T} fn - The function to execute.
 * @returns {T} The result of the function.
 */
function withEmissionStamp(stamp, fn) {
    const prev = currentEmissionStamp;
    currentEmissionStamp = stamp;
    try {
        return fn();
    }
    finally {
        currentEmissionStamp = prev;
    }
}
/**
 * Set the emission stamp on an async iterator for tracking emission order.
 * @param {AsyncIterator<any>} iterator - The iterator to tag.
 * @param {number} stamp - The emission stamp to set.
 */
function setIteratorEmissionStamp(iterator, stamp) {
    ITERATOR_EMISSION_STAMP.set(iterator, stamp);
}
/**
 * Get the emission stamp from an async iterator, if present.
 * @param {AsyncIterator<any>} iterator - The iterator to inspect.
 * @returns {number | undefined} The emission stamp, if set.
 */
function getIteratorEmissionStamp(iterator) {
    return ITERATOR_EMISSION_STAMP.get(iterator);
}

/* ============================================================================
 * Global hook registry
 * ========================================================================== */
const HOOKS_KEY = "__STREAMIX_RUNTIME_HOOKS__";
/**
 * Registers runtime hooks used by instrumentation and devtools.
 *
 * Replaces any previously-registered hooks for the current global context.
 */
function registerRuntimeHooks(hooks) {
    globalThis[HOOKS_KEY] = hooks;
}
/**
 * Returns the currently-registered runtime hooks, if any.
 *
 * @returns {StreamRuntimeHooks | null} The registered hooks or null.
 */
function getRuntimeHooks() {
    return (globalThis[HOOKS_KEY] ?? null);
}
const ITERATOR_META = new WeakMap();
const VALUE_META = new WeakMap();
/** Symbol key used when wrapping primitive values with metadata. */
const VALUE_META_SYMBOL = Symbol("__streamix_value_meta__");
/**
 * Attach iterator-level metadata used by tracing and until-style operators.
 */
function setIteratorMeta(iterator, meta, operatorIndex, operatorName) {
    const entry = {
        valueId: meta.valueId,
        operatorIndex,
        operatorName,
    };
    if (meta.kind !== undefined)
        entry.kind = meta.kind;
    if (meta.inputValueIds !== undefined)
        entry.inputValueIds = meta.inputValueIds;
    ITERATOR_META.set(iterator, entry);
}
/**
 * Retrieve attached iterator metadata, if present.
 */
function getIteratorMeta(iterator) {
    return ITERATOR_META.get(iterator);
}
/**
 * Attach metadata to a value. Object values receive metadata directly; primitive
 * values are wrapped in a small object so their metadata can be tracked.
 */
function setValueMeta(value, meta, operatorIndex, operatorName) {
    const entry = {
        valueId: meta.valueId,
        operatorIndex,
        operatorName,
        // only include optional fields when provided so equality checks
        // don't see explicit `undefined` properties
        ...(meta.kind !== undefined ? { kind: meta.kind } : {}),
        ...(meta.inputValueIds !== undefined ? { inputValueIds: meta.inputValueIds } : {}),
    };
    if (value !== null && typeof value === "object") {
        VALUE_META.set(value, entry);
        return value;
    }
    if (value !== null && value !== undefined) {
        const wrapper = { [VALUE_META_SYMBOL]: value };
        VALUE_META.set(wrapper, entry);
        return wrapper;
    }
    return value;
}
/**
 * Return metadata previously attached to a value, or `undefined` if none.
 */
function getValueMeta(value) {
    if (value !== null && typeof value === "object") {
        return VALUE_META.get(value);
    }
    return undefined;
}
/**
 * Returns true when a value is a wrapper created to hold metadata for a
 * primitive value.
 */
function isWrappedPrimitive(value) {
    return (value !== null &&
        typeof value === "object" &&
        VALUE_META_SYMBOL in value);
}
/**
 * Unwrap a primitive value previously wrapped by `setValueMeta`.
 */
function unwrapPrimitive(value) {
    return isWrappedPrimitive(value) ? value[VALUE_META_SYMBOL] : value;
}
/* ============================================================================
 * Pipe hook application
 * ========================================================================== */
/**
 * Apply any configured `onPipeStream` hooks and then materialize the
 * operator chain into a final `AsyncIterator`.
 */
function applyPipeStreamHooks(ctx) {
    const hooks = getRuntimeHooks();
    let iterator = ctx.source;
    let operators = ctx.operators;
    let finalWrap;
    if (hooks?.onPipeStream) {
        const patch = hooks.onPipeStream(ctx);
        if (patch && typeof patch === 'object') {
            if ('source' in patch && patch.source)
                iterator = patch.source;
            if ('operators' in patch && patch.operators)
                operators = patch.operators;
            if ('final' in patch && patch.final)
                finalWrap = patch.final;
        }
    }
    for (const op of operators) {
        iterator = op.apply(iterator);
    }
    if (finalWrap) {
        iterator = finalWrap(iterator);
    }
    if (typeof iterator[Symbol.asyncIterator] !== "function") {
        iterator[Symbol.asyncIterator] = () => iterator;
    }
    return iterator;
}
/**
 * Create a fresh `UntilGate`. Each notifier must use its own gate instance.
 */
function createUntilGate() {
    return {
        openStamp: null,
        closeStamp: null,
        error: null,
    };
}
/* ============================================================================
 * Stream & subscription identity
 * ========================================================================== */
/**
 * Monotonically increasing counters for ID generation.
 *
 * These counters are intentionally process-local and reset on reload.
 * They are NOT persisted and MUST NOT be reused across runtimes.
 */
let streamIdCounter = 0;
let subscriptionIdCounter = 0;
/**
 * Generate a short, unique stream id for runtime tracing.
 */
function generateStreamId() {
    return `str_${++streamIdCounter}`;
}
/**
 * Generate a short, unique subscription id used to correlate subscriptions.
 */
function generateSubscriptionId() {
    return `sub_${++subscriptionIdCounter}`;
}

/**
 * Type guard that checks whether a value behaves like a promise.
 *
 * We avoid relying on `instanceof Promise` so that promise-like values from
 * different realms or custom thenables are still treated correctly.
 */
const isPromiseLike = (value) => !!value && typeof value.then === 'function';
/**
 * A constant representing a completed stream result.
 *
 * Always `{ done: true, value: undefined }`.
 * Used to signal the end of a stream.
 */
const DONE = Object.freeze({ done: true, value: undefined });
/**
 * Factory function to create a normal stream result.
 *
 * @template R The type of the emitted value.
 * @param value The value to emit downstream.
 * @returns A `IteratorResult<R>` object with `{ done: false, value }`.
 */
const NEXT = (value) => ({ done: false, value });
/**
 * Creates a reusable stream operator.
 *
 * This factory function simplifies the creation of operators by bundling a name and a
 * transformation function into a single `Operator` object.
 *
 * @template T The type of the value the operator will consume.
 * @template R The type of the value the operator will produce.
 * @param name The name of the operator, for identification and debugging.
 * @param transformFn The transformation function that defines the operator's logic.
 * @returns A new `Operator` object with the specified name and transformation function.
 */
function createOperator(name, transformFn) {
    return {
        name,
        type: 'operator',
        apply: transformFn
    };
}
;

const performMicrotask = typeof queueMicrotask === "function"
    ? queueMicrotask
    : (fn) => void Promise.resolve().then(fn);
function enqueueMicrotask(fn) {
    performMicrotask(fn);
}
function runInMicrotask(fn) {
    return new Promise((resolve, reject) => {
        performMicrotask(() => {
            Promise.resolve()
                .then(fn)
                .then(resolve, reject);
        });
    });
}

/**
 * Create a strict receiver from a callback or receiver object.
 *
 * @template T The type of values received.
 * @param {((value: T) => MaybePromise) | Receiver<T>} [callbackOrReceiver] - Callback or receiver object.
 * @returns {StrictReceiver<T>} A strict receiver instance.
 */
function createReceiver(callbackOrReceiver) {
    let _completed = false;
    let _completedScheduled = false;
    let _active = 0;
    const _idleResolvers = [];
    // Normalize input to a receiver object
    const target = (typeof callbackOrReceiver === 'function'
        ? { next: callbackOrReceiver }
        : callbackOrReceiver || {});
    const wantsRaw = target.__wantsRawValues === true;
    // Helper to safely execute a user-provided handler within the scheduler
    const runAction = (handler, ...args) => {
        if (!handler || _completed || _completedScheduled)
            return Promise.resolve();
        const action = async () => {
            // Re-check completed status inside the scheduled task
            if (_completed)
                return;
            _active++;
            try {
                const result = handler.apply(target, args);
                if (isPromiseLike(result))
                    await result;
            }
            catch (err) {
                // If 'next' fails, trigger error flow but don't await it to avoid deadlocks
                if (handler === target.next) {
                    void wrapped.error(err);
                }
                else {
                    console.error("Unhandled error in Receiver:", err);
                }
            }
            finally {
                _active--;
                if (_active === 0) {
                    const resolvers = _idleResolvers.splice(0);
                    for (const r of resolvers)
                        r();
                }
            }
        };
        // If we're already in an emission context (i.e. called from a Subject/Stream
        // delivery loop), execute inline to preserve sync semantics.
        const stamp = getCurrentEmissionStamp();
        if (stamp !== null) {
            return action();
        }
        return new Promise((resolve, reject) => {
            enqueueMicrotask(() => void action().then(resolve, reject));
        });
    };
    const wrapped = {
        next: (value) => {
            if (_completed)
                return Promise.resolve();
            const payload = wantsRaw ? value : unwrapPrimitive(value);
            return runAction(target.next, payload);
        },
        error: (err) => {
            if (_completed || _completedScheduled)
                return Promise.resolve();
            _completedScheduled = true;
            const normalizedError = err instanceof Error ? err : new Error(String(err));
            const action = async () => {
                if (_completed)
                    return;
                // Wait until any active handlers finish before delivering terminal
                if (_active > 0) {
                    await new Promise((resolve) => _idleResolvers.push(resolve));
                }
                try {
                    const result = target.error?.(normalizedError);
                    if (isPromiseLike(result))
                        await result;
                }
                catch (err) {
                    try {
                        console.error('Unhandled error in error handler:', err);
                    }
                    catch (_) {
                        /* ignore logging failures */
                    }
                }
                finally {
                    _completed = true;
                }
            };
            const stamp = getCurrentEmissionStamp();
            if (stamp !== null) {
                return action();
            }
            return new Promise((resolve, reject) => {
                enqueueMicrotask(() => void action().then(resolve, reject));
            });
        },
        complete: () => {
            if (_completed || _completedScheduled)
                return Promise.resolve();
            _completedScheduled = true;
            const action = async () => {
                if (_completed)
                    return;
                // Wait until any active handlers finish before delivering terminal
                if (_active > 0) {
                    await new Promise((resolve) => _idleResolvers.push(resolve));
                }
                _completed = true;
                try {
                    const result = target.complete?.();
                    if (isPromiseLike(result))
                        await result;
                }
                catch (err) {
                    try {
                        console.error('Unhandled error in complete handler:', err);
                    }
                    catch (_) {
                        /* ignore logging failures */
                    }
                }
            };
            const stamp = getCurrentEmissionStamp();
            if (stamp !== null) {
                return action();
            }
            return new Promise((resolve, reject) => {
                enqueueMicrotask(() => void action().then(resolve, reject));
            });
        },
        get completed() {
            return _completed;
        },
    };
    return wrapped;
}

/**
 * Converts a `Stream` into an async generator, yielding each emitted value.
 * Distinguishes between undefined values and stream completion.
 *
 * This function creates a bridge between the push-based nature of a stream and
 * the pull-based nature of an async generator. It relies on the stream's
 * async-iterable interface (backed by the same multicast machinery used for
 * subscriptions), so `for await...of eachValueFrom(stream)` is equivalent to
 * `for await...of stream`.
 *
 * The generator handles all stream events:
 * - Each yielded value corresponds to a `next` event, including undefined values.
 * - The generator terminates when the stream `complete`s.
 * - It throws an error if the stream emits an `error` event.
 *
 * It correctly handles situations where the stream completes or errors out
 * before any values are yielded, and ensures the subscription is
 * always cleaned up.
 *
 * @template T The type of the values emitted by the stream.
 * @param stream The source stream to convert.
 * @returns An async generator that yields the values from the stream.
 */
function eachValueFrom(stream) {
    const iterator = stream[Symbol.asyncIterator]();
    // Some iterators only satisfy AsyncIterator; ensure AsyncGenerator shape by
    // making `[Symbol.asyncIterator]` return itself.
    if (typeof iterator[Symbol.asyncIterator] !== "function") {
        iterator[Symbol.asyncIterator] = () => iterator;
    }
    return iterator;
}

/**
 * Returns a promise that resolves with the first emitted value from a `Stream`.
 *
 * This utility function bridges the gap between the stream's push-based system and
 * JavaScript's standard promise-based asynchronous programming model. It's designed
 * for scenarios where you only care about the very first value a stream produces,
 * treating the stream like a single-value asynchronous source.
 *
 * The function's behavior is as follows:
 * - If the stream emits a value, the promise resolves with that value.
 * - If the stream emits an error, the promise rejects with that error.
 * - If the stream completes without ever emitting a value, the promise rejects with an `Error`.
 *
 * Once the promise is either resolved or rejected, the subscription to the stream is
 * automatically terminated, preventing any further resource consumption. This makes it
 * an efficient way to "query" a stream for a single result.
 *
 * @template T The type of the value that the promise will resolve with.
 * @param stream The source stream to listen to.
 * @returns A promise that resolves with the first value from the stream or rejects on error or completion without a value.
 */
function firstValueFrom(stream) {
    const iterator = stream[Symbol.asyncIterator]();
    return (async () => {
        try {
            const first = await iterator.next();
            if (first.done) {
                throw new Error("Stream completed without emitting a value");
            }
            return first.value;
        }
        finally {
            try {
                await iterator.return?.();
            }
            catch {
            }
        }
    })();
}

/**
 * Converts various value types into a Stream.
 *
 * This function normalizes different input types into a consistent Stream interface:
 * - Streams are passed through as-is
 * - Promises are awaited and their resolved values are processed
 * - Arrays have each element emitted individually
 * - Single values are emitted as-is
 *
 * @template R The type of values emitted by the resulting stream.
 * @param value The input value to convert. Can be:
 *   - a {@link Stream<R>}
 *   - a `Promise<R>` (single value)
 *   - a `Promise<Array<R>>` (multiple values from array)
 *   - a plain value `R`
 *   - an array `Array<R>`
 * @returns A {@link Stream<R>} that emits the normalized values.
 */
function fromAny(value) {
    // Step 1: If it's already a stream, return as-is
    if (isStreamLike(value)) {
        return value;
    }
    // Step 2: Handle promises, arrays, and single values in one generator
    return createStream("fromAny", async function* () {
        // Await promise if needed
        const resolved = isPromiseLike(value) ? await value : value;
        // Handle arrays - emit each element
        if (Array.isArray(resolved)) {
            for (const item of resolved) {
                yield item;
            }
        }
        else {
            // Single value
            yield resolved;
        }
    });
}

/**
 * Returns a promise that resolves with the last emitted value from a `Stream`.
 *
 * This function subscribes to the provided stream and buffers the last value
 * received. The returned promise is only settled once the stream completes or
 * errors.
 *
 * - **Successful resolution:** The promise resolves with the last value emitted
 * by the stream, but only after the stream has completed.
 * - **Rejection on error:** If the stream emits an error, the promise is rejected with that error.
 * - **Rejection on no value:** If the stream completes without emitting any values,
 * the promise is rejected with a specific error message.
 *
 * The subscription is automatically and immediately unsubscribed upon completion or
 * on error, ensuring proper resource cleanup.
 *
 * @template T The type of the value expected from the stream.
 * @param stream The source stream to listen to for the final value.
 * @returns A promise that resolves with the last value from the stream or rejects on completion without a value or on error.
 */
function lastValueFrom(stream) {
    const iterator = stream[Symbol.asyncIterator]();
    return (async () => {
        let hasValue = false;
        let lastValue;
        try {
            while (true) {
                const next = await iterator.next();
                if (next.done)
                    break;
                hasValue = true;
                lastValue = next.value;
            }
            if (!hasValue) {
                throw new Error("Stream completed without emitting a value");
            }
            return lastValue;
        }
        finally {
            try {
                await iterator.return?.();
            }
            catch {
            }
        }
    })();
}

/**
 * Create the commit function which drains the subject `queue` and delivers
 * items to eligible receivers, honoring backpressure, delivery ordering,
 * and terminal semantics.
 *
 * @template T
 * @param opts - options object (see signature)
 * @returns {() => void} a function to attempt committing queued items
 */
function createTryCommit(opts) {
    const { receivers, ready, queue, setLatestValue, scheduleCommit } = opts;
    let isCommitting = false;
    let pendingCommit = false;
    const tryCommit = () => {
        if (isCommitting) {
            pendingCommit = true;
            return;
        }
        isCommitting = true;
        try {
            while (queue.length > 0) {
                if (receivers.size === 0) {
                    const ctx = getCurrentEmissionStamp();
                    if (ctx !== null && ctx !== undefined)
                        break;
                }
                const item = queue[0];
                const eligible = Array.from(receivers).filter((r) => {
                    const s = r.subscribedAt;
                    const subscribedAt = typeof s === "number" ? s : Number.NEGATIVE_INFINITY;
                    return subscribedAt <= item.stamp;
                });
                if (item.kind === "next") {
                    // Backpressure: if there are eligible receivers and any is not ready,
                    // pause committing to preserve ordering and avoid drops.
                    if (eligible.length > 0 && eligible.some((r) => !ready.has(r))) {
                        break;
                    }
                    queue.shift();
                    let pendingAsync = 0;
                    withEmissionStamp(item.stamp, () => {
                        setLatestValue(item.value);
                        for (const r of eligible) {
                            const result = r.next(item.value);
                            if (isPromiseLike(result)) {
                                pendingAsync++;
                                ready.delete(r);
                                result.finally(() => {
                                    if (!r.completed && receivers.has(r)) {
                                        ready.add(r);
                                        if (typeof scheduleCommit === "function") {
                                            scheduleCommit();
                                        }
                                        else {
                                            tryCommit();
                                        }
                                    }
                                });
                            }
                        }
                    });
                    if (pendingAsync > 0)
                        break;
                }
                else {
                    queue.shift();
                    withEmissionStamp(item.stamp, () => {
                        for (const r of eligible) {
                            if (item.kind === "complete")
                                r.complete();
                            else {
                                r.error(item.error);
                            }
                        }
                    });
                    receivers.clear();
                    ready.clear();
                    return;
                }
            }
        }
        finally {
            isCommitting = false;
            if (pendingCommit) {
                pendingCommit = false;
                tryCommit();
            }
        }
    };
    return tryCommit;
}
function createRegister(opts) {
    const { receivers, ready, terminalRef, createSubscription, tryCommit } = opts;
    return function register(receiver, paused = false) {
        const r = receiver;
        const item = terminalRef.current;
        if (item) {
            if (item.kind === "complete") {
                withEmissionStamp(item.stamp, () => r.complete());
            }
            else if (item.kind === "error") {
                const err = item.error;
                withEmissionStamp(item.stamp, () => {
                    r.error(err);
                });
            }
            return createSubscription();
        }
        // Record registration stamp so this receiver does not receive
        // previously queued emissions.
        // IMPORTANT: always use a fresh stamp (even inside an emission context)
        // so a subscription created while an emission is in-flight does not
        // receive that same emission.
        r.subscribedAt = nextEmissionStamp();
        receivers.add(r);
        if (!paused)
            ready.add(r);
        tryCommit();
        // Schedule receiver completion via the subscription's onUnsubscribe, but
        // remove the receiver from the delivery sets synchronously so that values
        // pushed after `unsubscribe()` are not delivered.
        const baseSub = createSubscription(() => {
            const stamp = getCurrentEmissionStamp() ?? nextEmissionStamp();
            withEmissionStamp(stamp, () => r.complete());
            tryCommit();
        });
        const baseUnsubscribe = baseSub.unsubscribe.bind(baseSub);
        let removed = false;
        baseSub.unsubscribe = () => {
            if (!removed) {
                removed = true;
                receivers.delete(r);
                ready.delete(r);
            }
            return baseUnsubscribe();
        };
        return baseSub;
    };
}
function createAsyncIterator(opts) {
    const { register, lazy = false } = opts;
    // IMPORTANT: return a *fresh* iterator per call. The old implementation
    // registered a receiver eagerly during subject creation, which could
    // deadlock subjects by introducing backpressure even when nobody is iterating.
    return () => {
        let pullResolve = null;
        let pullReject = null;
        const queue = [];
        const backpressureQueue = [];
        let pendingError = null;
        let completed = false;
        let sub = null;
        let iteratorReceiver;
        const ensureSubscribed = () => {
            if (completed)
                return;
            if (!sub)
                sub = register(iteratorReceiver);
        };
        const iterator = {
            next() {
                ensureSubscribed();
                if (pendingError) {
                    const { err, stamp } = pendingError;
                    pendingError = null;
                    setIteratorEmissionStamp(iterator, stamp);
                    return Promise.reject(err);
                }
                if (queue.length > 0) {
                    const { result, stamp } = queue.shift();
                    setIteratorEmissionStamp(iterator, stamp);
                    // Resolves the backpressure promise returned by receiver.next().
                    backpressureQueue.shift()?.();
                    if (result.done) {
                        const unsubscribePromise = sub?.unsubscribe();
                        sub = null;
                        if (unsubscribePromise && isPromiseLike(unsubscribePromise)) {
                            unsubscribePromise.catch(() => { });
                        }
                    }
                    return Promise.resolve(result);
                }
                if (completed) {
                    const unsubscribePromise = sub?.unsubscribe();
                    sub = null;
                    // Ensure teardown has a chance to run, but don't block iteration.
                    if (unsubscribePromise && isPromiseLike(unsubscribePromise)) {
                        unsubscribePromise.catch(() => { });
                    }
                    return Promise.resolve(DONE);
                }
                return new Promise((res, rej) => {
                    pullResolve = res;
                    pullReject = rej;
                });
            },
            async return() {
                completed = true;
                const unsubscribePromise = sub?.unsubscribe();
                sub = null;
                if (pullResolve) {
                    const r = pullResolve;
                    pullResolve = pullReject = null;
                    r(DONE);
                }
                // Release any pending producer backpressure.
                for (const resolve of backpressureQueue)
                    resolve();
                backpressureQueue.length = 0;
                try {
                    await unsubscribePromise;
                }
                catch {
                }
                return Promise.resolve(DONE);
            },
            async throw(err) {
                completed = true;
                const unsubscribePromise = sub?.unsubscribe();
                sub = null;
                if (pullReject) {
                    const r = pullReject;
                    pullResolve = pullReject = null;
                    r(err);
                }
                for (const resolve of backpressureQueue)
                    resolve();
                backpressureQueue.length = 0;
                try {
                    await unsubscribePromise;
                }
                catch {
                }
                return Promise.reject(err);
            }
        };
        iterator.__hasBufferedValues = () => queue.length > 0 || pendingError != null || completed;
        iterator.__tryNext = () => {
            ensureSubscribed();
            if (pendingError) {
                const { err, stamp } = pendingError;
                pendingError = null;
                setIteratorEmissionStamp(iterator, stamp);
                throw err;
            }
            if (queue.length > 0) {
                const { result, stamp } = queue.shift();
                setIteratorEmissionStamp(iterator, stamp);
                backpressureQueue.shift()?.();
                if (result.done) {
                    const unsubscribePromise = sub?.unsubscribe();
                    sub = null;
                    if (unsubscribePromise && isPromiseLike(unsubscribePromise)) {
                        unsubscribePromise.catch(() => { });
                    }
                }
                return result;
            }
            if (completed) {
                const unsubscribePromise = sub?.unsubscribe();
                sub = null;
                if (unsubscribePromise && isPromiseLike(unsubscribePromise)) {
                    unsubscribePromise.catch(() => { });
                }
                return DONE;
            }
            return null;
        };
        const _iteratorReceiver = {
            next(value) {
                if (completed)
                    return;
                const stamp = getCurrentEmissionStamp() ?? nextEmissionStamp();
                const result = { done: false, value };
                if (pullResolve) {
                    const r = pullResolve;
                    pullResolve = pullReject = null;
                    setIteratorEmissionStamp(iterator, stamp);
                    r(result);
                    iterator.__onPush?.();
                    return;
                }
                queue.push({ result, stamp });
                // Give consumers a chance to drain synchronously from the buffer.
                if (typeof iterator.__onPush === "function") {
                    iterator.__onPush();
                    return;
                }
                // Producer backpressure: block the producer until the consumer pulls.
                return new Promise((resolve) => backpressureQueue.push(resolve));
            },
            complete() {
                if (completed)
                    return;
                completed = true;
                const stamp = getCurrentEmissionStamp() ?? nextEmissionStamp();
                if (pullResolve) {
                    const r = pullResolve;
                    pullResolve = pullReject = null;
                    setIteratorEmissionStamp(iterator, stamp);
                    r(DONE);
                    return;
                }
                queue.push({ result: DONE, stamp });
                iterator.__onPush?.();
            },
            error(err) {
                if (completed)
                    return;
                completed = true;
                const stamp = getCurrentEmissionStamp() ?? nextEmissionStamp();
                if (pullReject) {
                    const r = pullReject;
                    pullResolve = pullReject = null;
                    setIteratorEmissionStamp(iterator, stamp);
                    r(err);
                    return;
                }
                pendingError = { err, stamp };
                iterator.__onPush?.();
            },
            get completed() {
                return completed;
            }
        };
        iteratorReceiver = _iteratorReceiver;
        // Subjects rely on buffering: many operators push into an internal Subject
        // immediately during `apply()`, before the downstream consumer starts
        // awaiting `next()`. Eager registration ensures those pushes are buffered.
        if (!lazy) {
            ensureSubscribed();
        }
        return iterator;
    };
}

/**
 * Creates a new `Subscription` instance.
 *
 * This factory encapsulates subscription state and ensures:
 * - Safe, idempotent unsubscription
 * - Proper execution of cleanup logic
 * - Consistent error handling during teardown
 *
 * @param onUnsubscribe Optional cleanup callback executed on first unsubscribe
 * @returns {Subscription} A new Subscription object
 */
function createSubscription(onUnsubscribe) {
    /** Internal mutable subscription state */
    let _unsubscribed = false;
    return {
        /**
       * - `true`  - subscription has been unsubscribed and is inactive
         */
        get unsubscribed() {
            return _unsubscribed;
        },
        /**
         * Unsubscribes from the subscription.
         *
         * This method:
         * 1. Marks the subscription as unsubscribed
         * 2. Executes the `onUnsubscribe` callback (if present)
         * 3. Suppresses and logs any errors thrown during cleanup
         */
        unsubscribe: async function () {
            if (!_unsubscribed) {
                _unsubscribed = true;
                try {
                    await this.onUnsubscribe?.();
                }
                catch (err) {
                    console.error("Error during unsubscribe callback:", err);
                }
            }
        },
        /**
         * Cleanup callback executed when unsubscribing.
         */
        onUnsubscribe
    };
}

/**
 * Type guard to check if a value is stream-like (has type and async iterator).
 *
 * @template T
 * @param value The value to check.
 * @returns {boolean} True if the value is a Stream.
 */
const isStreamLike = (value) => {
    if (!value || (typeof value !== "object" && typeof value !== "function"))
        return false;
    const v = value;
    return ((v.type === "stream" || v.type === "subject") &&
        typeof v[Symbol.asyncIterator] === "function");
};
function waitForAbort(signal) {
    if (signal.aborted)
        return Promise.resolve();
    return new Promise((resolve) => signal.addEventListener("abort", resolve, { once: true }));
}
function wrapReceiver(receiver) {
    const wrapped = {};
    const execute = (cb) => {
        const stamp = getCurrentEmissionStamp();
        if (stamp !== null) {
            try {
                return cb();
            }
            catch (err) {
                return Promise.reject(err);
            }
        }
        return runInMicrotask(cb).then(() => void 0);
    };
    if (receiver.next) {
        wrapped.next = (value) => execute(async () => {
            try {
                await receiver.next(value);
            }
            catch (err) {
                const error = err instanceof Error ? err : new Error(String(err));
                if (receiver.error) {
                    try {
                        await receiver.error(error);
                    }
                    catch {
                    }
                }
            }
        });
    }
    if (receiver.error) {
        wrapped.error = (err) => {
            const error = err instanceof Error ? err : new Error(String(err));
            return execute(() => {
                try {
                    return receiver.error(error);
                }
                catch {
                }
            });
        };
    }
    if (receiver.complete) {
        wrapped.complete = () => execute(() => {
            try {
                return receiver.complete();
            }
            catch {
            }
        });
    }
    return wrapped;
}
async function drainIterator(iterator, getReceivers, signal) {
    const abortPromise = waitForAbort(signal);
    const processResult = (result) => {
        if (result.done)
            return true;
        const stamp = getIteratorEmissionStamp(iterator) ?? nextEmissionStamp();
        const receivers = getReceivers();
        const forward = () => {
            for (const { receiver, subscription } of receivers) {
                if (!subscription.unsubscribed) {
                    receiver.next?.(result.value);
                }
            }
        };
        withEmissionStamp(stamp, forward);
        return false;
    };
    let forwardedError = false;
    try {
        while (true) {
            if (iterator.__tryNext) {
                while (true) {
                    const nextResult = iterator.__tryNext();
                    if (!nextResult)
                        break;
                    if (processResult(nextResult))
                        return;
                }
            }
            const winner = await Promise.race([
                abortPromise.then(() => ({ aborted: true })),
                iterator.next().then((result) => ({ result })),
            ]);
            if ("aborted" in winner || signal.aborted)
                break;
            if (processResult(winner.result))
                break;
        }
    }
    catch (err) {
        if (!signal.aborted) {
            const error = err instanceof Error ? err : new Error(String(err));
            for (const { receiver, subscription } of getReceivers()) {
                if (!subscription.unsubscribed) {
                    receiver.error?.(error);
                    forwardedError = true;
                }
            }
        }
    }
    finally {
        const entries = getReceivers();
        if (iterator.return) {
            try {
                await iterator.return();
            }
            catch { }
        }
        if (!signal.aborted && !forwardedError) {
            for (const { receiver, subscription } of entries) {
                if (!subscription.unsubscribed) {
                    receiver.complete?.();
                }
            }
        }
        // Streams created with `createStream` keep subscribers in an array until they
        // explicitly unsubscribe. Most consumers/tests do not call `unsubscribe()`
        // after natural completion, so we drop references here to prevent receiver
        // growth across long test runs.
        entries.length = 0;
    }
}
function createStream(name, generatorFn) {
    const id = generateStreamId();
    getRuntimeHooks()?.onCreateStream?.({ id, name });
    let activeSubscriptions = [];
    let isRunning = false;
    let abortController = new AbortController();
    const getActiveReceivers = () => activeSubscriptions;
    const startMulticastLoop = () => {
        isRunning = true;
        abortController = new AbortController();
        (async () => {
            const signal = abortController.signal;
            const iterator = generatorFn(signal)[Symbol.asyncIterator]();
            try {
                await drainIterator(iterator, getActiveReceivers, signal);
            }
            finally {
                isRunning = false;
                // Once the generator terminates, all current subscribers are terminal.
                // Clear references so future subscriptions restart cleanly and we don't
                // retain completed receivers between runs.
                activeSubscriptions = [];
            }
        })();
    };
    const registerReceiver = (receiver) => {
        const wrapped = wrapReceiver(receiver);
        let subscription;
        subscription = createSubscription(async () => {
            return runInMicrotask(async () => {
                const entry = activeSubscriptions.find((s) => s.subscription === subscription);
                if (entry) {
                    activeSubscriptions = activeSubscriptions.filter((s) => s !== entry);
                    entry.receiver.complete?.();
                }
                if (activeSubscriptions.length === 0) {
                    abortController.abort();
                }
            });
        });
        // IMPORTANT: register synchronously so operators like switchMap can
        // subscribe/unsubscribe inner streams in the same tick without racing the
        // microtask-delivery loop. Receiver callbacks are still scheduled by `wrapReceiver`.
        activeSubscriptions = [...activeSubscriptions, { receiver: wrapped, subscription }];
        if (!isRunning) {
            startMulticastLoop();
        }
        return subscription;
    };
    let self;
    const pipe = ((...ops) => pipeSourceThrough(self, ops));
    self = {
        type: "stream",
        name,
        id,
        pipe,
        subscribe: (cb) => registerReceiver(createReceiver(cb)),
        query: () => firstValueFrom(self),
        [Symbol.asyncIterator]: () => {
            const factory = createAsyncIterator({ register: registerReceiver, lazy: true });
            const it = factory();
            it.__streamix_streamId = id;
            return it;
        },
    };
    return self;
}
function pipeSourceThrough(source, operators) {
    const pipedId = generateStreamId();
    function registerReceiver(receiver) {
        const wrapped = wrapReceiver(receiver);
        const abortController = new AbortController();
        const signal = abortController.signal;
        const subscriptionId = generateSubscriptionId();
        const baseSource = source[Symbol.asyncIterator]();
        const iterator = applyPipeStreamHooks({
            streamId: pipedId,
            streamName: source.name,
            subscriptionId,
            source: baseSource,
            operators,
        });
        const subscription = createSubscription(async () => {
            return runInMicrotask(async () => {
                abortController.abort();
                wrapped.complete?.();
            });
        });
        enqueueMicrotask(() => {
            drainIterator(iterator, () => [{ receiver: wrapped, subscription }], signal).catch(() => { });
        });
        return subscription;
    }
    const pipedStream = {
        name: `${source.name}Sink`,
        id: pipedId,
        type: "stream",
        pipe: (...nextOps) => pipeSourceThrough(source, [...operators, ...nextOps]),
        subscribe: (cb) => registerReceiver(createReceiver(cb)),
        query: () => firstValueFrom(pipedStream),
        [Symbol.asyncIterator]: () => {
            const subscriptionId = generateSubscriptionId();
            const baseSource = source[Symbol.asyncIterator]();
            return applyPipeStreamHooks({
                streamId: pipedId,
                streamName: source.name,
                subscriptionId,
                source: baseSource,
                operators,
            });
        },
    };
    return pipedStream;
}

/**
 * Create a `BehaviorSubject` seeded with `initialValue`.
 *
 * @template T
 * @param {T} initialValue - initial value held by the subject
 * @returns {BehaviorSubject<T>} a new behavior subject
 */
function createBehaviorSubject(initialValue) {
    const id = generateStreamId();
    let latestValue = initialValue;
    let isCompleted = false;
    let terminalItem = null;
    const receivers = new Set();
    const next = (value) => {
        if (isCompleted)
            return;
        latestValue = value;
        const stamp = getCurrentEmissionStamp() ?? nextEmissionStamp();
        // Synchronous delivery
        const targets = Array.from(receivers).filter((r) => stamp > r.subscribedAt);
        withEmissionStamp(stamp, () => {
            for (const r of targets) {
                r.next(value);
            }
        });
    };
    const complete = () => {
        if (isCompleted)
            return;
        isCompleted = true;
        const stamp = getCurrentEmissionStamp() ?? nextEmissionStamp();
        terminalItem = { kind: "complete", stamp };
        // Synchronous delivery
        const targets = Array.from(receivers);
        withEmissionStamp(stamp, () => {
            for (const r of targets) {
                r.complete();
            }
        });
        receivers.clear();
    };
    const error = (err) => {
        if (isCompleted)
            return;
        isCompleted = true;
        const stamp = getCurrentEmissionStamp() ?? nextEmissionStamp();
        terminalItem = { kind: "error", error: err, stamp };
        // Synchronous delivery
        const targets = Array.from(receivers);
        withEmissionStamp(stamp, () => {
            for (const r of targets) {
                r.error(err);
            }
        });
        receivers.clear();
    };
    /**
     * Register a receiver to receive emissions from the BehaviorSubject.
     * Handles replaying the current value and terminal state if needed.
     *
     * @param receiver The receiver to register.
     * @returns {Subscription} Subscription object for unsubscription.
     */
    const register = (receiver) => {
        const r = receiver;
        if (terminalItem) {
            const term = terminalItem;
            withEmissionStamp(term.stamp, () => {
                if (term.kind === "complete")
                    r.complete();
                else if (term.kind === "error")
                    r.error(term.error);
            });
            return createSubscription();
        }
        // Capture the value and stamp at the EXACT moment of registration
        const replayValue = latestValue;
        const replayStamp = getCurrentEmissionStamp() ?? nextEmissionStamp();
        // Use the emission stamp as the subscription marker so delivery logic
        // (which compares emission stamps) remains consistent across helpers.
        // Mutate the receiver to attach `subscribedAt` so helpers that expect
        // the property on the original receiver work correctly.
        r.subscribedAt = replayStamp;
        const trackedReceiver = r;
        receivers.add(trackedReceiver);
        // Replay the current state to the new subscriber immediately so
        // async iterators see the value before returning.
        try {
            if (!r.completed && receivers.has(trackedReceiver)) {
                withEmissionStamp(replayStamp, () => r.next(replayValue));
            }
        }
        catch (_) { }
        const baseSub = createSubscription(() => {
            // Synchronous completion
            if (!r.completed) {
                const stamp = getCurrentEmissionStamp() ?? nextEmissionStamp();
                withEmissionStamp(stamp, () => r.complete());
            }
            receivers.delete(trackedReceiver);
        });
        const wrappedSub = {
            get unsubscribed() {
                return baseSub.unsubscribed;
            },
            unsubscribe() {
                // Remove receiver synchronously to prevent further deliveries
                receivers.delete(trackedReceiver);
                return baseSub.unsubscribe();
            },
            onUnsubscribe: baseSub.onUnsubscribe,
        };
        return wrappedSub;
    };
    /**
     * The BehaviorSubject instance returned to consumers.
     *
     * @returns {BehaviorSubject<T>} The subject instance with imperative and stream methods.
     */
    return {
        type: "subject",
        name: "behaviorSubject",
        id,
        get value() {
            return latestValue;
        },
        pipe(...steps) {
            return pipeSourceThrough(this, steps);
        },
        subscribe: (cb) => register(createReceiver(cb)),
        async query() {
            return firstValueFrom(this);
        },
        next,
        complete,
        error,
        completed: () => isCompleted,
        [Symbol.asyncIterator]: createAsyncIterator({ register })
    };
}

/**
 * Create a `ReplaySubject` with an optional capacity of buffered items.
 *
 * @template T
 * @param {number} [capacity=Infinity] - max number of values to retain
 * @returns {ReplaySubject<T>} a new replay subject
 */
function createReplaySubject(capacity = Infinity) {
    const id = generateStreamId();
    let latestValue;
    let isCompleted = false;
    const receivers = new Set();
    const ready = new Set();
    const queue = [];
    const replay = [];
    const terminalRef = { current: null };
    const pushReplay = (value, stamp) => {
        replay.push({ value, stamp });
        if (replay.length > capacity) {
            replay.shift();
        }
    };
    const setLatestValue = (v) => {
        latestValue = v;
    };
    const tryCommit = createTryCommit({
        receivers,
        ready,
        queue,
        setLatestValue,
    });
    const deliverTerminal = (r, terminal) => {
        withEmissionStamp(terminal.stamp, () => {
            if (terminal.kind === "complete") {
                r.complete();
                return;
            }
            if (terminal.kind === "error") {
                r.error(terminal.error);
            }
        });
    };
    const register = createRegister({
        receivers,
        ready,
        terminalRef,
        createSubscription,
        tryCommit,
    });
    const next = (value) => {
        if (isCompleted)
            return;
        const stamp = getCurrentEmissionStamp() ?? nextEmissionStamp();
        setLatestValue(value);
        pushReplay(value, stamp);
        queue.push({ kind: "next", value: value, stamp });
        tryCommit();
    };
    const complete = () => {
        if (isCompleted)
            return;
        isCompleted = true;
        const stamp = getCurrentEmissionStamp() ?? nextEmissionStamp();
        const item = { kind: "complete", stamp };
        terminalRef.current = item;
        queue.push(item);
        tryCommit();
    };
    const error = (err) => {
        if (isCompleted)
            return;
        isCompleted = true;
        const stamp = getCurrentEmissionStamp() ?? nextEmissionStamp();
        const item = { kind: "error", error: err, stamp };
        terminalRef.current = item;
        queue.push(item);
        tryCommit();
    };
    const deliverReplayAsync = async (r, snapshot, isActive, onDone) => {
        let index = 0;
        while (index < snapshot.length) {
            if (!isActive() || r.completed)
                break;
            const it = snapshot[index++];
            const result = withEmissionStamp(it.stamp, () => r.next(it.value));
            if (result && typeof result.then === "function") {
                await result;
            }
        }
        onDone?.();
    };
    /**
     * Register a receiver to receive emissions from the ReplaySubject, including replayed values.
     * Handles replaying buffered values and terminal state if needed.
     *
     * @param r The receiver to register.
     * @returns {Subscription} Subscription object for unsubscription.
     */
    const registerWithReplay = (r) => {
        const snapshot = replay.slice();
        const terminal = terminalRef.current;
        // Late subscribers should get replay values (snapshot) first, then terminal.
        // createRegister's terminal fast-path completes immediately, so we bypass it.
        if (terminal) {
            let active = true;
            const sub = createSubscription(() => {
                active = false;
                const stamp = getCurrentEmissionStamp() ?? nextEmissionStamp();
                return withEmissionStamp(stamp, () => r.complete());
            });
            // Deliver replay with backpressure support
            deliverReplayAsync(r, snapshot, () => active, () => {
                if (active && !r.completed) {
                    deliverTerminal(r, terminal);
                }
            });
            return sub;
        }
        // Normal registration. Pass 'true' to start paused (not in ready set)
        // so live updates form a queue until we replay everything.
        const sub = register(r, snapshot.length > 0);
        if (snapshot.length > 0) {
            // Deliver replay with backpressure support
            deliverReplayAsync(r, snapshot, () => !r.completed && receivers.has(r), () => {
                if (!sub.unsubscribed) {
                    ready.add(r);
                    tryCommit();
                }
            });
        }
        return sub;
    };
    const subscribe = (cb) => {
        const r = createReceiver(cb);
        return registerWithReplay(r);
    };
    return {
        type: "subject",
        name: "replaySubject",
        id,
        get value() {
            return latestValue;
        },
        pipe(...steps) {
            return pipeSourceThrough(this, steps);
        },
        subscribe,
        async query() {
            return firstValueFrom(this);
        },
        next,
        complete,
        error,
        completed: () => isCompleted,
        [Symbol.asyncIterator]: createAsyncIterator({
            register: (r) => registerWithReplay(r),
        }),
    };
}

/**
 * Create a plain `Subject` which buffers emissions and delivers them to
 * current subscribers. The returned subject can be used as an async
 * iterable and as an imperative emitter via `next`/`complete`/`error`.
 *
 * @template T
 * @returns {Subject<T>} A new subject instance.
 */
function createSubject() {
    const id = generateStreamId();
    let latestValue;
    let isCompleted = false;
    const receivers = new Set();
    const ready = new Set();
    const queue = [];
    const terminalRef = { current: null };
    const setLatestValue = (v) => (latestValue = v);
    const tryCommit = createTryCommit({ receivers, ready, queue, setLatestValue });
    /**
     * Register a receiver to receive emissions from the Subject.
     * Handles replaying the current value and terminal state if needed.
     *
     * @param receiver The receiver to register.
     * @returns {Subscription} Subscription object for unsubscription.
     */
    const register = createRegister({
        receivers,
        ready,
        terminalRef,
        createSubscription,
        tryCommit,
    });
    const next = (value) => {
        if (isCompleted)
            return;
        const stamp = getCurrentEmissionStamp() ?? nextEmissionStamp();
        setLatestValue(value);
        queue.push({ kind: 'next', value: value, stamp });
        tryCommit();
    };
    const complete = () => {
        if (isCompleted)
            return;
        const stamp = getCurrentEmissionStamp() ?? nextEmissionStamp();
        isCompleted = true;
        terminalRef.current = { kind: 'complete', stamp };
        queue.push({ kind: 'complete', stamp });
        tryCommit();
    };
    const error = (err) => {
        if (isCompleted)
            return;
        const stamp = getCurrentEmissionStamp() ?? nextEmissionStamp();
        isCompleted = true;
        terminalRef.current = { kind: 'error', error: err, stamp };
        queue.push({ kind: 'error', error: err, stamp });
        tryCommit();
    };
    return {
        type: "subject",
        name: "subject",
        id,
        get value() { return latestValue; },
        pipe(...steps) {
            return pipeSourceThrough(this, steps);
        },
        subscribe: (cb) => register(createReceiver(cb)),
        async query() { return firstValueFrom(this); },
        next,
        complete,
        error,
        completed: () => isCompleted,
        [Symbol.asyncIterator]: createAsyncIterator({ register })
    };
}

/**
 * Creates a stream operator that emits the latest value from the source stream
 * at most once per specified duration.
 *
 * Each incoming value is stored as the "latest"; a timer emits that latest value
 * when the duration elapses. If the source completes before emission, the last
 * buffered value is flushed before completing.
 *
 * @template T The type of the values in the stream.
 * @param duration The time in milliseconds (or a promise resolving to it) to wait
 * before emitting the latest value. The duration is resolved once when the operator starts.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const audit = (duration) => createOperator('audit', function (source) {
    const output = createSubject();
    const outputIterator = eachValueFrom(output);
    let bufferedResult;
    let timerId;
    let resolvedDuration;
    let completed = false;
    const flush = () => {
        if (!bufferedResult)
            return;
        const value = bufferedResult.value;
        // Emit value directly - tracer tracks it via inputQueue
        output.next(value);
        bufferedResult = undefined;
        timerId = undefined;
        if (completed) {
            output.complete();
        }
    };
    const startTimer = () => {
        if (resolvedDuration === undefined || timerId !== undefined)
            return;
        timerId = setTimeout(flush, resolvedDuration);
    };
    (async () => {
        try {
            resolvedDuration = isPromiseLike(duration)
                ? await duration
                : duration;
            while (true) {
                const result = await source.next();
                if (result.done) {
                    completed = true;
                    if (bufferedResult)
                        flush();
                    break;
                }
                getIteratorMeta(source);
                // ⚠️ Replace buffered value → mark previous as filtered
                bufferedResult = result;
                // Timer starts only once per window
                startTimer();
            }
        }
        catch (err) {
            output.error(err);
        }
        finally {
            if (timerId) {
                clearTimeout(timerId);
                timerId = undefined;
            }
            if (!output.completed())
                output.complete();
        }
    })();
    return outputIterator;
});

/**
 * Combines multiple streams and emits a tuple containing the latest values
 * from each stream whenever any of the source streams emits a new value.
 *
 * This operator is useful for scenarios where you need to react to changes
 * in multiple independent data sources simultaneously. The output stream
 * will not emit a value until all source streams have emitted at least one
 * value. The output stream completes when all source streams have completed.
 *
 * @template {unknown[]} T A tuple type representing the combined values from the sources.
 * @param sources Streams or values (including promises) to combine.
 * @returns {Stream<T>} A new stream that emits a tuple of the latest values from all source streams.
 */
function combineLatest(...sources) {
    async function* generator() {
        if (sources.length === 0)
            return;
        const resolvedStreams = [];
        for (const source of sources) {
            resolvedStreams.push(isPromiseLike(source) ? await source : source);
        }
        const latestValues = [];
        const hasEmitted = new Array(resolvedStreams.length).fill(false);
        let completedStreams = 0;
        const iterators = resolvedStreams.map((stream) => eachValueFrom(fromAny(stream)));
        const promisesByIndex = new Array(resolvedStreams.length).fill(null);
        const createPromise = (index) => {
            const promise = iterators[index]
                .next()
                .then((result) => ({
                index,
                value: result.value,
                done: result.done,
            }));
            promisesByIndex[index] = promise;
            return promise;
        };
        // Initialize
        for (let i = 0; i < resolvedStreams.length; i++) {
            createPromise(i);
        }
        try {
            while (completedStreams < resolvedStreams.length) {
                const result = await Promise.race(promisesByIndex.filter((p) => p !== null));
                if (result.done) {
                    completedStreams++;
                    promisesByIndex[result.index] = null;
                    continue;
                }
                latestValues[result.index] = result.value;
                hasEmitted[result.index] = true;
                if (hasEmitted.every(Boolean)) {
                    yield [...latestValues];
                }
                createPromise(result.index);
            }
        }
        finally {
            for (const iterator of iterators) {
                if (iterator.return) {
                    try {
                        await iterator.return(undefined);
                    }
                    catch {
                        // Ignore cleanup errors
                    }
                }
            }
        }
    }
    return createStream("combineLatest", generator);
}

function concat(...sources) {
    async function* generator() {
        const isPromiseSource = (value) => isPromiseLike(value);
        const resolvedSources = [];
        for (const source of sources) {
            resolvedSources.push(isPromiseSource(source) ? await source : source);
        }
        for (const source of resolvedSources) {
            const iterator = eachValueFrom(fromAny(source));
            try {
                for await (const value of iterator) {
                    yield value;
                }
            }
            catch (error) {
                throw error;
            }
            finally {
                // Attempt to close iterator early on abort or completion
                if (iterator.return) {
                    try {
                        await iterator.return(undefined);
                    }
                    catch {
                        // ignore
                    }
                }
            }
        }
    }
    return createStream("concat", generator);
}

/**
 * Creates a stream that defers the creation of an inner stream until it is
 * subscribed to.
 *
 * This operator ensures that the `factory` function is called only when
 * a consumer subscribes to the stream, making it a good choice for
 * creating "cold" streams. Each new subscription will trigger a new
 * call to the `factory` and create a fresh stream instance.
 *
 * @template T The type of the values in the inner stream.
 * @param {() => (Stream<T> | MaybePromise<T>)} factory A function that returns the stream or value to be subscribed to.
 * @returns {Stream<T>} A new stream that defers subscription to the inner stream.
 */
function defer(factory) {
    async function* generator() {
        const produced = factory();
        const innerStream = isPromiseLike(produced) ? await produced : produced;
        try {
            const iterator = eachValueFrom(fromAny(innerStream));
            try {
                for await (const value of iterator) {
                    yield value;
                }
            }
            finally {
                if (iterator.return) {
                    try {
                        await iterator.return(undefined);
                    }
                    catch {
                        // ignore
                    }
                }
            }
        }
        catch (error) {
            throw error;
        }
    }
    return createStream('defer', generator);
}

/**
 * Creates an empty stream that emits no values and completes immediately.
 *
 * This function creates a stream that serves as a useful utility for
 * scenarios where a stream is expected but no values need to be produced.
 * It completes immediately upon subscription, allowing a sequence of
 * other streams to proceed without delay.
 *
 * @template T The type of the stream's values (will never be emitted).
 * @returns {Stream<T>} An empty stream.
 */
/**
 * A singleton instance of an empty stream.
 *
 * This constant provides a reusable, empty stream that immediately completes
 * upon subscription without emitting any values. It is useful in stream
 * compositions as a placeholder or to represent a sequence with no elements.
 *
 * @type {Stream<any>}
 */
const empty = () => {
    const stream = createStream('EMPTY', async function* () {
        // No emissions, just complete immediately
    });
    // Empty stream does not subscribe to any source
    const subscribe = (callbackOrReceiver) => {
        const receiver = createReceiver(callbackOrReceiver);
        // No data is emitted, immediately complete the receiver
        queueMicrotask(async () => receiver.complete && await receiver.complete());
        return {
            unsubscribed: false,
            unsubscribe: () => { },
        };
    };
    return Object.assign(stream, { subscribe, completed: () => true });
};
/**
 * A singleton instance of an empty stream.
 *
 * This constant provides a reusable, empty stream that immediately completes
 * upon subscription without emitting any values. It is useful in stream
 * compositions as a placeholder or to represent a sequence with no elements.
 */
const EMPTY = empty();

function forkJoin(...sources) {
    async function* generator() {
        const normalizedSources = sources.length === 1 && Array.isArray(sources[0]) ? sources[0] : sources;
        const resolvedSources = [];
        for (const source of normalizedSources) {
            resolvedSources.push(isPromiseLike(source) ? await source : source);
        }
        const results = new Array(resolvedSources.length);
        const hasValue = new Array(resolvedSources.length).fill(false);
        const resolvedIterators = resolvedSources.map((source) => eachValueFrom(fromAny(source)));
        try {
            const promises = resolvedIterators.map(async (iterator, index) => {
                while (true) {
                    const result = await iterator.next();
                    if (result.done)
                        break;
                    hasValue[index] = true;
                    results[index] = result.value;
                }
                if (!hasValue[index]) {
                    throw new Error("forkJoin: one of the streams completed without emitting any value");
                }
            });
            await Promise.all(promises);
            yield results;
        }
        finally {
            await Promise.all(resolvedIterators.map((iterator) => iterator.return ? iterator.return(undefined).catch(() => { }) : Promise.resolve()));
        }
    }
    return createStream("forkJoin", generator);
}

/**
 * Creates a stream from an asynchronous or synchronous iterable.
 *
 * This operator is a powerful way to convert any source that can be iterated
 * over (such as arrays, strings, `Map`, `Set`, `AsyncGenerator`, etc.) into
 * a reactive stream. The stream will emit each value from the source in order
 * before completing.
 *
 * @template T The type of the values in the iterable.
 * @param {AsyncIterable<T> | Iterable<T> | PromiseLike<AsyncIterable<T> | Iterable<T>>} source The iterable source to convert into a stream.
 * @returns {Stream<T>} A new stream that emits each value from the source.
 */
function from(source) {
    async function* generator() {
        const resolvedSource = isPromiseLike(source) ? await source : source;
        for await (const value of resolvedSource) {
            yield value;
        }
    }
    return createStream("from", generator);
}

/**
 * Creates a stream that emits events of the specified type from the given EventTarget.
 *
 * This function provides a reactive way to handle DOM events or other events,
 * such as mouse clicks, keyboard presses, or custom events. The stream
 * will emit a new event object each time the event is dispatched.
 *
 * @template {Event} T The type of the event to listen for. Defaults to a generic `Event`.
 * @param {EventTarget | PromiseLike<EventTarget>} target The event target to listen to (e.g., a DOM element, `window`, or `document`).
 * @param {string | PromiseLike<string>} event The name of the event to listen for (e.g., 'click', 'keydown').
 * @returns {Stream<T>} A stream that emits the event objects as they occur.
 */
function fromEvent(target, event) {
    const subject = createSubject(); // Create a subject to emit event values.
    let subscriberCount = 0;
    let listening = false;
    let resolvedTarget = null;
    let resolvedEvent = null;
    const originalSubscribe = subject.subscribe; // Capture original subscribe method.
    const listener = (ev) => {
        if (!subject.completed()) {
            subject.next(ev); // Emit the event directly into the subject's stream
        }
    };
    const start = async () => {
        if (listening)
            return;
        listening = true;
        if (!isPromiseLike(target) && !isPromiseLike(event)) {
            resolvedTarget = target;
            resolvedEvent = event;
            resolvedTarget.addEventListener(resolvedEvent, listener);
            return;
        }
        const targetValue = isPromiseLike(target) ? await target : target;
        const eventValue = isPromiseLike(event) ? await event : event;
        if (!listening)
            return;
        resolvedTarget = targetValue;
        resolvedEvent = eventValue;
        resolvedTarget.addEventListener(resolvedEvent, listener);
    };
    const stop = () => {
        if (!listening)
            return;
        listening = false;
        if (resolvedTarget && resolvedEvent) {
            resolvedTarget.removeEventListener(resolvedEvent, listener);
        }
        resolvedTarget = null;
        resolvedEvent = null;
    };
    subject.subscribe = (callback) => {
        const subscription = originalSubscribe.call(subject, callback);
        if (++subscriberCount === 1) {
            void start();
        }
        const originalOnUnsubscribe = subscription.onUnsubscribe;
        subscription.onUnsubscribe = () => {
            if (--subscriberCount === 0) {
                stop();
            }
            originalOnUnsubscribe?.call(subscription);
        };
        return subscription;
    };
    subject.name = 'fromEvent';
    return subject;
}

/**
 * Creates a stream from a cancelable, lazy asynchronous factory.
 *
 * The factory is invoked on subscription and receives an {@link AbortSignal}
 * that is aborted when the stream is unsubscribed. If the factory throws or
 * returns a rejected promise, the stream will emit an error.
 *
 * @template T The type of the emitted value.
 *
 * @param factory
 * A function producing a value or promise, optionally reacting to cancellation
 * via the provided abort signal.
 *
 * @returns
 * A stream that emits the produced value and then completes.
 */
function fromPromise(input) {
    return createStream('fromPromise', async function* (signal) {
        const effectiveSignal = signal ?? new AbortController().signal;
        const valueOrPromise = typeof input === "function" ? input(effectiveSignal) : input;
        yield isPromiseLike(valueOrPromise) ? await valueOrPromise : valueOrPromise;
    });
}

/**
 * Creates a stream that chooses between two streams based on a condition.
 *
 * The condition is evaluated lazily when the stream is subscribed to. This allows
 * for dynamic stream selection based on runtime state.
 *
 * @template T The type of the values in the streams.
 * @param {() => MaybePromise<boolean>} condition A function that returns a boolean to determine which stream to use. It is called when the iif stream is subscribed to.
 * @param {Stream<T> | MaybePromise<T>} trueStream The stream or value to use if the condition is `true`.
 * @param {Stream<T> | MaybePromise<T>} falseStream The stream or value to use if the condition is `false`.
 * @returns {Stream<T>} A new stream that emits values from either `trueStream` or `falseStream` based on the condition.
 */
function iif(condition, trueStream, falseStream) {
    async function* generator() {
        // Evaluate condition lazily when the stream starts
        const conditionResult = condition();
        const resolvedCondition = isPromiseLike(conditionResult) ? await conditionResult : conditionResult;
        const chosen = resolvedCondition ? trueStream : falseStream;
        const resolvedChosen = isPromiseLike(chosen) ? await chosen : chosen;
        const iterator = eachValueFrom(fromAny(resolvedChosen));
        try {
            while (true) {
                const result = await iterator.next();
                if (result.done)
                    break;
                yield result.value;
            }
        }
        finally {
            // Ensure proper cleanup of the iterator
            if (iterator.return) {
                try {
                    await iterator.return(undefined);
                }
                catch {
                    // Ignore any errors during cleanup
                }
            }
        }
    }
    return createStream('iif', generator);
}

/**
 * Creates a timer stream that emits numbers starting from 0.
 *
 * This stream is useful for scheduling events or generating periodic data.
 * It is analogous to `setInterval` but as an asynchronous stream.
 *
 * @param {number} [delayMs=0] - The time in milliseconds to wait before emitting the first value (0).
 * If 0, the first value is emitted immediately (in the next microtask).
 * @param {number} [intervalMs] - The time in milliseconds between subsequent emissions.
 * If not provided, it defaults to `delayMs`.
 * @returns {Stream<number>} A stream that emits incrementing numbers (0, 1, 2, ...).
 */
function timer(delayMs = 0, intervalMs) {
    async function* timerGenerator() {
        const resolvedDelay = isPromiseLike(delayMs) ? await delayMs : delayMs;
        const resolvedInterval = intervalMs !== undefined
            ? (isPromiseLike(intervalMs) ? await intervalMs : intervalMs)
            : resolvedDelay;
        let count = 0;
        let cancelled = false;
        let timeoutId = null;
        const sleep = (ms) => new Promise((resolve) => {
            timeoutId = setTimeout(() => {
                timeoutId = null;
                if (!cancelled)
                    resolve();
            }, ms);
        });
        const clearPending = () => {
            if (timeoutId !== null) {
                clearTimeout(timeoutId);
                timeoutId = null;
            }
        };
        try {
            const start = performance.now();
            let nextTime = start + (resolvedDelay > 0 ? resolvedDelay : 0);
            if (resolvedDelay > 0) {
                await sleep(Math.max(0, nextTime - performance.now()));
            }
            else {
                await Promise.resolve();
                nextTime = performance.now();
            }
            yield count++;
            nextTime += resolvedInterval;
            while (true) {
                const waitMs = Math.max(0, nextTime - performance.now());
                await sleep(waitMs);
                yield count++;
                nextTime += resolvedInterval;
            }
        }
        finally {
            cancelled = true;
            clearPending();
        }
    }
    return createStream('timer', timerGenerator);
}

/**
 * Creates a stream that emits incremental numbers starting from 0 at a regular
 * interval.
 *
 * This operator is a shorthand for `timer(0, intervalMs)`, useful for
 * creating a simple, repeating sequence of numbers. The stream emits a new
 * value every `intervalMs` milliseconds. It is analogous to `setInterval` but
 * as an asynchronous stream.
 *
 * @param {MaybePromise<number>} intervalMs The time in milliseconds between each emission.
 * @returns {Stream<number>} A stream that emits incrementing numbers (0, 1, 2, ...).
 */
function interval(intervalMs) {
    // Use the timer function to create a stream that emits at the specified interval
    const stream = timer(0, intervalMs);
    stream.name = 'interval';
    return stream;
}

/**
 * Creates a stream that emits values in a loop based on a condition and an
 * iteration function.
 *
 * This operator is useful for generating a sequence of values until a specific
 * condition is no longer met. It starts with an `initialValue` and, for each
 * iteration, it yields the current value and then uses `iterateFn` to
 * calculate the next value in the sequence.
 *
 * @template T The type of the values in the stream.
 * @param {MaybePromise<T>} initialValue The starting value for the loop.
 * @param {(value: T) => MaybePromise<boolean>} condition A function that returns `true` to continue the loop and `false` to stop.
 * @param {(value: T) => MaybePromise<T>} iterateFn A function that returns the next value in the sequence.
 * @returns {Stream<T>} A stream that emits the generated sequence of values.
 */
function loop(initialValue, condition, iterateFn) {
    return createStream('loop', async function* (signal) {
        let currentValue = isPromiseLike(initialValue) ? await initialValue : initialValue;
        while (true) {
            if (signal?.aborted)
                break;
            const shouldContinue = condition(currentValue);
            const continueValue = isPromiseLike(shouldContinue) ? await shouldContinue : shouldContinue;
            if (!continueValue)
                break;
            yield currentValue;
            await Promise.resolve();
            if (signal?.aborted)
                break;
            const nextValue = iterateFn(currentValue);
            currentValue = isPromiseLike(nextValue) ? await nextValue : nextValue;
        }
    });
}

/**
 * Merges multiple source streams into a single stream, emitting values as they arrive from any source.
 *
 * This is useful for combining data from multiple independent sources into a single,
 * unified stream of events. Unlike `zip`, it does not wait for a value from every
 * stream before emitting; it emits values on a first-come, first-served basis.
 *
 * The merged stream completes only after all source streams have completed.
 * If any source stream errors, the merged stream immediately errors.
 *
 * @template T The type of the values in the streams.
 * @param sources Streams or values (including promises) to merge.
 * @returns {Stream<T>} A new stream that emits values from all input streams.
 */
function merge(...sources) {
    return createStream('merge', async function* () {
        if (sources.length === 0)
            return;
        const isPromiseSource = (value) => isPromiseLike(value);
        const resolvedSources = [];
        for (const source of sources) {
            resolvedSources.push(isPromiseSource(source) ? await source : source);
        }
        const iterators = resolvedSources.map((source) => eachValueFrom(fromAny(source)));
        const nextPromises = iterators.map(it => it.next());
        let activeCount = iterators.length;
        const reflect = (promise, index) => promise.then(result => ({ ...result, index, status: 'fulfilled' }), error => ({ error, index, status: 'rejected' }));
        const cleanup = async () => {
            const cleanupErrors = [];
            for (let i = 0; i < iterators.length; i++) {
                const iterator = iterators[i];
                if (iterator.return) {
                    try {
                        await iterator.return(undefined);
                    }
                    catch (error) {
                        cleanupErrors.push({ index: i, error });
                    }
                }
            }
            if (cleanupErrors.length > 0) {
                console.warn('Merge cleanup errors:', cleanupErrors.map(e => `[${e.index}]: ${e.error}`));
            }
        };
        try {
            while (activeCount > 0) {
                const race = Promise.race(nextPromises
                    .map((p, i) => (p ? reflect(p, i) : null))
                    .filter(Boolean));
                const winner = await race;
                if (winner.status === 'rejected') {
                    await cleanup();
                    throw winner.error;
                }
                const { value, done, index } = winner;
                if (done) {
                    nextPromises[index] = null;
                    activeCount--;
                }
                else {
                    yield value;
                    nextPromises[index] = iterators[index].next();
                }
            }
        }
        finally {
            await cleanup();
        }
    });
}

/**
 * Creates a stream that emits a single value and then completes.
 *
 * This operator is useful for scenarios where you need to treat a static,
 * single value as a stream. It immediately yields the provided `value`
 * and then signals completion, which is a common pattern for creating a
 * "hot" stream from a predefined value.
 *
 * @template T The type of the value to be emitted.
 * @param {MaybePromise<T>} value The single value to emit.
 * @returns {Stream<T>} A new stream that emits the value and then completes.
 */
function of(value) {
    return createStream('of', async function* () {
        const resolved = isPromiseLike(value) ? await value : value;
        yield resolved;
    });
}

/**
 * Returns a stream that races multiple input streams.
 * It emits values from the first stream that produces a value,
 * then cancels all other streams.
 *
 * This operator is useful for scenarios where you only need the result from the fastest
 * of several asynchronous operations. For example, fetching data from multiple servers
 * and only taking the result from the one that responds first.
 *
 * Once the winning stream completes, the output stream also completes.
 * If the winning stream emits an error, the output stream will emit that error.
 *
 * @template {readonly unknown[]} T - A tuple type representing the combined values from the streams.
 * @param streams Streams or values (including promises) to race against each other.
 * @returns {Stream<T[number]>} A new stream that emits values from the first stream to produce a value.
 */
function race(...streams) {
    return createStream('race', async function* () {
        if (streams.length === 0)
            return;
        const resolvedStreams = [];
        for (const stream of streams) {
            resolvedStreams.push(isPromiseLike(stream) ? await stream : stream);
        }
        const iterators = resolvedStreams.map((s) => eachValueFrom(fromAny(s)));
        let winnerIndex = null;
        try {
            const first = await Promise.race(iterators.map((it, index) => it.next().then(result => ({ ...result, index }))));
            winnerIndex = first.index;
            // Cancel all losing streams as soon as the winner is known.
            await Promise.all(iterators.map((it, index) => index !== winnerIndex && it.return
                ? it.return(undefined).catch(() => { })
                : Promise.resolve()));
            if (first.done)
                return;
            yield first.value;
            const winner = iterators[winnerIndex];
            while (true) {
                const result = await winner.next();
                if (result.done)
                    break;
                yield result.value;
            }
        }
        finally {
            await Promise.all(iterators.map((it) => it.return ? it.return(undefined).catch(() => { }) : Promise.resolve()));
        }
    });
}

/**
 * Creates a stream that emits a sequence of numbers, starting from `start`,
 * incrementing by `step`, and emitting a total of `count` values.
 *
 * This operator is a powerful way to generate a numerical sequence in a
 * reactive context. It's similar to a standard `for` loop but produces
 * values as a stream. It's built upon the `loop` operator for its
 * underlying logic.
 *
 * @param {MaybePromise<number>} start - The first number to emit in the sequence.
 * @param {MaybePromise<number>} count - The total number of values to emit. Must be a non-negative number.
 * @param {MaybePromise<number>} [step=1] - The amount to increment or decrement the value in each step.
 * @returns {Stream<number>} A stream that emits a sequence of numbers.
 */
function range(start, count, step = 1) {
    return createStream('range', async function* () {
        const resolvedStart = isPromiseLike(start) ? await start : start;
        const resolvedCount = isPromiseLike(count) ? await count : count;
        const resolvedStep = isPromiseLike(step) ? await step : step;
        const end = resolvedStart + resolvedCount * resolvedStep;
        let current = resolvedStart;
        while (resolvedStep > 0 ? current < end : current > end) {
            yield current;
            current += resolvedStep;
        }
    });
}

/**
 * Creates a stream that subscribes to a source factory and retries on error.
 *
 * This operator is useful for handling streams that may fail due to
 * temporary issues, such as network problems. It will attempt to
 * resubscribe to the source stream up to `maxRetries` times, with an
 * optional delay between each attempt. If the stream completes successfully
 * on any attempt, it will emit all of its values and then complete.
 * If all retry attempts fail, the final error is propagated.
 *
 * @template T The type of values emitted by the stream.
 * @param {() => (Stream<T> | MaybePromise<T>)} factory A function that returns a new stream or value for each attempt.
 * @param {MaybePromise<number>} [maxRetries=3] The maximum number of times to retry the stream. A value of 0 means no retries.
 * @param {MaybePromise<number>} [delay=1000] The time in milliseconds to wait before each retry attempt.
 * @returns {Stream<T>} A new stream that applies the retry logic.
 */
function retry(factory, maxRetries = 3, delay = 1000) {
    return createStream("retry", async function* (signal) {
        const resolvedMaxRetries = isPromiseLike(maxRetries) ? await maxRetries : maxRetries;
        let resolvedDelayValue;
        const resolveDelayValue = async () => {
            if (resolvedDelayValue !== undefined) {
                return resolvedDelayValue;
            }
            if (delay === undefined) {
                return undefined;
            }
            resolvedDelayValue = isPromiseLike(delay) ? await delay : delay;
            return resolvedDelayValue;
        };
        let retryCount = 0;
        let lastError = null;
        while (retryCount <= resolvedMaxRetries) {
            let iterator = null;
            let buffered = [];
            try {
                // Check abort signal at loop start
                if (signal?.aborted) {
                    throw new Error("Stream aborted");
                }
                // Wrap factory call in try-catch to handle factory errors
                let produced;
                try {
                    produced = factory();
                }
                catch (factoryError) {
                    throw factoryError instanceof Error ? factoryError : new Error(String(factoryError));
                }
                const source = isPromiseLike(produced) ? await produced : produced;
                iterator = eachValueFrom(fromAny(source));
                for await (const value of iterator) {
                    // Check abort signal during iteration
                    if (signal?.aborted) {
                        throw new Error("Stream aborted");
                    }
                    buffered.push(value);
                }
                for (const value of buffered) {
                    yield value;
                }
                lastError = null;
                break;
            }
            catch (error) {
                lastError = error instanceof Error ? error : new Error(String(error));
                retryCount++;
                // Only delay if we're going to retry (check BEFORE sleeping)
                const resolvedDelay = await resolveDelayValue();
                if (retryCount <= resolvedMaxRetries && resolvedDelay !== undefined && resolvedDelay > 0) {
                    // Allow abortion during delay
                    try {
                        await new Promise((resolve, reject) => {
                            const timeoutId = setTimeout(resolve, resolvedDelay);
                            if (signal) {
                                const abortHandler = () => {
                                    clearTimeout(timeoutId);
                                    reject(new Error("Stream aborted"));
                                };
                                signal.addEventListener("abort", abortHandler, { once: true });
                            }
                        });
                    }
                    catch (delayError) {
                        throw delayError;
                    }
                }
            }
            finally {
                if (iterator?.return) {
                    try {
                        await iterator.return(undefined);
                    }
                    catch {
                        // Ignore cleanup errors
                    }
                }
            }
        }
        // If we exhausted retries and had errors, throw the last error
        if (lastError) {
            throw lastError;
        }
    });
}

/**
 * Combine multiple streams into a single stream that emits arrays of the latest values
 * from each input stream whenever any input emits. Emission occurs only when all inputs
 * have emitted at least once.
 *
 * @template T
 * @param {...Stream<T[number]>[]} sources - The input streams to zip.
 * @returns {Stream<T>} A stream emitting arrays of values from each input.
 */
function zip(...sources) {
    return createStream('zip', async function* () {
        if (sources.length === 0)
            return;
        const resolvedSources = [];
        for (const source of sources) {
            resolvedSources.push(isPromiseLike(source) ? await source : source);
        }
        const iterators = resolvedSources.map((source) => eachValueFrom(fromAny(source)));
        try {
            while (true) {
                const results = await Promise.all(iterators.map(it => it.next()));
                if (results.some(r => r.done))
                    break;
                yield results.map(r => r.value);
            }
        }
        finally {
            await Promise.all(iterators.map(it => (typeof it.return === 'function' ? it.return(undefined).catch(() => { }) : Promise.resolve())));
        }
    });
}

/**
 * Buffers values from the source stream and emits them as arrays every `period` milliseconds,
 * while tracking pending and phantom values in the PipeContext.
 *
 * @template T The type of the values in the source stream.
 * @param period Time in milliseconds between each buffer flush.
 * @returns An Operator instance for use in a stream's `pipe` method.
 */
function buffer(period) {
    return createOperator("buffer", function (source) {
        const output = createSubject();
        const outputIterator = eachValueFrom(output);
        let buffer = [];
        let completed = false;
        const flush = () => {
            if (buffer.length === 0)
                return;
            const targetMeta = buffer[buffer.length - 1]?.meta;
            const inputValueIds = buffer.map((e) => e.meta?.valueId).filter(Boolean);
            if (targetMeta) {
                setIteratorMeta(outputIterator, {
                    valueId: targetMeta.valueId,
                    kind: "collapse",
                    inputValueIds: inputValueIds.length > 0 ? inputValueIds : undefined,
                }, targetMeta.operatorIndex, targetMeta.operatorName);
            }
            // Emit expanded value
            let values = buffer.map((e) => e.result.value);
            if (targetMeta) {
                values = setValueMeta(values, { valueId: targetMeta.valueId, kind: "collapse", inputValueIds: inputValueIds.length > 0 ? inputValueIds : undefined }, targetMeta.operatorIndex, targetMeta.operatorName);
            }
            output.next(values);
            buffer = [];
        };
        let intervalSubscription;
        let pendingIntervalUnsubscribe = false;
        const requestIntervalUnsubscribe = () => {
            if (intervalSubscription) {
                const sub = intervalSubscription;
                intervalSubscription = undefined;
                sub.unsubscribe();
                return;
            }
            pendingIntervalUnsubscribe = true;
        };
        const cleanup = () => {
            requestIntervalUnsubscribe();
        };
        const flushAndComplete = () => {
            flush();
            if (!completed) {
                completed = true;
                output.complete();
            }
            cleanup();
        };
        const fail = (err) => {
            buffer = [];
            output.error(err);
            cleanup();
        };
        // Periodic flush
        intervalSubscription = timer(period, period).subscribe({
            next: () => flush(),
            error: (err) => fail(err),
            complete: () => flushAndComplete(),
        });
        if (pendingIntervalUnsubscribe) {
            requestIntervalUnsubscribe();
        }
        (async () => {
            try {
                while (true) {
                    const result = await source.next();
                    if (result.done)
                        break;
                    buffer.push({
                        result,
                        meta: getIteratorMeta(source),
                    });
                }
            }
            catch (err) {
                fail(err);
            }
            finally {
                flushAndComplete();
            }
        })();
        return outputIterator;
    });
}

/**
 * Buffers a fixed number of values from the source stream and emits them as arrays,
 * tracking pending and phantom values in the PipeContext.
 *
 * @template T The type of values in the source stream.
 * @param bufferSize The maximum number of values per buffer (default: Infinity).
 * @returns An Operator instance for use in a stream's `pipe` method.
 */
const bufferCount = (bufferSize = Infinity) => createOperator("bufferCount", function (source) {
    let completed = false;
    const iterator = {
        next: async () => {
            if (completed)
                return DONE;
            const buffer = [];
            const metaByIndex = [];
            const size = isPromiseLike(bufferSize) ? await bufferSize : bufferSize;
            while (buffer.length < size) {
                const result = await source.next();
                if (result.done) {
                    completed = true;
                    // Flush any remaining buffered values
                    if (buffer.length > 0) {
                        const metas = metaByIndex.filter(Boolean);
                        const lastMeta = metas[metas.length - 1];
                        let values = buffer.map((r) => r.value);
                        if (lastMeta) {
                            setIteratorMeta(iterator, {
                                valueId: lastMeta.valueId,
                                kind: "collapse",
                                inputValueIds: metas.map((m) => m.valueId),
                            }, lastMeta.operatorIndex, lastMeta.operatorName);
                            values = setValueMeta(values, { valueId: lastMeta.valueId, kind: "collapse", inputValueIds: metas.map((m) => m.valueId) }, lastMeta.operatorIndex, lastMeta.operatorName);
                        }
                        return NEXT(values);
                    }
                    return DONE;
                }
                buffer.push(result);
                metaByIndex.push(getIteratorMeta(source));
            }
            const metas = metaByIndex.filter(Boolean);
            const lastMeta = metas[metas.length - 1];
            let values = buffer.map((r) => r.value);
            if (lastMeta) {
                setIteratorMeta(iterator, {
                    valueId: lastMeta.valueId,
                    kind: "collapse",
                    inputValueIds: metas.map((m) => m.valueId),
                }, lastMeta.operatorIndex, lastMeta.operatorName);
                values = setValueMeta(values, { valueId: lastMeta.valueId, kind: "collapse", inputValueIds: metas.map((m) => m.valueId) }, lastMeta.operatorIndex, lastMeta.operatorName);
            }
            return NEXT(values);
        },
    };
    return iterator;
});

/**
 * Buffers values until the notifier emits once, then flushes the collected values.
 *
 * Every notifier emission triggers a flush of the current buffer; values are released
 * as a collapsed array, preserving metadata for PipeContext tracing. When the source
 * completes, any remaining buffered values are emitted.
 *
 * @template T Source value type.
 * @param notifier Stream or Promise whose emissions cause buffer flushes.
 */
const bufferUntil = (notifier) => createOperator("bufferUntil", function (source) {
    const output = createSubject();
    const buffer = [];
    const notifierIterator = fromAny(notifier)[Symbol.asyncIterator]();
    let cancelled = false;
    // Create the output iterator once so metadata sticks
    const outputIt = output[Symbol.asyncIterator]();
    const flushBuffer = () => {
        if (buffer.length === 0)
            return;
        const records = buffer.splice(0);
        const metas = records
            .map((record) => record.meta)
            .filter(Boolean);
        const lastMeta = metas[metas.length - 1];
        let values = records.map((record) => record.result.value);
        if (lastMeta) {
            setIteratorMeta(iterator, {
                valueId: lastMeta.valueId,
                kind: "collapse",
                inputValueIds: metas.map((meta) => meta.valueId),
            }, lastMeta.operatorIndex, lastMeta.operatorName);
            values = setValueMeta(values, {
                valueId: lastMeta.valueId,
                kind: "collapse",
                inputValueIds: metas.map((meta) => meta.valueId),
            }, lastMeta.operatorIndex, lastMeta.operatorName);
        }
        output.next(values);
    };
    // Notifier loop - flush on each emission
    (async () => {
        try {
            while (!cancelled) {
                const result = await notifierIterator.next();
                if (result.done || cancelled)
                    break;
                queueMicrotask(() => flushBuffer());
            }
        }
        catch (err) {
            if (!cancelled) {
                output.error(err);
            }
        }
    })();
    // Source loop - buffer values
    (async () => {
        try {
            while (!cancelled) {
                const result = await source.next();
                if (result.done || cancelled)
                    break;
                buffer.push({
                    result,
                    meta: getIteratorMeta(source),
                });
            }
            if (!cancelled) {
                flushBuffer();
                output.complete();
            }
        }
        catch (err) {
            if (!cancelled) {
                output.error(err);
            }
        }
        finally {
            if (!cancelled) {
                try {
                    await notifierIterator.return?.();
                }
                catch { }
            }
        }
    })();
    // Custom iterator with cleanup
    const iterator = {
        next: () => outputIt.next(),
        return: async (value) => {
            cancelled = true;
            // Cleanup source iterator
            try {
                await source.return?.();
            }
            catch { }
            // Cleanup notifier iterator
            try {
                await notifierIterator.return?.();
            }
            catch { }
            output.complete();
            if (value !== undefined) {
                return NEXT(value);
            }
            return DONE;
        },
        throw: async (error) => {
            cancelled = true;
            output.error(error);
            return outputIt.throw?.(error) ?? Promise.reject(error);
        },
    };
    return iterator;
});

/**
 * Buffers values while the provided predicate returns `true`.
 *
 * The predicate is evaluated for each incoming value against the *current* buffer (before the value is added).
 * If it resolves to `true`, the value is appended to the current buffer. If it resolves to `false`, the current
 * buffer is flushed and a new buffer is started with the incoming value.
 *
 * When the source completes, any remaining buffered values are emitted automatically.
 *
 * @template T Source value type.
 * @param predicate Function invoked for each value to decide whether the value should remain in the current buffer.
 * Receives the incoming value, the index, and the current buffer (before pushing the value). It may return a promise.
 */
const bufferWhile = (predicate) => createOperator("bufferWhile", function (source) {
    let completed = false;
    let index = 0;
    const buffer = [];
    const iterator = {
        next: async () => {
            const flushBuffer = () => {
                const records = buffer.splice(0);
                if (records.length === 0)
                    return NEXT([]);
                const metas = records
                    .map((record) => record.meta)
                    .filter(Boolean);
                const lastMeta = metas[metas.length - 1];
                let values = records.map((record) => record.result.value);
                if (lastMeta) {
                    setIteratorMeta(iterator, {
                        valueId: lastMeta.valueId,
                        kind: "collapse",
                        inputValueIds: metas.map((e) => e.valueId),
                    }, lastMeta.operatorIndex, lastMeta.operatorName);
                    values = setValueMeta(values, { valueId: lastMeta.valueId, kind: "collapse", inputValueIds: metas.map((e) => e.valueId) }, lastMeta.operatorIndex, lastMeta.operatorName);
                }
                return NEXT(values);
            };
            if (completed) {
                if (buffer.length > 0) {
                    return flushBuffer();
                }
                return DONE;
            }
            while (true) {
                const result = await source.next();
                if (result.done) {
                    completed = true;
                    if (buffer.length > 0) {
                        return flushBuffer();
                    }
                    return DONE;
                }
                const record = { result, meta: getIteratorMeta(source) };
                const values = buffer.map((item) => item.result.value);
                const predicateResult = predicate(result.value, index++, values);
                const shouldKeep = isPromiseLike(predicateResult) ? await predicateResult : predicateResult;
                // Always start a buffer with the first value.
                if (buffer.length === 0) {
                    buffer.push(record);
                    continue;
                }
                if (shouldKeep) {
                    buffer.push(record);
                    continue;
                }
                // Boundary: flush the current buffer and start a new one with this value.
                const flushed = flushBuffer();
                buffer.push(record);
                return flushed;
            }
        },
    };
    return iterator;
});

/**
 * Creates a stream operator that catches errors from the source stream and handles them.
 *
 * This operator listens for errors from the upstream source. When the first error is
 * caught, it invokes a provided `handler` callback and then immediately completes
 * the stream, preventing the error from propagating further down the pipeline.
 *
 * - **Error Handling:** The `handler` is executed only for the first error encountered.
 * - **Completion:** After an error is caught and handled, the operator completes,
 * terminating the stream's flow.
 * - **Subsequent Errors:** Any errors after the first will be re-thrown.
 *
 * This is useful for error-handling strategies where you want to perform a specific
 * cleanup action and then gracefully terminate the stream.
 *
 * @template T The type of the values emitted by the stream.
 * @param handler The function to call when an error is caught. It can return a `void` or a `Promise<void>`.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const catchError = (handler = () => { }) => createOperator('catchError', function (source) {
    let errorCaughtAndHandled = false;
    let completed = false;
    return {
        next: async () => {
            while (true) {
                // If an error was already caught and handled, or we're completed, this operator is done
                if (errorCaughtAndHandled || completed) {
                    return DONE;
                }
                try {
                    const result = await source.next();
                    if (result.done) {
                        completed = true; // Source completed without error
                        return DONE;
                    }
                    return result; // Emit value from source
                }
                catch (error) {
                    // An error occurred from the source
                    if (!errorCaughtAndHandled) { // Only handle the first error
                        const handlerResult = handler(error);
                        if (isPromiseLike(handlerResult))
                            await handlerResult;
                        errorCaughtAndHandled = true; // Mark as handled
                        completed = true;
                        // After handling, this operator completes
                        return DONE;
                    }
                    else {
                        // If subsequent errors occur (shouldn't happen with a proper upstream), re-throw
                        throw error;
                    }
                }
            }
        },
    };
});

/**
 * Creates a stream operator that maps each value from the source stream to a new
 * inner stream (or value/array/promise) and flattens all inner streams sequentially.
 *
 * For each value from the source:
 * 1. The `project` function is called with the value and its index.
 * 2. The returned value is normalized into a stream using {@link fromAny}.
 * 3. The inner stream is consumed fully before processing the next outer value.
 *
 * This ensures that all emitted values maintain their original sequential order.
 *
 * @template T The type of values in the source stream.
 * @template R The type of values emitted by the inner streams and the output.
 * @param project A function that takes a value from the source stream and its index,
 * and returns either:
 *   - a {@link Stream<R>},
 *   - a {@link MaybePromise<R>} (value or promise),
 *   - or an array of `R`.
 * @returns An {@link Operator} instance that can be used in a stream's `pipe` method.
 */
const concatMap = (project) => createOperator("concatMap", function (source) {
    let outerIndex = 0;
    let innerIterator = null;
    let result = null;
    let currentMeta;
    const iterator = {
        next: async () => {
            while (true) {
                // If no active inner iterator, pull the next outer value
                if (!innerIterator) {
                    result = await source.next();
                    if (result.done)
                        return DONE;
                    currentMeta = getIteratorMeta(source);
                    const projected = project(result.value, outerIndex++);
                    const normalized = isPromiseLike(projected) ? await projected : projected;
                    innerIterator = eachValueFrom(fromAny(normalized));
                }
                // Pull next value from inner stream
                const innerResult = await innerIterator.next();
                if (innerResult.done) {
                    innerIterator = null;
                    // Otherwise continue to next outer value
                    continue;
                }
                let value = innerResult.value;
                if (currentMeta) {
                    // Attach per-value metadata so tracers can attribute outputs even when emitted asynchronously.
                    value = setValueMeta(value, { valueId: currentMeta.valueId, kind: "expand" }, currentMeta.operatorIndex, currentMeta.operatorName);
                    setIteratorMeta(iterator, { valueId: currentMeta.valueId, kind: "expand" }, currentMeta.operatorIndex, currentMeta.operatorName);
                }
                // Mark that inner stream produced a value
                return NEXT(value);
            }
        },
    };
    return iterator;
});

/**
 * Creates a stream operator that emits the most recent value from the source stream
 * only after a specified duration has passed without another new value.
 *
 * This version tracks pending results in the PipeContext and marks
 * superseded values as phantoms.
 *
 * @template T The type of the values in the source and output streams.
 * @param duration The debounce duration in milliseconds.
 * @returns An Operator instance for use in a stream pipeline.
 */
function debounce(duration) {
    return createOperator("debounce", function (source) {
        const output = createSubject();
        const outputIterator = eachValueFrom(output);
        let timeoutId;
        let latestResult;
        let resolvedDuration;
        let completed = false;
        const flush = () => {
            if (!latestResult)
                return;
            const value = latestResult.value;
            if (latestResult.meta) {
                setIteratorMeta(outputIterator, latestResult.meta, latestResult.meta.operatorIndex, latestResult.meta.operatorName);
            }
            // Emit value directly - tracer tracks it via inputQueue
            output.next(value);
            latestResult = undefined;
            timeoutId = undefined;
            if (completed) {
                output.complete();
            }
        };
        (async () => {
            try {
                resolvedDuration = isPromiseLike(duration)
                    ? await duration
                    : duration;
                while (true) {
                    const result = await source.next();
                    if (result.done) {
                        completed = true;
                        if (latestResult && timeoutId === undefined) {
                            flush();
                        }
                        break;
                    }
                    // 🔍 Extract tracing metadata of incoming value
                    const meta = getIteratorMeta(source);
                    // ⚠️ Supersede previous pending value
                    latestResult = result;
                    if (meta) {
                        latestResult.meta = meta;
                    }
                    if (timeoutId)
                        clearTimeout(timeoutId);
                    if (resolvedDuration !== undefined) {
                        timeoutId = setTimeout(flush, resolvedDuration);
                    }
                }
            }
            catch (err) {
                output.error(err);
            }
            finally {
                completed = true;
                if (timeoutId) {
                    clearTimeout(timeoutId);
                    timeoutId = undefined;
                }
                if (latestResult)
                    flush();
                if (!output.completed())
                    output.complete();
            }
        })();
        return outputIterator;
    });
}

/**
 * Creates a stream operator that emits a default value if the source stream is empty.
 *
 * This operator monitors the source stream for any emitted values. If the source
 * stream completes without emitting any values, this operator will emit a single
 * `defaultValue` and then complete. If the source stream does emit at least one value,
 * this operator will pass all values through and will not emit the `defaultValue`.
 *
 * @template T The type of the values in the stream.
 * @param defaultValue The value to emit if the source stream is empty.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const defaultIfEmpty = (defaultValue) => createOperator("defaultIfEmpty", function (source) {
    let emitted = false;
    let completed = false;
    return {
        next: async () => {
            while (true) {
                if (completed) {
                    return DONE;
                }
                const result = await source.next();
                if (!result.done) {
                    emitted = true;
                    return result;
                }
                // Source completed
                if (!emitted) {
                    // Source was empty, emit default value
                    completed = true;
                    const value = isPromiseLike(defaultValue) ? await defaultValue : defaultValue;
                    return NEXT(value);
                }
                // Source had values, just complete
                completed = true;
                return DONE;
            }
        }
    };
});

/**
 * Creates a stream operator that delays the emission of each value from the source stream
 * while tracking pending and phantom states.
 *
 * Each value received from the source is added to `context.pendingResults` and is only
 * resolved once the delay has elapsed and the value is emitted downstream.
 *
 * @template T The type of the values in the source and output streams.
 * @param ms The time in milliseconds to delay each value.
 * @returns An Operator instance for use in a stream's `pipe` method.
 */
function delay(ms) {
    return createOperator('delay', function (source) {
        const output = createSubject();
        const outputIterator = eachValueFrom(output);
        let resolvedMs;
        (async () => {
            try {
                resolvedMs = isPromiseLike(ms) ? await ms : ms;
                while (true) {
                    const result = await source.next();
                    if (result.done)
                        break;
                    // Capture tracing metadata immediately
                    const meta = getIteratorMeta(source);
                    if (resolvedMs !== undefined) {
                        await new Promise((resolve) => setTimeout(resolve, resolvedMs));
                    }
                    // Restore tracing metadata before emission
                    if (meta) {
                        setIteratorMeta(outputIterator, { valueId: meta.valueId }, meta.operatorIndex, meta.operatorName);
                    }
                    let value = result.value;
                    if (meta) {
                        value = setValueMeta(value, { valueId: meta.valueId }, meta.operatorIndex, meta.operatorName);
                    }
                    output.next(value);
                }
            }
            catch (err) {
                output.error(err);
            }
            finally {
                if (!output.completed())
                    output.complete();
            }
        })();
        return outputIterator;
    });
}

/**
 * Delay values from the source until a notifier emits.
 *
 * This operator buffers every value produced by the source stream and releases
 * them only after the provided `notifier` produces its first emission. After the
 * notifier emits, the operator flushes the buffered values and forwards all
 * subsequent source values immediately.
 *
 * Important semantics:
 * - Buffering: values are buffered until the notifier emits, then flushed in order
 * - Notifier completion without emission: if the notifier completes without
 *   emitting, buffered values are discarded and the operator will not forward
 *   any buffered values (it simply waits for the source to continue/complete).
 * - Error propagation: any error from the notifier or source is propagated to
 *   the output (the operator records the error and terminates the output
 *   iterator accordingly).
 *
 * Use-cases:
 * - Delay producing values until an initialization step completes (e.g. wait
 *   for a connection or configuration event).
 * - Gate values until user interaction or external readiness signal occurs.
 *
 * @template T Source/output value type.
 * @template R Notifier value type (ignored by this operator).
 * @param notifier A `Stream<R>` or `Promise<R>` that gates the source.
 * @returns An `Operator<T, T>` that can be used in a stream pipeline.
 */
function delayUntil(notifier) {
    return createOperator("delayUntil", (source) => {
        const output = createSubject();
        const outputIt = output[Symbol.asyncIterator]();
        const notifierIt = fromAny(notifier)[Symbol.asyncIterator]();
        const buffer = [];
        let gateOpened = false;
        let cancelled = false;
        let resolveSourceLoop = null;
        // Flush buffered values when gate opens
        const flushBuffer = () => {
            if (buffer.length === 0)
                return;
            for (const { value, stamp } of buffer) {
                setIteratorEmissionStamp(outputIt, stamp);
                output.next(value);
            }
            buffer.length = 0;
        };
        // Notifier observer - wait for first emission to open gate
        (async () => {
            try {
                const result = await notifierIt.next();
                if (!result.done && !cancelled) {
                    gateOpened = true;
                    // Flush synchronously so buffered values come before new source values
                    flushBuffer();
                    // Wake up the source loop if it was waiting
                    if (resolveSourceLoop) {
                        const resolve = resolveSourceLoop;
                        resolveSourceLoop = null;
                        resolve();
                    }
                }
                // Close notifier iterator after first emission or completion
                try {
                    await notifierIt.return?.();
                }
                catch { }
            }
            catch (err) {
                if (!cancelled) {
                    output.error(err);
                }
            }
        })();
        // Source producer
        (async () => {
            try {
                while (!cancelled) {
                    const r = await source.next();
                    if (r.done || cancelled)
                        break;
                    const stamp = getIteratorEmissionStamp(source) ?? 0;
                    if (gateOpened) {
                        // Gate is open, forward immediately
                        setIteratorEmissionStamp(outputIt, stamp);
                        output.next(r.value);
                    }
                    else {
                        // Gate is closed, buffer the value
                        buffer.push({ value: r.value, stamp });
                    }
                }
                // Source completed - flush if gate is open, otherwise discard buffer
                if (!cancelled && gateOpened) {
                    flushBuffer();
                }
                if (!cancelled) {
                    output.complete();
                }
            }
            catch (err) {
                if (!cancelled) {
                    output.error(err);
                }
            }
            finally {
                if (!cancelled) {
                    try {
                        await notifierIt.return?.();
                    }
                    catch { }
                }
            }
        })();
        // Custom iterator with cleanup
        const iterator = {
            next: () => outputIt.next(),
            return: async (value) => {
                cancelled = true;
                // Cleanup source iterator
                try {
                    await source.return?.();
                }
                catch { }
                // Cleanup notifier iterator
                try {
                    await notifierIt.return?.();
                }
                catch { }
                output.complete();
                return outputIt.return?.(value) ?? { done: true, value };
            },
            throw: async (error) => {
                cancelled = true;
                output.error(error);
                return outputIt.throw?.(error) ?? Promise.reject(error);
            },
        };
        return iterator;
    });
}

/**
 * Buffers values while a predicate returns `true` and releases them once the predicate flips to `false`.
 *
 * This operator evaluates the provided predicate for every value coming from the source stream.
 * - When the predicate resolves to `true`, the value is held in an internal queue.
 * - Once the predicate returns `false` for the first time, all buffered values are flushed in order,
 *   including the current value, and the operator resumes emitting immediately.
 * - The operator can re-enter the buffering state later if the predicate becomes `true` again.
 * - When the source completes while values are buffered, those values are flushed before completing.
 *
 * The predicate is allowed to return either a boolean or a promise of a boolean.
 *
 * @template T The type of values flowing through the stream.
 * @param predicate Function to test each value. Receives the value and its index; `true` means delay, `false` means emit immediately.
 */
const delayWhile = (predicate) => createOperator('delayWhile', function (source) {
    const output = createSubject();
    const outputIterator = eachValueFrom(output);
    const queue = [];
    let index = 0;
    const flushQueue = () => {
        for (const item of queue) {
            setIteratorEmissionStamp(outputIterator, item.stamp);
            output.next(item.value);
        }
        queue.length = 0;
    };
    (async () => {
        try {
            while (true) {
                const result = await source.next();
                const stamp = getIteratorEmissionStamp(source) ?? nextEmissionStamp();
                if (result.done) {
                    break;
                }
                const predicateResult = predicate(result.value, index++);
                const shouldDelay = isPromiseLike(predicateResult)
                    ? await predicateResult
                    : predicateResult;
                if (shouldDelay) {
                    queue.push({ value: result.value, stamp });
                    continue;
                }
                if (queue.length > 0) {
                    flushQueue();
                }
                setIteratorEmissionStamp(outputIterator, stamp);
                output.next(result.value);
            }
            if (queue.length > 0) {
                flushQueue();
            }
        }
        catch (err) {
            output.error(err);
            return;
        }
        finally {
            if (!output.completed())
                output.complete();
        }
    })();
    return outputIterator;
});

/**
 * Creates a stream operator that emits values from the source stream only if
 * they are different from the previous value.
 *
 * This operator filters out consecutive duplicate values, ensuring that the
 * output stream only contains values that have changed since the last emission.
 * It's particularly useful for preventing redundant updates in data streams.
 *
 * @template T The type of the values in the stream.
 * @param comparator An optional function that compares the previous and current values.
 * It should return `true` if they are considered the same, and `false` otherwise.
 * If not provided, a strict equality check (`===`) is used.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const distinctUntilChanged = (comparator) => createOperator('distinctUntilChanged', function (source) {
    // State variables to keep track of the last emitted value.
    let lastValue;
    let hasLast = false;
    // The next() method now contains all the logic for a single value.
    return {
        next: async () => {
            while (true) {
                // Await the next value from the source stream.
                const result = await source.next();
                // If the source stream is done, we are also done.
                if (result.done)
                    return DONE;
                if (!hasLast) {
                    lastValue = result.value;
                    hasLast = true;
                    return NEXT(result.value);
                }
                // Check if the value is different from the last one.
                const comparison = comparator ? comparator(lastValue, result.value) : (lastValue === result.value);
                const isSame = comparator
                    ? (isPromiseLike(comparison) ? await comparison : comparison)
                    : comparison;
                const isDistinct = !isSame;
                if (isDistinct) {
                    // If the value is distinct, we update our state and return it as a normal IteratorResult.
                    lastValue = result.value;
                    hasLast = true;
                    return NEXT(result.value);
                }
            }
        },
    };
});

/**
 * Creates a stream operator that filters out consecutive values from the source
 * stream if a specified key's value has not changed.
 *
 * This operator is a specialized version of `distinctUntilChanged`. It is designed
 * to work with streams of objects and checks for uniqueness based on the value
 * of a single property (`key`).
 *
 * @template T The type of the objects in the stream. Must extend `object`.
 * @param key The name of the property to check for changes.
 * @param comparator An optional function to compare the previous and current values of the `key`.
 * It should return `true` if the values are considered the same. If not provided,
 * strict inequality (`!==`) is used.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const distinctUntilKeyChanged = (key, comparator) => createOperator('distinctUntilKeyChanged', function (source) {
    let lastValue;
    let isFirst = true;
    let resolvedKey;
    const getKey = async () => {
        if (resolvedKey === undefined) {
            resolvedKey = isPromiseLike(key) ? await key : key;
        }
        return resolvedKey;
    };
    return {
        next: async () => {
            while (true) {
                const result = await source.next();
                if (result.done)
                    return result;
                const current = result.value;
                const currentKey = await getKey();
                if (isFirst) {
                    isFirst = false;
                    lastValue = current;
                    return NEXT(current);
                }
                const comparison = comparator
                    ? comparator(lastValue[currentKey], current[currentKey])
                    : lastValue[currentKey] === current[currentKey];
                const isSame = comparator
                    ? (isPromiseLike(comparison) ? await comparison : comparison)
                    : comparison;
                const isDistinct = !isSame;
                isFirst = false;
                if (isDistinct) {
                    lastValue = current;
                    return NEXT(current);
                }
            }
        }
    };
});

/**
 * Creates a stream operator that emits a final, specified value after the source stream has completed.
 *
 * The operator first consumes all values from the upstream source. Once the source stream signals
 * its completion (`done`), this operator then emits the `finalValue` and immediately completes.
 *
 * @template T The type of the values in the stream.
 * @param finalValue The value to be emitted as the last item in the stream.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const endWith = (finalValue) => createOperator("endWith", function (source) {
    let sourceDone = false;
    let finalEmitted = false;
    let completed = false;
    const finalValuePromise = Promise.resolve(finalValue);
    return {
        next: async () => {
            while (true) {
                if (completed) {
                    return DONE;
                }
                if (!sourceDone) {
                    const result = await source.next();
                    if (!result.done) {
                        return result;
                    }
                    sourceDone = true;
                }
                if (!finalEmitted) {
                    finalEmitted = true;
                    return NEXT(await finalValuePromise);
                }
                completed = true;
                return DONE;
            }
        }
    };
});

/**
 * Maps each value from the source stream to an inner stream, ignoring
 * new outer values while the current inner stream is still executing.
 *
 * This operator is useful for preventing overlapping operations (e.g., preventing
 * multiple simultaneous form submissions or API calls). If a new value arrives
 * from the source while an earlier projected stream is still active, that
 * new value is silently discarded.
 * * Only after the current inner stream completes will the operator become
 * "idle" and ready to accept the next value from the source.
 *
 * @template T The type of values emitted by the source stream.
 * @template R The type of values emitted by the produced inner streams.
 * @param project A function that transforms a source value into a {@link Stream},
 * a {@link MaybePromise}, or an array. It receives the source value and a
 * zero-based index of the emission.
 * @returns An {@link Operator} that performs the "exhaust" transformation.
 */
const exhaustMap = (project) => createOperator("exhaustMap", function (source) {
    let outerIndex = 0;
    let innerIterator = null;
    let isSourceDone = false;
    // Drop source emissions that happened while an inner was active.
    // We implement this by recording an emission stamp window for the inner:
    // (ignoreStartStamp, ignoreEndStamp]. Any source value with a stamp inside
    // that window is skipped.
    let ignoreStartStamp = null;
    let ignoreEndStamp = null;
    const stampOf = (it) => {
        const s = getIteratorEmissionStamp(it);
        return typeof s === "number" ? s : nextEmissionStamp();
    };
    return {
        async next() {
            while (true) {
                if (innerIterator) {
                    const result = await innerIterator.next();
                    if (!result.done)
                        return NEXT(result.value);
                    innerIterator = null;
                    if (ignoreStartStamp !== null && ignoreEndStamp === null) {
                        ignoreEndStamp = nextEmissionStamp();
                    }
                    if (isSourceDone)
                        return DONE;
                    continue;
                }
                const result = await source.next();
                if (result.done) {
                    isSourceDone = true;
                    return DONE;
                }
                // Ignore values that arrived while the previous inner was active.
                if (ignoreStartStamp !== null && ignoreEndStamp !== null) {
                    const stamp = stampOf(source);
                    if (stamp > ignoreStartStamp && stamp <= ignoreEndStamp) {
                        continue;
                    }
                }
                const projected = project(result.value, outerIndex++);
                // Mark the start of a new active-inner window.
                ignoreStartStamp = nextEmissionStamp();
                ignoreEndStamp = null;
                if (isPromiseLike(projected)) {
                    const normalized = await projected;
                    innerIterator = eachValueFrom(fromAny(normalized));
                }
                else {
                    innerIterator = eachValueFrom(fromAny(projected));
                }
            }
        },
    };
});

/**
 * Creates a stream operator that recursively expands each emitted value.
 *
 * This operator takes each value from the source stream and applies the `project`
 * function to it, which must return a new stream. It then recursively applies
 * the same logic to each value emitted by that new stream, effectively
 * flattening an infinitely deep, asynchronous data structure.
 *
 * This is particularly useful for traversing graph or tree-like data, such as
 * file directories or hierarchical API endpoints, where each item might lead
 * to a new collection of items that also need to be processed.
 *
 * @template T The type of the values in the source and output streams.
 * @param project A function that takes a value and returns a stream, value/array,
 * or a promise of those shapes to be expanded.
 * @param options An optional configuration object for traversal strategy and max depth.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const expand = (project, options = {}) => createOperator('expand', function (source) {
    const queue = [];
    let sourceDone = false;
    const enqueueChildren = async (value, depth, meta) => {
        if (options.maxDepth !== undefined && depth >= options.maxDepth)
            return;
        const projected = project(value);
        const normalized = isPromiseLike(projected) ? await projected : projected;
        for await (const child of eachValueFrom(fromAny(normalized))) {
            const item = { value: child, depth: depth + 1, meta };
            if (options.traversal === 'breadth') {
                queue.push(item);
            }
            else {
                queue.unshift(item);
            }
        }
    };
    const iterator = {
        next: async () => {
            while (true) {
                while (queue.length === 0 && !sourceDone) {
                    const result = await source.next();
                    if (result.done) {
                        sourceDone = true;
                        break;
                    }
                    const meta = getIteratorMeta(source);
                    queue.push({ value: result.value, depth: 0, meta });
                }
                if (queue.length > 0) {
                    const item = options.traversal === 'breadth' ? queue.shift() : queue.pop();
                    await enqueueChildren(item.value, item.depth, item.meta);
                    let value = item.value;
                    if (item.meta) {
                        value = setValueMeta(value, {
                            valueId: item.meta.valueId,
                            ...(item.depth > 0 ? { kind: 'expand' } : {}),
                        }, item.meta.operatorIndex, item.meta.operatorName);
                        setIteratorMeta(iterator, {
                            valueId: item.meta.valueId,
                            ...(item.depth > 0 ? { kind: 'expand' } : {}),
                        }, item.meta.operatorIndex, item.meta.operatorName);
                    }
                    return NEXT(value);
                }
                if (sourceDone && queue.length === 0) {
                    return DONE;
                }
                await new Promise((resolve) => setTimeout(resolve, 0));
            }
        },
    };
    return iterator;
});

/**
 * Creates a stream operator that filters values emitted by the source stream.
 *
 * This operator provides flexible filtering capabilities. It processes each value
 * from the source stream and passes it through to the output stream only if it meets
 * a specific criterion.
 *
 * The filtering can be configured in one of three ways:
 * - A **predicate function**: A function that returns `true` for values to be included.
 * - A **single value**: Only values that are strictly equal (`===`) to this value are included.
 * - An **array of values**: Only values that are present in this array are included.
 *
 * @template T The type of the values in the stream.
 * @param predicateOrValue The filtering criterion. Can be a predicate function, a single value, or an array of values.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const filter = (predicateOrValue) => createOperator('filter', function (source) {
    let index = 0;
    return {
        next: async () => {
            while (true) {
                const result = await source.next();
                if (result.done)
                    return result;
                const value = result.value;
                let shouldInclude = false;
                if (typeof predicateOrValue === 'function') {
                    const predicateResult = predicateOrValue(value, index);
                    shouldInclude = isPromiseLike(predicateResult) ? await predicateResult : predicateResult;
                }
                else if (Array.isArray(predicateOrValue)) {
                    shouldInclude = predicateOrValue.includes(value);
                }
                else {
                    shouldInclude = value === predicateOrValue;
                }
                if (shouldInclude) {
                    index++; // Increment index only if included
                    // If the value passes the filter, return it as a normal IteratorResult.
                    return NEXT(value);
                }
            }
        }
    };
});

/**
 * Creates a stream operator that invokes a finalizer callback upon stream termination.
 *
 * This operator is useful for performing cleanup tasks, such as closing resources
 * or logging, after a stream has completed or encountered an error. The provided
 * `callback` is guaranteed to be called exactly once, regardless of whether the
 * stream terminates gracefully or with an error.
 *
 * @template T The type of the values emitted by the stream.
 * @param callback The function to be called when the stream completes or errors.
 * It can be synchronous or return a Promise.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const finalize = (callback) => {
    // Shared state across all subscriptions - moved outside createOperator
    let finalized = false;
    let completed = false;
    let finalizationPromise = null;
    const doFinalize = async () => {
        if (!finalized) {
            finalized = true;
            completed = true;
            // Create finalization promise if it doesn't exist
            if (!finalizationPromise) {
                finalizationPromise = (async () => {
                    try {
                        await callback?.();
                    }
                    catch {
                        // Swallow errors to avoid affecting downstream consumers
                    }
                })();
            }
            await finalizationPromise;
        }
        else if (finalizationPromise) {
            // Wait for existing finalization to complete
            await finalizationPromise;
        }
    };
    return createOperator("finalize", function (source) {
        const iterator = {
            async next() {
                while (true) {
                    if (completed) {
                        return DONE;
                    }
                    try {
                        const result = await source.next();
                        if (result.done) {
                            await doFinalize();
                            return DONE;
                        }
                        return result;
                    }
                    catch (err) {
                        await doFinalize();
                        throw err;
                    }
                }
            },
            async return(value) {
                await doFinalize();
                if (source.return) {
                    return source.return(value);
                }
                return { done: true, value: undefined };
            },
            async throw(error) {
                await doFinalize();
                if (source.throw) {
                    return source.throw(error);
                }
                throw error;
            }
        };
        return iterator;
    });
};

/**
 * Creates a stream operator that emits only the first element from the source stream
 * that matches an optional predicate.
 *
 * This operator is designed to find a specific value and then immediately terminate.
 * - If a `predicate` function is provided, the operator will emit the first value for which
 * the predicate returns a truthy value.
 * - If no predicate is provided, it will simply emit the very first value from the source.
 *
 * After emitting a single value, the operator completes. If the source stream completes
 * before a matching value is found, an error is thrown.
 *
 * @template T The type of the values in the source stream.
 * @param predicate An optional function to test each value. It receives the value
 * and should return `true` to indicate a match.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 * @throws {Error} Throws an error with the message "No elements in sequence" if no matching
 * value is found before the source stream completes.
 */
const first = (predicate) => createOperator('first', function (source) {
    let found = false;
    let sourceDone = false;
    let stopped = false;
    const stopSource = async () => {
        if (stopped)
            return;
        stopped = true;
        try {
            await source.return?.();
        }
        catch {
        }
    };
    return {
        next: async () => {
            if (found) {
                return DONE;
            }
            if (sourceDone) {
                throw new Error("No elements in sequence");
            }
            while (!found) {
                const result = await source.next();
                if (result.done) {
                    sourceDone = true;
                    await stopSource();
                    throw new Error("No elements in sequence");
                }
                const value = result.value;
                const predicateResult = predicate ? predicate(value) : true;
                const matches = predicate ? (isPromiseLike(predicateResult) ? await predicateResult : predicateResult) : predicateResult;
                if (matches) {
                    found = true;
                    await stopSource();
                    return NEXT(value);
                }
            }
            return DONE;
        },
        return: async () => {
            await stopSource();
            return DONE;
        },
        throw: async (err) => {
            await stopSource();
            throw err;
        },
    };
});

/**
 * Creates a stream operator that routes each source value through a specific handler
 * based on matching predicates defined in the provided `ForkOption`s.
 *
 * For each value from the source stream:
 * 1. Iterates over the `options` array.
 * 2. Executes the `on` predicate for each option until one returns `true`.
 * 3. Calls the corresponding `handler` for the first matching option.
 * 4. Flattens the result (stream, value, promise, or array) sequentially into the output stream.
 *
 * If no predicate matches a value, an error is thrown.
 *
 * This operator allows conditional branching in streams based on the content of each item.
 *
 * @template T The type of values in the source stream.
 * @template R The type of values emitted by the output stream.
 * @param options {@link ForkOption} objects defining predicates and handlers.
 * @returns An {@link Operator} instance suitable for use in a stream's `pipe` method.
 *
 * @throws {Error} If a source value does not match any predicate.
 */
const fork = (...options) => createOperator('fork', function (source) {
    const resolvedOptions = options;
    let outerIndex = 0;
    let innerIterator = null;
    let outerValue;
    let currentMeta;
    const iterator = {
        next: async () => {
            while (true) {
                // If no active inner iterator, get next outer value
                if (!innerIterator) {
                    const result = await source.next();
                    if (result.done) {
                        return DONE;
                    }
                    currentMeta = getIteratorMeta(source);
                    let matched;
                    outerValue = result.value;
                    const currentIndex = outerIndex++;
                    for (const option of resolvedOptions) {
                        const predicateResult = option.on(outerValue, currentIndex);
                        if (isPromiseLike(predicateResult) ? await predicateResult : predicateResult) {
                            matched = option;
                            break;
                        }
                    }
                    if (!matched) {
                        throw new Error(`No handler found for value: ${outerValue}`);
                    }
                    innerIterator = eachValueFrom(fromAny(matched.handler(outerValue)));
                }
                // Pull next inner value
                const innerResult = await innerIterator.next();
                if (innerResult.done) {
                    innerIterator = null;
                    continue;
                }
                if (currentMeta) {
                    // Attach per-value metadata so tracers can attribute outputs even when emitted asynchronously.
                    const tagged = setValueMeta(innerResult.value, { valueId: currentMeta.valueId, kind: "expand" }, currentMeta.operatorIndex, currentMeta.operatorName);
                    setIteratorMeta(iterator, { valueId: currentMeta.valueId, kind: "expand" }, currentMeta.operatorIndex, currentMeta.operatorName);
                    return NEXT(tagged);
                }
                return NEXT(innerResult.value);
            }
        }
    };
    return iterator;
});

/**
 * Creates a stream operator that groups values from the source stream by a computed key.
 *
 * This operator is a projection operator that transforms a stream of values into a
 * stream of `GroupItem` objects. For each value from the source, it applies the
 * `keySelector` function to determine a key and then emits an object containing both
 * the original value and the computed key.
 *
 * This operator is the first step in a typical grouping pipeline. The resulting stream
 * of `GroupItem` objects can then be processed further by other operators (e.g., `scan`
 * or `reduce`) to perform a true grouping into collections.
 *
 * @template T The type of the values in the source stream.
 * @template K The type of the key computed by `keySelector`.
 * @param keySelector A function that takes a value from the source stream and returns
 * a key. This function can be synchronous or asynchronous.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const groupBy = (keySelector) => createOperator("groupBy", function (source) {
    let completed = false;
    return {
        next: async () => {
            while (true) {
                if (completed) {
                    return DONE;
                }
                const result = await source.next();
                if (result.done) {
                    completed = true;
                    return DONE;
                }
                const keyResult = keySelector(result.value);
                const key = isPromiseLike(keyResult) ? await keyResult : keyResult;
                return NEXT({ key, value: result.value });
            }
        }
    };
});

/**
 * Creates a stream operator that ignores all values emitted by the source stream.
 *
 * This operator consumes the source stream but does not emit any values. It only
 * forwards the completion or error signal from the source stream. This is useful
 * when you only care about the "end" of an operation, not the intermediate results.
 * For example, waiting for a stream of side effects to complete before continuing.
 *
 * @template T The type of the values in the source stream (which are ignored).
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const ignoreElements = () => createOperator("ignoreElements", function (source) {
    return {
        next: async () => {
            while (true) {
                const result = await source.next();
                if (result.done) {
                    // If the source is done, we are also done.
                    return DONE;
                }
            }
        }
    };
});

/**
 * Creates a stream operator that emits only the last value from the source stream
 * that matches an optional predicate.
 *
 * This operator must consume the entire source stream to find the last matching
 * value. It caches the last value that satisfies the `predicate` (or the last
 * value of the stream if no predicate is provided) and emits it only when the
 * source stream completes.
 *
 * @template T The type of the values in the source stream.
 * @param predicate An optional function to test each value. It receives the value
 * and should return `true` to indicate a match.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 * @throws {Error} Throws an error with the message "No elements in sequence" if no
 * matching value is found before the source stream completes.
 */
const last = (predicate) => createOperator("last", function (source) {
    let lastValue = undefined;
    let hasMatch = false;
    let finished = false;
    return {
        next: async () => {
            while (true) {
                if (finished)
                    return DONE;
                const result = await source.next();
                if (result.done) {
                    finished = true;
                    if (!hasMatch)
                        throw new Error("No elements in sequence");
                    return NEXT(lastValue);
                }
                const value = result.value;
                const predicateResult = predicate ? predicate(value) : true;
                const matches = predicate ? (isPromiseLike(predicateResult) ? await predicateResult : predicateResult) : predicateResult;
                if (matches) {
                    if (hasMatch) {
                        lastValue = value;
                        continue;
                    }
                    else {
                        lastValue = value;
                        hasMatch = true;
                        continue;
                    }
                }
            }
        }
    };
});

/**
 * Creates a stream operator that applies a transformation function to each value
 * emitted by the source stream.
 *
 * This operator is a fundamental part of stream processing. It consumes each value
 * from the source, passes it to the `transform` function, and then emits the result
 * of that function. This is a one-to-one mapping, meaning the output stream will
 * have the same number of values as the source stream, but with potentially different
 * content and/or type.
 *
 * @template T The type of the values in the source stream.
 * @template R The type of the values in the output stream.
 * @param transform The transformation function to apply to each value. It receives
 * the value and its index. This function can be synchronous or asynchronous.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const map = (transform) => createOperator('map', function (source) {
    let index = 0;
    let completed = false;
    return {
        async next() {
            while (true) {
                if (completed) {
                    return DONE;
                }
                const result = await source.next();
                if (result.done) {
                    completed = true;
                    return DONE;
                }
                const transformedResult = transform(result.value, index++);
                const transformedValue = isPromiseLike(transformedResult) ? await transformedResult : transformedResult;
                return NEXT(transformedValue);
            }
        },
    };
});

/**
 * Creates a stream operator that maps each value from the source stream to an "inner" stream
 * and merges all inner streams concurrently into a single output stream.
 *
 * For each value from the source stream:
 * 1. The `project` function is called with the value and its index.
 * 2. The returned value is normalized into a stream using {@link fromAny}.
 * 3. The inner stream is consumed concurrently with all other active inner streams.
 * 4. Emitted values from all inner streams are interleaved into the output stream
 *    in the order they are produced, without waiting for other inner streams to complete.
 *
 * This operator is useful for performing parallel asynchronous operations while
 * preserving all emitted values in a merged output.
 *
 * @template T The type of values in the source stream.
 * @template R The type of values emitted by the inner and output streams.
 * @param project A function that maps a source value and its index to either:
 *   - a {@link Stream<R>},
 *   - a {@link MaybePromise<R>} (value or promise),
 *   - or an array of `R`.
 * @returns An {@link Operator} instance that can be used in a stream's `pipe` method.
 */
function mergeMap(project) {
    return createOperator('mergeMap', function (source) {
        const output = createSubject();
        const outputIterator = eachValueFrom(output);
        let index = 0;
        let activeInner = 0;
        let outerCompleted = false;
        let errorOccurred = false;
        let stopped = false;
        const activeInnerIterators = new Set();
        // Process each inner stream concurrently.
        const processInner = async (innerStream, parentMeta) => {
            const innerIt = innerStream[Symbol.asyncIterator]();
            activeInnerIterators.add(innerIt);
            try {
                while (!stopped) {
                    const r = await innerIt.next();
                    if (r.done)
                        break;
                    if (stopped || errorOccurred)
                        break;
                    let value = r.value;
                    if (parentMeta) {
                        setIteratorMeta(outputIterator, { valueId: parentMeta.valueId, kind: "expand" }, parentMeta.operatorIndex, parentMeta.operatorName);
                        value = setValueMeta(value, { valueId: parentMeta.valueId, kind: "expand" }, parentMeta.operatorIndex, parentMeta.operatorName);
                    }
                    output.next(value);
                }
            }
            catch (err) {
                if (!errorOccurred) {
                    errorOccurred = true;
                    output.error(err);
                }
            }
            finally {
                activeInnerIterators.delete(innerIt);
                activeInner--;
                if (outerCompleted && activeInner === 0 && !errorOccurred) {
                    output.complete();
                }
            }
        };
        (async () => {
            try {
                while (!stopped) {
                    const result = await source.next();
                    if (result.done)
                        break;
                    if (errorOccurred)
                        break;
                    const projected = project(result.value, index++);
                    // IMPORTANT: do NOT await promises here; each projected value/promise/stream
                    // should start concurrently.
                    const inner = fromAny(projected);
                    const parentMeta = getIteratorMeta(source);
                    activeInner++;
                    processInner(inner, parentMeta);
                }
                outerCompleted = true;
                if (activeInner === 0 && !errorOccurred) {
                    output.complete();
                }
            }
            catch (err) {
                if (!errorOccurred) {
                    errorOccurred = true;
                    output.error(err);
                }
            }
        })();
        const baseReturn = outputIterator.return?.bind(outputIterator);
        const baseThrow = outputIterator.throw?.bind(outputIterator);
        outputIterator.return = async () => {
            stopped = true;
            try {
                try {
                    await source.return?.();
                }
                catch { }
                for (const it of activeInnerIterators) {
                    try {
                        await it.return?.();
                    }
                    catch { }
                }
                activeInnerIterators.clear();
            }
            finally {
                return baseReturn ? baseReturn(undefined) : { done: true, value: undefined };
            }
        };
        outputIterator.throw = async (err) => {
            stopped = true;
            try {
                try {
                    await source.return?.();
                }
                catch { }
                for (const it of activeInnerIterators) {
                    try {
                        await it.return?.();
                    }
                    catch { }
                }
                activeInnerIterators.clear();
            }
            finally {
                if (baseThrow)
                    return baseThrow(err);
            }
            throw err;
        };
        return outputIterator;
    });
}

/**
 * Creates a stream operator that schedules the emission of each value from the source
 * stream on a specified JavaScript task queue.
 *
 * This operator is a scheduler. It decouples the timing of value production from
 * its consumption, allowing you to control when values are emitted to downstream
 * operators. This is essential for preventing long-running synchronous operations
 * from blocking the main thread and for prioritizing different types of work.
 *
 * The operator supports three contexts:
 * - `"microtask"`: Emits the value at the end of the current task using `queueMicrotask`.
 * - `"macrotask"`: Emits the value in the next event loop cycle using `setTimeout(0)`.
 * - `"idle"`: Emits the value when the browser is idle using `requestIdleCallback`.
 *
 * @template T The type of the values in the source and output streams.
 * @param context The JavaScript task queue context to schedule emissions on.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
/**
 * Creates a stream operator that schedules the emission of each value from the source
 * stream on a specified JavaScript task queue.
 *
 * This operator is a scheduler. It decouples the timing of value production from
 * its consumption, allowing you to control when values are emitted to downstream
 * operators. This is essential for preventing long-running synchronous operations
 * from blocking the main thread and for prioritizing different types of work.
 *
 * The operator supports three contexts:
 * - `"microtask"`: Emits the value at the end of the current task using `queueMicrotask`.
 * - `"macrotask"`: Emits the value in the next event loop cycle using `setTimeout(0)`.
 * - `"idle"`: Emits the value when the browser is idle using `requestIdleCallback`.
 *
 * @template T The type of the values in the source and output streams.
 * @param context The JavaScript task queue context to schedule emissions on.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const observeOn = (context) => {
    return createOperator('observeOn', function (source) {
        const output = createSubject();
        const outputIterator = eachValueFrom(output);
        const scheduledPromises = [];
        (async () => {
            try {
                const contextValue = isPromiseLike(context) ? await context : context;
                const schedule = contextValue === 'microtask'
                    ? (fn) => queueMicrotask(fn)
                    : contextValue === 'macrotask'
                        ? (fn) => setTimeout(fn, 0)
                        : (fn) => requestIdleCallback(fn);
                while (true) {
                    const result = await source.next();
                    if (result.done)
                        break;
                    const meta = getIteratorMeta(source);
                    const p = new Promise((resolve) => {
                        schedule(() => {
                            try {
                                let value = result.value;
                                if (meta) {
                                    setIteratorMeta(outputIterator, { valueId: meta.valueId }, meta.operatorIndex, meta.operatorName);
                                    value = setValueMeta(value, { valueId: meta.valueId }, meta.operatorIndex, meta.operatorName);
                                }
                                output.next(value);
                            }
                            finally {
                                resolve();
                            }
                        });
                    });
                    scheduledPromises.push(p);
                }
                // Wait for all scheduled emissions before completing
                await Promise.all(scheduledPromises);
            }
            catch (err) {
                output.error(err);
            }
            finally {
                if (!output.completed())
                    output.complete();
            }
        })();
        let completed = false;
        return {
            async next() {
                while (true) {
                    if (completed)
                        return DONE;
                    const result = await outputIterator.next();
                    if (result.done) {
                        completed = true;
                        return DONE;
                    }
                    return { type: 'next', value: result.value };
                }
            }
        };
    });
};

/**
 * Creates a stream operator that partitions the source stream into two groups based on a predicate.
 *
 * This operator is a specialized form of `groupBy`. For each value from the source stream,
 * it applies the provided `predicate` function. It then emits a new object, a `GroupItem`,
 * containing the original value and a key of `"true"` or `"false"`, indicating whether the
 * value satisfied the predicate.
 *
 * This operator does not create two physical streams, but rather tags each item with its
 * group membership, allowing for subsequent conditional routing or processing.
 *
 * @template T The type of the values in the source stream.
 * @param predicate A function that takes a value and its index and returns a boolean or
 * `Promise<boolean>`. `true` for one group, `false` for the other.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method,
 * emitting objects of type `GroupItem<T, "true" | "false">`.
 */
const partition = (predicate) => createOperator('partition', function (source) {
    let index = 0;
    let completed = false;
    return {
        next: async () => {
            while (true) {
                if (completed) {
                    return DONE;
                }
                const result = await source.next();
                if (result.done) {
                    completed = true;
                    return DONE;
                }
                const predicateResult = predicate(result.value, index++);
                const key = (isPromiseLike(predicateResult) ? await predicateResult : predicateResult) ? "true" : "false";
                return NEXT({ key, value: result.value });
            }
        }
    };
});

/**
 * Creates a stream operator that accumulates all values from the source stream
 * into a single value using a provided accumulator function.
 *
 * This operator consumes the source lazily and emits intermediate values as phantoms.
 * It will always emit at least the seed value if the stream is empty.
 *
 * @template T The type of the values in the source stream.
 * @template A The type of the accumulated value.
 * @param accumulator Function combining current accumulated value with a new value.
 * Can be synchronous or asynchronous.
 * @param seed Initial value for the accumulator.
 * @returns An `Operator` instance usable in a stream's `pipe` method.
 */
const reduce = (accumulator, seed) => createOperator("reduce", function (source) {
    let finalValue = seed;
    let emittedFinal = false;
    return {
        next: async () => {
            while (true) {
                const result = await source.next();
                if (result.done) {
                    if (!emittedFinal) {
                        emittedFinal = true;
                        return NEXT(finalValue);
                    }
                    return DONE;
                }
                const accumulated = accumulator(finalValue, result.value);
                finalValue = isPromiseLike(accumulated) ? await accumulated : accumulated;
            }
        },
    };
});

/**
 * Creates a stream operator that emits the most recent value from the source stream
 * at a fixed periodic interval while tracking pending and phantom states.
 *
 * Values that arrive faster than the period are considered phantoms if skipped,
 * and pending results are tracked in PipeContext until resolved or emitted.
 *
 * @template T The type of the values in the source and output streams.
 * @param period The time in milliseconds between each emission.
 * @returns An Operator instance for use in a stream's `pipe` method.
 */
const sample = (period) => createOperator('sample', function (source) {
    const output = createSubject();
    const outputIterator = eachValueFrom(output);
    let lastResult;
    let skipped = false;
    let intervalId = null;
    let resolvedPeriod = undefined;
    const startSampling = () => {
        if (resolvedPeriod === undefined) {
            return;
        }
        intervalId = setInterval(async () => {
            if (!lastResult)
                return;
            if (!skipped) {
                const value = lastResult.value;
                // Emit value directly - tracer tracks it via inputQueue
                output.next(value);
            }
            skipped = true;
        }, resolvedPeriod);
    };
    const stopSampling = () => {
        if (intervalId !== null)
            clearInterval(intervalId);
        intervalId = null;
    };
    (async () => {
        try {
            resolvedPeriod = isPromiseLike(period) ? await period : period;
            startSampling();
            while (true) {
                const result = await source.next();
                if (result.done)
                    break;
                getIteratorMeta(source);
                lastResult = result;
                skipped = false;
            }
            // Emit final value
            if (lastResult) {
                const value = lastResult.value;
                // Emit value directly - tracer tracks it via inputQueue
                output.next(value);
            }
        }
        catch (err) {
            output.error(err);
        }
        finally {
            stopSampling();
            if (!output.completed())
                output.complete();
        }
    })();
    return outputIterator;
});

/**
 * Creates a stream operator that accumulates values from the source stream,
 * emitting each intermediate accumulated result.
 *
 * This operator is stateful and is ideal for scenarios where you need to maintain
 * a running total or build a state object over the life of a stream. It takes a
 * `seed` value and an `accumulator` function. For each value from the source,
 * it applies the accumulator and emits the new result immediately.
 *
 * @template T The type of the values in the source stream.
 * @template R The type of the accumulated value and the output stream.
 * @param accumulator The function that combines the current accumulated value
 * with the new value from the source. This function can be synchronous or asynchronous.
 * @param seed The initial value for the accumulator.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const scan = (accumulator, seed) => createOperator("scan", function (source) {
    let acc = seed;
    let index = 0;
    let completed = false;
    return {
        next: async () => {
            while (true) {
                if (completed) {
                    return DONE;
                }
                const result = await source.next();
                if (result.done) {
                    completed = true;
                    return DONE;
                }
                const accumulated = accumulator(acc, result.value, index++);
                acc = isPromiseLike(accumulated) ? await accumulated : accumulated;
                return NEXT(acc);
            }
        },
    };
});

/**
 * Creates a stream operator that emits only the values at the specified indices from a source stream.
 *
 * This operator takes an `indexIterator` (which can be a synchronous or asynchronous iterator
 * of numbers) and uses it to determine which values from the source stream should be emitted.
 * It acts as a positional filter: each source value is inspected once, and if its zero-based
 * index matches the next index yielded by `indexIterator`, that value is emitted. No buffering
 * of past values occurs. If the iterator completes, the operator completes regardless of
 * remaining source values.
 *
 * @template T The type of the values in the source and output streams.
 * @param indexIterator An iterator or async iterator that provides the zero-based indices
 * of the elements to be emitted.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const select = (indexIterator) => createOperator("select", function (source) {
    function toAsyncIterator(iter) {
        if (typeof iter[Symbol.asyncIterator] === "function") {
            return iter;
        }
        const syncIter = iter;
        return {
            async next() {
                return syncIter.next();
            },
            [Symbol.asyncIterator]() {
                return this;
            }
        };
    }
    const asyncIndexIterator = toAsyncIterator(indexIterator);
    async function* generator() {
        let currentIndex = 0;
        let nextTargetIndexPromise = asyncIndexIterator.next();
        while (true) {
            const result = await source.next();
            if (result.done)
                break;
            const targetIndexResult = await nextTargetIndexPromise;
            if (targetIndexResult.done)
                return;
            const nextTargetIndex = targetIndexResult.value;
            if (currentIndex === nextTargetIndex) {
                yield result.value;
                // fetch next target index
                nextTargetIndexPromise = asyncIndexIterator.next();
            }
            currentIndex++;
        }
    }
    // Return the async iterator directly - operators work with AsyncIterator<T>
    return generator();
});

/**
 * Shares a single subscription to the source stream between multiple consumers.
 *
 * This operator multicasts the upstream iterator through an internal subject so
 * that every subsequent consumer receives the same values without re-running the source.
 * The subject does not replay values for late subscribers; they receive only values
 * emitted after they subscribe.
 *
 * @template T Value type in the shared stream.
 * @returns An operator that can be inserted into a pipeline to share the source.
 */
function share() {
    let shared;
    let isConnected = false;
    const connect = (source) => {
        isConnected = true;
        (async () => {
            try {
                while (true) {
                    const result = await source.next();
                    if (result.done)
                        break;
                    shared.next(result.value);
                }
            }
            catch (err) {
                shared.error(err);
                return;
            }
            finally {
                if (shared && !shared.completed())
                    shared.complete();
            }
        })();
    };
    return createOperator('share', function (source) {
        if (!shared)
            shared = createSubject();
        if (!isConnected) {
            connect(source);
        }
        else if (typeof source.return === "function") {
            // Each `for await` on the piped stream creates a fresh upstream iterator.
            // Once we're connected, we must close these unused iterators immediately,
            // otherwise they remain subscribed and can backpressure the shared source.
            Promise.resolve(source.return()).catch(() => { });
        }
        return eachValueFrom(shared);
    });
}

/**
 * Creates a stream operator that shares a single subscription to the source stream
 * and replays a specified number of past values to new subscribers.
 *
 * This operator multicasts the source stream, ensuring that multiple downstream
 * consumers can receive values from a single source connection. It uses an internal
 * `ReplaySubject` to cache the most recent values. When a new consumer subscribes,
 * it immediately receives these cached values before receiving new ones.
 *
 * This is useful for:
 * - Preventing redundant execution of a source stream (e.g., a network request).
 * - Providing a "state history" to late subscribers.
 *
 * @template T The type of the values in the stream.
 * @param bufferSize The number of last values to replay to new subscribers. Defaults to `Infinity`.
 *                   Can be a Promise that resolves to a number.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
function shareReplay(bufferSize = Infinity) {
    let isConnected = false;
    let output;
    let resolvedSize;
    const isSync = !isPromiseLike(bufferSize);
    if (isSync) {
        resolvedSize = bufferSize;
    }
    const connectSource = (source) => {
        isConnected = true;
        (async () => {
            try {
                while (true) {
                    const result = await source.next();
                    if (result.done)
                        break;
                    output.next(result.value);
                }
            }
            catch (err) {
                output.error(err);
            }
            finally {
                if (output && !output.completed())
                    output.complete();
            }
        })();
    };
    return createOperator('shareReplay', function (source) {
        // Short path: plain value, return synchronously
        if (isSync) {
            if (!output)
                output = createReplaySubject(resolvedSize);
            if (!isConnected)
                connectSource(source);
            else if (typeof source.return === "function") {
                Promise.resolve(source.return()).catch(() => { });
            }
            return eachValueFrom(output);
        }
        // Long path: Promise, wrap in async generator
        return (async function* () {
            if (resolvedSize === undefined) {
                resolvedSize = await bufferSize;
            }
            if (!output)
                output = createReplaySubject(resolvedSize);
            if (!isConnected)
                connectSource(source);
            else if (typeof source.return === "function") {
                Promise.resolve(source.return()).catch(() => { });
            }
            yield* eachValueFrom(output);
        })();
    });
}

/**
 * Creates a stream operator that skips the first specified number of values from the source stream.
 *
 * This operator is useful for "fast-forwarding" a stream. It consumes the initial `count` values
 * from the source stream without emitting them to the output. Once the count is reached,
 * it begins to pass all subsequent values through unchanged.
 *
 * @template T The type of the values in the source and output streams.
 * @param count The number of values to skip from the beginning of the stream.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const skip = (count) => createOperator('skip', function (source) {
    let counter;
    const getCounter = () => {
        if (counter !== undefined) {
            return counter;
        }
        if (isPromiseLike(count)) {
            return count.then((val) => {
                counter = val;
                return val;
            });
        }
        counter = count;
        return counter;
    };
    return {
        next: async () => {
            while (true) {
                const result = await source.next();
                if (result.done)
                    return DONE;
                const counterOrPromise = getCounter();
                const currentCounter = isPromiseLike(counterOrPromise) ? await counterOrPromise : counterOrPromise;
                if (currentCounter > 0) {
                    counter = currentCounter - 1;
                    continue;
                }
                return NEXT(result.value);
            }
        },
    };
});

/**
 * Skip source values until a notifier emits.
 *
 * `skipUntil` suppresses (drops) source values until the provided `notifier`
 * produces its first emission. After the notifier emits, subsequent source
 * values are forwarded normally. Uses stamp-based filtering to ensure correct
 * ordering between notifier and source events.
 *
 * Important details:
 * - Ordering and stamps: when the gate opens (notifier emits) only source
 *   values whose stamp is strictly greater than the gate-opening stamp will be
 *   forwarded. This prevents forwarding values that were logically emitted
 *   before or concurrently with the notifier signal.
 * - Notifier completion without emission: if the notifier completes without
 *   emitting, the operator remains closed and continues to drop source values.
 * - Error propagation: errors from either the notifier or source are propagated
 *   to the output and will terminate the subscription.
 *
 * Common uses:
 * - Ignore initial values until a readiness signal arrives.
 * - Wait for user interaction before processing inputs.
 *
 * @template T Source/output value type.
 * @template R Notifier value type (ignored by this operator).
 * @param notifier A `Stream<R>` or `Promise<R>` that opens the gate when it emits.
 * @returns An `Operator<T, T>` that drops source values until the notifier emits.
 */
function skipUntil(notifier) {
    return createOperator("skipUntil", (sourceIt) => {
        const notifierIt = fromAny(notifier)[Symbol.asyncIterator]();
        let gateStamp = null;
        let notifierError = null;
        const stampOf = (it) => {
            const s = getIteratorEmissionStamp(it);
            return typeof s === "number" ? s : nextEmissionStamp();
        };
        // Observe notifier exactly once
        (async () => {
            try {
                const r = await notifierIt.next();
                const stamp = stampOf(notifierIt);
                if (!r.done) {
                    gateStamp = stamp;
                }
            }
            catch (err) {
                notifierError = err;
                try {
                    await sourceIt.return?.();
                }
                catch { }
            }
            finally {
                try {
                    await notifierIt.return?.();
                }
                catch { }
            }
        })();
        const iterator = {
            async next() {
                while (true) {
                    if (notifierError)
                        throw notifierError;
                    const r = await sourceIt.next();
                    const stamp = stampOf(sourceIt);
                    if (r.done) {
                        if (notifierError)
                            throw notifierError;
                        return { done: true, value: undefined };
                    }
                    // Gate closed: drop values until notifier emits.
                    if (gateStamp === null) {
                        continue;
                    }
                    // Only forward values strictly after the gate-opening stamp.
                    if (stamp <= gateStamp) {
                        continue;
                    }
                    setIteratorEmissionStamp(iterator, stamp);
                    return { done: false, value: r.value };
                }
            },
            async return() {
                try {
                    await sourceIt.return?.();
                }
                catch { }
                try {
                    await notifierIt.return?.();
                }
                catch { }
                return { done: true, value: undefined };
            },
            async throw(err) {
                try {
                    await sourceIt.return?.();
                }
                catch { }
                try {
                    await notifierIt.return?.();
                }
                catch { }
                throw err;
            },
        };
        return iterator;
    });
}

/**
 * Creates a stream operator that skips values from the source stream while a predicate returns true.
 *
 * This operator is a powerful filtering tool for removing a contiguous prefix of a stream.
 * It consumes values from the source and applies the `predicate` function to each one.
 * As long as the predicate returns `true`, the values are ignored. As soon as the predicate
 * returns `false` for the first time, this operator begins to emit that value and all
 * subsequent values from the source, regardless of whether they satisfy the predicate.
 *
 * @template T The type of the values in the source and output streams.
 * @param predicate The function to test each value. Receives the value and its index. `true` means to continue skipping,
 * and `false` means to stop skipping and begin emitting.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const skipWhile = (predicate) => createOperator('skipWhile', function (source) {
    let skipping = true;
    let index = 0;
    return {
        next: async () => {
            while (true) {
                const result = await source.next();
                if (result.done)
                    return DONE;
                if (skipping) {
                    const predicateResult = predicate(result.value, index++);
                    const shouldSkip = isPromiseLike(predicateResult) ? await predicateResult : predicateResult;
                    if (!shouldSkip) {
                        skipping = false;
                        return NEXT(result.value);
                    }
                    // Still skipping, ignore this value
                }
                else {
                    index++;
                    return NEXT(result.value);
                }
            }
        }
    };
});

/**
 * Creates a stream operator that emits pairs of values from the source stream,
 * where each pair consists of the previous and the current value.
 *
 * This operator is a powerful tool for comparing consecutive values in a stream.
 * It maintains an internal state to remember the last value it received. For
 * each new value, it creates a tuple of `[previousValue, currentValue]` and
 * emits it to the output stream.
 *
 * The very first value emitted will have `undefined` as its "previous" value.
 *
 * @template T The type of the values in the source stream.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method,
 * emitting tuples of `[T | undefined, T]`.
 */
const slidingPair = () => createOperator('slidingPair', function (source) {
    let prev = undefined;
    let first = true;
    let completed = false;
    return {
        next: async () => {
            while (true) {
                if (completed) {
                    return DONE;
                }
                const result = await source.next();
                if (result.done) {
                    completed = true;
                    return DONE;
                }
                const value = [first ? undefined : prev, result.value];
                prev = result.value;
                first = false;
                return NEXT(value);
            }
        }
    };
});

/**
 * Creates a stream operator that prepends a specified value to the beginning of the stream.
 *
 * The operator first emits the `initialValue` immediately upon being iterated.
 * After this initial emission, it begins to pull and emit values from the
 * source stream as they become available.
 *
 * @template T The type of the values in the stream.
 * @param initialValue The value to be emitted as the first item in the stream.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const startWith = (initialValue) => createOperator("startWith", function (source) {
    let emittedInitial = false;
    let completed = false;
    const initialValuePromise = Promise.resolve(initialValue);
    return {
        next: async () => {
            while (true) {
                if (completed) {
                    return DONE;
                }
                if (!emittedInitial) {
                    emittedInitial = true;
                    return NEXT(await initialValuePromise);
                }
                const result = await source.next();
                if (result.done) {
                    completed = true;
                    return DONE;
                }
                return result;
            }
        }
    };
});

/**
 * Projects each source value to a Stream which is merged into the output Stream,
 * emitting values only from the most recently projected Stream.
 */
function switchMap(project) {
    return createOperator("switchMap", function (source) {
        const output = createSubject();
        const outputIterator = eachValueFrom(output);
        let currentInner = null;
        let inputCompleted = false;
        let currentInnerStreamId = 0;
        let index = 0;
        let stopped = false;
        /**
         * Checks if the overall operator should complete.
         * Only completes if the source is done AND no inner stream is active.
         */
        const checkComplete = () => {
            if (inputCompleted && !currentInner) {
                output.complete();
            }
        };
        const subscribeToInner = (innerStream, streamId, parentMeta) => {
            // Cancel the previous inner immediately so sync inner streams can't
            // interleave emissions out-of-order via re-entrant scheduler execution.
            const prev = currentInner;
            if (prev) {
                try {
                    void prev.it.return?.();
                }
                catch { }
            }
            const it = innerStream[Symbol.asyncIterator]();
            currentInner = { id: streamId, it };
            void (async () => {
                try {
                    while (!stopped && streamId === currentInnerStreamId) {
                        const r = await it.next();
                        const stamp = getIteratorEmissionStamp(it) ?? nextEmissionStamp();
                        if (r.done)
                            break;
                        if (stopped || streamId !== currentInnerStreamId)
                            break;
                        const operatorIndex = this.index ?? 0;
                        const operatorName = "switchMap";
                        let outputValue = r.value;
                        if (parentMeta) {
                            setIteratorMeta(outputIterator, { valueId: parentMeta.valueId, kind: "expand" }, operatorIndex, operatorName);
                            outputValue = setValueMeta(outputValue, { valueId: parentMeta.valueId, kind: "expand" }, operatorIndex, operatorName);
                        }
                        // Ensure downstream subject emissions carry the inner iterator stamp.
                        withEmissionStamp(stamp, () => {
                            setIteratorEmissionStamp(outputIterator, stamp);
                            output.next(outputValue);
                        });
                    }
                }
                catch (err) {
                    if (!stopped && streamId === currentInnerStreamId) {
                        output.error(err);
                    }
                }
                finally {
                    if (currentInner?.id === streamId) {
                        currentInner = null;
                    }
                    checkComplete();
                }
            })();
        };
        const processOuterValue = (value) => {
            const streamId = ++currentInnerStreamId;
            const parentMeta = getIteratorMeta(source);
            let projected;
            try {
                projected = project(value, index++);
            }
            catch (err) {
                output.error(err);
                return;
            }
            if (isPromiseLike(projected)) {
                const capturedId = streamId;
                Promise.resolve(projected).then((normalized) => {
                    if (stopped || capturedId !== currentInnerStreamId)
                        return;
                    subscribeToInner(fromAny(normalized), capturedId, parentMeta);
                }, (err) => {
                    if (stopped || capturedId !== currentInnerStreamId)
                        return;
                    output.error(err);
                });
            }
            else {
                subscribeToInner(fromAny(projected), streamId, parentMeta);
            }
        };
        const tryNext = source.__tryNext;
        if (typeof tryNext === "function") {
            const drain = () => {
                while (!stopped) {
                    let result;
                    try {
                        result = tryNext.call(source);
                    }
                    catch (err) {
                        output.error(err);
                        return;
                    }
                    if (!result)
                        return;
                    if (result.done) {
                        inputCompleted = true;
                        checkComplete();
                        return;
                    }
                    processOuterValue(result.value);
                }
            };
            source.__onPush = drain;
            drain();
        }
        else {
            (async () => {
                try {
                    while (!stopped) {
                        const result = await source.next();
                        if (result.done)
                            break;
                        processOuterValue(result.value);
                    }
                    inputCompleted = true;
                    checkComplete();
                }
                catch (err) {
                    output.error(err);
                }
            })();
        }
        const baseReturn = outputIterator.return?.bind(outputIterator);
        const baseThrow = outputIterator.throw?.bind(outputIterator);
        outputIterator.return = async () => {
            stopped = true;
            try {
                try {
                    await currentInner?.it.return?.();
                }
                catch { }
            }
            finally {
                currentInner = null;
            }
            return baseReturn ? baseReturn(undefined) : { done: true, value: undefined };
        };
        outputIterator.throw = async (err) => {
            stopped = true;
            try {
                try {
                    await currentInner?.it.return?.();
                }
                catch { }
            }
            finally {
                currentInner = null;
            }
            if (baseThrow)
                return baseThrow(err);
            throw err;
        };
        return outputIterator;
    });
}

/**
 * Creates a stream operator that emits only the first `count` values from the source stream
 * and then completes.
 *
 * This operator is a powerful tool for controlling the length of a stream. It consumes values
 * from the source one by one, and as long as the total number of values emitted is less than
 * `count`, it passes them through to the output. Once the count is reached, it stops
 * processing the source and signals completion to its downstream consumers. This is especially
 * useful for managing finite segments of large or infinite streams.
 *
 * @template T The type of the values in the source and output streams.
 * @param count The maximum number of values to take from the beginning of the stream.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const take = (count) => createOperator("take", function (source) {
    let emitted = 0;
    let done = false;
    let resolvedCount;
    const getCount = () => {
        if (resolvedCount !== undefined) {
            return resolvedCount;
        }
        if (isPromiseLike(count)) {
            return count.then((val) => {
                resolvedCount = val;
                return val;
            });
        }
        resolvedCount = count;
        return resolvedCount;
    };
    return {
        next: async () => {
            while (true) {
                if (done) {
                    return DONE;
                }
                const result = await source.next();
                if (result.done) {
                    done = true;
                    return DONE;
                }
                emitted++;
                const countOrPromise = getCount();
                const limit = isPromiseLike(countOrPromise) ? await countOrPromise : countOrPromise;
                if (emitted > limit) {
                    done = true;
                    return DONE;
                }
                return NEXT(result.value);
            }
        },
    };
});

/**
 * Complete the output when a notifier emits.
 *
 * `takeUntil` subscribes to the provided `notifier` (a `Stream` or `Promise`) and
 * completes the output iterator as soon as the notifier produces its first
 * emission. Ordering between notifier and source values is managed using
 * emission stamps so that values from the source that are stamped at or after
 * the notifier emission will not be forwarded.
 *
 * Semantics and edge cases:
 * - Notifier emits: the operator records the notifier's emission stamp and
 *   cancels the source. Any source value whose stamp is greater than or equal
 *   to the notifier stamp is considered after the notifier and will not be
 *   emitted.
 * - Notifier errors: if the notifier throws before the next source value is
 *   emitted, the error is propagated immediately. If the notifier errors after
 *   a source value has been pulled, the operator will yield that pulled value
 *   first and then throw the notifier error on the subsequent pull.
 * - Notifier completes without emitting: the operator keeps forwarding source
 *   values normally (i.e. it stays open).
 *
 * Use-cases:
 * - Stop processing a stream when an external cancellation/timeout signal fires.
 *
 * @template T Source/output value type.
 * @param notifier A `Stream<any>` or `Promise<any>` whose first emission
 *        triggers completion of the output.
 * @returns An `Operator<T, T>` that completes when the notifier emits.
 */
function takeUntil(notifier) {
    return createOperator("takeUntil", (sourceIt) => {
        const notifierIt = fromAny(notifier)[Symbol.asyncIterator]();
        let gateStamp = null; // ONLY for notifier emit
        let notifierError = null;
        let notifierErrorStamp = null;
        let pending = null;
        const stampOf = (it) => {
            const s = getIteratorEmissionStamp(it);
            return typeof s === "number" ? s : nextEmissionStamp();
        };
        // Observe notifier exactly once
        (async () => {
            try {
                const r = await notifierIt.next();
                const stamp = stampOf(notifierIt);
                if (!r.done) {
                    // notifier EMIT → gate + cancel source
                    gateStamp = stamp;
                    try {
                        await sourceIt.return?.();
                    }
                    catch { }
                }
            }
            catch (err) {
                // notifier ERROR → NO source cancellation
                notifierError = err;
                notifierErrorStamp = stampOf(notifierIt);
            }
            finally {
                try {
                    await notifierIt.return?.();
                }
                catch { }
            }
        })();
        const tryDrainBufferedValue = () => {
            const tryNext = sourceIt.__tryNext;
            if (typeof tryNext === "function") {
                try {
                    return tryNext.call(sourceIt);
                }
                catch {
                    return null;
                }
            }
            return null;
        };
        const iterator = {
            async next() {
                while (true) {
                    // 1) deliver buffered value
                    if (pending) {
                        const { value, stamp } = pending;
                        pending = null;
                        setIteratorEmissionStamp(iterator, stamp);
                        return { done: false, value };
                    }
                    // 2) notifier ERROR: flush buffered source values that happened
                    // before the notifier error stamp, then throw.
                    if (notifierError) {
                        const buffered = tryDrainBufferedValue();
                        if (buffered && !buffered.done) {
                            const stamp = stampOf(sourceIt);
                            if (notifierErrorStamp === null || stamp < notifierErrorStamp) {
                                setIteratorEmissionStamp(iterator, stamp);
                                return { done: false, value: buffered.value };
                            }
                        }
                        throw notifierError;
                    }
                    // 3) pull source
                    const r = await sourceIt.next();
                    const stamp = stampOf(sourceIt);
                    if (r.done) {
                        if (notifierError)
                            throw notifierError;
                        return { done: true, value: undefined };
                    }
                    // 4) gate ONLY on notifier emit
                    if (gateStamp !== null && stamp >= gateStamp) {
                        return { done: true, value: undefined };
                    }
                    // 5) notifier errored AFTER pull → yield value, then error
                    if (notifierError) {
                        if (notifierErrorStamp === null || stamp < notifierErrorStamp) {
                            pending = { value: r.value, stamp };
                            continue;
                        }
                        throw notifierError;
                    }
                    // 6) normal path
                    setIteratorEmissionStamp(iterator, stamp);
                    return { done: false, value: r.value };
                }
            },
            async return() {
                try {
                    await sourceIt.return?.();
                }
                catch { }
                try {
                    await notifierIt.return?.();
                }
                catch { }
                pending = null;
                return { done: true, value: undefined };
            },
            async throw(err) {
                try {
                    await sourceIt.return?.();
                }
                catch { }
                try {
                    await notifierIt.return?.();
                }
                catch { }
                pending = null;
                throw err;
            },
        };
        return iterator;
    });
}

/**
 * Creates a stream operator that emits values from the source stream as long as
 * a predicate returns true.
 *
 * This operator is a conditional limiter. It consumes values from the source stream
 * and applies the `predicate` function to each. As long as the predicate returns `true`,
 * the value is passed through to the output stream. The first time the predicate returns
 * a falsy value, the operator stops emitting and immediately completes the output stream.
 * The value that caused the predicate to fail is not emitted.
 *
 * This is useful for taking a contiguous block of data from a stream that meets a certain
 * condition, such as processing user input until an invalid entry is made.
 *
 * @template T The type of the values in the source and output streams.
 * @param predicate The function to test each value. Receives the value and its index. `true` means to continue emitting,
 * and `false` means to stop and complete. It can be synchronous or asynchronous.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const takeWhile = (predicate) => createOperator("takeWhile", function (source) {
    let active = true;
    let index = 0;
    return {
        next: async () => {
            if (!active) {
                return DONE;
            }
            const result = await source.next();
            if (result.done)
                return DONE;
            const predicateResult = predicate(result.value, index++);
            const pass = isPromiseLike(predicateResult) ? await predicateResult : predicateResult;
            if (!pass) {
                active = false;
                return DONE;
            }
            return NEXT(result.value);
        },
    };
});

/**
 * Creates a stream operator that performs a side-effect for each value from the source
 * stream without modifying the value.
 *
 * This operator is primarily used for debugging, logging, or other non-intrusive
 * actions that need to be performed on each value as it passes through the pipeline.
 * It is completely transparent to the data stream itself, as it does not transform,
 * filter, or buffer the values. The provided `tapFunction` is executed for each
 * value before the value is emitted to the next operator.
 *
 * @template T The type of the values in the source and output streams.
 * @param tapFunction The function to perform the side-effect. It receives the value
 * from the stream and can be synchronous or asynchronous.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const tap = (tapFunction) => createOperator('tap', function (source) {
    return {
        next: async () => {
            while (true) {
                const result = await source.next();
                if (result.done)
                    return result;
                const tapResult = tapFunction(result.value); // side-effect
                if (isPromiseLike(tapResult)) {
                    await tapResult;
                }
                return result;
            }
        }
    };
});

/**
 * Creates a throttle operator that emits the first value immediately, then ignores subsequent
 * values for the specified duration. If new values arrive during the cooldown, the
 * last one is emitted after the cooldown expires (trailing emit).
 *
 * This version tracks pending results and phantoms in PipeContext.
 *
 * @template T The type of values emitted by the source and output.
 * @param duration The throttle duration in milliseconds.
 * @returns An Operator instance that applies throttling to the source stream.
 */
const throttle = (duration) => createOperator('throttle', function (source) {
    const output = createSubject();
    const outputIterator = eachValueFrom(output);
    let lastEmit = 0;
    let pendingResult;
    let timer = null;
    let resolvedDuration = undefined;
    const flushPending = () => {
        if (pendingResult !== undefined) {
            const value = pendingResult.value;
            if (pendingResult.meta) {
                setIteratorMeta(outputIterator, pendingResult.meta, pendingResult.meta.operatorIndex, pendingResult.meta.operatorName);
            }
            // Emit value directly - tracer tracks it via inputQueue
            output.next(value);
            pendingResult = undefined;
        }
        timer = null;
        lastEmit = Date.now();
    };
    (async () => {
        try {
            resolvedDuration = isPromiseLike(duration) ? await duration : duration;
            while (true) {
                const result = await source.next();
                if (result.done)
                    break;
                const now = Date.now();
                if (resolvedDuration === undefined) {
                    // If duration isn't available, we can't throttle properly yet?
                    // Original code had this check to possibly consume stream while waiting for duration (unlikely)
                    // or just safe-guard. 
                    // We just buffer it.
                    pendingResult = result;
                    const meta = getIteratorMeta(source);
                    if (meta) {
                        pendingResult.meta = meta;
                    }
                    getIteratorMeta(source);
                    continue;
                }
                if (now - lastEmit >= resolvedDuration) {
                    // Emit immediately (Leading edge)
                    const value = result.value;
                    const meta = getIteratorMeta(source);
                    if (meta) {
                        setIteratorMeta(outputIterator, meta, meta.operatorIndex, meta.operatorName);
                    }
                    // Emit value directly - tracer tracks it via inputQueue
                    output.next(value);
                    lastEmit = now;
                }
                else {
                    // Throttling - buffer as trailing
                    pendingResult = result;
                    const meta = getIteratorMeta(source);
                    if (meta) {
                        pendingResult.meta = meta;
                    }
                    // Schedule trailing emit
                    if (!timer) {
                        const delay = resolvedDuration - (now - lastEmit);
                        timer = setTimeout(flushPending, delay);
                    }
                }
            }
            // Source completed – flush trailing pending
            if (pendingResult !== undefined)
                flushPending();
        }
        catch (err) {
            output.error(err);
        }
        finally {
            if (timer) {
                clearTimeout(timer);
                timer = null;
            }
            if (!output.completed())
                output.complete();
        }
    })();
    return outputIterator;
});

/**
 * Creates a stream operator that immediately throws an error with the provided message.
 *
 * This operator is a source operator that is used to create a stream that immediately
 * fails. When a consumer requests a value by calling `next()`, the operator
 * will throw an `Error` with the given `message`, without emitting any values.
 *
 * This is useful for testing error handling logic in a stream pipeline or for
 * explicitly modeling a failed asynchronous operation.
 *
 * @template T The type of the values in the stream (this is a formality, as no values are emitted).
 * @param message The error message to be thrown.
 * @returns An `Operator` instance that creates a stream which errors upon its first request.
 */
const throwError = (message) => createOperator('throwError', function (source) {
    return {
        next: async () => {
            while (true) {
                const result = await source.next();
                if (result.done)
                    return DONE;
                break;
            }
            throw new Error(isPromiseLike(message) ? await message : message);
        }
    };
});

/**
 * Collects all emitted values from the source stream into an array
 * and emits that array once the source completes, tracking pending state.
 *
 * @template T The type of the values in the source stream.
 * @returns An Operator instance for use in a stream's `pipe` method.
 */
const toArray = () => createOperator("toArray", function (source) {
    const collected = [];
    const collectedMeta = [];
    let completed = false;
    let emitted = false;
    return {
        next: async function () {
            while (true) {
                // All done and final array emitted → complete
                if (completed && emitted) {
                    return DONE;
                }
                const result = await source.next();
                if (result.done) {
                    completed = true;
                    if (!emitted) {
                        emitted = true;
                        const metas = collectedMeta.filter(Boolean);
                        const lastMeta = metas[metas.length - 1];
                        let values = collected.map((r) => r.value);
                        if (lastMeta) {
                            setIteratorMeta(this, { valueId: lastMeta.valueId, kind: "collapse", inputValueIds: metas.map((m) => m.valueId) }, lastMeta.operatorIndex, lastMeta.operatorName);
                            values = setValueMeta(values, { valueId: lastMeta.valueId, kind: "collapse", inputValueIds: metas.map((m) => m.valueId) }, lastMeta.operatorIndex, lastMeta.operatorName);
                        }
                        // Emit the final array of values
                        return NEXT(values);
                    }
                    continue;
                }
                collected.push(result);
                collectedMeta.push(getIteratorMeta(source));
            }
        },
    };
});

function withLatestFrom(...streams) {
    return createOperator("withLatestFrom", function (source) {
        const output = createSubject();
        const outputIterator = eachValueFrom(output);
        const abortController = new AbortController();
        const { signal } = abortController;
        let latestValues = [];
        let hasValue = [];
        const subscriptions = [];
        let errorEmitted = false;
        let auxiliaryError = null;
        let isCompleted = false;
        const normalizedInputs = streams.length === 1 && Array.isArray(streams[0]) ? streams[0] : streams;
        // Setup function for auxiliary streams
        const setupAuxiliary = (inputs) => {
            latestValues = new Array(inputs.length).fill(undefined);
            hasValue = new Array(inputs.length).fill(false);
            for (let i = 0; i < inputs.length; i++) {
                const subscription = fromAny(inputs[i]).subscribe({
                    next: (value) => {
                        latestValues[i] = value;
                        hasValue[i] = true;
                    },
                    error: (err) => {
                        // Only the first error is recorded
                        if (!errorEmitted && !isCompleted) {
                            errorEmitted = true;
                            auxiliaryError = err instanceof Error ? err : new Error(String(err));
                            // Emit error in next microtask to ensure proper propagation
                            queueMicrotask(() => {
                                if (!isCompleted) {
                                    output.error(auxiliaryError);
                                    abortController.abort();
                                }
                            });
                        }
                    },
                });
                subscriptions.push(subscription);
            }
        };
        const cleanup = () => {
            subscriptions.forEach(sub => sub.unsubscribe());
            if (typeof source.return === "function") {
                source.return().catch(() => { });
            }
        };
        // Main iteration function
        const iterate = async () => {
            try {
                // --- 1. Setup Auxiliary Streams ---
                const hasPromises = normalizedInputs.some(isPromiseLike);
                if (hasPromises) {
                    const resolvedInputs = await Promise.all(normalizedInputs.map(async (stream) => (isPromiseLike(stream) ? await stream : stream)));
                    if (signal.aborted) {
                        cleanup();
                        return;
                    }
                    setupAuxiliary(resolvedInputs);
                }
                else {
                    setupAuxiliary(normalizedInputs);
                }
                // Check for auxiliary errors that occurred during setup
                if (auxiliaryError || signal.aborted) {
                    cleanup();
                    return;
                }
                // --- 2. Iterate Source Stream ---
                const iterator = source;
                const abortPromise = new Promise((resolve) => {
                    if (signal.aborted) {
                        resolve();
                    }
                    else {
                        signal.addEventListener("abort", () => resolve(), { once: true });
                    }
                });
                while (true) {
                    const winner = await Promise.race([
                        abortPromise.then(() => ({ aborted: true })),
                        iterator.next().then(result => ({ result }))
                    ]);
                    // Check for auxiliary errors each iteration
                    if (auxiliaryError || signal.aborted) {
                        cleanup();
                        return;
                    }
                    if ('aborted' in winner)
                        break;
                    const result = winner.result;
                    if (result.done)
                        break;
                    const meta = getIteratorMeta(source);
                    // Gate check: Only emit if ALL auxiliary streams have emitted a value
                    if (hasValue.length > 0 && hasValue.every(Boolean)) {
                        let combined = [result.value, ...latestValues];
                        if (meta) {
                            setIteratorMeta(outputIterator, { valueId: meta.valueId }, meta.operatorIndex, meta.operatorName);
                            combined = setValueMeta(combined, { valueId: meta.valueId }, meta.operatorIndex, meta.operatorName);
                        }
                        output.next(combined);
                    }
                }
                // Complete normally if no errors occurred
                if (!errorEmitted && !isCompleted) {
                    isCompleted = true;
                    output.complete();
                }
            }
            catch (err) {
                // Catch errors from source iteration
                if (!errorEmitted && !isCompleted) {
                    errorEmitted = true;
                    output.error(err instanceof Error ? err : new Error(String(err)));
                }
            }
            finally {
                cleanup();
            }
        };
        // Start iteration
        iterate();
        // --- Custom Subscription Handling ---
        const originalSubscribe = output.subscribe;
        output.subscribe = (callbackOrReceiver) => {
            const receiver = createReceiver(callbackOrReceiver);
            const subscription = originalSubscribe.call(output, receiver);
            const originalOnUnsubscribe = subscription.onUnsubscribe;
            subscription.onUnsubscribe = () => {
                if (!signal.aborted) {
                    abortController.abort();
                }
                subscriptions.forEach(sub => sub.unsubscribe());
                originalOnUnsubscribe?.call(subscription);
            };
            return subscription;
        };
        return outputIterator;
    });
}

/**
 * Creates a simple asynchronous lock mechanism. Only one caller can hold the lock at a time.
 * Subsequent calls will queue up and wait for the lock to be released. This is useful
 * for synchronizing access to shared resources in an asynchronous environment.
 *
 * The function returns a promise that resolves with a `ReleaseFn`. The caller must
 * invoke this function to release the lock, allowing the next queued caller to proceed.
 *
 * @returns {SimpleLock} A function that, when called, returns a promise to acquire the lock.
 * Prefer scheduler-backed or stream-based coordination utilities for most use cases.
 */
const createLock = () => {
    let locked = false;
    const queue = [];
    return () => new Promise((resolve) => {
        const acquire = () => {
            if (!locked) {
                locked = true;
                resolve(() => {
                    locked = false;
                    if (queue.length > 0) {
                        const next = queue.shift();
                        next(acquire);
                    }
                });
            }
            else {
                queue.push(acquire);
            }
        };
        acquire();
    });
};

/**
 * Creates an asynchronous queue that processes operations sequentially.
 * Operations are guaranteed to run in the order they are enqueued, one after another.
 * This is useful for preventing race conditions and ensuring that dependent
 * asynchronous tasks are executed in a specific order.
 *
 * @returns {{ enqueue: (operation: () => Promise<any>) => Promise<any>, pending: number, isEmpty: boolean }} An object representing the queue.
 * @property {(operation: () => Promise<any>) => Promise<any>} enqueue Enqueues an asynchronous operation to be executed sequentially.
 * @property {number} pending The number of operations currently in the queue (including the one running).
 * @property {boolean} isEmpty A boolean indicating whether the queue is empty.
 */
function createQueue() {
    let last = Promise.resolve();
    let pendingCount = 0;
    const enqueue = (operation) => {
        pendingCount++;
        let result;
        try {
            // Create the chained promise that will execute the operation
            result = last.then(() => operation());
        }
        catch (err) {
            result = Promise.reject(err);
        }
        // Ensure pendingCount decrements even if the operation throws synchronously
        result = result.finally(() => {
            pendingCount--;
        });
        // Chain the next operation (with error handling to prevent queue lock)
        // This maintains the sequential order regardless of operation success/failure
        last = result.catch(() => { });
        return result;
    };
    return {
        enqueue,
        // Utility methods for debugging/monitoring
        get pending() { return pendingCount; },
        get isEmpty() { return pendingCount === 0; }
    };
}

/**
 * Creates a semaphore for controlling access to a limited number of resources.
 *
 * A semaphore is a synchronization primitive that allows you to manage
 * concurrent access to resources by maintaining a count of available "permits."
 *
 * @param {number} initialCount The initial number of permits available. Must be a non-negative integer.
 * @returns {Semaphore} A semaphore object with `acquire`, `tryAcquire`, and `release` methods.
 * Prefer scheduler-backed or stream-based coordination utilities for most use cases.
 */
const createSemaphore = (initialCount) => {
    let count = initialCount;
    const queue = [];
    const release = () => {
        if (queue.length > 0) {
            // Don't call the resolver immediately - schedule it as a microtask
            // to maintain the expected order of execution
            const nextResolver = queue.shift();
            enqueueMicrotask(nextResolver);
        }
        else {
            count++;
        }
    };
    const acquire = () => new Promise((resolve) => {
        const resolverFn = () => resolve(() => release());
        if (count > 0) {
            count--;
            resolverFn();
        }
        else {
            queue.push(resolverFn);
        }
    });
    const tryAcquire = () => {
        if (count > 0) {
            count--;
            return () => release();
        }
        return null;
    };
    return { acquire, tryAcquire, release };
};

/*
 * Public API Surface of generator
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DONE, EMPTY, NEXT, VALUE_META_SYMBOL, applyPipeStreamHooks, audit, buffer, bufferCount, bufferUntil, bufferWhile, catchError, combineLatest, concat, concatMap, createAsyncIterator, createBehaviorSubject, createLock, createOperator, createQueue, createReceiver, createRegister, createReplaySubject, createSemaphore, createStream, createSubject, createSubscription, createTryCommit, createUntilGate, debounce, defaultIfEmpty, defer, delay, delayUntil, delayWhile, distinctUntilChanged, distinctUntilKeyChanged, eachValueFrom, empty, endWith, enqueueMicrotask, exhaustMap, expand, filter, finalize, first, firstValueFrom, fork, forkJoin, from, fromAny, fromEvent, fromPromise, generateStreamId, generateSubscriptionId, getCurrentEmissionStamp, getIteratorEmissionStamp, getIteratorMeta, getRuntimeHooks, getValueMeta, groupBy, ignoreElements, iif, interval, isPromiseLike, isStreamLike, isWrappedPrimitive, last, lastValueFrom, loop, map, merge, mergeMap, nextEmissionStamp, observeOn, of, partition, performMicrotask, pipeSourceThrough, race, range, reduce, registerRuntimeHooks, retry, runInMicrotask, sample, scan, select, setIteratorEmissionStamp, setIteratorMeta, setValueMeta, share, shareReplay, skip, skipUntil, skipWhile, slidingPair, startWith, switchMap, take, takeUntil, takeWhile, tap, throttle, throwError, timer, toArray, unwrapPrimitive, withEmissionStamp, withLatestFrom, zip };
//# sourceMappingURL=epikodelabs-streamix.mjs.map
