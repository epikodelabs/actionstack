import { type MaybePromise, type Operator } from "@epikodelabs/streamix";
/**
 * Emits the most frequently occurring value(s) sampled from the source stream.
 *
 * Values are keyed (optionally via `keySelector`) and counted as the stream flows through.
 * After the source completes, the operator emits all values whose count matches the maximum frequency.
 * Empty streams result in `DONE` without emission.
 *
 * @template T The type of values emitted downstream.
 * @template K The type of the key used for tracking counts.
 * @param keySelector Optional function that derives a key from each value; it may return a promise.
 * If omitted, the values themselves act as keys.
 * @returns An `Operator` instance that emits an array of the most-frequent items before completing.
 */
export declare const mode: <T = any, K = any>(keySelector?: ((value: T) => MaybePromise<K>) | undefined) => Operator<T, T[]>;
