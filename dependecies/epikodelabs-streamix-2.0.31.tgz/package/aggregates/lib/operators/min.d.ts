import { type MaybePromise, type Operator } from '@epikodelabs/streamix';
/**
 * Creates a stream operator that emits the smallest value produced by the source stream.
 *
 * This terminal operator consumes every value, retaining the minimum seen so far as the stream progresses.
 * A comparator may be provided to customize how values are ordered (asynchronous comparators are supported).
 * Once the source completes, the minimum is emitted exactly once; empty sources result in `DONE` without emission.
 *
 * @template T The type of the values in the source stream.
 * @param comparator Optional comparison function. It should return a negative number when `a < b`, zero when equal,
 * and a positive number when `a > b`. Defaults to the `<` operator.
 * @returns An `Operator` instance usable in a stream's `pipe` method.
 */
export declare const min: <T = any>(comparator?: ((a: T, b: T) => MaybePromise<number>) | undefined) => Operator<T, T>;
