import { type MaybePromise, type Operator } from '@epikodelabs/streamix';
/**
 * Creates a stream operator that emits the maximum value from the source stream.
 *
 * This terminal operator consumes every downstream value, retains the current maximum
 * as data flows through, and waits for the source to complete before emitting the winner.
 * A comparator can be provided to override the default `>` comparison; asynchronous comparators
 * are supported because they are awaited internally.
 * The operator emits once with the maximum value (if any values were provided) and then completes.
 * For empty sources it returns `DONE` without emitting.
 *
 * @template T The type of the values in the source stream.
 * @param comparator Optional comparison function: positive if `a > b`, negative if `a < b`.
 * @returns An `Operator` instance usable in a stream's `pipe` method.
 */
export declare const max: <T = any>(comparator?: ((a: T, b: T) => MaybePromise<number>) | undefined) => Operator<T, T>;
