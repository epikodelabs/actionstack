import { type MaybePromise, type Stream } from "@epikodelabs/streamix";
/**
 * A stream that represents a WebSocket-like interface.
 * Extends a standard Stream with a `.send()` method to send messages.
 *
 * @template T The type of messages sent and received.
 */
export type WebSocketStream<T = any> = Stream<T> & {
    /** Sends a JSON-serializable message to the WebSocket server. */
    send: (message: T) => void;
    /** Close the WebSocket and stop the generator */
    close: () => void;
};
/**
 * Creates a WebSocket stream for bidirectional communication with a server.
 *
 * Incoming messages from the WebSocket are emitted as stream values.
 * Outgoing messages are sent via the `.send()` method.
 * Messages sent before the connection is open are queued automatically.
 *
 * @template T - Type of messages to send and receive.
 * @param url The WebSocket URL (can be a Promise).
 * @param factory Optional WebSocket factory for dependency injection (useful for testing, can be a Promise).
 * @returns {WebSocketStream<T>} A WebSocketStream that can be used to
 * send and receive messages of type T.
 */
export declare function webSocket<T = any>(url: MaybePromise<string>, factory?: (url: string) => MaybePromise<WebSocket>): WebSocketStream<T>;
