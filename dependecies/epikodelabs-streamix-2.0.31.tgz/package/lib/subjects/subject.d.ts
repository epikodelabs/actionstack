import { type Stream } from "../abstractions";
/**
 * Subject is a hot, multicast stream that allows imperatively pushing values
 * with `next`, signalling completion with `complete`, or errors with
 * `error`. It implements `Stream<T>` and exposes the current value via
 * the `value` getter when available.
 *
 * @template T
 */
export type Subject<T = any> = Stream<T> & {
    next(value: T): void;
    complete(): void;
    error(err: any): void;
    completed(): boolean;
    get value(): T | undefined;
};
/**
 * Create a plain `Subject` which buffers emissions and delivers them to
 * current subscribers. The returned subject can be used as an async
 * iterable and as an imperative emitter via `next`/`complete`/`error`.
 *
 * @template T
 * @returns {Subject<T>} A new subject instance.
 */
export declare function createSubject<T = any>(): Subject<T>;
