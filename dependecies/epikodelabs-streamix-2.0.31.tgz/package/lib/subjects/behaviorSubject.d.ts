import { type Stream } from "../abstractions";
/**
 * BehaviorSubject holds a current value and emits it immediately to new
 * subscribers. It exposes imperative `next`/`complete`/`error` methods and
 * guarantees `value` is always available.
 *
 * @template T
 */
export type BehaviorSubject<T = any> = Stream<T> & {
    next(value: T): void;
    complete(): void;
    error(err: any): void;
    completed(): boolean;
    get value(): T;
};
/**
 * Create a `BehaviorSubject` seeded with `initialValue`.
 *
 * @template T
 * @param {T} initialValue - initial value held by the subject
 * @returns {BehaviorSubject<T>} a new behavior subject
 */
export declare function createBehaviorSubject<T = any>(initialValue: T): BehaviorSubject<T>;
