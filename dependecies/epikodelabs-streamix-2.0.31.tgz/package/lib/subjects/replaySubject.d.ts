import type { Subject } from "./subject";
/**
 * ReplaySubject replays a bounded history of values to late subscribers.
 * It buffers up to `capacity` items and delivers them before continuing
 * with live emissions.
 *
 * @template T
 */
export type ReplaySubject<T = any> = Subject<T>;
/**
 * Create a `ReplaySubject` with an optional capacity of buffered items.
 *
 * @template T
 * @param {number} [capacity=Infinity] - max number of values to retain
 * @returns {ReplaySubject<T>} a new replay subject
 */
export declare function createReplaySubject<T = any>(capacity?: number): ReplaySubject<T>;
