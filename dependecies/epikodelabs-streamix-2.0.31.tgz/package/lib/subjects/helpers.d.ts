import { MaybePromise, type Receiver, type StrictReceiver, type Subscription } from "../abstractions";
/**
 * QueueItem represents an enqueued subject operation used for ordered
 * delivery. Items may be `next` (with a value), `complete`, or `error`.
 *
 * @template T
 */
export type QueueItem<T> = {
    kind: "next";
    value: T;
    stamp: number;
} | {
    kind: "complete";
    stamp: number;
} | {
    kind: "error";
    error: Error;
    stamp: number;
};
/**
 * Create the commit function which drains the subject `queue` and delivers
 * items to eligible receivers, honoring backpressure, delivery ordering,
 * and terminal semantics.
 *
 * @template T
 * @param opts - options object (see signature)
 * @returns {() => void} a function to attempt committing queued items
 */
export declare function createTryCommit<T>(opts: {
    receivers: Set<StrictReceiver<T>>;
    ready: Set<StrictReceiver<T>>;
    queue: QueueItem<T>[];
    setLatestValue: (v: T) => void;
    /**
     * Optional hook used by Subjects to ensure commit continuation runs on the
     * subject's scheduler. When omitted, continuations call `tryCommit()` directly.
     */
    scheduleCommit?: () => void;
}): () => void;
/**
 * Creates a `register(receiver)` function for Subjects.
 *
 * The returned function:
 * - Adds a receiver to the subject's delivery sets.
 * - Ensures new subscriptions do not receive already-queued emissions by
 *   tracking a `subscribedAt` stamp.
 * - Integrates with the subject's terminal state so late subscribers are
 *   immediately completed/errored.
 * - Ensures `unsubscribe()` stops future deliveries synchronously, while the
 *   receiver completion is still scheduled via the subscription hook.
 *
 * This is an internal building block used by different Subject variants to keep
 * subscription semantics consistent.
 *
 * @template T Value type.
 * @param opts Shared subject state and helpers.
 * @returns A registration function that returns a Subscription.
 */
export declare function createRegister<T>(opts: {
    receivers: Set<StrictReceiver<T>>;
    ready: Set<StrictReceiver<T>>;
    terminalRef: {
        current: QueueItem<T> | null;
    };
    createSubscription: (onUnsubscribe?: () => MaybePromise<void>) => Subscription;
    tryCommit: () => void;
}): (receiver: Receiver<T>, paused?: boolean) => Subscription;
/**
 * Creates a factory for async iterators backed by a Subject/Stream subscription.
 *
 * The iterator buffers `next` notifications until the consumer calls `next()`.
 * It also participates in subject backpressure by returning a Promise from the
 * receiver's `next(...)` that resolves when the consumer pulls the buffered
 * value.
 *
 * When `lazy: true`, registration is deferred until the consumer actually pulls
 * (either `next()` or `__tryNext()`), which avoids hidden subscriptions for
 * iterators that are constructed but never consumed.
 *
 * @template T Value type.
 * @param opts Registration function and lazy mode.
 * @returns A function that creates a fresh AsyncIterator per call.
 */
export declare function createAsyncIterator<T>(opts: {
    register: (receiver: Receiver<T>) => Subscription;
    /**
     * When `true`, the iterator does not register with the source until the
     * consumer actually pulls (`next()`/`__tryNext()`).
     *
     * Streams should generally use `lazy: true` to avoid creating hidden
     * subscriptions when an iterator is constructed but never consumed.
     *
     * Subjects should generally use `lazy: false` so operators that eagerly
     * emit into an internal Subject can buffer values for downstream consumers.
     */
    lazy?: boolean;
}): () => AsyncIterator<T, any, undefined> & {
    __tryNext?: (() => IteratorResult<T> | null) | undefined;
    __hasBufferedValues?: (() => boolean) | undefined;
    __onPush?: (() => void) | undefined;
};
