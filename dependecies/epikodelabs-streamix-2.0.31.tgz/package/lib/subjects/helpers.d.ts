import { MaybePromise, type Receiver, type StrictReceiver, type Subscription } from "../abstractions";
/**
 * QueueItem represents an enqueued subject operation used for ordered
 * delivery. Items may be `next` (with a value), `complete`, or `error`.
 *
 * @template T
 */
export type QueueItem<T> = {
    kind: "next";
    value: T;
    stamp: number;
} | {
    kind: "complete";
    stamp: number;
} | {
    kind: "error";
    error: Error;
    stamp: number;
};
/**
 * Create the commit function which drains the subject `queue` and delivers
 * items to eligible receivers, honoring backpressure, delivery ordering,
 * and terminal semantics.
 *
 * @template T
 * @param opts - options object (see signature)
 * @returns {() => void} a function to attempt committing queued items
 */
export declare function createTryCommit<T>(opts: {
    receivers: Set<StrictReceiver<T>>;
    ready: Set<StrictReceiver<T>>;
    queue: QueueItem<T>[];
    setLatestValue: (v: T) => void;
    /**
     * Optional hook used by Subjects to ensure commit continuation runs on the
     * subject's scheduler. When omitted, continuations call `tryCommit()` directly.
     */
    scheduleCommit?: () => void;
}): () => void;
export declare function createRegister<T>(opts: {
    receivers: Set<StrictReceiver<T>>;
    ready: Set<StrictReceiver<T>>;
    terminalRef: {
        current: QueueItem<T> | null;
    };
    createSubscription: (onUnsubscribe?: () => MaybePromise<void>) => Subscription;
    tryCommit: () => void;
}): (receiver: Receiver<T>, paused?: boolean) => Subscription;
export declare function createAsyncIterator<T>(opts: {
    register: (receiver: Receiver<T>) => Subscription;
    /**
     * When `true`, the iterator does not register with the source until the
     * consumer actually pulls (`next()`/`__tryNext()`).
     *
     * Streams should generally use `lazy: true` to avoid creating hidden
     * subscriptions when an iterator is constructed but never consumed.
     *
     * Subjects should generally use `lazy: false` so operators that eagerly
     * emit into an internal Subject can buffer values for downstream consumers.
     */
    lazy?: boolean;
}): () => AsyncIterator<T, any, undefined> & {
    __tryNext?: (() => IteratorResult<T> | null) | undefined;
    __hasBufferedValues?: (() => boolean) | undefined;
    __onPush?: (() => void) | undefined;
};
