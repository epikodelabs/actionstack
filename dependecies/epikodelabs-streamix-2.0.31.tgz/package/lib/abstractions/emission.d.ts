/**
 * Generate and return the next unique emission stamp (monotonically increasing number).
 * Used to order emissions in streams and subjects.
 * @returns {number} The next emission stamp.
 */
export declare function nextEmissionStamp(): number;
/**
 * Get the current emission stamp from the context, if any.
 * Returns null if not inside an emission context.
 * @returns {number | null} The current emission stamp or null.
 */
export declare function getCurrentEmissionStamp(): number | null;
/**
 * Run a function within a specific emission stamp context.
 * Temporarily sets the emission stamp for the duration of the function.
 * @template T
 * @param {number} stamp - The emission stamp to set.
 * @param {() => T} fn - The function to execute.
 * @returns {T} The result of the function.
 */
export declare function withEmissionStamp<T>(stamp: number, fn: () => T): T;
/**
 * Set the emission stamp on an async iterator for tracking emission order.
 * @param {AsyncIterator<any>} iterator - The iterator to tag.
 * @param {number} stamp - The emission stamp to set.
 */
export declare function setIteratorEmissionStamp(iterator: AsyncIterator<any>, stamp: number): void;
/**
 * Get the emission stamp from an async iterator, if present.
 * @param {AsyncIterator<any>} iterator - The iterator to inspect.
 * @returns {number | undefined} The emission stamp, if set.
 */
export declare function getIteratorEmissionStamp(iterator: AsyncIterator<any>): number | undefined;
