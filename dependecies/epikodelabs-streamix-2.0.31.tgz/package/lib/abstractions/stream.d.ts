import type { MaybePromise, Operator, OperatorChain } from "./operator";
import { type Receiver } from "./receiver";
import { type Subscription } from "./subscription";
/**
 * A Stream is an async iterable with additional methods for piping, subscribing, and querying values.
 *
 * @template T The type of values emitted by the stream.
 */
export type Stream<T = any> = AsyncIterable<T> & {
    type: "stream" | "subject";
    name?: string;
    id: string;
    pipe: OperatorChain<T>;
    subscribe: (callback?: ((value: T) => MaybePromise) | Receiver<T>) => Subscription;
    query: () => Promise<T>;
    [Symbol.asyncIterator](): AsyncIterator<T>;
};
/**
 * Type guard to check if a value is stream-like (has type and async iterator).
 *
 * @template T
 * @param value The value to check.
 * @returns {boolean} True if the value is a Stream.
 */
export declare const isStreamLike: <T = unknown>(value: unknown) => value is Stream<T>;
export declare function createStream<T>(name: string, generatorFn: (signal?: AbortSignal) => AsyncGenerator<T, void, unknown>): Stream<T>;
export declare function pipeSourceThrough<TIn, Ops extends Operator<any, any>[]>(source: Stream<TIn>, operators: [...Ops]): Stream<any>;
