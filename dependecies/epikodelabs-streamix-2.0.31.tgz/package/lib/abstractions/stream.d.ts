import type { MaybePromise, Operator, OperatorChain } from "./operator";
import { type Receiver } from "./receiver";
import { type Subscription } from "./subscription";
/**
 * A Stream is an async iterable with additional methods for piping, subscribing, and querying values.
 *
 * @template T The type of values emitted by the stream.
 */
export type Stream<T = any> = AsyncIterable<T> & {
    type: "stream" | "subject";
    name?: string;
    id: string;
    pipe: OperatorChain<T>;
    subscribe: (callback?: ((value: T) => MaybePromise) | Receiver<T>) => Subscription;
    query: () => Promise<T>;
    [Symbol.asyncIterator](): AsyncIterator<T>;
};
/**
 * Type guard to check if a value is stream-like (has type and async iterator).
 *
 * @template T
 * @param value The value to check.
 * @returns {boolean} True if the value is a Stream.
 */
export declare const isStreamLike: <T = unknown>(value: unknown) => value is Stream<T>;
/**
 * Creates a multicast {@link Stream} from an async generator factory.
 *
 * The returned Stream starts producing values on the first subscription and
 * delivers each yielded value to *all* active subscribers.
 *
 * - When the last subscriber unsubscribes, the underlying generator is aborted
 *   via an {@link AbortSignal}.
 * - When the generator completes, subscribers are completed and internal
 *   receiver references are cleared to avoid memory growth in long-running
 *   processes/tests.
 * - A new subscription after completion starts a fresh generator run.
 *
 * Receiver callbacks are executed in a microtask when there is no active
 * emission context, which helps keep delivery ordering consistent and avoids
 * surprising re-entrancy.
 *
 * @template T Value type emitted by the stream.
 * @param name Human-friendly name (used for debugging/tracing).
 * @param generatorFn Async generator factory. Receives an optional AbortSignal
 * that is aborted when the stream is torn down.
 * @returns A Stream that can be piped, subscribed to, or iterated.
 *
 * @example
 * const s = createStream('ticks', async function* (signal) {
 *   while (!signal?.aborted) {
 *     yield Date.now();
 *     await new Promise(r => setTimeout(r, 1000));
 *   }
 * });
 */
export declare function createStream<T>(name: string, generatorFn: (signal?: AbortSignal) => AsyncGenerator<T, void, unknown>): Stream<T>;
/**
 * Applies a list of operators to a source stream and returns the resulting stream.
 *
 * This is the implementation behind `stream.pipe(...)`. It creates a new stream
 * identity (stream id) for the piped stream and ensures runtime hooks are
 * invoked consistently for both `subscribe()` and direct async iteration.
 *
 * @template TIn Source value type.
 * @param source Source stream.
 * @param operators Operators to apply, in order.
 * @returns A new Stream that emits the transformed values.
 */
export declare function pipeSourceThrough<TIn, Ops extends Operator<any, any>[]>(source: Stream<TIn>, operators: [...Ops]): Stream<any>;
