import { type Operator } from "./operator";
/**
 * Context object provided to the `onPipeStream` runtime hook.
 *
 * Contains identifiers and the current operator chain so tooling can
 * inspect or modify the stream pipeline before it is executed.
 */
export type PipeStreamHookContext = {
    streamId: string;
    streamName?: string;
    subscriptionId: string;
    parentValueId?: string;
    source: AsyncIterator<any>;
    operators: Operator<any, any>[];
};
/**
 * Result returned by an `onPipeStream` hook.
 *
 * Any provided fields patch the pipeline used for the subscription.
 */
export type PipeStreamHookResult = {
    source?: AsyncIterator<any>;
    operators?: any[];
    final?: (iterator: AsyncIterator<any>) => AsyncIterator<any>;
};
/**
 * Hooks that can be registered to observe or modify runtime stream behavior.
 */
export type StreamRuntimeHooks = {
    /** Called when a stream is created. Useful for tracing and instrumentation. */
    onCreateStream?: (info: {
        id: string;
        name?: string;
    }) => void;
    /**
     * Called when a source stream is piped through operators. Returning a
     * `PipeStreamHookResult` allows modifying the source iterator, operator
     * list or applying a final wrapper around the iterator.
     */
    onPipeStream?: (ctx: PipeStreamHookContext) => PipeStreamHookResult | void;
};
/**
 * Registers runtime hooks used by instrumentation and devtools.
 *
 * Replaces any previously-registered hooks for the current global context.
 */
export declare function registerRuntimeHooks(hooks: StreamRuntimeHooks): void;
/**
 * Returns the currently-registered runtime hooks, if any.
 *
 * @returns {StreamRuntimeHooks | null} The registered hooks or null.
 */
export declare function getRuntimeHooks(): StreamRuntimeHooks | null;
/**
 * Kinds of iterator metadata describing how a value was produced.
 */
export type IteratorMetaKind = "transform" | "collapse" | "expand";
/**
 * Metadata tag attached to iterators to correlate values across operators.
 */
export type IteratorMetaTag = {
    /** Unique identifier for the value produced by the iterator. */
    valueId: string;
    /** Optional kind describing the transformation performed. */
    kind?: IteratorMetaKind;
    /** Optional list of parent value ids (for collapse/expand operations). */
    inputValueIds?: string[];
};
/** Symbol key used when wrapping primitive values with metadata. */
export declare const VALUE_META_SYMBOL: unique symbol;
/**
 * Attach iterator-level metadata used by tracing and until-style operators.
 */
export declare function setIteratorMeta(iterator: AsyncIterator<any>, meta: IteratorMetaTag, operatorIndex: number, operatorName: string): void;
/**
 * Retrieve attached iterator metadata, if present.
 */
export declare function getIteratorMeta(iterator: AsyncIterator<any>): {
    valueId: string;
    operatorIndex: number;
    operatorName: string;
    kind?: IteratorMetaKind;
    inputValueIds?: string[];
} | undefined;
/**
 * Attach metadata to a value. Object values receive metadata directly; primitive
 * values are wrapped in a small object so their metadata can be tracked.
 */
export declare function setValueMeta(value: any, meta: IteratorMetaTag, operatorIndex: number, operatorName: string): any;
/**
 * Return metadata previously attached to a value, or `undefined` if none.
 */
export declare function getValueMeta(value: any): {
    valueId: string;
    operatorIndex: number;
    operatorName: string;
    kind?: IteratorMetaKind | undefined;
    inputValueIds?: string[] | undefined;
} | undefined;
/**
 * Returns true when a value is a wrapper created to hold metadata for a
 * primitive value.
 */
export declare function isWrappedPrimitive(value: any): boolean;
/**
 * Unwrap a primitive value previously wrapped by `setValueMeta`.
 */
export declare function unwrapPrimitive(value: any): any;
/**
 * Apply any configured `onPipeStream` hooks and then materialize the
 * operator chain into a final `AsyncIterator`.
 */
export declare function applyPipeStreamHooks(ctx: PipeStreamHookContext): AsyncIterator<any>;
/**
 * Gate used by "until" style operators (e.g. `takeUntil`, `skipUntil`).
 *
 * Populated at emission time and used by operators to determine whether a
 * source value should be forwarded or whether the notifier already fired.
 */
export type UntilGate = {
    /** First notifier emission stamp */
    openStamp: number | null;
    /** Notifier terminal stamp if completed before open */
    closeStamp: number | null;
    /** Notifier error, if any */
    error: any | null;
};
/**
 * Create a fresh `UntilGate`. Each notifier must use its own gate instance.
 */
export declare function createUntilGate(): UntilGate;
/**
 * Generate a short, unique stream id for runtime tracing.
 */
export declare function generateStreamId(): string;
/**
 * Generate a short, unique subscription id used to correlate subscriptions.
 */
export declare function generateSubscriptionId(): string;
