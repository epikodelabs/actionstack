import { MaybePromise, type Operator } from "../abstractions";
/**
 * Creates a stream operator that prepends a specified value to the beginning of the stream.
 *
 * The operator first emits the `initialValue` immediately upon being iterated.
 * After this initial emission, it begins to pull and emit values from the
 * source stream as they become available.
 *
 * @template T The type of the values in the stream.
 * @param initialValue The value to be emitted as the first item in the stream.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare const startWith: <T = any>(initialValue: MaybePromise<T>) => Operator<T, T>;
