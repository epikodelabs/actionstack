import { type MaybePromise, type Operator, type Stream } from "../abstractions";
/**
 * Creates a stream operator that combines the source stream with the latest values
 * from other provided streams.
 *
 * This operator is useful for merging a "trigger" stream with "state" streams.
 * It waits for a value from the source stream and, when one arrives, it emits a
 * tuple containing that source value along with the most recently emitted value
 * from each of the other streams.
 *
 * The operator is "gated" and will not emit any values until all provided streams
 * have emitted at least one value.
 * Inputs may be streams or values (including promises).
 *
 * @template T The type of the values in the source stream.
 * @template R The tuple type of the values from the other streams (e.g., [R1, R2, R3]).
 * @param streams Streams or values (including promises) to combine with the source stream.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 * The output stream emits tuples of `[T, ...R]`.
 */
export declare function withLatestFrom<T = any, R extends readonly unknown[] = any[]>(...streams: {
    [K in keyof R]: Stream<R[K]> | MaybePromise<R[K]>;
}): Operator<T, [T, ...R]>;
/**
 * Overload that accepts an array/tuple of auxiliary sources.
 *
 * @template T
 * @template R
 * @param streams Tuple/array of auxiliary sources.
 * @returns An operator that emits `[sourceValue, ...latestAuxValues]`.
 */
export declare function withLatestFrom<T = any, R extends readonly unknown[] = any[]>(streams: {
    [K in keyof R]: Stream<R[K]> | MaybePromise<R[K]>;
}): Operator<T, [T, ...R]>;
