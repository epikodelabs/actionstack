import type { MaybePromise, Operator, Stream } from "../abstractions";
/**
 * Projects each source value to a Stream which is merged into the output Stream,
 * emitting values only from the most recently projected Stream.
 */
export declare function switchMap<T = any, R = any>(project: (value: T, index: number) => Stream<R> | MaybePromise<R> | Array<R>): Operator<T, R>;
