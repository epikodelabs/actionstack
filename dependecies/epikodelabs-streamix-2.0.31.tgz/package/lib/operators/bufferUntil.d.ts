import { type Operator, type Stream } from "../abstractions";
/**
 * Buffers values until the notifier emits once, then flushes the collected values.
 *
 * Every notifier emission triggers a flush of the current buffer; values are released
 * as a collapsed array, preserving metadata for PipeContext tracing. When the source
 * completes, any remaining buffered values are emitted.
 *
 * @template T Source value type.
 * @param notifier Stream or Promise whose emissions cause buffer flushes.
 */
export declare const bufferUntil: <T = any>(notifier: Stream<any>) => Operator<T, T[]>;
