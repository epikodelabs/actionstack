import { type MaybePromise, type Operator, type Stream } from "../abstractions";
/**
 * Maps each value from the source stream to an inner stream, ignoring
 * new outer values while the current inner stream is still executing.
 *
 * This operator is useful for preventing overlapping operations (e.g., preventing
 * multiple simultaneous form submissions or API calls). If a new value arrives
 * from the source while an earlier projected stream is still active, that
 * new value is silently discarded.
 * * Only after the current inner stream completes will the operator become
 * "idle" and ready to accept the next value from the source.
 *
 * @template T The type of values emitted by the source stream.
 * @template R The type of values emitted by the produced inner streams.
 * @param project A function that transforms a source value into a {@link Stream},
 * a {@link MaybePromise}, or an array. It receives the source value and a
 * zero-based index of the emission.
 * @returns An {@link Operator} that performs the "exhaust" transformation.
 */
export declare const exhaustMap: <T = any, R = T>(project: (value: T, index: number) => Stream<R> | MaybePromise<R> | Array<R>) => Operator<T, R>;
