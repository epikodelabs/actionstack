import { type MaybePromise, type Stream } from '../abstractions';
/**
 * Combine multiple streams into a single stream that emits arrays of the latest values
 * from each input stream whenever any input emits. Emission occurs only when all inputs
 * have emitted at least once.
 *
 * @template T
 * @param {...Stream<T[number]>[]} sources - The input streams to zip.
 * @returns {Stream<T>} A stream emitting arrays of values from each input.
 */
export declare function zip<T extends readonly unknown[] = any[]>(...sources: Array<Stream<T[number]> | MaybePromise<T[number]>>): Stream<T>;
