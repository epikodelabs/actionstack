import { type MaybePromise, type Stream } from "../abstractions";
/**
 * Waits for all sources to complete and emits an array of their last values.
 *
 * This is similar to RxJS `forkJoin`:
 * - Each source is consumed fully.
 * - The output emits exactly once (an array of the last value from each source)
 *   and then completes.
 * - If any source errors, the output errors.
 * - If any source completes without emitting a value, `forkJoin` errors.
 *
 * Sources may be Streams or plain values (including promises). Plain values are
 * converted to streams via `fromAny(...)`.
 *
 * @template T The type of the last values emitted by each stream.
 * @param sources Streams or values (including promises) to join.
 * @returns A stream that emits a single array of last values.
 *
 * @example
 * const s = forkJoin(from([1, 2]), from([10]));
 * // emits: [2, 10]
 */
export declare function forkJoin<T = any, R extends readonly unknown[] = any[]>(...sources: {
    [K in keyof R]: Stream<R[K]> | MaybePromise<R[K]>;
}): Stream<T[]>;
/**
 * Overload that accepts an array/tuple of sources.
 *
 * @template T
 * @template R
 * @param sources Tuple/array of sources.
 * @returns A stream that emits a single array of last values.
 */
export declare function forkJoin<T = any, R extends readonly unknown[] = any[]>(sources: {
    [K in keyof R]: Stream<R[K]> | MaybePromise<R[K]>;
}): Stream<T[]>;
