import { type MaybePromise, type Stream } from "../abstractions";
/**
 * Waits for all streams to complete and emits an array of their last values.
 *
 * @template T The type of the last values emitted by each stream.
 * @param sources Streams or values (including promises) to join.
 * @returns Stream<T[]>
 */
export declare function forkJoin<T = any, R extends readonly unknown[] = any[]>(...sources: {
    [K in keyof R]: Stream<R[K]> | MaybePromise<R[K]>;
}): Stream<T[]>;
export declare function forkJoin<T = any, R extends readonly unknown[] = any[]>(sources: {
    [K in keyof R]: Stream<R[K]> | MaybePromise<R[K]>;
}): Stream<T[]>;
