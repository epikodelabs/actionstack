import { type MaybePromise, type Stream } from "../abstractions";
/**
 * Input accepted by {@link concat}.
 *
 * Values (including promises) are converted to a Stream via `fromAny(...)`.
 */
type ConcatSource<T> = Stream<T> | MaybePromise<T>;
/**
 * Concatenates sources sequentially.
 *
 * `concat(a, b, c)` subscribes to `a`, yields all its values, waits for it to
 * complete, then moves to `b`, then `c`.
 *
 * - If any source errors, the concatenated stream errors and remaining sources
 *   are not processed.
 * - Sources may be Streams, raw values, arrays/iterables, or Promises of those.
 *
 * @template T Value type.
 * @param sources Streams or values (including promises) to concatenate.
 * @returns A new stream that emits values from all input sources in order.
 *
 * @example
 * const s = concat(from([1, 2]), from([3]), 4);
 * // emits: 1, 2, 3, 4
 */
export declare function concat<T = any>(...sources: ConcatSource<T>[]): Stream<T>;
export {};
