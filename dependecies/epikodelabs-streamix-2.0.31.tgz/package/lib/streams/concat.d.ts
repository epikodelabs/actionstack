import { type MaybePromise, type Stream } from "../abstractions";
/**
 * Creates a stream that subscribes to multiple streams in sequence.
 *
 * This operator will subscribe to the first stream and yield all of its
 * values. Once the first stream completes, it will then subscribe to the
 * second stream, and so on, until all streams have completed. The resulting
 * stream will complete only after the last source stream has completed.
 *
 * If any of the source streams errors, the concatenated stream will also error and
 * stop processing the remaining streams.
 *
 * @template T The type of the values in the streams.
 * @param sources Streams or values (including promises) to concatenate.
 * @returns {Stream<T>} A new stream that emits values from all input streams in sequence.
 */
type ConcatSource<T> = Stream<T> | MaybePromise<T>;
export declare function concat<T = any>(...sources: ConcatSource<T>[]): Stream<T>;
export {};
