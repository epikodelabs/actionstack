export declare const performMicrotask: typeof queueMicrotask;
export declare function enqueueMicrotask(fn: () => void): void;
export declare function runInMicrotask<T>(fn: () => T | Promise<T>): Promise<T>;
