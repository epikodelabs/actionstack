/**
 * Low-level microtask scheduler used across Streamix internals.
 *
 * Prefers the platform-native `queueMicrotask` when available and falls back to
 * `Promise.resolve().then(...)` otherwise.
 *
 * This is intentionally exported so other Streamix packages (and power users)
 * can share a consistent scheduling primitive.
 */
export declare const performMicrotask: typeof queueMicrotask;
/**
 * Enqueues a callback to run in a microtask.
 *
 * @param fn Callback to schedule.
 */
export declare function enqueueMicrotask(fn: () => void): void;
/**
 * Runs a callback in a microtask and returns its result as a Promise.
 *
 * Unlike calling `Promise.resolve().then(fn)` directly, this helper ensures that
 * synchronous throws from `fn` are converted into a rejected Promise.
 *
 * @template T Return type.
 * @param fn Callback to run in a microtask.
 * @returns A Promise that resolves to the callback result.
 */
export declare function runInMicrotask<T>(fn: () => T | Promise<T>): Promise<T>;
