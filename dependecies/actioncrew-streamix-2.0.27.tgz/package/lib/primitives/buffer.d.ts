import { MaybePromise } from "../abstractions";
/**
 * Core interface for a buffer that supports concurrent reading and writing.
 * It models an asynchronous iterable stream.
 */
export type CyclicBuffer<T = any> = {
    /** Writes a value to the buffer, making it available for readers. */
    write(value: T): Promise<void>;
    /** Writes an error to the buffer, which will be thrown by readers. */
    error(err: Error): Promise<void>;
    /** Reads the next available item, waiting if the buffer is empty. */
    read(readerId: number): Promise<IteratorResult<T, void>>;
    /** Peeks at the next available item without consuming it. */
    peek(readerId: number): Promise<IteratorResult<T, void>>;
    /** Completes the buffer, signaling readers that no more items will arrive. */
    complete(): Promise<void>;
    /** Registers a new reader and returns its unique ID. */
    attachReader(): Promise<number>;
    /** Removes a reader and may trigger buffer pruning/memory cleanup. */
    detachReader(readerId: number): Promise<void>;
    /** Checks if the buffer has completed or errored for a specific reader. */
    completed(readerId: number): boolean;
};
/** Extends CyclicBuffer for "Subject" behavior, providing access to the current value. */
export type SubjectBuffer<T = any> = CyclicBuffer<T> & {
    /** Gets the latest non-error value written to the buffer, or undefined. */
    get value(): T | undefined;
};
/** Extends CyclicBuffer for "Replay" behavior, providing access to the history. */
export type ReplayBuffer<T = any> = CyclicBuffer<T> & {
    /** Gets an array containing all currently buffered values (the replay history). */
    get buffer(): T[];
};
/**
 * Simple condition variable implementation based on Promises.
 * Used to signal waiting readers when new data arrives or completion/error occurs.
 */
export declare function createNotifier(): {
    /** Returns a Promise that resolves when signal() or signalAll() is called. */
    wait: () => Promise<void>;
    /** Signals a single waiting reader. */
    signal: () => void | undefined;
    /** Signals all waiting readers. */
    signalAll: () => void;
};
/**
 * Creates a Subject Buffer. It acts as a queuing stream:
 * 1. Values are buffered only if active readers are present.
 * 2. New readers DO NOT receive past values (non-replaying).
 * 3. Multiple writes are delivered to readers in order (queued).
 */
export declare function createSubjectBuffer<T = any>(): CyclicBuffer<T>;
/**
 * Creates a BehaviorSubject Buffer. It extends the Subject Buffer by:
 * 1. Storing the single latest value (or error).
 * 2. Delivering the latest value to new readers upon attachment (replaying 1 item).
 * 3. Exposing the current value via the `.value` getter.
 */
export declare function createBehaviorSubjectBuffer<T = any>(initialValue?: MaybePromise<T>): SubjectBuffer<T>;
/**
 * Creates a Replay Buffer with a fixed capacity. It acts as a history stream:
 * 1. Buffers the last 'capacity' number of items (circular buffer).
 * 2. New readers start from the oldest available item within the capacity window (replaying).
 * 3. Supports backpressure via a Semaphore when the buffer is full.
 */
export declare function createReplayBuffer<T = any>(capacity: MaybePromise<number>): ReplayBuffer<T>;
