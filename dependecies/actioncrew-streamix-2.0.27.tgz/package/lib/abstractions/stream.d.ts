import { MaybePromise, Operator, OperatorChain } from "./operator";
import { Receiver } from "./receiver";
import { Subscription } from "./subscription";
/**
 * A reactive stream representing a sequence of values over time.
 *
 * Streams support:
 * - **Subscription** to receive asynchronous values.
 * - **Operator chaining** through `.pipe()`.
 * - **Querying** the first emitted value.
 * - **Async iteration** via `for await...of`.
 *
 * Two variants exist:
 * - `"stream"`: automatically driven, typically created by `createStream()`.
 * - `"subject"`: manually driven (not implemented here but retained for API symmetry).
 *
 * @template T The value type emitted by the stream.
 */
export type Stream<T = any> = AsyncIterable<T> & {
    /** Identifies the underlying behavior of the stream. */
    type: "stream" | "subject";
    /** Human-readable name primarily for debugging and introspection. */
    name?: string;
    /**
     * Internal unique identifier of the stream instance.
     *
     * Used by runtime hooks (e.g. tracing, profiling, devtools).
     * Not part of the public reactive API.
     */
    id: string;
    /**
     * Creates a new derived stream by applying one or more `Operator`s.
     *
     * Operators compose into an async-iterator pipeline, transforming emitted values.
     */
    pipe: OperatorChain<T>;
    /**
     * Subscribes to the stream.
     *
     * A callback or Receiver will be invoked for each next/error/complete event.
     * Returns a `Subscription` that may be used to unsubscribe.
     */
    subscribe: (callback?: ((value: T) => MaybePromise) | Receiver<T>) => Subscription;
    /**
     * Convenience method for retrieving the first emitted value.
     *
     * Internally subscribes, resolves on the first `next`, and then unsubscribes.
     */
    query: () => Promise<T>;
    /** Allows direct async iteration: `for await (const value of stream) { ... }`. */
    [Symbol.asyncIterator](): AsyncGenerator<T>;
};
/**
 * Creates a pull-based async iterator view over a stream's push-based events.
 *
 * This powers both `eachValueFrom` and direct `for await...of` consumption.
 * It registers a receiver with the stream, buffers incoming values, and yields
 * them to the consumer until completion or error. The underlying subscription
 * is always cleaned up when iteration ends or the consumer stops early.
 */
export declare function createAsyncGenerator<T = any>(register: (receiver: Receiver<T>) => Subscription): AsyncGenerator<T>;
/**
 * Creates a **multicast reactive stream** backed by an async generator.
 *
 * ## Semantics
 * - The generator runs **once per active subscriber group**.
 * - The **first subscriber** starts the generator.
 * - Emitted values are **shared across all subscribers** (hot multicast).
 * - When the **last subscriber unsubscribes**, the generator is aborted.
 * - A later subscriber causes the generator to **restart** (cold restart).
 *
 * ## Scheduler guarantees
 * - All receiver callbacks (`next`, `error`, `complete`) are executed inside
 *   the scheduler's microtask queue.
 *
 * ## Runtime hooks
 * If runtime hooks are registered (e.g. tracing, profiling, devtools),
 * `onCreateStream` is invoked with the generated stream identifier.
 *
 * @template T
 * @param name Optional human-readable stream label.
 * @param generatorFn Function producing an async generator yielding values.
 *
 * @returns A multicast `Stream<T>` instance.
 */
export declare function createStream<T>(name: string, generatorFn: () => AsyncGenerator<T, void, unknown>): Stream<T>;
/**
 * Pipes a source stream through a chain of operators to create a **derived stream**.
 *
 * ## Semantics
 * - Derived streams are **unicast**.
 * - Each subscriber receives an **independent execution** of the operator pipeline.
 * - The source stream remains multicast; only the pipeline is per-subscriber.
 *
 * ## Execution model
 * For every subscription:
 * 1. A fresh async iterator is created from the source stream.
 * 2. Runtime hooks may wrap the source iterator and operator chain.
 * 3. Operators are applied sequentially.
 * 4. The resulting iterator is drained until completion or unsubscribe.
 *
 * ## Runtime hooks
 * If registered, `onPipeStream` may:
 * - Wrap the source iterator (e.g. value emission tracing).
 * - Replace or wrap operators.
 * - Wrap the final iterator (e.g. delivery tracking).
 *
 * Hooks are **optional** and impose **zero overhead** when not present.
 *
 * @template TIn
 * @template Ops
 * @param source Source stream to pipe from.
 * @param operators Operator chain applied to the source.
 *
 * @returns A new unicast `Stream` derived from the source.
 */
export declare function pipeSourceThrough<TIn, Ops extends Operator<any, any>[]>(source: Stream<TIn>, operators: [...Ops]): Stream<any>;
