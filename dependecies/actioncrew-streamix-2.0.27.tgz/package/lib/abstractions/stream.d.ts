import { MaybePromise, Operator, OperatorChain } from "./operator";
import { Receiver } from "./receiver";
import { Subscription } from "./subscription";
/**
 * A reactive stream representing a sequence of values over time.
 *
 * Streams support:
 * - **Subscription** to receive asynchronous values.
 * - **Operator chaining** through `.pipe()`.
 * - **Querying** the first emitted value.
 * - **Async iteration** via `for await...of`.
 *
 * Two variants exist:
 * - `"stream"`: automatically driven, typically created by `createStream()`.
 * - `"subject"`: manually driven (not implemented here but retained for API symmetry).
 *
 * @template T The value type emitted by the stream.
 */
export type Stream<T = any> = AsyncIterable<T> & {
    /** Identifies the underlying behavior of the stream. */
    type: "stream" | "subject";
    /** Human-readable name primarily for debugging and introspection. */
    name?: string;
    /**
     * Creates a new derived stream by applying one or more `Operator`s.
     *
     * Operators compose into an async-iterator pipeline, transforming emitted values.
     */
    pipe: OperatorChain<T>;
    /**
     * Subscribes to the stream.
     *
     * A callback or Receiver will be invoked for each next/error/complete event.
     * Returns a `Subscription` that may be used to unsubscribe.
     */
    subscribe: (callback?: ((value: T) => MaybePromise) | Receiver<T>) => Subscription;
    /**
     * Convenience method for retrieving the first emitted value.
     *
     * Internally subscribes, resolves on the first `next`, and then unsubscribes.
     */
    query: () => Promise<T>;
    /** Allows direct async iteration: `for await (const value of stream) { ... }`. */
    [Symbol.asyncIterator](): AsyncGenerator<T>;
};
/**
 * Creates a pull-based async iterator view over a stream's push-based events.
 *
 * This powers both `eachValueFrom` and direct `for await...of` consumption.
 * It registers a receiver with the stream, buffers incoming values, and yields
 * them to the consumer until completion or error. The underlying subscription
 * is always cleaned up when iteration ends or the consumer stops early.
 */
export declare function createAsyncGenerator<T = any>(register: (receiver: Receiver<T>) => Subscription): AsyncGenerator<T>;
/**
 * Creates a **multicast reactive stream** backed by an async generator.
 *
 * Semantics:
 * - The generator runs once per group of subscribers.
 * - Adding the first subscriber starts the generator.
 * - Values are shared across all subscribers (hot multicast).
 * - When the last subscriber unsubscribes, the generator is aborted.
 * - A later subscriber causes the generator to start again (cold-restart).
 *
 * Scheduler guarantees:
 * - All receiver callbacks (`next`, `error`, `complete`) run in scheduled microtasks.
 *
 * @template T Value type emitted by the generator.
 * @param name Optional human-readable stream label.
 * @param generatorFn Function producing an async iterator yielding values for subscribers.
 */
export declare function createStream<T>(name: string, generatorFn: () => AsyncGenerator<T, void, unknown>): Stream<T>;
/**
 * Pipes a source stream through a chain of operators to produce a **derived stream**.
 *
 * For each subscription:
 * - A fresh iterator is created from the source's async-iterable interface.
 * - All operators transform the iterator in sequence.
 * - `drainIterator` consumes the transformed iterator until completion or abort.
 *
 * Unlike `createStream`, piped streams are **unicast**:
 * - Each subscriber gets an independent execution of the operator pipeline.
 * - Only the source stream remains multicast.
 *
 * @template TIn  Input value type.
 * @template Ops  Tuple of operators used to transform the pipeline.
 */
export declare function pipeStream<TIn, Ops extends Operator<any, any>[]>(source: Stream<TIn>, operators: [...Ops]): Stream<any>;
