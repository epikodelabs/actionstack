import { MaybePromise, Operator, OperatorChain } from "./operator";
import { Receiver } from "./receiver";
import { Subscription } from "./subscription";
/**
 * A reactive stream representing a sequence of values over time.
 *
 * Streams support:
 * - **Subscription** to receive asynchronous values.
 * - **Operator chaining** through `.pipe()`.
 * - **Querying** the first emitted value.
 * - **Async iteration** via `for await...of`.
 *
 * Two variants exist:
 * - `"stream"`: automatically driven, typically created by `createStream()`.
 * - `"subject"`: manually driven (not implemented here but retained for API symmetry).
 *
 * @template T The value type emitted by the stream.
 */
export type Stream<T = any> = AsyncIterable<T> & {
    /** Identifies the underlying behavior of the stream. */
    type: "stream" | "subject";
    /** Human-readable name primarily for debugging and introspection. */
    name?: string;
    /**
     * Internal unique identifier of the stream instance.
     *
     * Used by runtime hooks (e.g. tracing, profiling, devtools).
     * Not part of the public reactive API.
     */
    id: string;
    /**
     * Creates a new derived stream by applying one or more `Operator`s.
     *
     * Operators compose into an async-iterator pipeline, transforming emitted values.
     */
    pipe: OperatorChain<T>;
    /**
     * Subscribes to the stream.
     *
     * A callback or Receiver will be invoked for each next/error/complete event.
     * Returns a `Subscription` that may be used to unsubscribe.
     */
    subscribe: (callback?: ((value: T) => MaybePromise) | Receiver<T>) => Subscription;
    /**
     * Convenience method for retrieving the first emitted value.
     *
     * Internally subscribes, resolves on the first `next`, and then unsubscribes.
     */
    query: () => Promise<T>;
    /** Allows direct async iteration: `for await (const value of stream) { ... }`. */
    [Symbol.asyncIterator](): AsyncGenerator<T>;
};
/**
 * Type guard for Stream-like objects.
 */
export declare const isStreamLike: <T = unknown>(value: unknown) => value is Stream<T>;
/**
 * Creates a pull-based async generator view over a stream.
 *
 * This bridges the push-based subscription model with
 * the pull-based async-iterator protocol.
 *
 * Characteristics:
 * - Buffers values when the producer is faster than the consumer
 * - Propagates errors via generator throws
 * - Guarantees subscription cleanup on completion, error, or early exit
 *
 * @template T
 * @param register Function registering a receiver and returning a subscription
 * @returns AsyncGenerator yielding stream values
 */
export declare function createAsyncGenerator<T = any>(register: (receiver: Receiver<T>) => Subscription): AsyncGenerator<T>;
/**
 * Creates a multicast stream backed by a shared async generator.
 *
 * @template T
 * @param name Stream name (debugging / tooling)
 * @param generatorFn Factory producing an async generator
 * @returns Multicast Stream instance
 */
export declare function createStream<T>(name: string, generatorFn: (signal: AbortSignal) => AsyncGenerator<T, void, unknown>): Stream<T>;
/**
 * Pipes a source stream through a chain of operators,
 * producing a derived unicast stream.
 *
 * @template TIn
 * @template Ops
 * @param source Source stream
 * @param operators Operators applied to the source
 * @returns Derived unicast Stream
 */
export declare function pipeSourceThrough<TIn, Ops extends Operator<any, any>[]>(source: Stream<TIn>, operators: [...Ops]): Stream<any>;
