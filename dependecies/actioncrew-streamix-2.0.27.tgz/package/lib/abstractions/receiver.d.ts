import type { MaybePromise } from "./operator";
/**
 * Defines a receiver interface for handling a stream's lifecycle events.
 *
 * A receiver is an object that can be passed to a stream's `subscribe` method
 * to handle the three primary events in a stream's lifecycle: `next` for
 * new values, `error` for stream errors, and `complete` when the stream has finished.
 *
 * All properties are optional, allowing you to subscribe only to the events you care about.
 *
 * @template T The type of the value handled by the receiver's `next` method.
 */
export type Receiver<T = any> = {
    /**
     * A function called for each new value emitted by the stream.
     * @param value The value emitted by the stream.
     */
    next?: (value: T) => MaybePromise;
    /**
     * A function called if the stream encounters an error.
     * @param err The error that occurred.
     */
    error?: (err: Error) => MaybePromise;
    /**
     * A function called when the stream has completed successfully and will emit no more values.
     */
    complete?: () => MaybePromise;
};
/**
 * A fully defined, state-aware receiver with guaranteed lifecycle handlers.
 *
 * This type extends the `Receiver` interface by making all handler methods
 * (`next`, `error`, and `complete`) required. It also includes a `completed`
 * property to track the receiver's state, preventing it from processing
 * new events after it has completed. This is an internal type used to ensure
 * robust handling of all stream events.
 *
 * @template T The type of the value handled by the receiver.
 */
export type StrictReceiver<T = any> = Required<Receiver<T>> & {
    readonly completed: boolean;
};
/**
 * Normalizes a receiver input (a function or an object) into a strict,
 * fully-defined receiver.
 *
 * This factory function ensures that a consistent `StrictReceiver` object is
 * always returned, regardless of the input. It wraps the provided handlers
 * with logic that ensures events are not processed after completion and that
 * unhandled errors are logged.
 *
 * If the input is a function, it is treated as the `next` handler. If it's an
 * object, its `next`, `error`, and `complete` properties are used. If no input
 * is provided, a receiver with no-op handlers is created.
 *
 * @template T The type of the value handled by the receiver.
 * @param callbackOrReceiver An optional function to serve as the `next` handler,
 * or a `Receiver` object with one or more optional handlers.
 * @returns A new `StrictReceiver` instance with normalized handlers and completion tracking.
 */
export declare function createReceiver<T = any>(callbackOrReceiver?: ((value: T) => MaybePromise) | Receiver<T>): StrictReceiver<T>;
