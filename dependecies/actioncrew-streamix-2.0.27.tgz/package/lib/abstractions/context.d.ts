/**
 * @fileoverview
 * Comprehensive emission logging and pipeline context management for reactive streaming systems.
 */
import { MaybePromise, Operator } from "./operator";
import { Stream } from "./stream";
export declare enum LogLevel {
    OFF = 0,
    ERROR = 1,
    WARN = 2,
    INFO = 3,
    DEBUG = 4
}
export type ResultType = "pending" | "done" | "error" | "phantom";
export interface LogEntry {
    timestamp: number;
    level: LogLevel;
    levelName: string;
    message: string;
    streamId: string;
    operatorPath: string;
    resultType?: ResultType;
    value?: any;
    error?: any;
}
export type LogState = LogEntry[];
export type StreamResult<T = any> = IteratorResult<T> & {
    type?: ResultType;
    sealed?: boolean;
    error?: any;
    parent?: StreamResult<any>;
    children?: Set<StreamResult<any>>;
    timestamp?: number;
    resolve(value?: T): Promise<void>;
    reject(reason: any): Promise<void>;
    wait(): Promise<void>;
    addChild(child: StreamResult<any>): void;
    finalize(): void;
    root(): StreamResult<any>;
    getAllDescendants(): StreamResult<any>[];
    isFullyResolved(): boolean;
    notifyParent(): void;
};
export interface StreamContext {
    pipeline: PipelineContext;
    streamId: string;
    pendingResults: Set<StreamResult<any>>;
    timestamp: number;
    phantomHandler: (operator: Operator, value: any) => MaybePromise;
    resolvePending: (operator: Operator, result: StreamResult<any>) => MaybePromise;
    markPhantom: (operator: Operator, result: StreamResult<any>) => MaybePromise;
    markPending: (operator: Operator, result: StreamResult<any>) => MaybePromise;
    createResult: <T>(options?: Partial<StreamResult<T>>) => StreamResult<T>;
    logFlow(eventType: 'pending' | 'resolved' | 'phantom' | 'error', operator: Operator, result?: StreamResult<any>, message?: string): void;
    finalize(): Promise<void>;
}
export interface PipelineContext {
    logLevel: LogLevel;
    operators: Operator[];
    flowLoggingEnabled: boolean;
    operatorStack(operator: Operator): string;
    phantomHandler: (operator: Operator, streamContext: StreamContext, value: any) => MaybePromise;
    activeStreams: Map<string, StreamContext>;
    flags: {
        isPending: boolean;
        isFinalized: boolean;
    };
    streamStack: StreamContext[];
    currentStreamContext(): StreamContext;
    registerStream(context: StreamContext): void;
    unregisterStream(streamId: string): void;
    finalize(): Promise<void>;
}
export declare const createLogEntry: (level: LogLevel, streamId: string, operatorPath: string, message: string, result?: StreamResult) => LogEntry;
export declare const appendLogEntry: (logState: LogState, newEntry: LogEntry) => LogState;
export declare const filterLogEntries: (logState: LogState, minLevel: LogLevel) => LogEntry[];
export declare function createStreamResult<T>(options?: Partial<StreamResult<T>>): StreamResult<T>;
export declare function createStreamContext(pipelineContext: PipelineContext, stream: Stream): StreamContext;
export declare function createPipelineContext(options?: {
    phantomHandler?: (operator: Operator, s: StreamContext, value: any) => MaybePromise;
    logLevel?: LogLevel;
    flowLoggingEnabled?: boolean;
}): PipelineContext;
