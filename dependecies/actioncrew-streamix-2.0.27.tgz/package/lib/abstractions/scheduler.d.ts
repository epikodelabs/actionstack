/**
 * Functional Scheduler
 *
 * Provides enqueue/run behavior without exposing internal mutable state.
 * State is held in a closure, and operations are returned as pure functions.
 */
export type Scheduler = {
    enqueue: <T>(fn: () => Promise<T> | T) => Promise<T>;
    flush: () => Promise<void>;
};
/**
 * Creates a cooperative asynchronous scheduler that serializes operations
 * in a global queue.
 *
 * This scheduler ensures that tasks scheduled via `enqueue` are executed
 * in the order they were added, one at a time. If a task throws an error,
 * it is rethrown asynchronously to avoid blocking subsequent tasks in the queue.
 *
 * @returns {Scheduler} An object with methods to enqueue tasks and flush the queue.
 * @property {(fn: () => Promise<T> | T) => Promise<T>} enqueue
 *   Adds a task to the queue. The task may be synchronous or asynchronous.
 * @property {() => Promise<void>} flush
 *   Waits until all scheduled tasks have completed execution.
 */
export declare function createScheduler(): Scheduler;
export declare const scheduler: Scheduler;
