/**
 * Functional Scheduler
 *
 * Guarantees:
 * - FIFO execution (one task at a time)
 * - Supports synchronous and asynchronous tasks
 * - Errors reject the task promise but do NOT stop the queue
 * - `flush()` is microtask-stable:
 *   it resolves only after the queue stays empty
 *   across a microtask turn (prevents “flush lies”)
 *
 * Performance optimizations:
 * - Parallel arrays instead of per-task objects
 * - At most one pump in flight
 * - Compact storage for flush waiters
 */
export type Scheduler = {
    /**
     * Enqueue a task for serialized execution.
     *
     * The task may return a value or a promise.
     * The returned promise resolves or rejects with the task result.
     */
    enqueue: <T>(fn: () => Promise<T> | T) => Promise<T>;
    /**
     * Resolves when the scheduler becomes idle and
     * remains idle across a microtask boundary.
     */
    flush: () => Promise<void>;
};
export declare function createScheduler(): Scheduler;
/**
 * Global scheduler instance used by Streamix.
 */
export declare const scheduler: Scheduler;
