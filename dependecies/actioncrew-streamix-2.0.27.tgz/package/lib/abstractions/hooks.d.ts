export type PipeStreamHookContext = {
    streamId: string;
    streamName?: string;
    subscriptionId: string;
    source: AsyncIterator<any>;
    operators: any[];
};
export type PipeStreamHookResult = {
    source?: AsyncIterator<any>;
    operators?: any[];
    final?: (iterator: AsyncIterator<any>) => AsyncIterator<any>;
};
export type StreamRuntimeHooks = {
    onCreateStream?: (info: {
        id: string;
        name?: string;
    }) => void;
    onPipeStream?: (ctx: PipeStreamHookContext) => PipeStreamHookResult | void;
};
export declare function generateStreamId(): string;
export declare function generateSubscriptionId(): string;
export declare function registerRuntimeHooks(hooks: StreamRuntimeHooks): void;
export declare function getRuntimeHooks(): StreamRuntimeHooks | null;
