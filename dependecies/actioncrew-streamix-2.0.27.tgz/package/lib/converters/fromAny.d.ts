import { MaybePromise, Stream } from "../abstractions";
/**
 * Converts a wide variety of input values into a {@link Stream}.
 *
 * This function normalizes different asynchronous or synchronous sources into a
 * unified `Stream<R>` so they can be processed uniformly in operators and pipelines.
 *
 * Supported inputs:
 * - A {@link Stream<R>} (returned as-is).
 * - A {@link MaybePromise<R>} (a value or a promise resolving to a value),
 *   wrapped into a single–emission stream.
 * - An array of `R`, converted into a stream using {@link from}.
 *
 * @template R The type of values emitted by the resulting stream.
 * @param value The input source to convert into a stream. Can be a stream, a value,
 * a promise, or an array of values.
 * @returns A {@link Stream<R>} representing the given input.
 */
export declare function fromAny<R = any>(value: MaybePromise<Stream<R> | Array<R> | R>): Stream<R>;
