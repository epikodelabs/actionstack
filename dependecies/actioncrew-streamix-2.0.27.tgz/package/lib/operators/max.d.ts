import { MaybePromise, Operator } from '../abstractions';
/**
 * Creates a stream operator that emits the maximum value from the source stream.
 *
 * This is a terminal operator that consumes the entire source lazily,
 * emitting phantoms along the way and finally emitting the maximum value.
 *
 * @template T The type of the values in the source stream.
 * @param comparator Optional comparison function: positive if `a > b`, negative if `a < b`.
 * @returns An `Operator` instance usable in a stream's `pipe` method.
 */
export declare const max: <T = any>(comparator?: ((a: T, b: T) => MaybePromise<number>) | undefined) => Operator<T, T>;
