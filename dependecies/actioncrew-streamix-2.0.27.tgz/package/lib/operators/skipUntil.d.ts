import { MaybePromise, Operator, Stream } from '../abstractions';
/**
 * Creates a stream operator that skips all values from the source stream until
 * a value is emitted by a `notifier` stream.
 *
 * This operator controls the flow of data based on an external signal. It initially
 * drops all values from the source stream. It also subscribes to a separate `notifier`
 * stream. When the notifier emits its first value, the operator's internal state
 * changes, allowing all subsequent values from the source stream to pass through.
 *
 * This is useful for delaying the start of a data-intensive process until a specific
 * condition is met, for example, waiting for a user to click a button or for
 * an application to finish loading.
 *
 * @template T The type of the values in the source and output streams.
 * @param notifier The stream that, upon its first emission, signals that the operator
 * should stop skipping values.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare function skipUntil<T = any, R = T>(notifier: MaybePromise<Stream<R> | R>): Operator<T, T>;
