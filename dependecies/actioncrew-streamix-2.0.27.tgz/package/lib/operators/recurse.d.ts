import { MaybePromise, Operator, Stream } from "../abstractions";
/**
 * Options to configure the recursive traversal behavior.
 */
export type RecurseOptions = {
    /**
     * The traversal strategy to use.
     * - `'depth'`: Processes deeper values first (LIFO queue).
     * - `'breadth'`: Processes values level by level (FIFO queue).
     * Defaults to depth-first.
     */
    traversal?: 'depth' | 'breadth';
    /**
     * The maximum depth to traverse. Prevents infinite recursion and limits the size
     * of the traversal. Defaults to no limit.
     */
    maxDepth?: number;
};
/**
 * Creates a stream operator that recursively processes values from a source stream.
 *
 * This operator is designed for traversing tree-like or hierarchical data structures.
 * For each value from the source, it checks if it meets a `condition`. If it does,
 * it applies a `project` function to get a new "inner" stream of children. These
 * children are then added to an internal queue and processed in the same recursive manner.
 *
 * The operator supports both depth-first and breadth-first traversal strategies and
 * can be configured with a maximum recursion depth to prevent runaway processing.
 *
 * @template T The type of the values in the source and output streams.
 * @param condition A function that returns a boolean indicating whether to recurse on a value.
 * @param project A function that takes a value and returns a stream of new values to be
 * recursively processed.
 * @param options An optional configuration object for traversal behavior.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare const recurse: <T = any>(condition: (value: T) => MaybePromise<boolean>, project: (value: T) => MaybePromise<Stream<T> | Array<T> | T>, options?: RecurseOptions) => Operator<T, T>;
