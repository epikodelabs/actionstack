import { MaybePromise, Operator } from "../abstractions";
/**
 * Buffers a fixed number of values from the source stream and emits them as arrays,
 * tracking pending and phantom values in the PipeContext.
 *
 * @template T The type of values in the source stream.
 * @param bufferSize The maximum number of values per buffer (default: Infinity).
 * @returns An Operator instance for use in a stream's `pipe` method.
 */
export declare const bufferCount: <T = any>(bufferSize?: MaybePromise<number>) => Operator<T, T[]>;
