import { type MaybePromise, type Operator } from "../abstractions";
/**
 * Buffers values from the source stream and emits them as arrays every `period` milliseconds,
 * while tracking pending and phantom values in the PipeContext.
 *
 * @template T The type of the values in the source stream.
 * @param period Time in milliseconds between each buffer flush.
 * @returns An Operator instance for use in a stream's `pipe` method.
 */
export declare function buffer<T = any>(period: MaybePromise<number>): Operator<T, T[]>;
