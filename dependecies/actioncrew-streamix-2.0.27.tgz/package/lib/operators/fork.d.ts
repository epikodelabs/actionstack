import { MaybePromise, Operator, Stream } from "../abstractions";
/**
 * Represents a conditional branch for the `fork` operator.
 *
 * Each `ForkOption` defines:
 * 1. A predicate function `on` to test source values.
 * 2. A handler function `handler` that produces a stream (or value/array/promise) when the predicate matches.
 *
 * @template T The type of values in the source stream.
 * @template R The type of values emitted by the handler and output stream.
 */
export interface ForkOption<T = any, R = any> {
    /**
     * Predicate function to determine if this option should handle a value.
     *
     * @param value The value from the source stream.
     * @param index The zero-based index of the value in the source stream.
     * @returns A boolean or a `Promise<boolean>` indicating whether this option matches.
     */
    on: (value: T, index: number) => MaybePromise<boolean>;
    /**
     * Handler function called for values that match the predicate.
     *
     * Can return:
     * - a {@link Stream<R>}
     * - a {@link MaybePromise<R>} (value or promise)
     * - an array of `R`
     *
     * @param value The source value that matched the predicate.
     * @returns A stream, value, promise, or array to be flattened and emitted.
     */
    handler: (value: T) => (Stream<R> | MaybePromise<R> | Array<R>);
}
/**
 * Creates a stream operator that routes each source value through a specific handler
 * based on matching predicates defined in the provided `ForkOption`s.
 *
 * For each value from the source stream:
 * 1. Iterates over the `options` array.
 * 2. Executes the `on` predicate for each option until one returns `true`.
 * 3. Calls the corresponding `handler` for the first matching option.
 * 4. Flattens the result (stream, value, promise, or array) sequentially into the output stream.
 *
 * If no predicate matches a value, an error is thrown.
 *
 * This operator allows conditional branching in streams based on the content of each item.
 *
 * @template T The type of values in the source stream.
 * @template R The type of values emitted by the output stream.
 * @param options {@link ForkOption} objects defining predicates and handlers.
 * @returns An {@link Operator} instance suitable for use in a stream's `pipe` method.
 *
 * @throws {Error} If a source value does not match any predicate.
 */
export declare const fork: <T = any, R = any>(...options: Array<MaybePromise<ForkOption<T, R>>>) => Operator<T, R>;
