import { type MaybePromise, type Operator, type Stream } from '../abstractions';
/**
 * Creates a stream operator that emits all values from the source stream until
 * a value is emitted by a `notifier` stream.
 *
 * This operator controls the lifespan of a stream based on an external signal.
 * It consumes and re-emits values from the source until the `notifier` stream
 * emits its first value. As soon as that happens, the operator completes the
 * output stream and unsubscribes from both the source and the notifier.
 *
 * This is useful for automatically stopping an operation when a certain condition
 * is met, such as waiting for a user to close a dialog or for an animation to complete.
 *
 * @template T The type of the values in the source and output streams.
 * @param notifier The stream that, upon its first emission, signals that the operator
 * should complete.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare function takeUntil<T = any, R = T>(notifier: MaybePromise<Stream<R> | R>): Operator<T, T>;
