import { MaybePromise, Operator } from "../abstractions";
import { Coroutine } from "./coroutine";
/**
 * A coroutine-like operator that can process tasks asynchronously in the background.
 * Extends the base Operator interface to provide task processing capabilities
 * with proper resource cleanup.
 *
 * This interface combines the properties of a stream `Operator` with the
 * functionality of a standalone coroutine, allowing it to be used for
 * both stream transformations and direct, one-off data processing.
 *
 * @template T The type of the input value.
 * @template R The type of the output value.
 */
export interface CoroutineLike<T = any, R = T> extends Operator<T, R> {
    /**
     * Processes a single piece of data asynchronously.
     * This method allows the coroutine's logic to be called directly, outside of a stream pipeline.
     *
     * @param data The input data to be processed.
     * @returns A Promise that resolves with the processed output.
     */
    processTask: (data: T) => Promise<R>;
    /**
     * Performs any necessary cleanup and finalization logic.
     * This method is called to release resources held by the coroutine.
     *
     * @returns A Promise that resolves when finalization is complete.
     */
    finalize: () => Promise<void>;
}
export declare function cascade<A, B>(...tasks: [MaybePromise<Coroutine<A, B>>]): CoroutineLike<A, B>;
export declare function cascade<A, B, C>(...tasks: [MaybePromise<Coroutine<A, B>>, MaybePromise<Coroutine<B, C>>]): CoroutineLike<A, C>;
export declare function cascade<A, B, C, D>(...tasks: [MaybePromise<Coroutine<A, B>>, MaybePromise<Coroutine<B, C>>, MaybePromise<Coroutine<C, D>>]): CoroutineLike<A, D>;
export declare function cascade<T = any, R = any>(...tasks: Array<MaybePromise<Coroutine<any, any>>>): CoroutineLike<T, R>;
