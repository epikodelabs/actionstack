import { type Operator } from "../abstractions";
/**
 * Creates a stream operator that counts the number of items emitted by the source stream.
 *
 * This operator consumes all values from the source stream without emitting anything.
 * Once the source stream completes, it emits a single value, which is the total
 * number of items that were in the source stream. It then completes.
 *
 * @template T The type of the values in the source stream.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare const count: <T = any>() => Operator<T, number>;
