import { MaybePromise, Operator } from '../abstractions';
/**
 * Creates a stream operator that emits the latest value from the source stream
 * at most once per specified duration.
 *
 * Each incoming value is stored as the "latest"; a timer emits that latest value
 * when the duration elapses. If the source completes before emission, the last
 * buffered value is flushed before completing.
 *
 * @template T The type of the values in the stream.
 * @param duration The time in milliseconds (or a promise resolving to it) to wait
 * before emitting the latest value. The duration is resolved once when the operator starts.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare const audit: <T = any>(duration: MaybePromise<number>) => Operator<T, T>;
