import { Operator } from "../abstractions";
/**
 * @typedef {object} CoroutineMessage
 * Message structure exchanged between main thread and Web Workers in the Coroutine operator.
 * @property {number} workerId - The unique ID of the worker.
 * @property {string} taskId - The unique ID of the task.
 * @property {string} type - The type of message (e.g., 'task', 'response', 'error').
 * @property {any} [payload] - The optional message payload.
 * @property {string} [error] - The optional error message.
 */
export type CoroutineMessage = {
    workerId: number;
    taskId: string;
    type: string;
    payload?: any;
    error?: string;
};
/**
 * @typedef {object} CoroutineConfig
 * Configuration object for the Coroutine factory.
 * @property {string} [template] - Custom worker script template. Use {HELPERS}, {DEPENDENCIES}, {MAIN_TASK} as placeholders.
 * @property {string[]} [helpers] - Custom helper scripts to inject.
 * @property {string} [initCode] - Custom initialization code that runs when the worker starts.
 * @property {string} [globals] - Additional imports or global variables.
 * @property {function(MessageEvent<CoroutineMessage>, Worker, Map<string, { resolve: (value: any) => void; reject: (error: Error) => void }>): void} [customMessageHandler] - A custom message handler for all messages from the worker.
 */
export type CoroutineConfig = {
    template?: string;
    helpers?: string[];
    initCode?: string;
    globals?: string;
    customMessageHandler?: (event: MessageEvent<CoroutineMessage>, worker: Worker, pendingTasks: Map<string, {
        resolve: (value: any) => void;
        reject: (error: Error) => void;
    }>) => void;
};
/**
 * @typedef {Operator<T, R> & {
 * assignTask: (workerId: number, data: T) => Promise<R>;
 * processTask: (data: T) => Promise<R>;
 * getIdleWorker: () => Promise<{ worker: Worker; workerId: number }>;
 * returnWorker: (workerId: number) => void;
 * finalize: () => Promise<void>;
 * }} Coroutine
 * @template T
 * @template R
 * Extended Operator that manages a pool of Web Workers for concurrent task processing.
 */
export type Coroutine<T = any, R = T> = Operator<T, R> & {
    /**
     * Assigns a task to a specific worker in the pool.
     *
     * @param workerId The ID of the worker to which the task will be assigned.
     * @param data The input data for the task.
     * @returns A Promise that resolves with the result of the task.
     */
    assignTask: (workerId: number, data: T) => Promise<R>;
    /**
     * Processes a task by assigning it to the next available worker in the pool.
     * This is the primary method for offloading work.
     *
     * @param data The input data for the task.
     * @returns A Promise that resolves with the result of the task.
     */
    processTask: (data: T) => Promise<R>;
    /**
     * Retrieves a worker from the pool that is ready to accept a new task.
     * If no workers are available, a new one may be created, up to a maximum limit.
     *
     * @returns A Promise that resolves with an object containing the worker and its ID.
     */
    getIdleWorker: () => Promise<{
        worker: Worker;
        workerId: number;
    }>;
    /**
     * Returns a worker to the pool, making it available for subsequent tasks.
     *
     * @param workerId The ID of the worker to return.
     */
    returnWorker: (workerId: number) => void;
    /**
     * Terminates all active workers and cleans up all related resources,
     * including the object URL for the worker script.
     *
     * @returns A Promise that resolves when all cleanup is complete.
     */
    finalize: () => Promise<void>;
};
/**
 * @callback ProgressCallback
 * @param {any} progressData - The data object containing progress information.
 * Callback function to report progress updates from a task.
 */
export type ProgressCallback = (progressData: any) => void;
/**
 * @typedef {object} WorkerUtils
 * The utility functions passed to the worker's main task function.
 * @property {(payload: any) => Promise<any>} requestData - A function to request data from the main thread.
 * @property {(progressData: any) => void} reportProgress - A function to report progress updates to the main thread.
 */
export type WorkerUtils = {
    requestData: (payload: any) => Promise<any>;
    reportProgress: (progressData: any) => void;
};
/**
 * @typedef {(data: T) => Promise<R> | R | ((data: T, utils: WorkerUtils) => Promise<R> | R)} MainTask
 * @template T
 * @template R
 * Type for the main task function running inside the worker.
 */
export type MainTask<T = any, R = any> = ((data: T) => Promise<R> | R) | ((data: T, utils: WorkerUtils) => Promise<R> | R);
/**
 * Creates a coroutine operator for managing a pool of Web Workers.
 *
 * This function has two overloaded signatures:
 * 1. `coroutine(config)`: Returns a factory function that takes a main task and helper functions.
 * 2. `coroutine(mainTask, ...helpers)`: Directly creates a coroutine operator with a default configuration.
 *
 * This operator is a powerful tool for offloading computationally intensive tasks from the main
 * thread, allowing for concurrent processing of stream data without blocking the UI. It manages a pool
 * of workers, dynamically scaling up to `navigator.hardwareConcurrency` and reusing workers
 * to minimize overhead.
 *
 * @template T The type of the input data for the main task.
 * @template R The type of the return value from the main task.
 * @param {CoroutineConfig} config - The configuration object for the worker pool.
 * @returns {<T, R>(main: MainTask<T, R>, ...functions: Function[]) => Coroutine<T, R>} A higher-order function for creating a Coroutine operator.
 */
export declare function coroutine(config: CoroutineConfig): <T, R>(main: MainTask<T, R>, ...functions: Function[]) => Coroutine<T, R>;
/**
 * Creates a coroutine operator with a default configuration.
 * @template T The type of the input data for the main task.
 * @template R The type of the return value from the main task.
 * @param {MainTask<T, R>} main - The main task function to run inside the workers.
 * @param {Function[]} functions - Any helper functions required by the main task.
 * @returns {Coroutine<T, R>} A Coroutine operator.
 */
export declare function coroutine<T, R>(main: MainTask<T, R>, ...functions: Function[]): Coroutine<T, R>;
