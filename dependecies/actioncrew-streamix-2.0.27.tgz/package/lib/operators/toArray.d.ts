import { Operator } from "../abstractions";
/**
 * Collects all emitted values from the source stream into an array
 * and emits that array once the source completes, tracking pending state.
 *
 * @template T The type of the values in the source stream.
 * @returns An Operator instance for use in a stream's `pipe` method.
 */
export declare const toArray: <T = any>() => Operator<T, T[]>;
