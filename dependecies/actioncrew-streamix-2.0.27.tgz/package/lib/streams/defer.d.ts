import { type MaybePromise, type Stream } from '../abstractions';
/**
 * Creates a stream that defers the creation of an inner stream until it is
 * subscribed to.
 *
 * This operator ensures that the `factory` function is called only when
 * a consumer subscribes to the stream, making it a good choice for
 * creating "cold" streams. Each new subscription will trigger a new
 * call to the `factory` and create a fresh stream instance.
 *
 * @template T The type of the values in the inner stream.
 * @param {() => (Stream<T> | MaybePromise<T> | Array<T>)} factory A function that returns the stream to be subscribed to.
 * @returns {Stream<T>} A new stream that defers subscription to the inner stream.
 */
export declare function defer<T = any>(factory: () => MaybePromise<(Stream<T> | Array<T> | T)>): Stream<T>;
