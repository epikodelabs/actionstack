import { MaybePromise, Stream } from '../abstractions';
/**
 * Creates a stream that emits an array of `MutationRecord` objects whenever
 * a change is detected on a given DOM element.
 *
 * Automatically unsubscribes if the element is removed from the DOM.
 *
 * @param element The DOM element (or promise) to observe for mutations.
 * @param options An optional object (or promise) specifying which DOM changes to observe.
 * @returns A Stream emitting arrays of `MutationRecord`s.
 */
export declare function onMutation(element: MaybePromise<Element>, options?: MaybePromise<MutationObserverInit>): Stream<MutationRecord[]>;
