import { Stream } from '../abstractions';
/**
 * Creates a stream that emits the current screen orientation, either
 * "portrait" or "landscape", whenever it changes.
 *
 * Automatically unsubscribes when unsubscribed.
 *
 * @returns {Stream<"portrait" | "landscape">} A stream that emits a string indicating the screen's orientation.
 */
/**
 * Creates a stream that emits the current screen orientation, either
 * "portrait" or "landscape", whenever it changes.
 *
 * Automatically unsubscribes when unsubscribed.
 *
 * @returns {Stream<"portrait" | "landscape">} A stream that emits a string indicating the screen's orientation.
 */
export declare function onOrientation(): Stream<"portrait" | "landscape">;
