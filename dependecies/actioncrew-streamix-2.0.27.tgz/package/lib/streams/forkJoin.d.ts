import { type MaybePromise, type Stream } from "../abstractions";
/**
 * Waits for all streams to complete and emits an array of their last values.
 *
 * @template T The type of the last values emitted by each stream.
 * @param sources Streams to join; arrays/iterables are also accepted for backward compatibility.
 * @returns Stream<T[]>
 */
export declare function forkJoin<T = any, R extends readonly unknown[] = any[]>(...sources: {
    [K in keyof R]: MaybePromise<Stream<R[K]> | Array<R[K]> | R[K]>;
}): Stream<T[]>;
