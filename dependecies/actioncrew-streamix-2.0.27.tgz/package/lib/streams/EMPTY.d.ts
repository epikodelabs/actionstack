import { type Stream } from '../abstractions';
/**
 * Creates an empty stream that emits no values and completes immediately.
 *
 * This function creates a stream that serves as a useful utility for
 * scenarios where a stream is expected but no values need to be produced.
 * It completes immediately upon subscription, allowing a sequence of
 * other streams to proceed without delay.
 *
 * @template T The type of the stream's values (will never be emitted).
 * @returns {Stream<T>} An empty stream.
 */
/**
 * A singleton instance of an empty stream.
 *
 * This constant provides a reusable, empty stream that immediately completes
 * upon subscription without emitting any values. It is useful in stream
 * compositions as a placeholder or to represent a sequence with no elements.
 *
 * @type {Stream<any>}
 */
export declare const empty: <T = any>() => Stream<T>;
/**
 * A singleton instance of an empty stream.
 *
 * This constant provides a reusable, empty stream that immediately completes
 * upon subscription without emitting any values. It is useful in stream
 * compositions as a placeholder or to represent a sequence with no elements.
 */
export declare const EMPTY: Stream<any>;
