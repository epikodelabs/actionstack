import { Stream } from '../abstractions';
/**
 * Creates a reactive stream that emits the time delta (in milliseconds) between
 * consecutive `requestAnimationFrame` calls.
 *
 * This stream provides a convenient way to track frame updates in animations,
 * game loops, or other time-sensitive operations. Each subscriber receives
 * a stream of `number` values representing the elapsed time since the previous frame.
 *
 * **Behavior:**
 * - When a subscriber subscribes, a new RAF loop starts immediately.
 * - The first emitted value is the delta between the first and second RAF callbacks.
 * - Each subsequent frame emits the delta since the previous frame.
 * - When the subscriber unsubscribes, the RAF loop is canceled to avoid unnecessary CPU usage.
 *
 * @returns {Stream<number>} A stream emitting the time delta between frames.
 */
export declare function onAnimationFrame(): Stream<number>;
