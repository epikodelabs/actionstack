import { MaybePromise, Stream } from '../abstractions';
/**
 * Combines multiple streams by emitting an array of values (a tuple),
 * only when all streams have a value ready (one-by-one, synchronized).
 *
 * It waits for the next value from all streams to form the next tuple.
 * The stream completes when any of the input streams complete.
 * Errors from any stream propagate immediately.
 *
 * @template T - A tuple type representing the combined values from the streams.
 * @param streams Streams to combine.
 * @returns {Stream<T>} A new stream that emits a synchronized tuple of values.
 */
export declare function zip<T extends readonly unknown[] = any[]>(...sources: Array<MaybePromise<Stream<T[number]> | Array<T[number]> | T[number]>>): Stream<T>;
