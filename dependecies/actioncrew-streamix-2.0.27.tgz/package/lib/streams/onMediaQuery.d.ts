import { MaybePromise, Stream } from '../abstractions';
/**
 * Creates a reactive stream that emits `true` or `false` whenever a CSS media query
 * matches or stops matching.
 *
 * This stream allows you to reactively track viewport changes, orientation, or
 * other media features in a consistent, subscription-based way.
 *
 * **Behavior:**
 * - The initial match status is emitted immediately upon subscription.
 * - Subsequent changes are emitted whenever the media query's match state changes.
 * - Each subscriber has its own listener, which is cleaned up when unsubscribing.
 *
 * @param mediaQueryString A valid CSS media query string (or promise) (e.g., "(min-width: 600px)").
 * @returns {Stream<boolean>} A stream emitting `true` if the query matches, `false` otherwise.
 */
export declare function onMediaQuery(mediaQueryString: MaybePromise<string>): Stream<boolean>;
