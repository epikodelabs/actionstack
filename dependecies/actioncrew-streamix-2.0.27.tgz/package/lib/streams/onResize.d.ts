import { MaybePromise, Stream } from '../abstractions';
/**
 * Creates a stream that emits the dimensions (width and height) of a given
 * DOM element whenever it is resized.
 *
 * Automatically unsubscribes and completes if the element is removed from the DOM.
 *
 * @param element The DOM element (or promise resolving to one) to observe for size changes.
 * @returns A Stream emitting objects with `width` and `height` properties.
 */
export declare function onResize(element: MaybePromise<HTMLElement>): Stream<{
    width: number;
    height: number;
}>;
