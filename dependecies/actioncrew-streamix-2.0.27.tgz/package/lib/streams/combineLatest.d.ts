import { MaybePromise, Stream } from "../abstractions";
/**
 * Combines multiple streams and emits a tuple containing the latest values
 * from each stream whenever any of the source streams emits a new value.
 *
 * This operator is useful for scenarios where you need to react to changes
 * in multiple independent data sources simultaneously. The output stream
 * will not emit a value until all source streams have emitted at least one
 * value. The output stream completes when all source streams have completed.
 *
 * @template {unknown[]} T A tuple type representing the combined values from the streams.
 * @param streams Streams/values to combine.
 * @returns {Stream<T>} A new stream that emits a tuple of the latest values from all source streams.
 */
export declare function combineLatest<T extends unknown[] = any[]>(...sources: Array<MaybePromise<Stream<T[number]> | Array<T[number]> | T[number]>>): Stream<T>;
