import { MaybePromise, Stream } from "../abstractions";
/**
 * Creates a stream that subscribes to a source factory and retries on error.
 *
 * This operator is useful for handling streams that may fail due to
 * temporary issues, such as network problems. It will attempt to
 * resubscribe to the source stream up to `maxRetries` times, with an
 * optional delay between each attempt. If the stream completes successfully
 * on any attempt, it will emit all of its values and then complete.
 * If all retry attempts fail, the final error is propagated.
 *
 * @template T The type of values emitted by the stream.
 * @param {() => (Stream<T> | MaybePromise<T>)} factory A function that returns a new stream instance for each subscription attempt.
 * @param {MaybePromise<number>} [maxRetries=3] The maximum number of times to retry the stream. A value of 0 means no retries.
 * @param {MaybePromise<number>} [delay=1000] The time in milliseconds to wait before each retry attempt.
 * @returns {Stream<T>} A new stream that applies the retry logic.
 */
export declare function retry<T = any>(factory: () => MaybePromise<(Stream<T> | T)>, maxRetries?: MaybePromise<number>, delay?: MaybePromise<number>): Stream<T>;
