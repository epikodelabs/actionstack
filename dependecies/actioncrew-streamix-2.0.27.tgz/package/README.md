<p align="center">
  <img src="https://github.com/actioncrew/streamix/blob/main/projects/libraries/streamix/LOGO.png?raw=true" alt="Streamix Logo" width="400">
</p>

<p align="center">
  <strong>A lightweight, high-performance alternative to RxJS</strong><br>
  Built for modern apps that need reactive streams without the complexity
</p>

<p align="center">
  <a href="https://github.com/actioncrew/streamix/workflows/build/badge.svg">
    <img src="https://github.com/actioncrew/streamix/workflows/build/badge.svg" alt="Build Status">
  </a>
  <a href="https://www.npmjs.com/package/@actioncrew%2Fstreamix">
    <img src="https://img.shields.io/npm/v/@actioncrew%2Fstreamix.svg?style=flat-square" alt="NPM Version">
  </a>
  <a href="https://www.npmjs.com/package/@actioncrew%2Fstreamix">
    <img src="https://img.shields.io/npm/dm/@actioncrew%2Fstreamix.svg?style=flat-square" alt="NPM Downloads">
  </a>
  <a href="https://github.com/actioncrew/streamix">
    <img src="https://raw.githubusercontent.com/actioncrew/streamix/main/projects/libraries/streamix/bundle-size.svg" alt="Bundle Size">
  </a>
  <a href="https://codecov.io/github/actioncrew/streamix" >
    <img src="https://codecov.io/github/actioncrew/streamix/graph/badge.svg?token=ITHDU7JVOI" alt="Code Coverage"/>
  </a>
  <a href="https://www.npmjs.com/package/@actioncrew/streamix">
    <img src="https://img.shields.io/badge/AI-Powered-blue" alt="AI-Powered">
  </a>
</p>

---

## 📖 Table of Contents

- [Why Streamix?](#-why-streamix)
- [Installation](#-installation)
- [Quick Start](#️-quick-start)
- [Core Concepts](#-core-concepts)
- [Stream Creation](#-stream-creation)
- [Operators Reference](#-operators-reference)
- [HTTP Client](#-http-client)
- [DOM Observation](#-dom-observation)
- [Advanced Patterns](#-advanced-patterns)
- [Real-World Examples](#-real-world-examples)
- [Performance & Architecture](#-performance--architecture)
- [Migration from RxJS](#-migration-from-rxjs)
- [Best Practices](#-best-practices)
- [API Documentation](#-api-documentation)
- [Contributing](#-contributing)

---

## 🚀 Why Streamix?

Streamix gives you all the power of reactive programming with **90% less complexity** than RxJS. At just **9 KB zipped**, it's perfect for modern applications that need performance without bloat.

### The Problem with Traditional Reactive Libraries

Traditional reactive programming libraries like RxJS are powerful but come with significant drawbacks:

- **Large bundle sizes** that impact load times and performance
- **Steep learning curves** with complex concepts like hot/cold observables
- **Push-based architectures** that can lead to wasted computations
- **Memory overhead** from subscription management
- **Difficult debugging** due to complex operator chains

### The Streamix Solution

Streamix solves these problems with a fundamentally different approach:

- **Generator-based architecture** that naturally handles async operations
- **Pull-based execution** where values are computed only when needed
- **Minimal API surface** that's easy to learn and remember
- **TypeScript-first design** for excellent IDE support
- **Zero dependencies** for maximum compatibility

### ✨ Key Benefits

- **🪶 Ultra Lightweight** — Only 9 KB zipped (vs RxJS's ~40 KB), with optional HTTP client at ~3 KB
- **⚡ High Performance** — Pull-based execution means values are only computed when needed
- **🎯 Easy to Learn** — Familiar API if you know RxJS, simpler if you don't
- **🔄 Generator-Powered** — Built on async generators for natural async flow
- **🌐 HTTP Ready** — Optional HTTP client with middleware support
- **🧠 Computation-Friendly** — Perfect for heavy processing tasks like data analysis
- **👁️ Native DOM Observation** — Built-in streams for intersection, resize, and mutation events
- **🔧 TypeScript Native** — Full type safety and excellent autocomplete
- **🎨 Framework Agnostic** — Works with React, Vue, Angular, Svelte, or vanilla JS
- **📦 Tree-Shakeable** — Only bundle the operators you actually use

### When to Use Streamix

Streamix excels in scenarios where you need:

- **Event handling** — User interactions, keyboard events, mouse movements
- **Data streaming** — Processing large datasets incrementally
- **API requests** — Managing multiple async operations with retries and timeouts
- **Real-time updates** — WebSocket connections, server-sent events
- **Complex async flows** — Coordinating multiple async operations
- **Heavy computations** — Processing data without blocking the UI
- **Form validation** — Debouncing input and coordinating validation rules

---

## 📦 Installation

```bash
# npm
npm install @actioncrew/streamix

# yarn
yarn add @actioncrew/streamix

# pnpm
pnpm add @actioncrew/streamix
```

### TypeScript Configuration

Streamix is built with TypeScript and requires ES2018 or later for async generator support:

```json
{
  "compilerOptions": {
    "target": "ES2018",
    "lib": ["ES2018", "DOM"],
    "module": "ESNext",
    "moduleResolution": "node"
  }
}
```

---

## 🏃‍♂️ Quick Start

### Basic Stream Operations

```typescript
import { range, map, filter, take } from '@actioncrew/streamix';

// Create a stream of numbers, transform them, and consume
const stream = range(1, 100)
  .pipe(
    map(x => x * 2),           // Double each number
    filter(x => x % 3 === 0),  // Keep only multiples of 3
    take(5)                    // Take first 5 results
  );

// Consume the stream
for await (const value of stream) {
  console.log(value); // 6, 12, 18, 24, 30
}
```

### Handling User Events

```typescript
import { fromEvent, debounce, map, filter } from '@actioncrew/streamix';

// Debounced search as user types
const searchInput = document.getElementById('search');
const searchStream = fromEvent(searchInput, 'input')
  .pipe(
    map(event => event.target.value),
    debounce(300), // Wait 300ms after user stops typing
    filter(text => text.length > 2)
  );

for await (const searchTerm of searchStream) {
  console.log('Searching for:', searchTerm);
  // Perform search...
}
```

### Working with Promises

```typescript
import { fromPromise, retry, map } from '@actioncrew/streamix';

// Retry a failed API call up to 3 times
const dataStream = retry(
  () => fromPromise(fetch('/api/data').then(r => r.json())),
  3
).pipe(
  map(data => data.results)
);

for await (const results of dataStream) {
  console.log('Got results:', results);
}
```

---

## 🔧 Core Concepts

### Streams

Streams are the fundamental building blocks of Streamix. They represent sequences of values that arrive over time, implemented as async generators under the hood.

```typescript
// Creating a custom stream
async function* numberStream() {
  for (let i = 0; i < 10; i++) {
    yield i;
    await new Promise(resolve => setTimeout(resolve, 100));
  }
}

const stream = createStream('numberStream', numberStream);

// Consume the stream
for await (const num of stream) {
  console.log(num); // 0, 1, 2, ... 9 (one per 100ms)
}
```

### Operators

Operators are functions that transform, filter, or combine streams. They're chainable using the `pipe` method:

```typescript
import { map, filter, take } from '@actioncrew/streamix';

const processedStream = sourceStream
  .pipe(
    map(x => x * 2),        // Transform each value
    filter(x => x > 10),    // Keep only values > 10
    take(5)                 // Take first 5 matching values
  );
```

### Subjects

Subjects allow you to manually control stream emissions, acting as both a stream and a way to emit values:

```typescript
import { createSubject } from '@actioncrew/streamix';

const subject = createSubject<string>();

// Start consuming in the background
(async () => {
  for await (const value of subject) {
    console.log('Received:', value);
  }
})();

// Emit values from anywhere
subject.next('Hello');
subject.next('World');
subject.complete();
```

### Pull-Based Execution

Unlike RxJS's push model, Streamix uses a pull model where values are only computed when the consumer requests them:

```typescript
// This expensive computation only runs when you iterate
const expensiveStream = range(1, 1000000)
  .pipe(
    map(x => {
      console.log('Computing:', x); // Only logs when pulled
      return heavyComputation(x);
    }),
    take(10) // Only computes first 10 values
  );
```

---

## 🌊 Stream Creation

Streamix provides multiple ways to create streams from various sources:

### From Values

```typescript
import { of, range, interval } from '@actioncrew/streamix';

// Create a stream from values
const valueStream = of(1, 2, 3, 4, 5);

// Create a range of numbers
const rangeStream = range(1, 100);

// Create a stream that emits every N milliseconds
const timerStream = interval(1000); // Emits 0, 1, 2, ... every second
```

### From DOM Events

```typescript
import { fromEvent } from '@actioncrew/streamix';

const button = document.getElementById('myButton');
const clicks = fromEvent(button, 'click');

for await (const event of clicks) {
  console.log('Button clicked!', event);
}
```

### From Promises

```typescript
import { fromPromise } from '@actioncrew/streamix';

// Single promise
const dataStream = fromPromise(fetch('/api/data').then(r => r.json()));

// Multiple promises
async function* fetchMultiple() {
  const urls = ['/api/users', '/api/posts', '/api/comments'];
  for (const url of urls) {
    yield fromPromise(fetch(url).then(r => r.json()));
  }
}
```

### From Arrays

```typescript
import { from } from '@actioncrew/streamix';

const arrayStream = from([1, 2, 3, 4, 5]);
const stringStream = from('hello'); // Emits 'h', 'e', 'l', 'l', 'o'
```

### Custom Streams

```typescript
import { createStream } from '@actioncrew/streamix';

// Custom stream that emits mouse positions
async function* mousePositions() {
  const element = document.body;
  const queue: MouseEvent[] = [];
  
  const handler = (e: MouseEvent) => queue.push(e);
  element.addEventListener('mousemove', handler);
  
  try {
    while (true) {
      if (queue.length > 0) {
        const event = queue.shift()!;
        yield { x: event.clientX, y: event.clientY };
      }
      await new Promise(resolve => setTimeout(resolve, 16)); // ~60fps
    }
  } finally {
    element.removeEventListener('mousemove', handler);
  }
}

const positions = createStream('mousePositions', mousePositions);
```

---

## 🎯 Operators Reference

### Transformation Operators

**`map`** - Transform each value in the stream

```typescript
import { range, map } from '@actioncrew/streamix';

const doubled = range(1, 5).pipe(
  map(x => x * 2)
);
// Output: 2, 4, 6, 8, 10
```

**`scan`** - Accumulate values over time (like Array.reduce)

```typescript
import { range, scan } from '@actioncrew/streamix';

const sum = range(1, 5).pipe(
  scan((acc, val) => acc + val, 0)
);
// Output: 1, 3, 6, 10, 15
```

**`buffer`** - Collect values into arrays

```typescript
import { range, buffer } from '@actioncrew/streamix';

const buffered = range(1, 10).pipe(
  buffer(3)
);
// Output: [1,2,3], [4,5,6], [7,8,9], [10]
```

### Filtering Operators

**`filter`** - Keep only values that match a condition

```typescript
import { range, filter } from '@actioncrew/streamix';

const evens = range(1, 10).pipe(
  filter(x => x % 2 === 0)
);
// Output: 2, 4, 6, 8, 10
```

**`take`** - Take first N values

```typescript
import { range, take } from '@actioncrew/streamix';

const firstThree = range(1, 100).pipe(
  take(3)
);
// Output: 1, 2, 3
```

**`takeWhile`** - Take values while condition is true

```typescript
import { range, takeWhile } from '@actioncrew/streamix';

const whileLessThan10 = range(1, 100).pipe(
  takeWhile(x => x < 10)
);
// Output: 1, 2, 3, 4, 5, 6, 7, 8, 9
```

**`skip`** - Skip first N values

```typescript
import { range, skip } from '@actioncrew/streamix';

const afterFirst5 = range(1, 10).pipe(
  skip(5)
);
// Output: 6, 7, 8, 9, 10
```

**`distinct`** - Remove duplicate values

```typescript
import { from, distinct } from '@actioncrew/streamix';

const unique = from([1, 2, 2, 3, 3, 3, 4]).pipe(
  distinct()
);
// Output: 1, 2, 3, 4
```

### Combination Operators

**`mergeMap`** - Map each value to a stream and merge results

```typescript
import { range, mergeMap, fromPromise } from '@actioncrew/streamix';

const users = range(1, 3).pipe(
  mergeMap(id => fromPromise(fetch(`/api/users/${id}`).then(r => r.json())))
);
// Fetches all users concurrently
```

**`switchMap`** - Map to a stream, cancelling previous

```typescript
import { fromEvent, switchMap, fromPromise, map } from '@actioncrew/streamix';

const searchResults = fromEvent(input, 'input').pipe(
  map(e => e.target.value),
  switchMap(query => fromPromise(fetch(`/search?q=${query}`).then(r => r.json())))
);
// Only the latest search request completes
```

**`combineLatest`** - Combine latest values from multiple streams

```typescript
import { combineLatest, fromEvent, map } from '@actioncrew/streamix';

const width = fromEvent(window, 'resize').pipe(
  map(() => window.innerWidth)
);
const height = fromEvent(window, 'resize').pipe(
  map(() => window.innerHeight)
);

const dimensions = combineLatest([width, height]).pipe(
  map(([w, h]) => ({ width: w, height: h }))
);
```

**`concat`** - Connect streams sequentially

```typescript
import { concat, of } from '@actioncrew/streamix';

const sequence = concat(
  of(1, 2, 3),
  of(4, 5, 6),
  of(7, 8, 9)
);
// Output: 1, 2, 3, 4, 5, 6, 7, 8, 9
```

### Utility Operators

**`tap`** - Perform side effects without changing the stream

```typescript
import { range, tap, map } from '@actioncrew/streamix';

const logged = range(1, 5).pipe(
  tap(x => console.log('Before:', x)),
  map(x => x * 2),
  tap(x => console.log('After:', x))
);
```

**`delay`** - Add delays between emissions

```typescript
import { range, delay } from '@actioncrew/streamix';

const delayed = range(1, 5).pipe(
  delay(1000) // 1 second delay between each value
);
```

**`debounce`** - Emit only after a period of silence

```typescript
import { fromEvent, debounce, map } from '@actioncrew/streamix';

const debounced = fromEvent(input, 'input').pipe(
  map(e => e.target.value),
  debounce(300) // Wait 300ms after user stops typing
);
```

**`retry`** - Retry failed operations

```typescript
import { retry, fromPromise } from '@actioncrew/streamix';

const withRetry = retry(
  () => fromPromise(fetch('/api/data').then(r => r.json())),
  3 // Retry up to 3 times
);
```

**`finalize`** - Run cleanup when stream completes

```typescript
import { range, finalize } from '@actioncrew/streamix';

const withCleanup = range(1, 5).pipe(
  finalize(() => console.log('Stream completed!'))
);
```

**`startWith`** - Begin stream with initial value

```typescript
import { fromEvent, startWith, map } from '@actioncrew/streamix';

const withDefault = fromEvent(input, 'input').pipe(
  map(e => e.target.value),
  startWith('') // Start with empty string
);
```

**`catchError`** - Handle errors gracefully

```typescript
import { fromPromise, catchError, map } from '@actioncrew/streamix';

const safe = fromPromise(fetch('/api/data').then(r => r.json())).pipe(
  catchError(error => ({ error: error.message, data: null }))
);
```

---

## 🌐 HTTP Client

Streamix includes a powerful HTTP client perfect for reactive applications:

### Basic Usage

```typescript
import { createHttpClient, readJson } from '@actioncrew/streamix/http';

const client = createHttpClient();

// Make a GET request
const users = client.get('/api/users', readJson);

for await (const data of users) {
  console.log('Users:', data);
}
```

### Middleware Support

The HTTP client supports middleware for cross-cutting concerns:

```typescript
import {
  createHttpClient,
  readJson,
  useBase,
  useLogger,
  useTimeout,
  useRetry
} from '@actioncrew/streamix/http';

const client = createHttpClient().withDefaults(
  useBase('https://api.example.com'),
  useLogger(),
  useTimeout(5000),
  useRetry(3)
);

// All requests now use the configured middleware
const users = client.get('/users', readJson);
const posts = client.get('/posts', readJson);
```

### Request Methods

```typescript
// GET request
const data = client.get('/api/data', readJson);

// POST request
const created = client.post('/api/users', {
  body: JSON.stringify({ name: 'John' }),
  headers: { 'Content-Type': 'application/json' }
}, readJson);

// PUT request
const updated = client.put('/api/users/1', {
  body: JSON.stringify({ name: 'Jane' }),
  headers: { 'Content-Type': 'application/json' }
}, readJson);

// DELETE request
const deleted = client.delete('/api/users/1', readJson);
```

### Response Readers

```typescript
import { readJson, readText, readBlob } from '@actioncrew/streamix/http';

// Read as JSON
const jsonData = client.get('/api/data', readJson);

// Read as text
const textData = client.get('/api/document', readText);

// Read as Blob (for files)
const fileData = client.get('/api/file.pdf', readBlob);
```

### Combining with Operators

```typescript
import { map, retry, catchError } from '@actioncrew/streamix';

const robustRequest = retry(
  () => client.get('/api/data', readJson),
  3
).pipe(
  map(data => data.results),
  catchError(error => ({ error: error.message, results: [] }))
);
```

---

## 👁️ DOM Observation

Streamix provides built-in support for observing DOM changes:

### Intersection Observer

```typescript
import { fromIntersection } from '@actioncrew/streamix';

const element = document.getElementById('myElement');
const visibility = fromIntersection(element, {
  threshold: 0.5 // Trigger when 50% visible
});

for await (const entry of visibility) {
  if (entry.isIntersecting) {
    console.log('Element is visible!');
  }
}
```

### Resize Observer

```typescript
import { fromResize } from '@actioncrew/streamix';

const container = document.getElementById('container');
const sizes = fromResize(container);

for await (const entry of sizes) {
  console.log('New size:', entry.contentRect.width, entry.contentRect.height);
}
```

### Mutation Observer

```typescript
import { fromMutation } from '@actioncrew/streamix';

const container = document.getElementById('container');
const mutations = fromMutation(container, {
  childList: true,
  subtree: true
});

for await (const mutation of mutations) {
  console.log('DOM changed:', mutation);
}
```

---

## 🚀 Advanced Patterns

### Lazy Evaluation

Streamix streams are lazy - they don't execute until you start consuming them:

```typescript
// This doesn't execute anything yet
const expensiveStream = range(1, 1000000).pipe(
  map(x => {
    console.log('Processing:', x); // Not called yet!
    return heavyComputation(x);
  })
);

// Now it executes, but only for values we consume
for await (const value of expensiveStream.pipe(take(10))) {
  console.log(value); // Only processes first 10 values
}
```

### Error Handling

```typescript
import { catchError, retry, finalize } from '@actioncrew/streamix';

const resilientStream = retry(
  () => fromPromise(fetch('/api/data').then(r => r.json())),
  3
).pipe(
  catchError(error => {
    console.error('Failed after retries:', error);
    return { error: true, data: null };
  }),
  finalize(() => console.log('Stream completed'))
);
```

### Backpressure Handling

The pull-based model naturally handles backpressure:

```typescript
async function* slowProducer() {
  for (let i = 0; i < 1000; i++) {
    yield i;
    await new Promise(r => setTimeout(r, 10)); // Slow production
  }
}

async function slowConsumer(stream) {
  for await (const value of stream) {
    await new Promise(r => setTimeout(r, 100)); // Slow consumption
    console.log(value);
  }
}

// Producer automatically slows to match consumer
const stream = createStream('slowProducer', slowProducer);
await slowConsumer(stream);
```

### Stream Composition

```typescript
// Create reusable stream transformations
function addLogging<T>(stream: Stream<T>) {
  return stream.pipe(
    tap(x => console.log('Value:', x)),
    tap(x => console.log('Type:', typeof x))
  );
}

function addErrorHandling<T>(stream: Stream<T>) {
  return stream.pipe(
    catchError(error => {
      console.error('Error:', error);
      return null;
    }),
    filter(x => x !== null)
  );
}

// Compose them
const robustLogged = addErrorHandling(
  addLogging(someStream)
);
```

---

## 🎯 Real-World Examples

### Live Search with Debouncing

```typescript
import {
  fromEvent,
  fromPromise,
  debounce,
  map,
  filter,
  switchMap,
  catchError,
  startWith
} from '@actioncrew/streamix';

const searchInput = document.getElementById('search');
const resultsDiv = document.getElementById('results');

const searchResults = fromEvent(searchInput, 'input')
  .pipe(
    map(e => e.target.value.trim()),
    debounce(300),
    filter(query => query.length > 2),
    switchMap(query =>
      fromPromise(
        fetch(`/api/search?q=${query}`)
          .then(r => r.json())
          .catch(err => ({ error: 'Search failed', query }))
      )
    ),
    startWith({ results: [], query: '' })
  );

for await (const result of searchResults) {
  if (result.error) {
    resultsDiv.innerHTML = `<p class="error">${result.error}</p>`;
  } else {
    resultsDiv.innerHTML = result.results
      .map(item => `<div class="result">${item.title}</div>`)
      .join('');
  }
}
```

### Real-Time Form Validation

```typescript
import { fromEvent, combineLatest, map, debounce } from '@actioncrew/streamix';

const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');

const email = fromEvent(emailInput, 'input').pipe(
  map(e => e.target.value),
  debounce(300),
  map(value => ({
    value,
    valid: /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)
  }))
);

const password = fromEvent(passwordInput, 'input').pipe(
  map(e => e.target.value),
  debounce(300),
  map(value => ({
    value,
    valid: value.length >= 8
  }))
);

const formValid = combineLatest([email, password]).pipe(
  map(([e, p]) => e.valid && p.valid)
);

for await (const isValid of formValid) {
  submitButton.disabled = !isValid;
}
```

### Infinite Scroll

```typescript
import { fromEvent, filter, switchMap, fromPromise } from '@actioncrew/streamix';

let page = 1;
const scrollStream = fromEvent(window, 'scroll').pipe(
  filter(() => {
    const scrollTop = window.scrollY;
    const windowHeight = window.innerHeight;
    const docHeight = document.documentElement.scrollHeight;
    return scrollTop + windowHeight >= docHeight - 100;
  }),
  switchMap(() => {
    const currentPage = page++;
    return fromPromise(
      fetch(`/api/posts?page=${currentPage}`).then(r => r.json())
    );
  })
);

for await (const posts of scrollStream) {
  appendPostsToPage(posts);
}
```

### WebSocket Connection

```typescript
import { createStream, map, filter } from '@actioncrew/streamix';

async function* websocketStream(url: string) {
  const ws = new WebSocket(url);
  const messageQueue: any[] = [];
  
  ws.onmessage = (event) => messageQueue.push(JSON.parse(event.data));
  ws.onerror = (error) => console.error('WebSocket error:', error);
  
  try {
    while (ws.readyState === WebSocket.OPEN) {
      if (messageQueue.length > 0) {
        yield messageQueue.shift();
      }
      await new Promise(resolve => setTimeout(resolve, 10));
    }
  } finally {
    ws.close();
  }
}

const messages = createStream('websocket', () => websocketStream('wss://example.com'))
  .pipe(
    filter(msg => msg.type === 'notification'),
    map(msg => msg.data)
  );

for await (const notification of messages) {
  showNotification(notification);
}
```

### Data Polling

```typescript
import { interval, switchMap, fromPromise, retry } from '@actioncrew/streamix';

// Poll API every 5 seconds
const polling = interval(5000).pipe(
  switchMap(() =>
    retry(
      () => fromPromise(fetch('/api/status').then(r => r.json())),
      3
    )
  )
);

for await (const status of polling) {
  updateStatusDisplay(status);
}
```

---

## ⚡ Performance & Architecture

### Pull-Based vs Push-Based

Streamix uses a pull-based model (like async generators) rather than the push-based model used by RxJS:

**Push-Based (RxJS)**
- Source pushes values to subscribers
- All computations happen immediately
- Can lead to wasted work if consumer is slow
- Requires complex backpressure handling

**Pull-Based (Streamix)**
- Consumer pulls values when ready
- Computations happen on demand
- Natural backpressure handling
- More memory efficient

```typescript
// In Streamix, this only computes values as they're consumed
const efficientStream = range(1, 1000000).pipe(
  map(x => expensiveOperation(x)), // Only runs when pulled
  take(10) // Stop after 10 values
);
```

### Memory Efficiency

Streamix processes one value at a time, keeping memory usage low:

```typescript
// Processes 1 million numbers with minimal memory
const sum = await range(1, 1000000)
  .pipe(
    scan((acc, val) => acc + val, 0),
    takeLast(1)
  )
  .toArray();
```

### Bundle Size Comparison

| Library | Minified | Gzipped |
|---------|----------|---------|
| Streamix Core | 25 KB | 9 KB |
| Streamix + HTTP | 33 KB | 12 KB |
| RxJS | 160 KB | 40 KB |
| Most.js | 60 KB | 18 KB |

### Performance Benchmarks

Streamix excels at:
- **Sequential processing** - 2-3x faster than RxJS for linear operations
- **Large datasets** - Constant memory usage regardless of stream size
- **Heavy computations** - Only processes what's needed
- **Initial load time** - Smaller bundle = faster startup

---

## 🔄 Migration from RxJS

### API Similarities

Streamix intentionally uses familiar operator names:

| RxJS | Streamix | Notes |
|------|----------|-------|
| `of()` | `of()` | ✅ Same |
| `from()` | `from()` | ✅ Same |
| `range()` | `range()` | ✅ Same |
| `interval()` | `interval()` | ✅ Same |
| `fromEvent()` | `fromEvent()` | ✅ Same |
| `map()` | `map()` | ✅ Same |
| `filter()` | `filter()` | ✅ Same |
| `take()` | `take()` | ✅ Same |
| `skip()` | `skip()` | ✅ Same |
| `debounceTime()` | `debounce()` | Slightly different name |
| `switchMap()` | `switchMap()` | ✅ Same |
| `mergeMap()` | `mergeMap()` | ✅ Same |
| `catchError()` | `catchError()` | ✅ Same |
| `retry()` | `retry()` | ✅ Same |
| `tap()` | `tap()` | ✅ Same |
| `finalize()` | `finalize()` | ✅ Same |

### Key Differences

**Subscription Model**
```typescript
// RxJS - Subscriptions
const subscription = observable.subscribe(
  value => console.log(value),
  error => console.error(error),
  () => console.log('Complete')
);
subscription.unsubscribe();

// Streamix - For-await loops
for await (const value of stream) {
  console.log(value);
}
// Cleanup happens automatically
```

**Hot vs Cold**
```typescript
// RxJS - Must consider hot/cold observables
const hot = observable.pipe(share());

// Streamix - All streams are "cold" by default (pull-based)
// Values computed when consumed
const stream = range(1, 10);
```

**Error Handling**
```typescript
// RxJS - Error callback
observable.subscribe({
  next: value => console.log(value),
  error: err => console.error(err)
});

// Streamix - Try-catch with for-await
try {
  for await (const value of stream) {
    console.log(value);
  }
} catch (error) {
  console.error(error);
}
```

### Migration Example

**Before (RxJS):**
```typescript
import { fromEvent, debounceTime, map, switchMap, catchError } from 'rxjs';
import { ajax } from 'rxjs/ajax';

const searchBox = document.getElementById('search');

fromEvent(searchBox, 'input')
  .pipe(
    map(event => event.target.value),
    debounceTime(300),
    switchMap(query => 
      ajax.getJSON(`/api/search?q=${query}`).pipe(
        catchError(error => of({ error: true }))
      )
    )
  )
  .subscribe(results => {
    displayResults(results);
  });
```

**After (Streamix):**
```typescript
import { fromEvent, debounce, map, switchMap, catchError, fromPromise } from '@actioncrew/streamix';

const searchBox = document.getElementById('search');

const results = fromEvent(searchBox, 'input')
  .pipe(
    map(event => event.target.value),
    debounce(300),
    switchMap(query => 
      fromPromise(fetch(`/api/search?q=${query}`).then(r => r.json()))
        .pipe(
          catchError(error => ({ error: true }))
        )
    )
  );

for await (const data of results) {
  displayResults(data);
}
```

---

## 📋 Best Practices

### Stream Lifecycle Management

Always ensure streams are properly cleaned up:

```typescript
// Use try-finally for cleanup
async function consumeStream(stream) {
  try {
    for await (const value of stream) {
      processValue(value);
    }
  } finally {
    // Cleanup code runs even if loop breaks
    console.log('Stream cleanup');
  }
}
```

### Error Handling Strategy

Implement robust error handling at appropriate levels:

```typescript
// Option 1: Handle at stream level
const safeStream = stream.pipe(
  catchError(error => {
    logError(error);
    return defaultValue;
  })
);

// Option 2: Handle at consumption level
try {
  for await (const value of stream) {
    processValue(value);
  }
} catch (error) {
  handleError(error);
}

// Option 3: Retry with fallback
const resilient = retry(() => stream, 3).pipe(
  catchError(error => fallbackStream)
);
```

### Memory Management

Keep memory usage low with proper stream design:

```typescript
// ✅ Good - Processes one at a time
const efficient = range(1, 1000000).pipe(
  map(processItem),
  filter(isValid),
  take(100)
);

// ❌ Bad - Loads everything into memory
const inefficient = await range(1, 1000000)
  .pipe(toArray())
  .then(arr => arr.map(processItem));
```

### Operator Composition

Create reusable operator combinations:

```typescript
// Create custom operators
function standardize<T>() {
  return (stream: Stream<T>) => stream.pipe(
    map(normalizeData),
    filter(isValid),
    tap(logProcessing)
  );
}

// Use across multiple streams
const stream1 = source1.pipe(standardize());
const stream2 = source2.pipe(standardize());
```

### Debouncing vs Throttling

Choose the right rate-limiting strategy:

```typescript
// Debounce - Wait for silence (search input)
const debounced = fromEvent(input, 'input').pipe(
  debounce(300) // Wait 300ms after last event
);

// Throttle - Emit at most once per period (scroll events)
// Note: Implement custom throttle or use debounce strategically
```

### Testing Streams

Test streams effectively:

```typescript
// Test stream transformations
async function testStream() {
  const input = of(1, 2, 3, 4, 5);
  const output = input.pipe(
    map(x => x * 2),
    filter(x => x > 5)
  );
  
  const results = [];
  for await (const value of output) {
    results.push(value);
  }
  
  console.assert(
    JSON.stringify(results) === JSON.stringify([6, 8, 10]),
    'Stream transformation failed'
  );
}
```

---

## 📚 API Documentation

### Core Functions

**`createStream(name, generator)`**
Create a stream from an async generator function.

```typescript
const stream = createStream('myStream', async function*() {
  yield 1;
  yield 2;
  yield 3;
});
```

**`createSubject<T>()`**
Create a subject for manually controlling emissions.

```typescript
const subject = createSubject<number>();
subject.next(1);
subject.next(2);
subject.complete();
```

### Creation Operators

**`of(...values)`** - Create stream from values
**`from(iterable)`** - Create stream from iterable
**`range(start, end)`** - Create range of numbers
**`interval(ms)`** - Emit incrementing numbers at interval
**`fromEvent(target, event)`** - Create stream from DOM events
**`fromPromise(promise)`** - Create stream from promise

### Transformation Operators

**`map(fn)`** - Transform each value
**`scan(fn, seed)`** - Accumulate values
**`buffer(size)`** - Collect into arrays

### Filtering Operators

**`filter(predicate)`** - Keep matching values
**`take(count)`** - Take first N values
**`takeWhile(predicate)`** - Take while condition true
**`skip(count)`** - Skip first N values
**`distinct()`** - Remove duplicates

### Combination Operators

**`mergeMap(fn)`** - Merge mapped streams
**`switchMap(fn)`** - Switch to latest stream
**`combineLatest(streams)`** - Combine latest values
**`concat(...streams)`** - Connect sequentially

### Utility Operators

**`tap(fn)`** - Side effects
**`delay(ms)`** - Add delay
**`debounce(ms)`** - Rate limiting
**`retry(fn, count)`** - Retry operations
**`finalize(fn)`** - Cleanup
**`startWith(value)`** - Initial value
**`catchError(fn)`** - Error handling

### HTTP Client

**`createHttpClient()`** - Create HTTP client
**`client.get(url, reader)`** - GET request
**`client.post(url, options, reader)`** - POST request
**`client.put(url, options, reader)`** - PUT request
**`client.delete(url, reader)`** - DELETE request

**Middleware:**
- `useBase(url)` - Base URL
- `useLogger()` - Request logging
- `useTimeout(ms)` - Request timeout
- `useRetry(count)` - Automatic retries

**Readers:**
- `readJson` - Parse as JSON
- `readText` - Parse as text
- `readBlob` - Parse as Blob

### DOM Observers

**`fromIntersection(element, options)`** - Intersection observer
**`fromResize(element)`** - Resize observer
**`fromMutation(element, options)`** - Mutation observer

---

## 🎓 Learning Resources

### Official Documentation
- **[Full API Documentation](https://actioncrew.github.io/streamix)** - Complete API reference
- **[GitHub Repository](https://github.com/actioncrew/streamix)** - Source code and examples

### Articles & Tutorials
- **[Exploring Streamix](https://medium.com/p/00d5467f0c01)** - Introduction to Streamix concepts
- **[Streamix 2.0 Updates](https://medium.com/p/a1eb9e7ce1d7)** - What's new in version 2
- **[Reactive Programming Guide](https://medium.com/p/0bfc206ad41c)** - Deep dive into reactive patterns

### Live Examples
- **[Simple Animation](https://stackblitz.com/edit/stackblitz-starters-pkzdzmuk)** - Smooth animations with streams
- **[Heavy Computation](https://stackblitz.com/edit/stackblitz-starters-73vspfzz)** - Mandelbrot set generation
- **[Travel Blog](https://stackblitz.com/edit/stackblitz-starters-873uh85w)** - Real-world app example

### Community
- **[Feedback Form](https://forms.gle/CDLvoXZqMMyp4VKu9)** - Share your experience
- **[GitHub Issues](https://github.com/actioncrew/streamix/issues)** - Report bugs or request features
- **[GitHub Discussions](https://github.com/actioncrew/streamix/discussions)** - Ask questions and share ideas

---

## 🤝 Contributing

We welcome contributions from the community! Here's how you can help:

### Ways to Contribute

**🐛 Report Bugs**
Found a bug? Open an issue with:
- Clear description of the problem
- Steps to reproduce
- Expected vs actual behavior
- Environment details (browser, Node version, etc.)

**💡 Suggest Features**
Have an idea? We'd love to hear it! Open an issue describing:
- The problem it solves
- How it would work
- Any implementation ideas

**📝 Improve Documentation**
Help others learn Streamix:
- Fix typos or clarify explanations
- Add examples
- Translate documentation
- Write tutorials or blog posts

**🔧 Submit Code**
Ready to code? Here's the process:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Make your changes
4. Write tests for new functionality
5. Ensure all tests pass (`npm test`)
6. Commit your changes (`git commit -m 'Add amazing feature'`)
7. Push to your branch (`git push origin feature/amazing-feature`)
8. Open a Pull Request

### Development Setup

```bash
# Clone the repository
git clone https://github.com/actioncrew/streamix.git
cd streamix

# Install dependencies
npm install

# Run tests
npm test

# Build the project
npm run build

# Run examples
npm run examples
```

### Code Style

- Follow the existing code style
- Use TypeScript for all code
- Write meaningful commit messages
- Add JSDoc comments for public APIs
- Include tests for new features

### Testing Guidelines

```typescript
// Write clear, focused tests
describe('map operator', () => {
  it('should transform values', async () => {
    const input = of(1, 2, 3);
    const output = input.pipe(map(x => x * 2));
    
    const results = [];
    for await (const value of output) {
      results.push(value);
    }
    
    expect(results).toEqual([2, 4, 6]);
  });
});
```

### Pull Request Guidelines

- Keep PRs focused on a single change
- Update documentation if needed
- Add tests for new functionality
- Ensure CI passes
- Respond to review feedback

---

## 🙏 Acknowledgments

Streamix builds on ideas from many excellent libraries:

- **RxJS** - For pioneering reactive programming in JavaScript
- **Most.js** - For demonstrating high-performance streams
- **Callbag** - For exploring minimalist reactive patterns
- **AsyncIterator Helpers** - For advancing async iteration standards

Special thanks to all contributors who have helped improve Streamix!

---

## 📊 Project Stats

- **Bundle Size**: 9 KB (core) + 3 KB (HTTP client)
- **TypeScript**: Full type safety
- **Test Coverage**: High coverage across all modules
- **Dependencies**: Zero runtime dependencies
- **Browser Support**: All modern browsers with ES2018+
- **Node.js**: Version 12+

---

## 🔮 Roadmap

### Upcoming Features

- **More Operators** - Additional transformation and combination operators
- **Performance Optimizations** - Even faster stream processing
- **Better DevTools** - Enhanced debugging experience
- **Framework Integrations** - Official React, Vue, and Angular adapters
- **Server-Side Rendering** - Improved SSR support
- **WebWorker Support** - Off-main-thread stream processing

### Long-Term Vision

- Become the go-to lightweight reactive library
- Maintain zero dependencies
- Keep bundle size under 15 KB (core + HTTP)
- Provide best-in-class TypeScript support
- Build a thriving community of contributors

---

## ❓ FAQ

**Q: How is Streamix different from RxJS?**
A: Streamix is lighter (9 KB vs 40 KB), uses pull-based async generators instead of push-based observables, and has a simpler learning curve while maintaining similar functionality.

**Q: Can I use Streamix with React/Vue/Angular?**
A: Yes! Streamix is framework-agnostic and works with any JavaScript framework. Use it in effects, hooks, or lifecycle methods.

**Q: Does Streamix support hot observables?**
A: Streamix uses a pull-based model, so all streams are "cold" by default. Use Subjects when you need to manually control emissions.

**Q: How do I cancel a stream?**
A: Simply break out of the `for await` loop. The stream will automatically clean up.

**Q: Can I use Streamix in Node.js?**
A: Absolutely! Streamix works in any JavaScript environment with ES2018+ support (Node.js 12+).

**Q: Is Streamix production-ready?**
A: Yes! Streamix is tested, documented, and used in production applications.

**Q: How do I migrate from RxJS?**
A: Most operators have the same names. Replace subscriptions with `for await` loops and adjust error handling. See the migration guide above.

**Q: Does Streamix work with TypeScript?**
A: Yes, Streamix is written in TypeScript and provides excellent type inference and safety.

---

## 📄 License

MIT License

Copyright (c) 2024 ActionCrew

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

---

<p align="center">
  <strong>Ready to stream? Get started with Streamix today! 🚀</strong><br>
  <a href="https://www.npmjs.com/package/@actioncrew/streamix">Install from NPM</a> • 
  <a href="https://github.com/actioncrew/streamix">View on GitHub</a> • 
  <a href="https://actioncrew.github.io/streamix">Read the Docs</a> • 
  <a href="https://forms.gle/CDLvoXZqMMyp4VKu9">Give Feedback</a>
</p>

---

## 🌟 Star History

If you find Streamix useful, consider giving it a star on GitHub! It helps others discover the project and motivates us to keep improving it.

<p align="center">
  <a href="https://github.com/actioncrew/streamix">⭐ Star on GitHub</a>
</p>