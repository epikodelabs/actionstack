/**
 * STREAMIX TRACING SYSTEM – COMPLETE IMPLEMENTATION
 *
 * A comprehensive tracing system for Streamix reactive streams.
 *
 * Features:
 * - Tracks value lifecycle from emission → delivery
 * - Supports filter / collapse / expand / error semantics
 * - Preserves type safety by wrapping primitives
 * - Provides public subscription API for observers (tests, trackers)
 * - Integrates via Streamix runtime hooks
 */
export type ValueState = "emitted" | "processing" | "transformed" | "filtered" | "collapsed" | "errored" | "delivered";
export type OperatorOutcome = "transformed" | "filtered" | "expanded" | "collapsed" | "errored";
export interface OperatorStep {
    operatorIndex: number;
    operatorName: string;
    enteredAt: number;
    exitedAt?: number;
    outcome?: OperatorOutcome;
    inputValue: any;
    outputValue?: any;
    error?: Error;
}
export interface ValueTrace {
    valueId: string;
    streamId: string;
    streamName?: string;
    subscriptionId: string;
    emittedAt: number;
    deliveredAt?: number;
    state: ValueState;
    sourceValue: any;
    finalValue?: any;
    operatorSteps: OperatorStep[];
    droppedReason?: {
        operatorIndex: number;
        operatorName: string;
        reason: "filtered" | "collapsed" | "errored";
        error?: Error;
    };
    collapsedInto?: {
        operatorIndex: number;
        operatorName: string;
        targetValueId: string;
    };
    totalDuration?: number;
    operatorDurations: Map<string, number>;
}
export declare function generateValueId(): string;
export type TracerEventHandlers = {
    delivered?: (trace: ValueTrace) => void;
    filtered?: (trace: ValueTrace) => void;
    collapsed?: (trace: ValueTrace) => void;
    dropped?: (trace: ValueTrace) => void;
};
export declare class ValueTracer {
    private traces;
    private active;
    private maxTraces;
    private onValueEmitted?;
    private onValueProcessing?;
    private onValueTransformed?;
    private onValueFiltered?;
    private onValueCollapsed?;
    private onValueDelivered?;
    private onValueDropped?;
    constructor(options?: {
        maxTraces?: number;
        onValueEmitted?: (trace: ValueTrace) => void;
        onValueProcessing?: (trace: ValueTrace, step: OperatorStep) => void;
        onValueTransformed?: (trace: ValueTrace, step: OperatorStep) => void;
        onValueFiltered?: (trace: ValueTrace, step: OperatorStep) => void;
        onValueCollapsed?: (trace: ValueTrace, step: OperatorStep) => void;
        onValueDelivered?: (trace: ValueTrace) => void;
        onValueDropped?: (trace: ValueTrace) => void;
    });
    subscribe(handlers: TracerEventHandlers): () => void;
    startTrace(valueId: string, streamId: string, streamName: string | undefined, subscriptionId: string, value: any): ValueTrace;
    enterOperator(valueId: string, operatorIndex: number, operatorName: string, inputValue: any): void;
    exitOperator(valueId: string, operatorIndex: number, outputValue: any, filtered?: boolean, outcome?: OperatorOutcome): string | null;
    collapseValue(valueId: string, operatorIndex: number, operatorName: string, targetValueId: string): void;
    errorInOperator(valueId: string, operatorIndex: number, error: Error): void;
    markDelivered(valueId: string): void;
    getAllTraces(): ValueTrace[];
    clear(): void;
}
declare const tracedValueBrand: unique symbol;
export interface TracedWrapper<T> {
    [tracedValueBrand]: true;
    value: T;
    meta: {
        valueId: string;
        streamId: string;
        subscriptionId: string;
    };
}
export declare function enableTracing(tracer: ValueTracer): void;
export declare function disableTracing(): void;
export declare function getGlobalTracer(): ValueTracer | null;
export {};
