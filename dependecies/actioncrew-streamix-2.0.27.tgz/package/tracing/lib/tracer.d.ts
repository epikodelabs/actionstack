/**
 * STREAMIX TRACING SYSTEM
 *
 * A comprehensive tracing system for Streamix reactive streams.
 *
 * Features:
 * - Tracks value lifecycle from emission → delivery
 * - Supports filter / collapse / expand / error semantics
 * - Preserves type safety by wrapping primitives
 * - Provides public subscription API for observers (tests, trackers)
 * - Integrates via Streamix runtime hooks
 */
/** Lifecycle state for a traced value. */
export type ValueState = "emitted" | "processing" | "transformed" | "filtered" | "collapsed" | "completed" | "errored" | "delivered";
/** Outcome for an operator step. */
export type OperatorOutcome = "transformed" | "filtered" | "expanded" | "collapsed" | "completed" | "errored";
/** Operator execution metadata within a trace. */
export interface OperatorStep {
    operatorIndex: number;
    operatorName: string;
    enteredAt: number;
    exitedAt?: number;
    outcome?: OperatorOutcome;
    inputValue: any;
    outputValue?: any;
    error?: Error;
}
/** Full trace record for a single value. */
export interface ValueTrace {
    valueId: string;
    streamId: string;
    streamName?: string;
    subscriptionId: string;
    emittedAt: number;
    deliveredAt?: number;
    state: ValueState;
    sourceValue: any;
    finalValue?: any;
    operatorSteps: OperatorStep[];
    droppedReason?: {
        operatorIndex: number;
        operatorName: string;
        reason: "filtered" | "collapsed" | "completed" | "errored";
        error?: Error;
    };
    collapsedInto?: {
        operatorIndex: number;
        operatorName: string;
        targetValueId: string;
    };
    totalDuration?: number;
    operatorDurations: Map<string, number>;
}
/** Generates a unique trace value identifier. */
export declare function generateValueId(): string;
/** Event handlers for tracer lifecycle notifications. */
export type TracerEventHandlers = {
    delivered?: (trace: ValueTrace) => void;
    filtered?: (trace: ValueTrace) => void;
    collapsed?: (trace: ValueTrace) => void;
    dropped?: (trace: ValueTrace) => void;
};
/** Event handlers for subscription-scoped tracing. */
export type TracerSubscriptionEventHandlers = TracerEventHandlers & {
    complete?: () => void;
};
/** Options used to configure a value tracer instance. */
export interface ValueTracerOptions {
    maxTraces?: number;
    devMode?: boolean;
    onTraceUpdate?: (trace: ValueTrace, step?: OperatorStep) => void;
}
/** Functional tracer API with state stored in a closure. */
export interface ValueTracer {
    subscribe: (handlers: TracerEventHandlers) => () => void;
    observeSubscription: (subscriptionId: string, handlers: TracerSubscriptionEventHandlers) => () => void;
    completeSubscription: (subscriptionId: string) => void;
    startTrace: (valueId: string, streamId: string, streamName: string | undefined, subscriptionId: string, value: any) => ValueTrace;
    createExpandedTrace: (baseValueId: string, operatorIndex: number, operatorName: string, expandedValue: any) => string;
    enterOperator: (valueId: string, operatorIndex: number, operatorName: string, inputValue: any) => void;
    exitOperator: (valueId: string, operatorIndex: number, outputValue: any, filtered?: boolean, outcome?: OperatorOutcome) => string | null;
    collapseValue: (valueId: string, operatorIndex: number, operatorName: string, targetValueId: string, outputValue?: any) => void;
    errorInOperator: (valueId: string, operatorIndex: number, error: Error) => void;
    completeInOperator: (valueId: string, operatorIndex: number, operatorName: string) => void;
    markDelivered: (valueId: string) => void;
    getAllTraces: () => ValueTrace[];
    getFilteredValues: () => ValueTrace[];
    getCollapsedValues: () => ValueTrace[];
    getDeliveredValues: () => ValueTrace[];
    getDroppedValues: () => ValueTrace[];
    getStats: () => {
        total: number;
        emitted: number;
        processing: number;
        delivered: number;
        filtered: number;
        collapsed: number;
        completed: number;
        errored: number;
        dropRate: number;
    };
    clear: () => void;
}
/**
 * Creates a new tracer with an isolated internal state container.
 */
export declare function createValueTracer(options?: ValueTracerOptions): ValueTracer;
declare const tracedValueBrand: unique symbol;
/** Branded wrapper used to tag traced values flowing through operators. */
export interface TracedWrapper<T> {
    [tracedValueBrand]: true;
    value: T;
    meta: {
        valueId: string;
        streamId: string;
        subscriptionId: string;
        correlationId: string;
    };
}
/** Enables tracing by registering a global tracer instance. */
export declare function enableTracing(tracer: ValueTracer): void;
/** Disables tracing by clearing the global tracer instance. */
export declare function disableTracing(): void;
/** Returns the current global tracer, if one is registered. */
export declare function getGlobalTracer(): ValueTracer | null;
export {};
