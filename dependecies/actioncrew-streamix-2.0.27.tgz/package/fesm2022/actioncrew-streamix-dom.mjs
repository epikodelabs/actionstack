import { createSubject, createAsyncGenerator, isPromiseLike } from '@actioncrew/streamix';

/**
 * Creates a reactive stream that emits the time delta (in milliseconds) between
 * consecutive animation frames.
 *
 * This stream is driven by `requestAnimationFrame` when available, with a
 * timer-based fallback for non-browser environments.
 *
 * **Behavior:**
 * - A shared RAF loop starts when the first subscriber subscribes.
 * - Emits the delta between consecutive frames.
 * - Stops the RAF loop when the last subscriber unsubscribes.
 * - Safe to import and subscribe in SSR (no-op).
 * - Fully compatible with async iteration.
 *
 * @returns {Stream<number>} A stream emitting frame-to-frame time deltas.
 */
function onAnimationFrame() {
    const subject = createSubject();
    let subscriberCount = 0;
    let stopped = true;
    let rafId = null;
    let lastTime = 0;
    const startLoop = () => {
        if (!stopped)
            return;
        stopped = false;
        // SSR / non-browser guard
        if (typeof performance === "undefined")
            return;
        const raf = typeof requestAnimationFrame === "function"
            ? requestAnimationFrame
            : ((cb) => setTimeout(() => cb(performance.now()), 16));
        lastTime = performance.now();
        const tick = (now) => {
            if (stopped)
                return;
            const delta = now - lastTime;
            lastTime = now;
            subject.next(delta);
            rafId = raf(tick);
        };
        rafId = raf(tick);
    };
    const stopLoop = () => {
        if (stopped)
            return;
        stopped = true;
        if (rafId !== null) {
            if (typeof cancelAnimationFrame === "function") {
                cancelAnimationFrame(rafId);
            }
            else {
                clearTimeout(rafId);
            }
            rafId = null;
        }
    };
    /* ------------------------------------------------------------------------
     * Ref-counted subscription handling
     * ---------------------------------------------------------------------- */
    const originalSubscribe = subject.subscribe;
    subject.subscribe = (callback) => {
        const subscription = originalSubscribe.call(subject, callback);
        if (++subscriberCount === 1) {
            startLoop();
        }
        const originalOnUnsubscribe = subscription.onUnsubscribe;
        subscription.onUnsubscribe = () => {
            if (--subscriberCount === 0) {
                stopLoop();
            }
            originalOnUnsubscribe?.call(subscription);
        };
        return subscription;
    };
    /* ------------------------------------------------------------------------
     * Async iteration support
     * ---------------------------------------------------------------------- */
    subject[Symbol.asyncIterator] = () => createAsyncGenerator(receiver => subject.subscribe(receiver));
    subject.name = "onAnimationFrame";
    return subject;
}

/**
 * Creates a reactive stream that emits battery state changes.
 *
 * Uses the Battery Status API when available.
 *
 * **Behavior:**
 * - Emits an initial battery snapshot on start.
 * - Emits on charging, level, and time changes.
 * - Starts listening on first subscriber.
 * - Stops listening when the last subscriber unsubscribes.
 * - Safe to import and subscribe in SSR (no-op).
 * - Fully compatible with async iteration.
 *
 * @returns {Stream<BatteryState>}
 */
function onBattery() {
    const subject = createSubject();
    let subscriberCount = 0;
    let stopped = true;
    let battery = null;
    const snapshot = () => ({
        charging: battery.charging,
        level: battery.level,
        chargingTime: battery.chargingTime,
        dischargingTime: battery.dischargingTime
    });
    const emit = () => {
        subject.next(snapshot());
    };
    const start = async () => {
        if (!stopped)
            return;
        stopped = false;
        // SSR / unsupported API guard
        if (typeof navigator === "undefined" || !navigator.getBattery) {
            return;
        }
        battery = await navigator.getBattery();
        emit();
        battery.addEventListener("chargingchange", emit);
        battery.addEventListener("levelchange", emit);
        battery.addEventListener("chargingtimechange", emit);
        battery.addEventListener("dischargingtimechange", emit);
    };
    const stop = () => {
        if (stopped)
            return;
        stopped = true;
        if (!battery)
            return;
        battery.removeEventListener("chargingchange", emit);
        battery.removeEventListener("levelchange", emit);
        battery.removeEventListener("chargingtimechange", emit);
        battery.removeEventListener("dischargingtimechange", emit);
        battery = null;
    };
    /* ------------------------------------------------------------------------
     * Ref-counted subscription handling
     * ---------------------------------------------------------------------- */
    const originalSubscribe = subject.subscribe;
    subject.subscribe = (cb) => {
        const sub = originalSubscribe.call(subject, cb);
        if (++subscriberCount === 1) {
            void start();
        }
        const o = sub.onUnsubscribe;
        sub.onUnsubscribe = () => {
            if (--subscriberCount === 0) {
                stop();
            }
            o?.call(sub);
        };
        return sub;
    };
    /* ------------------------------------------------------------------------
     * Async iteration support
     * ---------------------------------------------------------------------- */
    subject[Symbol.asyncIterator] = () => createAsyncGenerator(receiver => subject.subscribe(receiver));
    subject.name = "onBattery";
    return subject;
}

/**
 * Creates a reactive stream that emits fullscreen state changes.
 *
 * Emits `true` when entering fullscreen and `false` when exiting.
 *
 * **Behavior:**
 * - Emits the initial fullscreen state on start.
 * - Emits on every fullscreen change.
 * - Starts listening on first subscriber.
 * - Stops listening when the last subscriber unsubscribes.
 * - Supports vendor-prefixed implementations.
 * - Safe to import and subscribe in SSR (no-op).
 * - Fully compatible with async iteration.
 *
 * @returns {Stream<boolean>}
 */
function onFullscreen() {
    const subject = createSubject();
    let subscriberCount = 0;
    let stopped = true;
    /**
     * Checks whether the document is currently in fullscreen mode.
     */
    const isFullscreen = () => {
        if (typeof document === "undefined")
            return false;
        return !!(document.fullscreenElement ||
            document.webkitFullscreenElement ||
            document.mozFullScreenElement ||
            document.msFullscreenElement);
    };
    const emit = () => {
        subject.next(isFullscreen());
    };
    const start = () => {
        if (!stopped)
            return;
        stopped = false;
        // SSR guard
        if (typeof document === "undefined")
            return;
        document.addEventListener("fullscreenchange", emit);
        document.addEventListener("webkitfullscreenchange", emit);
        document.addEventListener("mozfullscreenchange", emit);
        document.addEventListener("MSFullscreenChange", emit);
        emit(); // initial state
    };
    const stop = () => {
        if (stopped)
            return;
        stopped = true;
        if (typeof document === "undefined")
            return;
        document.removeEventListener("fullscreenchange", emit);
        document.removeEventListener("webkitfullscreenchange", emit);
        document.removeEventListener("mozfullscreenchange", emit);
        document.removeEventListener("MSFullscreenChange", emit);
    };
    /* ------------------------------------------------------------------------
     * Ref-counted subscription handling
     * ---------------------------------------------------------------------- */
    const originalSubscribe = subject.subscribe;
    subject.subscribe = (cb) => {
        const sub = originalSubscribe.call(subject, cb);
        if (++subscriberCount === 1) {
            start();
        }
        const o = sub.onUnsubscribe;
        sub.onUnsubscribe = () => {
            if (--subscriberCount === 0) {
                stop();
            }
            o?.call(sub);
        };
        return sub;
    };
    /* ------------------------------------------------------------------------
     * Async iteration support
     * ---------------------------------------------------------------------- */
    subject[Symbol.asyncIterator] = () => createAsyncGenerator(receiver => subject.subscribe(receiver));
    subject.name = "onFullscreen";
    return subject;
}

/**
 * Creates a reactive stream that emits `IdleDeadline` objects whenever
 * the browser enters an idle period.
 *
 * This stream is useful for scheduling low-priority work such as:
 * - background computations
 * - prefetching
 * - cache warming
 * - non-urgent state updates
 *
 * **Behavior:**
 * - Starts a shared idle loop when the first subscriber subscribes.
 * - Emits the `IdleDeadline` object provided by `requestIdleCallback`.
 * - Continues scheduling idle callbacks until all subscribers unsubscribe.
 * - Falls back to `setTimeout` when `requestIdleCallback` is unavailable.
 * - Safe to import and subscribe in SSR (no-op).
 * - Fully compatible with async iteration.
 *
 * @param timeout Optional timeout (ms) after which idle callback must fire.
 * @returns {Stream<IdleDeadline>} A stream emitting idle deadlines.
 */
function onIdle(timeout) {
    const subject = createSubject();
    let subscriberCount = 0;
    let stopped = true;
    let idleId = null;
    const startLoop = () => {
        if (!stopped)
            return;
        stopped = false;
        // SSR / non-browser guard
        if (typeof setTimeout !== "function")
            return;
        const ric = typeof requestIdleCallback === "function"
            ? requestIdleCallback
            : ((cb) => setTimeout(() => cb({
                didTimeout: false,
                timeRemaining: () => 0
            }), 0));
        const tick = (deadline) => {
            if (stopped)
                return;
            subject.next(deadline);
            idleId = ric(tick, timeout != null ? { timeout } : undefined);
        };
        idleId = ric(tick, timeout != null ? { timeout } : undefined);
    };
    const stopLoop = () => {
        if (stopped)
            return;
        stopped = true;
        if (idleId !== null) {
            if (typeof cancelIdleCallback === "function") {
                cancelIdleCallback(idleId);
            }
            else {
                clearTimeout(idleId);
            }
            idleId = null;
        }
    };
    /* ------------------------------------------------------------------------
     * Ref-counted subscription handling
     * ---------------------------------------------------------------------- */
    const originalSubscribe = subject.subscribe;
    subject.subscribe = (callback) => {
        const subscription = originalSubscribe.call(subject, callback);
        if (++subscriberCount === 1) {
            startLoop();
        }
        const originalOnUnsubscribe = subscription.onUnsubscribe;
        subscription.onUnsubscribe = () => {
            if (--subscriberCount === 0) {
                stopLoop();
            }
            originalOnUnsubscribe?.call(subscription);
        };
        return subscription;
    };
    /* ------------------------------------------------------------------------
     * Async iteration support
     * ---------------------------------------------------------------------- */
    subject[Symbol.asyncIterator] = () => createAsyncGenerator(receiver => subject.subscribe(receiver));
    subject.name = "onIdle";
    return subject;
}

/**
 * Creates a reactive stream that emits `true` when a given element enters
 * the viewport and `false` when it leaves.
 *
 * This stream is a wrapper around the `IntersectionObserver` API and is useful
 * for lazy loading, visibility tracking, and viewport-aware effects.
 *
 * **Behavior:**
 * - Resolves the element and options once on first subscription.
 * - Emits the current intersection state whenever it changes.
 * - Starts observing on first subscriber.
 * - Stops observing when the last subscriber unsubscribes.
 * - Safe to import and subscribe in SSR (no-op).
 * - Fully compatible with async iteration.
 *
 * @param element The DOM element (or promise) to observe.
 * @param options Optional IntersectionObserver options (or promise).
 * @returns {Stream<boolean>} A stream emitting intersection state.
 */
function onIntersection(element, options) {
    const subject = createSubject();
    subject.name = "onIntersection";
    let subscriberCount = 0;
    let active = false;
    let el = null;
    let io = null;
    let mo = null;
    const subscriptions = new Set();
    /* -------------------------------------------------- */
    const start = async () => {
        if (active)
            return;
        active = true;
        if (typeof IntersectionObserver === "undefined" ||
            typeof document === "undefined") {
            return;
        }
        el = isPromiseLike(element) ? await element : element;
        const resolvedOptions = isPromiseLike(options) ? await options : options;
        if (!active || !el)
            return;
        io = new IntersectionObserver(entries => {
            subject.next(entries[0]?.isIntersecting ?? false);
        }, resolvedOptions);
        io.observe(el);
        // 👇 REQUIRED: detect DOM removal
        mo = new MutationObserver(() => {
            if (el && !document.body.contains(el)) {
                // Force-unsubscribe ALL subscribers
                for (const sub of subscriptions) {
                    sub.unsubscribe();
                }
                subscriptions.clear();
                stop();
            }
        });
        mo.observe(document.body, { childList: true, subtree: true });
    };
    const stop = () => {
        if (!active)
            return;
        active = false;
        if (io && el) {
            io.unobserve(el);
            io.disconnect();
        }
        mo?.disconnect();
        io = null;
        mo = null;
        el = null;
    };
    /* -------------------------------------------------- */
    /* Ref-counted subscription handling                  */
    /* -------------------------------------------------- */
    const originalSubscribe = subject.subscribe;
    subject.subscribe = (cb) => {
        const sub = originalSubscribe.call(subject, cb);
        subscriptions.add(sub);
        if (++subscriberCount === 1) {
            void start();
        }
        const prev = sub.onUnsubscribe;
        sub.onUnsubscribe = () => {
            subscriptions.delete(sub);
            if (--subscriberCount === 0) {
                stop();
            }
            prev?.call(sub);
        };
        return sub;
    };
    /* -------------------------------------------------- */
    /* Async iteration support                            */
    /* -------------------------------------------------- */
    subject[Symbol.asyncIterator] = () => createAsyncGenerator(r => subject.subscribe(r));
    return subject;
}

/**
 * Creates a reactive stream that emits `true` or `false` whenever a CSS media
 * query matches or stops matching.
 *
 * This stream is useful for reacting to viewport size changes, orientation
 * changes, or other media feature conditions.
 *
 * **Behavior:**
 * - Resolves the media query once on first subscription.
 * - Emits the initial match state on start.
 * - Emits on every media query change.
 * - Starts listening on first subscriber.
 * - Stops listening when the last subscriber unsubscribes.
 * - Safe to import and subscribe in SSR (no-op).
 * - Fully compatible with async iteration.
 *
 * @param mediaQueryString A CSS media query string (or promise).
 * @returns {Stream<boolean>} A stream emitting match state.
 */
function onMediaQuery(query) {
    const subject = createSubject();
    subject.name = 'onMediaQuery';
    let subscriberCount = 0;
    let active = false;
    let mql = null;
    let listener = null;
    /* -------------------------------------------------- */
    /* Immediate environment check (required by tests)    */
    /* -------------------------------------------------- */
    if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') {
        console.warn('matchMedia is not supported in this environment');
        return subject;
    }
    /* -------------------------------------------------- */
    /* Lifecycle                                          */
    /* -------------------------------------------------- */
    const start = async () => {
        if (active)
            return;
        active = true;
        // Promise query → emit false immediately
        if (isPromiseLike(query)) {
            subject.next(false);
        }
        const q = isPromiseLike(query) ? await query : query;
        if (!active)
            return;
        mql = window.matchMedia(q);
        // Emit resolved state
        subject.next(mql.matches);
        listener = (e) => {
            subject.next(e.matches);
        };
        if (typeof mql.addEventListener === 'function') {
            mql.addEventListener('change', listener);
        }
        else if (typeof mql.addListener === 'function') {
            mql.addListener(listener);
        }
    };
    const stop = () => {
        if (!active)
            return;
        active = false;
        if (mql && listener) {
            if (typeof mql.removeEventListener === 'function') {
                mql.removeEventListener('change', listener);
            }
            else if (typeof mql.removeListener === 'function') {
                mql.removeListener(listener);
            }
        }
        mql = null;
        listener = null;
    };
    /* -------------------------------------------------- */
    /* Ref-counted subscribe override                     */
    /* -------------------------------------------------- */
    const originalSubscribe = subject.subscribe;
    subject.subscribe = (cb) => {
        const sub = originalSubscribe.call(subject, cb);
        if (++subscriberCount === 1) {
            void start();
        }
        const prev = sub.onUnsubscribe;
        sub.onUnsubscribe = () => {
            if (--subscriberCount === 0) {
                stop();
            }
            prev?.call(sub);
        };
        return sub;
    };
    /* -------------------------------------------------- */
    /* Async iteration support                            */
    /* -------------------------------------------------- */
    subject[Symbol.asyncIterator] = () => createAsyncGenerator(r => subject.subscribe(r));
    return subject;
}

/**
 * Creates a reactive stream that emits arrays of `MutationRecord` objects
 * whenever mutations are observed on a given DOM element.
 *
 * This stream is a wrapper around the `MutationObserver` API and is useful
 * for reacting to DOM structure or attribute changes.
 *
 * **Behavior:**
 * - Resolves the target element and options once on first subscription.
 * - Emits mutation records whenever changes occur.
 * - Starts observing on first subscriber.
 * - Stops observing when the last subscriber unsubscribes.
 * - Safe to import and subscribe in SSR (no-op).
 * - Fully compatible with async iteration.
 *
 * @param element The DOM element (or promise) to observe.
 * @param options Optional MutationObserver options (or promise).
 * @returns {Stream<MutationRecord[]>} A stream of mutation records.
 */
function onMutation(element, options) {
    const subject = createSubject();
    subject.name = "onMutation";
    let subscriberCount = 0;
    let stopped = true;
    let resolvedElement = null;
    let resolvedOptions;
    let observer = null;
    const start = async () => {
        if (!stopped)
            return;
        stopped = false;
        // SSR / unsupported guard
        if (typeof MutationObserver === "undefined")
            return;
        resolvedElement = isPromiseLike(element) ? await element : element;
        resolvedOptions = isPromiseLike(options) ? await options : options;
        if (stopped || !resolvedElement)
            return;
        observer = new MutationObserver(mutations => {
            subject.next([...mutations]);
        });
        observer.observe(resolvedElement, resolvedOptions);
    };
    const stop = () => {
        if (stopped)
            return;
        stopped = true;
        observer?.disconnect();
        observer = null;
        resolvedElement = null;
    };
    /* ------------------------------------------------------------------------
     * Ref-counted subscription handling
     * ---------------------------------------------------------------------- */
    const originalSubscribe = subject.subscribe;
    subject.subscribe = (cb) => {
        const sub = originalSubscribe.call(subject, cb);
        if (++subscriberCount === 1) {
            void start();
        }
        const o = sub.onUnsubscribe;
        sub.onUnsubscribe = () => {
            if (--subscriberCount === 0) {
                stop();
            }
            o?.call(sub);
        };
        return sub;
    };
    /* ------------------------------------------------------------------------
     * Async iteration support
     * ---------------------------------------------------------------------- */
    subject[Symbol.asyncIterator] = () => createAsyncGenerator(receiver => subject.subscribe(receiver));
    return subject;
}

/**
 * Creates a reactive stream that emits network connectivity changes.
 *
 * This stream combines:
 * - `online` / `offline` events
 * - Network Information API (when available)
 *
 * **Behavior:**
 * - Emits an initial snapshot on start.
 * - Emits whenever connectivity or connection quality changes.
 * - Starts listening on first subscriber.
 * - Stops listening when the last subscriber unsubscribes.
 * - Gracefully degrades when Network Information API is unavailable.
 * - Safe to import and subscribe in SSR (no-op).
 * - Fully compatible with async iteration.
 *
 * @returns {Stream<NetworkState>}
 */
function onNetwork() {
    const subject = createSubject();
    subject.name = "onNetwork";
    let subscriberCount = 0;
    let stopped = true;
    let connection = null;
    const snapshot = () => ({
        online: typeof navigator !== "undefined" ? navigator.onLine : false,
        type: connection?.type,
        effectiveType: connection?.effectiveType,
        downlink: connection?.downlink,
        rtt: connection?.rtt,
        saveData: connection?.saveData
    });
    const emit = () => {
        subject.next(snapshot());
    };
    const start = () => {
        if (!stopped)
            return;
        stopped = false;
        // SSR / unsupported guard
        if (typeof window === "undefined" || typeof navigator === "undefined") {
            return;
        }
        connection = navigator.connection ?? null;
        window.addEventListener("online", emit);
        window.addEventListener("offline", emit);
        connection?.addEventListener?.("change", emit);
        emit(); // initial snapshot
    };
    const stop = () => {
        if (stopped)
            return;
        stopped = true;
        if (typeof window === "undefined")
            return;
        window.removeEventListener("online", emit);
        window.removeEventListener("offline", emit);
        connection?.removeEventListener?.("change", emit);
        connection = null;
    };
    /* ------------------------------------------------------------------------
     * Ref-counted subscription handling
     * ---------------------------------------------------------------------- */
    const originalSubscribe = subject.subscribe;
    subject.subscribe = (cb) => {
        const sub = originalSubscribe.call(subject, cb);
        if (++subscriberCount === 1) {
            start();
        }
        const o = sub.onUnsubscribe;
        sub.onUnsubscribe = () => {
            if (--subscriberCount === 0) {
                stop();
            }
            o?.call(sub);
        };
        return sub;
    };
    /* ------------------------------------------------------------------------
     * Async iteration support
     * ---------------------------------------------------------------------- */
    subject[Symbol.asyncIterator] = () => createAsyncGenerator(receiver => subject.subscribe(receiver));
    return subject;
}

/**
 * Creates a reactive stream that emits the current screen orientation,
 * either `"portrait"` or `"landscape"`, whenever it changes.
 *
 * **Behavior:**
 * - Emits the initial orientation on start.
 * - Emits whenever the orientation changes.
 * - Starts listening on first subscriber.
 * - Stops listening when the last subscriber unsubscribes.
 * - Safe to import and subscribe in SSR (no-op).
 * - Fully compatible with async iteration.
 *
 * @returns {Stream<"portrait" | "landscape">}
 */
function onOrientation() {
    const subject = createSubject();
    subject.name = "onOrientation";
    let subscriberCount = 0;
    let stopped = true;
    const getOrientation = () => {
        if (typeof window === "undefined" ||
            !window.screen ||
            !window.screen.orientation) {
            return "portrait";
        }
        const angle = window.screen.orientation.angle;
        return angle === 0 || angle === 180 ? "portrait" : "landscape";
    };
    const emit = () => {
        subject.next(getOrientation());
    };
    const start = () => {
        if (!stopped)
            return;
        stopped = false;
        // SSR / unsupported guard
        if (typeof window === "undefined" ||
            !window.screen ||
            !window.screen.orientation) {
            return;
        }
        window.screen.orientation.addEventListener("change", emit);
        emit(); // initial value
    };
    const stop = () => {
        if (stopped)
            return;
        stopped = true;
        if (typeof window === "undefined" ||
            !window.screen ||
            !window.screen.orientation) {
            return;
        }
        window.screen.orientation.removeEventListener("change", emit);
    };
    /* ------------------------------------------------------------------------
     * Ref-counted subscription handling
     * ---------------------------------------------------------------------- */
    const originalSubscribe = subject.subscribe;
    subject.subscribe = (cb) => {
        const sub = originalSubscribe.call(subject, cb);
        if (++subscriberCount === 1) {
            start();
        }
        const o = sub.onUnsubscribe;
        sub.onUnsubscribe = () => {
            if (--subscriberCount === 0) {
                stop();
            }
            o?.call(sub);
        };
        return sub;
    };
    /* ------------------------------------------------------------------------
     * Async iteration support
     * ---------------------------------------------------------------------- */
    subject[Symbol.asyncIterator] = () => createAsyncGenerator(receiver => subject.subscribe(receiver));
    return subject;
}

/**
 * Creates a reactive stream that emits the dimensions of a given DOM element
 * whenever it is resized.
 *
 * This stream is a wrapper around the `ResizeObserver` API.
 *
 * **Behavior:**
 * - Resolves the element once on first subscription.
 * - Emits the current width and height whenever the element is resized.
 * - Emits the initial size on start.
 * - Starts observing on first subscriber.
 * - Stops observing when the last subscriber unsubscribes.
 * - Safe to import and subscribe in SSR (no-op).
 * - Fully compatible with async iteration.
 *
 * @param element The DOM element (or promise) to observe.
 * @returns {Stream<{ width: number; height: number }>}
 */
function onResize(element) {
    const subject = createSubject();
    subject.name = "onResize";
    let subscriberCount = 0;
    let active = false;
    let resolvedElement = null;
    let observer = null;
    /* -------------------------------------------------- */
    /* Helpers                                            */
    /* -------------------------------------------------- */
    const emit = (entry) => {
        if (!resolvedElement)
            return;
        const rect = entry?.contentRect ?? resolvedElement.getBoundingClientRect();
        subject.next({
            width: Math.round(rect.width),
            height: Math.round(rect.height)
        });
    };
    /* -------------------------------------------------- */
    /* Lifecycle                                          */
    /* -------------------------------------------------- */
    const start = async () => {
        if (active)
            return;
        active = true;
        // SSR / unsupported
        if (typeof ResizeObserver === "undefined") {
            active = false;
            return;
        }
        const el = isPromiseLike(element) ? await element : element;
        // Guard against unsubscribe during await
        if (!active || !el)
            return;
        resolvedElement = el;
        observer = new ResizeObserver(entries => {
            emit(entries[0]);
        });
        observer.observe(resolvedElement);
        // Initial synchronous emission
        emit();
    };
    const stop = () => {
        if (!active)
            return;
        active = false;
        observer?.disconnect();
        observer = null;
        resolvedElement = null;
    };
    /* -------------------------------------------------- */
    /* Ref-counted subscription override                  */
    /* -------------------------------------------------- */
    const originalSubscribe = subject.subscribe;
    subject.subscribe = (cb) => {
        const sub = originalSubscribe.call(subject, cb);
        if (++subscriberCount === 1) {
            void start();
        }
        const prev = sub.onUnsubscribe;
        sub.onUnsubscribe = () => {
            if (--subscriberCount === 0) {
                stop();
            }
            prev?.call(sub);
        };
        return sub;
    };
    /* -------------------------------------------------- */
    /* Async iteration support                            */
    /* -------------------------------------------------- */
    subject[Symbol.asyncIterator] = () => createAsyncGenerator(receiver => subject.subscribe(receiver));
    return subject;
}

/**
 * Creates a reactive stream that emits changes to the visual viewport.
 *
 * Uses `visualViewport` when available, falling back to `window`.
 *
 * **Behavior:**
 * - Emits initial viewport metrics on start.
 * - Emits on resize, scroll, and zoom.
 * - Starts listening on first subscriber.
 * - Stops listening when the last subscriber unsubscribes.
 * - Safe to import and subscribe in SSR (no-op).
 * - Fully compatible with async iteration.
 *
 * @returns {Stream<ViewportState>}
 */
function onViewportChange() {
    const subject = createSubject();
    subject.name = "onViewportChange";
    let subscriberCount = 0;
    let stopped = true;
    let target = null;
    const snapshot = () => {
        if (typeof window === "undefined") {
            return {
                width: 0,
                height: 0,
                scale: 1,
                offsetLeft: 0,
                offsetTop: 0
            };
        }
        if (window.visualViewport) {
            const vp = window.visualViewport;
            return {
                width: vp.width,
                height: vp.height,
                scale: vp.scale,
                offsetLeft: vp.offsetLeft,
                offsetTop: vp.offsetTop
            };
        }
        return {
            width: window.innerWidth,
            height: window.innerHeight,
            scale: 1,
            offsetLeft: 0,
            offsetTop: 0
        };
    };
    const emit = () => {
        subject.next(snapshot());
    };
    const start = () => {
        if (!stopped)
            return;
        stopped = false;
        // SSR guard
        if (typeof window === "undefined")
            return;
        target = window.visualViewport ?? window;
        target.addEventListener("resize", emit);
        target.addEventListener("scroll", emit);
        emit(); // initial snapshot
    };
    const stop = () => {
        if (stopped)
            return;
        stopped = true;
        if (!target)
            return;
        target.removeEventListener("resize", emit);
        target.removeEventListener("scroll", emit);
        target = null;
    };
    /* ------------------------------------------------------------------------
     * Ref-counted subscription handling
     * ---------------------------------------------------------------------- */
    const originalSubscribe = subject.subscribe;
    subject.subscribe = (cb) => {
        const sub = originalSubscribe.call(subject, cb);
        if (++subscriberCount === 1) {
            start();
        }
        const o = sub.onUnsubscribe;
        sub.onUnsubscribe = () => {
            if (--subscriberCount === 0) {
                stop();
            }
            o?.call(sub);
        };
        return sub;
    };
    /* ------------------------------------------------------------------------
     * Async iteration support
     * ---------------------------------------------------------------------- */
    subject[Symbol.asyncIterator] = () => createAsyncGenerator(receiver => subject.subscribe(receiver));
    return subject;
}

/**
 * Creates a reactive stream that emits the document's visibility state
 * whenever it changes.
 *
 * This stream is useful for:
 * - pausing animations or polling when the page is hidden
 * - throttling background work
 * - detecting tab switching or minimization
 *
 * **Behavior:**
 * - Emits the current visibility state on start.
 * - Emits on every `visibilitychange` event.
 * - Starts listening on first subscriber.
 * - Stops listening when the last subscriber unsubscribes.
 * - Safe to import and subscribe in SSR (no-op).
 * - Fully compatible with async iteration.
 *
 * @returns {Stream<DocumentVisibilityState>}
 */
function onVisibilityChange() {
    const subject = createSubject();
    subject.name = "onVisibilityChange";
    let subscriberCount = 0;
    let stopped = true;
    const getState = () => {
        if (typeof document === "undefined" || !("visibilityState" in document)) {
            return "visible";
        }
        return document.visibilityState;
    };
    const emit = () => {
        subject.next(getState());
    };
    const start = () => {
        if (!stopped)
            return;
        stopped = false;
        // SSR / unsupported guard
        if (typeof document === "undefined")
            return;
        document.addEventListener("visibilitychange", emit);
        emit(); // initial value
    };
    const stop = () => {
        if (stopped)
            return;
        stopped = true;
        if (typeof document === "undefined")
            return;
        document.removeEventListener("visibilitychange", emit);
    };
    /* ------------------------------------------------------------------------
     * Ref-counted subscription handling
     * ---------------------------------------------------------------------- */
    const originalSubscribe = subject.subscribe;
    subject.subscribe = (cb) => {
        const sub = originalSubscribe.call(subject, cb);
        if (++subscriberCount === 1) {
            start();
        }
        const o = sub.onUnsubscribe;
        sub.onUnsubscribe = () => {
            if (--subscriberCount === 0) {
                stop();
            }
            o?.call(sub);
        };
        return sub;
    };
    /* ------------------------------------------------------------------------
     * Async iteration support
     * ---------------------------------------------------------------------- */
    subject[Symbol.asyncIterator] = () => createAsyncGenerator(receiver => subject.subscribe(receiver));
    return subject;
}

/*
 * Public API Surface of actionstack
 */

/**
 * Generated bundle index. Do not edit.
 */

export { onAnimationFrame, onBattery, onFullscreen, onIdle, onIntersection, onMediaQuery, onMutation, onNetwork, onOrientation, onResize, onViewportChange, onVisibilityChange };
//# sourceMappingURL=actioncrew-streamix-dom.mjs.map
