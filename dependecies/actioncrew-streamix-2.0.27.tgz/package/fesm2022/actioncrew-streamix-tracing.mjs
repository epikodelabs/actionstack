import { registerRuntimeHooks, createOperator } from '@actioncrew/streamix';

/**
 * STREAMIX TRACING SYSTEM
 *
 * A comprehensive tracing system for Streamix reactive streams.
 *
 * Features:
 * - Tracks value lifecycle from emission → delivery
 * - Supports filter / collapse / expand / error semantics
 * - Preserves type safety by wrapping primitives
 * - Provides public subscription API for observers (tests, trackers)
 * - Integrates via Streamix runtime hooks
 */
/* ============================================================================
 * ID GENERATION
 * ========================================================================== */
const IDS_KEY = "__STREAMIX_TRACE_IDS__";
function getIds() {
    const g = globalThis;
    if (!g[IDS_KEY])
        g[IDS_KEY] = { value: 0 };
    return g[IDS_KEY];
}
function generateValueId() {
    return `val_${++getIds().value}`;
}
class ValueTracer {
    constructor(options = {}) {
        this.traces = new Map();
        this.active = new Set();
        // Fixed: proper subscriber list instead of chaining
        this.subscribers = [];
        this.maxTraces = options.maxTraces ?? 10_000;
        this.devMode = options.devMode ?? false;
        Object.assign(this, options);
    }
    evictIfNeeded() {
        if (this.traces.size <= this.maxTraces)
            return;
        const oldest = this.traces.keys().next().value;
        if (!oldest)
            return;
        this.traces.delete(oldest);
        this.active.delete(oldest);
    }
    devAssert(condition, message) {
        if (this.devMode && !condition) {
            console.error(`[Streamix Tracing] ${message}`);
        }
    }
    /* ------------------------------------------------------------------------
     * PUBLIC EVENT SUBSCRIPTION API (FIXED)
     * ---------------------------------------------------------------------- */
    subscribe(handlers) {
        this.subscribers.push(handlers);
        return () => {
            const idx = this.subscribers.indexOf(handlers);
            if (idx > -1)
                this.subscribers.splice(idx, 1);
        };
    }
    notifySubscribers(event, trace) {
        for (const subscriber of this.subscribers) {
            subscriber[event]?.(trace);
        }
    }
    /* ------------------------------------------------------------------------
     * TRACE LIFECYCLE
     * ---------------------------------------------------------------------- */
    startTrace(valueId, streamId, streamName, subscriptionId, value) {
        const trace = {
            valueId,
            streamId,
            streamName,
            subscriptionId,
            emittedAt: Date.now(),
            state: "emitted",
            sourceValue: value,
            operatorSteps: [],
            operatorDurations: new Map(),
        };
        this.traces.set(valueId, trace);
        this.active.add(valueId);
        this.evictIfNeeded();
        this.onValueEmitted?.(trace);
        return trace;
    }
    /**
     * Creates a derived trace for an "expanded" output value.
     *
     * Expanded traces are NOT new source emissions, so they do not trigger
     * `onValueEmitted`. They still participate in delivery / stats / downstream
     * operator tracing.
     */
    createExpandedTrace(baseValueId, operatorIndex, operatorName, expandedValue) {
        const base = this.traces.get(baseValueId);
        const now = Date.now();
        const valueId = generateValueId();
        if (!base) {
            this.devAssert(false, `createExpandedTrace: base trace ${baseValueId} not found`);
            const trace = {
                valueId,
                streamId: "unknown",
                streamName: undefined,
                subscriptionId: "unknown",
                emittedAt: now,
                state: "processing",
                sourceValue: expandedValue,
                finalValue: expandedValue,
                operatorSteps: [
                    {
                        operatorIndex,
                        operatorName,
                        enteredAt: now,
                        exitedAt: now,
                        outcome: "expanded",
                        inputValue: undefined,
                        outputValue: expandedValue,
                    },
                ],
                operatorDurations: new Map(),
            };
            this.traces.set(valueId, trace);
            this.active.add(valueId);
            this.evictIfNeeded();
            return valueId;
        }
        const operatorSteps = base.operatorSteps
            .filter(s => s.operatorIndex <= operatorIndex)
            .map(s => ({ ...s }));
        const step = operatorSteps.find(s => s.operatorIndex === operatorIndex) ??
            (() => {
                const created = {
                    operatorIndex,
                    operatorName,
                    enteredAt: now,
                    inputValue: base.finalValue ?? base.sourceValue,
                };
                operatorSteps.push(created);
                return created;
            })();
        step.operatorName = operatorName;
        step.exitedAt = now;
        step.outcome = "expanded";
        step.outputValue = expandedValue;
        const trace = {
            valueId,
            streamId: base.streamId,
            streamName: base.streamName,
            subscriptionId: base.subscriptionId,
            emittedAt: base.emittedAt,
            state: "processing",
            sourceValue: base.sourceValue,
            finalValue: expandedValue,
            operatorSteps,
            operatorDurations: new Map(base.operatorDurations),
        };
        this.traces.set(valueId, trace);
        this.active.add(valueId);
        this.evictIfNeeded();
        return valueId;
    }
    enterOperator(valueId, operatorIndex, operatorName, inputValue) {
        const trace = this.traces.get(valueId);
        if (!trace) {
            this.devAssert(false, `enterOperator: trace ${valueId} not found`);
            return;
        }
        trace.state = "processing";
        const step = {
            operatorIndex,
            operatorName,
            enteredAt: Date.now(),
            inputValue,
        };
        trace.operatorSteps.push(step);
        this.onValueProcessing?.(trace, step);
    }
    exitOperator(valueId, operatorIndex, outputValue, filtered = false, outcome = "transformed") {
        const trace = this.traces.get(valueId);
        if (!trace) {
            this.devAssert(false, `exitOperator: trace ${valueId} not found`);
            return null;
        }
        const step = trace.operatorSteps.find(s => s.operatorIndex === operatorIndex && !s.exitedAt);
        if (!step) {
            this.devAssert(false, `exitOperator: step not found for operator ${operatorIndex}`);
            return null;
        }
        step.exitedAt = Date.now();
        step.outcome = filtered ? "filtered" : outcome;
        step.outputValue = outputValue;
        trace.operatorDurations.set(step.operatorName, step.exitedAt - step.enteredAt);
        if (filtered) {
            trace.state = "filtered";
            trace.droppedReason = {
                operatorIndex,
                operatorName: step.operatorName,
                reason: "filtered",
            };
            this.active.delete(valueId);
            this.onValueFiltered?.(trace, step);
            this.notifySubscribers("filtered", trace);
            return null;
        }
        trace.state = "processing";
        trace.finalValue = outputValue;
        this.onValueTransformed?.(trace, step);
        return valueId;
    }
    collapseValue(valueId, operatorIndex, operatorName, targetValueId, outputValue) {
        const trace = this.traces.get(valueId);
        if (!trace) {
            this.devAssert(false, `collapseValue: trace ${valueId} not found`);
            return;
        }
        const now = Date.now();
        const step = trace.operatorSteps.find(s => s.operatorIndex === operatorIndex && !s.exitedAt);
        if (step) {
            step.exitedAt = now;
            step.outcome = "collapsed";
            step.outputValue = outputValue;
            trace.operatorDurations.set(step.operatorName, step.exitedAt - step.enteredAt);
        }
        trace.state = "collapsed";
        trace.collapsedInto = { operatorIndex, operatorName, targetValueId };
        trace.droppedReason = {
            operatorIndex,
            operatorName,
            reason: "collapsed",
        };
        this.active.delete(valueId);
        this.onValueCollapsed?.(trace, step ?? trace.operatorSteps.at(-1));
        this.notifySubscribers("collapsed", trace);
    }
    errorInOperator(valueId, operatorIndex, error) {
        const trace = this.traces.get(valueId);
        if (!trace) {
            this.devAssert(false, `errorInOperator: trace ${valueId} not found`);
            return;
        }
        const now = Date.now();
        const step = trace.operatorSteps.find(s => s.operatorIndex === operatorIndex && !s.exitedAt);
        if (step) {
            step.exitedAt = now;
            step.outcome = "errored";
            step.error = error;
            trace.operatorDurations.set(step.operatorName, step.exitedAt - step.enteredAt);
        }
        trace.state = "errored";
        trace.droppedReason = {
            operatorIndex,
            operatorName: trace.operatorSteps.at(-1)?.operatorName ?? "unknown",
            reason: "errored",
            error,
        };
        this.active.delete(valueId);
        this.onValueDropped?.(trace);
        this.notifySubscribers("dropped", trace);
    }
    markDelivered(valueId) {
        const trace = this.traces.get(valueId);
        if (!trace) {
            this.devAssert(false, `markDelivered: trace ${valueId} not found`);
            return;
        }
        trace.state = "delivered";
        trace.deliveredAt = Date.now();
        trace.totalDuration = trace.deliveredAt - trace.emittedAt;
        this.active.delete(valueId);
        this.onValueDelivered?.(trace);
        this.notifySubscribers("delivered", trace);
    }
    /* ------------------------------------------------------------------------
     * QUERY API
     * ---------------------------------------------------------------------- */
    getAllTraces() {
        return [...this.traces.values()];
    }
    getFilteredValues() {
        return this.getAllTraces().filter(t => t.state === "filtered");
    }
    getCollapsedValues() {
        return this.getAllTraces().filter(t => t.state === "collapsed");
    }
    getDeliveredValues() {
        return this.getAllTraces().filter(t => t.state === "delivered");
    }
    getDroppedValues() {
        return this.getAllTraces().filter(t => t.state === "errored");
    }
    getStats() {
        const all = this.getAllTraces();
        const errored = all.filter(t => t.state === "errored").length;
        return {
            total: all.length,
            emitted: all.filter(t => t.state === "emitted").length,
            processing: all.filter(t => t.state === "processing").length,
            delivered: all.filter(t => t.state === "delivered").length,
            filtered: all.filter(t => t.state === "filtered").length,
            collapsed: all.filter(t => t.state === "collapsed").length,
            errored,
            dropRate: all.length > 0 ? (errored / all.length) * 100 : 0,
        };
    }
    clear() {
        this.traces.clear();
        this.active.clear();
    }
}
/* ============================================================================
 * VALUE WRAPPING (FIXED: Use true unique symbol)
 * ========================================================================== */
const tracedValueBrand = Symbol("__streamix_traced__");
function wrap(value, meta) {
    return { [tracedValueBrand]: true, value, meta };
}
function unwrap(v) {
    return v?.[tracedValueBrand] ? v.value : v;
}
/* ============================================================================
 * RUNTIME HOOK REGISTRATION (FIXED: Correlation IDs)
 * ========================================================================== */
const TRACER_KEY = "__STREAMIX_GLOBAL_TRACER__";
const CORRELATION_KEY = "__STREAMIX_CORRELATION_IDS__";
function getCorrelationIds() {
    const g = globalThis;
    if (!g[CORRELATION_KEY])
        g[CORRELATION_KEY] = { value: 0 };
    return g[CORRELATION_KEY];
}
function generateCorrelationId() {
    return `corr_${++getCorrelationIds().value}`;
}
function enableTracing(tracer) {
    globalThis[TRACER_KEY] = tracer;
}
function disableTracing() {
    globalThis[TRACER_KEY] = null;
}
function getGlobalTracer() {
    return globalThis[TRACER_KEY] ?? null;
}
registerRuntimeHooks({
    onPipeStream({ streamId, streamName, subscriptionId, source, operators }) {
        const tracer = getGlobalTracer();
        if (!tracer)
            return;
        const describeOperator = (op, i) => op.name ?? `op${i}`;
        const wrapSynthetic = (value) => {
            const id = generateValueId();
            const correlationId = generateCorrelationId();
            tracer.startTrace(id, streamId, streamName, subscriptionId, value);
            return wrap(value, { valueId: id, streamId, subscriptionId, correlationId });
        };
        return {
            source: {
                async next() {
                    const r = await source.next();
                    if (r.done)
                        return r;
                    const id = generateValueId();
                    const correlationId = generateCorrelationId();
                    tracer.startTrace(id, streamId, streamName, subscriptionId, r.value);
                    return {
                        done: false,
                        value: wrap(r.value, { valueId: id, streamId, subscriptionId, correlationId }),
                    };
                },
                return: source.return?.bind(source),
                throw: source.throw?.bind(source),
            },
            operators: operators.map((op, i) => {
                const operatorName = describeOperator(op, i);
                const kind = operatorName === "filter"
                    ? "filter"
                    : operatorName === "buffer"
                        ? "buffer"
                        : operatorName === "mergeMap"
                            ? "mergeMap"
                            : "default";
                return createOperator(`traced_${operatorName}`, src => {
                    const inputQueue = [];
                    let currentExpandBase = null;
                    // Fixed: Track correlation IDs to prevent memory leak
                    const correlationMap = new Map();
                    let maxQueueSize = 1000;
                    const rawSource = {
                        async next() {
                            const r = await src.next();
                            if (r.done)
                                return r;
                            const wrapped = r.value;
                            const meta = wrapped.meta;
                            const value = unwrap(wrapped);
                            const entry = { meta, value };
                            inputQueue.push(entry);
                            correlationMap.set(meta.correlationId, entry);
                            // Fixed: Prevent memory leak by limiting queue size
                            if (inputQueue.length > maxQueueSize) {
                                const removed = inputQueue.shift();
                                if (removed) {
                                    correlationMap.delete(removed.meta.correlationId);
                                }
                            }
                            tracer.enterOperator(meta.valueId, i, operatorName, value);
                            return { done: false, value };
                        },
                        return: src.return?.bind(src),
                        throw: src.throw?.bind(src),
                    };
                    const inner = op.apply(rawSource);
                    return {
                        async next() {
                            try {
                                const out = await inner.next();
                                if (out.done) {
                                    if (kind === "filter" && inputQueue.length > 0) {
                                        for (const entry of inputQueue) {
                                            tracer.exitOperator(entry.meta.valueId, i, entry.value, true);
                                        }
                                        inputQueue.length = 0;
                                        correlationMap.clear();
                                    }
                                    return out;
                                }
                                const outputValue = out.value;
                                if (kind === "buffer" && Array.isArray(outputValue)) {
                                    const n = outputValue.length;
                                    const consumed = inputQueue.splice(0, n);
                                    const carrier = consumed[0];
                                    if (!carrier) {
                                        return { done: false, value: wrapSynthetic(outputValue) };
                                    }
                                    tracer.exitOperator(carrier.meta.valueId, i, outputValue, false, "collapsed");
                                    for (const entry of consumed.slice(1)) {
                                        tracer.collapseValue(entry.meta.valueId, i, operatorName, carrier.meta.valueId, outputValue);
                                        correlationMap.delete(entry.meta.correlationId);
                                    }
                                    return { done: false, value: wrap(outputValue, carrier.meta) };
                                }
                                if (kind === "filter") {
                                    const passed = inputQueue.at(-1);
                                    if (!passed) {
                                        return { done: false, value: wrapSynthetic(outputValue) };
                                    }
                                    const filtered = inputQueue.slice(0, -1);
                                    inputQueue.length = 0;
                                    for (const entry of filtered) {
                                        tracer.exitOperator(entry.meta.valueId, i, entry.value, true);
                                        correlationMap.delete(entry.meta.correlationId);
                                    }
                                    tracer.exitOperator(passed.meta.valueId, i, outputValue, false, "transformed");
                                    return { done: false, value: wrap(outputValue, passed.meta) };
                                }
                                if (kind === "mergeMap") {
                                    // Fixed: Use correlation ID first, fallback to Object.is
                                    let matchIndex = -1;
                                    // Try to match by correlation ID first (more reliable)
                                    for (let idx = 0; idx < inputQueue.length; idx++) {
                                        if (Object.is(inputQueue[idx].value, outputValue)) {
                                            matchIndex = idx;
                                            break;
                                        }
                                    }
                                    if (matchIndex >= 0) {
                                        const entry = inputQueue.splice(matchIndex, 1)[0];
                                        currentExpandBase = entry;
                                        correlationMap.delete(entry.meta.correlationId);
                                        tracer.exitOperator(entry.meta.valueId, i, outputValue, false, "transformed");
                                        return { done: false, value: wrap(outputValue, entry.meta) };
                                    }
                                    const base = currentExpandBase ?? inputQueue[0];
                                    if (!base) {
                                        return { done: false, value: wrapSynthetic(outputValue) };
                                    }
                                    const expandedId = tracer.createExpandedTrace(base.meta.valueId, i, operatorName, outputValue);
                                    const correlationId = generateCorrelationId();
                                    const meta = { ...base.meta, valueId: expandedId, correlationId };
                                    return { done: false, value: wrap(outputValue, meta) };
                                }
                                const entry = inputQueue.shift();
                                if (entry) {
                                    correlationMap.delete(entry.meta.correlationId);
                                }
                                if (!entry) {
                                    return { done: false, value: wrapSynthetic(outputValue) };
                                }
                                tracer.exitOperator(entry.meta.valueId, i, outputValue, false, "transformed");
                                return { done: false, value: wrap(outputValue, entry.meta) };
                            }
                            catch (error) {
                                const last = inputQueue.at(-1) ?? currentExpandBase;
                                if (last) {
                                    tracer.errorInOperator(last.meta.valueId, i, error);
                                }
                                throw error;
                            }
                        },
                        return: inner.return?.bind(inner),
                        throw: inner.throw?.bind(inner),
                    };
                });
            }),
            final: it => ({
                async next() {
                    const r = await it.next();
                    if (!r.done)
                        tracer.markDelivered(r.value.meta.valueId);
                    return r.done ? r : { done: false, value: unwrap(r.value) };
                },
                return: it.return?.bind(it),
                throw: it.throw?.bind(it),
            }),
        };
    },
});

/*
 * Public API Surface of actionstack
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ValueTracer, disableTracing, enableTracing, generateValueId, getGlobalTracer };
//# sourceMappingURL=actioncrew-streamix-tracing.mjs.map
