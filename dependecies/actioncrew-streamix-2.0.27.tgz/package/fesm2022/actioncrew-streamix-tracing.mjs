import { registerRuntimeHooks, createOperator } from '@actioncrew/streamix';

/**
 * STREAMIX TRACING SYSTEM – COMPLETE IMPLEMENTATION
 *
 * A comprehensive tracing system for Streamix reactive streams.
 *
 * Features:
 * - Tracks value lifecycle from emission → delivery
 * - Supports filter / collapse / expand / error semantics
 * - Preserves type safety by wrapping primitives
 * - Provides public subscription API for observers (tests, trackers)
 * - Integrates via Streamix runtime hooks
 */
/* ============================================================================
 * ID GENERATION
 * ========================================================================== */
const IDS_KEY = "__STREAMIX_TRACE_IDS__";
function getIds() {
    const g = globalThis;
    if (!g[IDS_KEY])
        g[IDS_KEY] = { value: 0 };
    return g[IDS_KEY];
}
function generateValueId() {
    return `val_${++getIds().value}`;
}
class ValueTracer {
    constructor(options = {}) {
        this.traces = new Map();
        this.active = new Set();
        this.maxTraces = options.maxTraces ?? 10_000;
        Object.assign(this, options);
    }
    /* ------------------------------------------------------------------------
     * PUBLIC EVENT SUBSCRIPTION API
     * ---------------------------------------------------------------------- */
    subscribe(handlers) {
        const prev = {
            delivered: this.onValueDelivered,
            filtered: this.onValueFiltered,
            collapsed: this.onValueCollapsed,
            dropped: this.onValueDropped,
        };
        if (handlers.delivered) {
            this.onValueDelivered = t => {
                prev.delivered?.(t);
                handlers.delivered(t);
            };
        }
        if (handlers.filtered) {
            this.onValueFiltered = (t, s) => {
                prev.filtered?.(t, s);
                handlers.filtered(t);
            };
        }
        if (handlers.collapsed) {
            this.onValueCollapsed = (t, s) => {
                prev.collapsed?.(t, s);
                handlers.collapsed(t);
            };
        }
        if (handlers.dropped) {
            this.onValueDropped = t => {
                prev.dropped?.(t);
                handlers.dropped(t);
            };
        }
        return () => {
            this.onValueDelivered = prev.delivered;
            this.onValueFiltered = prev.filtered;
            this.onValueCollapsed = prev.collapsed;
            this.onValueDropped = prev.dropped;
        };
    }
    /* ------------------------------------------------------------------------
     * TRACE LIFECYCLE
     * ---------------------------------------------------------------------- */
    startTrace(valueId, streamId, streamName, subscriptionId, value) {
        const trace = {
            valueId,
            streamId,
            streamName,
            subscriptionId,
            emittedAt: Date.now(),
            state: "emitted",
            sourceValue: value,
            operatorSteps: [],
            operatorDurations: new Map(),
        };
        this.traces.set(valueId, trace);
        this.active.add(valueId);
        if (this.traces.size > this.maxTraces) {
            const oldest = this.traces.keys().next().value;
            if (oldest) {
                this.traces.delete(oldest);
                this.active.delete(oldest);
            }
        }
        this.onValueEmitted?.(trace);
        return trace;
    }
    enterOperator(valueId, operatorIndex, operatorName, inputValue) {
        const trace = this.traces.get(valueId);
        if (!trace)
            return;
        trace.state = "processing";
        const step = {
            operatorIndex,
            operatorName,
            enteredAt: Date.now(),
            inputValue,
        };
        trace.operatorSteps.push(step);
        this.onValueProcessing?.(trace, step);
    }
    exitOperator(valueId, operatorIndex, outputValue, filtered = false, outcome = "transformed") {
        const trace = this.traces.get(valueId);
        if (!trace)
            return null;
        const step = trace.operatorSteps.find(s => s.operatorIndex === operatorIndex && !s.exitedAt);
        if (!step)
            return null;
        step.exitedAt = Date.now();
        step.outcome = filtered ? "filtered" : outcome;
        step.outputValue = outputValue;
        trace.operatorDurations.set(step.operatorName, step.exitedAt - step.enteredAt);
        if (filtered) {
            trace.state = "filtered";
            trace.droppedReason = {
                operatorIndex,
                operatorName: step.operatorName,
                reason: "filtered",
            };
            this.active.delete(valueId);
            this.onValueFiltered?.(trace, step);
            return null;
        }
        trace.state = "processing";
        trace.finalValue = outputValue;
        this.onValueTransformed?.(trace, step);
        return valueId;
    }
    collapseValue(valueId, operatorIndex, operatorName, targetValueId) {
        const trace = this.traces.get(valueId);
        if (!trace)
            return;
        trace.state = "collapsed";
        trace.collapsedInto = { operatorIndex, operatorName, targetValueId };
        this.active.delete(valueId);
        this.onValueCollapsed?.(trace, trace.operatorSteps.at(-1));
    }
    errorInOperator(valueId, operatorIndex, error) {
        const trace = this.traces.get(valueId);
        if (!trace)
            return;
        trace.state = "errored";
        trace.droppedReason = {
            operatorIndex,
            operatorName: trace.operatorSteps.at(-1)?.operatorName ?? "unknown",
            reason: "errored",
            error,
        };
        this.active.delete(valueId);
        this.onValueDropped?.(trace);
    }
    markDelivered(valueId) {
        const trace = this.traces.get(valueId);
        if (!trace)
            return;
        trace.state = "delivered";
        trace.deliveredAt = Date.now();
        trace.totalDuration = trace.deliveredAt - trace.emittedAt;
        this.active.delete(valueId);
        this.onValueDelivered?.(trace);
    }
    /* ------------------------------------------------------------------------
     * QUERY API
     * ---------------------------------------------------------------------- */
    getAllTraces() {
        return [...this.traces.values()];
    }
    clear() {
        this.traces.clear();
        this.active.clear();
    }
}
/* ============================================================================
 * VALUE WRAPPING
 * ========================================================================== */
const tracedValueBrand = Symbol.for("__streamix_traced__");
function wrap(value, meta) {
    return { [tracedValueBrand]: true, value, meta };
}
function unwrap(v) {
    return v?.[tracedValueBrand] ? v.value : v;
}
/* ============================================================================
 * RUNTIME HOOK REGISTRATION
 * ========================================================================== */
const TRACER_KEY = "__STREAMIX_GLOBAL_TRACER__";
function enableTracing(tracer) {
    globalThis[TRACER_KEY] = tracer;
}
function disableTracing() {
    globalThis[TRACER_KEY] = null;
}
function getGlobalTracer() {
    return globalThis[TRACER_KEY] ?? null;
}
registerRuntimeHooks({
    onPipeStream({ streamId, streamName, subscriptionId, source, operators }) {
        const tracer = getGlobalTracer();
        if (!tracer)
            return;
        return {
            source: {
                async next() {
                    const r = await source.next();
                    if (r.done)
                        return r;
                    const id = generateValueId();
                    tracer.startTrace(id, streamId, streamName, subscriptionId, r.value);
                    return { done: false, value: wrap(r.value, { valueId: id, streamId, subscriptionId }) };
                },
            },
            operators: operators.map((op, i) => createOperator(`traced_${op.name ?? i}`, src => ({
                async next() {
                    const r = await src.next();
                    if (r.done)
                        return r;
                    const meta = r.value.meta;
                    const value = unwrap(r.value);
                    tracer.enterOperator(meta.valueId, i, op.name ?? `op${i}`, value);
                    const out = await op.apply({ next: async () => ({ done: false, value }) }).next();
                    if (out.done)
                        return out;
                    tracer.exitOperator(meta.valueId, i, out.value);
                    return { done: false, value: wrap(out.value, meta) };
                },
            }))),
            final: it => ({
                async next() {
                    const r = await it.next();
                    if (!r.done)
                        tracer.markDelivered(r.value.meta.valueId);
                    return r.done ? r : { done: false, value: unwrap(r.value) };
                },
            }),
        };
    },
});

/*
 * Public API Surface of actionstack
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ValueTracer, disableTracing, enableTracing, generateValueId, getGlobalTracer };
//# sourceMappingURL=actioncrew-streamix-tracing.mjs.map
