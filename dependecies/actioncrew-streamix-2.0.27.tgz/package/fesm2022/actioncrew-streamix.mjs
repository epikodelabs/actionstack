/**
 * Global symbol key used to store runtime hooks.
 *
 * Stored on `globalThis` to allow cross-module access
 * without introducing hard dependencies.
 */
const HOOKS_KEY = "__STREAMIX_RUNTIME_HOOKS__";
/**
 * Monotonically increasing counters for ID generation.
 *
 * These counters are intentionally process-local
 * and reset on application restart.
 */
let streamIdCounter = 0;
let subscriptionIdCounter = 0;
/**
 * Generates a unique stream identifier.
 *
 * IDs are stable within a single runtime session
 * and deterministic for tracing purposes.
 */
function generateStreamId() {
    return `str_${++streamIdCounter}`;
}
/**
 * Generates a unique subscription identifier.
 *
 * Used to correlate subscriptions with
 * emitted values and lifecycle events.
 */
function generateSubscriptionId() {
    return `sub_${++subscriptionIdCounter}`;
}
/**
 * Registers runtime hooks globally.
 *
 * Calling this function replaces any previously
 * registered hooks.
 */
function registerRuntimeHooks(hooks) {
    globalThis[HOOKS_KEY] = hooks;
}
/**
 * Retrieves the currently registered runtime hooks.
 *
 * Returns `null` if no hooks are registered.
 */
function getRuntimeHooks() {
    return (globalThis[HOOKS_KEY] ?? null);
}

/**
 * Type guard that checks whether a value behaves like a promise.
 *
 * We avoid relying on `instanceof Promise` so that promise-like values from
 * different realms or custom thenables are still treated correctly.
 */
const isPromiseLike = (value) => !!value && typeof value.then === 'function';
/**
 * A constant representing a completed stream result.
 *
 * Always `{ done: true, value: undefined }`.
 * Used to signal the end of a stream.
 */
const DONE = { done: true, value: undefined };
/**
 * Factory function to create a normal stream result.
 *
 * @template R The type of the emitted value.
 * @param value The value to emit downstream.
 * @returns A `IteratorResult<R>` object with `{ done: false, value }`.
 */
const NEXT = (value) => ({ done: false, value });
/**
 * Creates a reusable stream operator.
 *
 * This factory function simplifies the creation of operators by bundling a name and a
 * transformation function into a single `Operator` object.
 *
 * @template T The type of the value the operator will consume.
 * @template R The type of the value the operator will produce.
 * @param name The name of the operator, for identification and debugging.
 * @param transformFn The transformation function that defines the operator's logic.
 * @returns A new `Operator` object with the specified name and transformation function.
 */
function createOperator(name, transformFn) {
    return {
        name,
        type: 'operator',
        apply: transformFn
    };
}
;

/**
 * Normalizes a receiver input (a function or an object) into a strict,
 * fully-defined receiver.
 *
 * This factory function ensures that a consistent `StrictReceiver` object is
 * always returned, regardless of the input. It wraps the provided handlers
 * with logic that ensures events are not processed after completion and that
 * unhandled errors are logged.
 *
 * If the input is a function, it is treated as the `next` handler. If it's an
 * object, its `next`, `error`, and `complete` properties are used. If no input
 * is provided, a receiver with no-op handlers is created.
 *
 * @template T The type of the value handled by the receiver.
 * @param callbackOrReceiver An optional function to serve as the `next` handler,
 * or a `Receiver` object with one or more optional handlers.
 * @returns A new `StrictReceiver` instance with normalized handlers and completion tracking.
 */
function createReceiver(callbackOrReceiver) {
    let _completed = false;
    let _processing = false;
    let _pendingComplete = false;
    const baseReceiver = {
        get completed() { return _completed; }
    };
    const receiver = (typeof callbackOrReceiver === 'function'
        ? { ...baseReceiver, next: callbackOrReceiver }
        : callbackOrReceiver
            ? { ...baseReceiver, ...callbackOrReceiver }
            : baseReceiver);
    const wrappedReceiver = {
        next: async (value) => {
            if (!_completed) {
                _processing = true;
                try {
                    await receiver.next?.call(receiver, value);
                }
                catch (err) {
                    await wrappedReceiver.error(err instanceof Error ? err : new Error(String(err)));
                }
                finally {
                    _processing = false;
                    // If completion was requested during processing, complete now
                    if (_pendingComplete && !_completed) {
                        _pendingComplete = false; // Clear the flag
                        _completed = true;
                        try {
                            await receiver.complete?.call(receiver);
                        }
                        catch (err) {
                            console.error('Unhandled error in complete handler:', err);
                        }
                    }
                }
            }
        },
        error: async function (err) {
            if (!_completed) {
                try {
                    await receiver.error?.call(receiver, err);
                }
                catch (e) {
                    console.error('Unhandled error in error handler:', e);
                }
            }
        },
        complete: async () => {
            if (!_completed) {
                if (_processing) {
                    // Defer completion until after current next() finishes
                    _pendingComplete = true;
                }
                else {
                    _completed = true;
                    try {
                        await receiver.complete?.call(receiver);
                    }
                    catch (err) {
                        console.error('Unhandled error in complete handler:', err);
                    }
                }
            }
        },
        get completed() {
            return _completed;
        },
    };
    return wrappedReceiver;
}

function createScheduler() {
    /**
     * Parallel arrays storing the task queue.
     *
     * This avoids allocating `{ fn, resolve, reject }` objects
     * per task and significantly reduces GC pressure.
     */
    const tasks = [];
    const resolves = [];
    const rejects = [];
    /**
     * Resolvers for pending `flush()` calls.
     * Multiple concurrent flush callers are supported.
     */
    let flushResolvers = [];
    /**
     * Indicates whether a pump is currently running
     * or scheduled to run.
     */
    let pumping = false;
    /**
     * Schedules a microtask.
     *
     * Wrapped for clarity and to avoid capturing extra state.
     */
    const scheduleMicrotask = (cb) => queueMicrotask(cb);
    /**
     * Resolves all pending flush promises if the scheduler
     * is idle AND remains idle across a microtask turn.
     *
     * This avoids a subtle bug where a task finishes,
     * the queue appears empty, but new tasks are enqueued
     * in a promise continuation.
     */
    const resolveFlushIfIdleMicrotaskStable = () => {
        scheduleMicrotask(() => {
            if (!pumping && tasks.length === 0 && flushResolvers.length) {
                const current = flushResolvers;
                flushResolvers = [];
                for (let i = 0; i < current.length; i++)
                    current[i]();
            }
        });
    };
    /**
     * Main execution loop.
     *
     * Pulls tasks from the queue one-by-one and executes them.
     * Errors reject the corresponding task promise but do not
     * stop the pump.
     */
    const pump = async () => {
        // Guard against multiple concurrent pumps.
        if (pumping)
            return;
        pumping = true;
        try {
            while (tasks.length > 0) {
                // Dequeue from parallel arrays.
                const task = tasks.shift();
                const resolve = resolves.shift();
                const reject = rejects.shift();
                try {
                    const result = task();
                    const value = isPromiseLike(result) ? await result : result;
                    resolve(value);
                }
                catch (err) {
                    // Reject only this task; continue pumping.
                    reject(err);
                }
                /**
                 * Yield between tasks.
                 *
                 * This allows:
                 * - promise continuations to enqueue new tasks
                 * - fair interleaving of async work
                 * - avoidance of deep synchronous recursion
                 *
                 * FIFO order is still preserved.
                 */
                await Promise.resolve();
            }
        }
        finally {
            pumping = false;
            resolveFlushIfIdleMicrotaskStable();
        }
    };
    /**
     * Ensures the pump is scheduled.
     *
     * Scheduling occurs on a microtask boundary to:
     * - avoid re-entrancy
     * - keep execution predictable
     */
    const ensurePump = () => {
        if (!pumping) {
            scheduleMicrotask(() => {
                // pump() rechecks `pumping` internally
                void pump();
            });
        }
    };
    /**
     * Enqueues a task for execution.
     */
    const enqueue = (fn) => {
        return new Promise((resolve, reject) => {
            tasks.push(fn);
            resolves.push(resolve);
            rejects.push(reject);
            ensurePump();
        });
    };
    /**
     * Resolves once the scheduler becomes fully idle.
     *
     * If already idle, resolves immediately.
     * Otherwise, waits until the queue is empty
     * and remains empty across a microtask turn.
     */
    const flush = () => {
        // Fast path: already idle.
        if (!pumping && tasks.length === 0)
            return Promise.resolve();
        return new Promise((resolve) => {
            flushResolvers.push(resolve);
            // Ensure progress even in edge cases.
            ensurePump();
            // Handle cases where pumping flips to false
            // before this flush registers.
            resolveFlushIfIdleMicrotaskStable();
        });
    };
    return { enqueue, flush };
}
/**
 * Global scheduler instance used by Streamix.
 */
const scheduler = createScheduler();

/**
 * Converts a `Stream` into an async generator, yielding each emitted value.
 * Distinguishes between undefined values and stream completion.
 *
 * This function creates a bridge between the push-based nature of a stream and
 * the pull-based nature of an async generator. It relies on the stream's
 * async-iterable interface (backed by the same multicast machinery used for
 * subscriptions), so `for await...of eachValueFrom(stream)` is equivalent to
 * `for await...of stream`.
 *
 * The generator handles all stream events:
 * - Each yielded value corresponds to a `next` event, including undefined values.
 * - The generator terminates when the stream `complete`s.
 * - It throws an error if the stream emits an `error` event.
 *
 * It correctly handles situations where the stream completes or errors out
 * before any values are yielded, and ensures the subscription is
 * always cleaned up.
 *
 * @template T The type of the values emitted by the stream.
 * @param stream The source stream to convert.
 * @returns An async generator that yields the values from the stream.
 */
function eachValueFrom(stream) {
    const iterator = stream[Symbol.asyncIterator]();
    // Some iterators only satisfy AsyncIterator; ensure AsyncGenerator shape by
    // making `[Symbol.asyncIterator]` return itself.
    if (typeof iterator[Symbol.asyncIterator] !== "function") {
        iterator[Symbol.asyncIterator] = () => iterator;
    }
    return iterator;
}

/**
 * Returns a promise that resolves with the first emitted value from a `Stream`.
 *
 * This utility function bridges the gap between the stream's push-based system and
 * JavaScript's standard promise-based asynchronous programming model. It's designed
 * for scenarios where you only care about the very first value a stream produces,
 * treating the stream like a single-value asynchronous source.
 *
 * The function's behavior is as follows:
 * - If the stream emits a value, the promise resolves with that value.
 * - If the stream emits an error, the promise rejects with that error.
 * - If the stream completes without ever emitting a value, the promise rejects with an `Error`.
 *
 * Once the promise is either resolved or rejected, the subscription to the stream is
 * automatically terminated, preventing any further resource consumption. This makes it
 * an efficient way to "query" a stream for a single result.
 *
 * @template T The type of the value that the promise will resolve with.
 * @param stream The source stream to listen to.
 * @returns A promise that resolves with the first value from the stream or rejects on error or completion without a value.
 */
function firstValueFrom(stream) {
    let subscription;
    let seen = false;
    return new Promise((resolve, reject) => {
        subscription = stream.subscribe({
            next(value) {
                seen = true;
                resolve(value);
                subscription.unsubscribe();
            },
            error(err) {
                reject(err);
                subscription.unsubscribe();
            },
            complete() {
                if (!seen) {
                    reject(new Error("Stream completed without emitting a value"));
                }
                subscription.unsubscribe();
            }
        });
    });
}

/**
 * Converts various value types into a Stream.
 *
 * This function normalizes different input types into a consistent Stream interface:
 * - Streams are passed through as-is
 * - Promises are awaited and their resolved values are processed
 * - Arrays have each element emitted individually
 * - Single values are emitted as-is
 *
 * @template R The type of values emitted by the resulting stream.
 * @param value The input value to convert. Can be:
 *   - a {@link Stream<R>}
 *   - a `Promise<R>` (single value)
 *   - a `Promise<Array<R>>` (multiple values from array)
 *   - a plain value `R`
 *   - an array `Array<R>`
 * @returns A {@link Stream<R>} that emits the normalized values.
 */
function fromAny(value) {
    // Step 1: If it's already a stream, return as-is
    if (isStreamLike(value)) {
        return value;
    }
    // Step 2: Handle promises, arrays, and single values in one generator
    return createStream("fromAny", async function* () {
        // Await promise if needed
        const resolved = isPromiseLike(value) ? await value : value;
        // Handle arrays - emit each element
        if (Array.isArray(resolved)) {
            for (const item of resolved) {
                yield item;
            }
        }
        else {
            // Single value
            yield resolved;
        }
    });
}

/**
 * Returns a promise that resolves with the last emitted value from a `Stream`.
 *
 * This function subscribes to the provided stream and buffers the last value
 * received. The returned promise is only settled once the stream completes or
 * errors.
 *
 * - **Successful resolution:** The promise resolves with the last value emitted
 * by the stream, but only after the stream has completed.
 * - **Rejection on error:** If the stream emits an error, the promise is rejected with that error.
 * - **Rejection on no value:** If the stream completes without emitting any values,
 * the promise is rejected with a specific error message.
 *
 * The subscription is automatically and immediately unsubscribed upon completion or
 * on error, ensuring proper resource cleanup.
 *
 * @template T The type of the value expected from the stream.
 * @param stream The source stream to listen to for the final value.
 * @returns A promise that resolves with the last value from the stream or rejects on completion without a value or on error.
 */
function lastValueFrom(stream) {
    return new Promise((resolve, reject) => {
        let lastValue;
        let hasValue = false;
        const subscription = stream.subscribe({
            next(value) {
                lastValue = value;
                hasValue = true;
            },
            error(err) {
                reject(err);
                subscription.unsubscribe();
            },
            complete() {
                if (hasValue) {
                    resolve(lastValue);
                }
                else {
                    reject(new Error("Stream completed without emitting a value"));
                }
                subscription.unsubscribe();
            }
        });
    });
}

/**
 * Creates a new `Subscription` instance.
 *
 * This factory encapsulates subscription state and ensures:
 * - Safe, idempotent unsubscription
 * - Proper execution of cleanup logic
 * - Consistent error handling during teardown
 *
 * @param onUnsubscribe Optional cleanup callback executed on first unsubscribe
 * @returns A new `Subscription` object
 */
function createSubscription(onUnsubscribe) {
    /** Internal mutable subscription state */
    let _unsubscribed = false;
    return {
        /**
         * Indicates whether the subscription has been unsubscribed.
         */
        get unsubscribed() {
            return _unsubscribed;
        },
        /**
         * Unsubscribes from the subscription.
         *
         * This method:
         * 1. Marks the subscription as unsubscribed
         * 2. Executes the `onUnsubscribe` callback (if present)
         * 3. Suppresses and logs any errors thrown during cleanup
         */
        unsubscribe: async function () {
            if (!_unsubscribed) {
                _unsubscribed = true;
                try {
                    await this.onUnsubscribe?.();
                }
                catch (err) {
                    console.error("Error during unsubscribe callback:", err);
                }
            }
        },
        /**
         * Cleanup callback executed when unsubscribing.
         */
        onUnsubscribe
    };
}

/**
 * Type guard for Stream-like objects.
 */
const isStreamLike = (value) => {
    if (!value || (typeof value !== "object" && typeof value !== "function"))
        return false;
    const v = value;
    return (v.type === "stream" || v.type === "subject") && typeof v[Symbol.asyncIterator] === "function";
};
/**
 * Returns a promise that resolves when an AbortSignal becomes aborted.
 *
 * If the signal is already aborted, the promise resolves immediately.
 *
 * @param signal AbortSignal to observe
 * @returns Promise resolved on abort
 */
function waitForAbort(signal) {
    if (signal.aborted)
        return Promise.resolve();
    return new Promise(resolve => signal.addEventListener("abort", resolve, { once: true }));
}
/**
 * Creates a pull-based async generator view over a stream.
 *
 * This bridges the push-based subscription model with
 * the pull-based async-iterator protocol.
 *
 * Characteristics:
 * - Buffers values when the producer is faster than the consumer
 * - Propagates errors via generator throws
 * - Guarantees subscription cleanup on completion, error, or early exit
 *
 * @template T
 * @param register Function registering a receiver and returning a subscription
 * @returns AsyncGenerator yielding stream values
 */
function createAsyncGenerator(register) {
    async function* generator() {
        /** Resolver for the next awaited iterator result */
        let resolveNext = null;
        /** Rejector for the next awaited iterator result */
        let rejectNext = null;
        /** Indicates that the stream has completed */
        let completed = false;
        /** Stores terminal error (if any) */
        let error = null;
        /** Value buffer when producer outpaces consumer */
        const queue = [];
        const subscription = register({
            next(value) {
                if (resolveNext) {
                    const r = resolveNext;
                    resolveNext = null;
                    rejectNext = null;
                    r({ done: false, value });
                }
                else {
                    queue.push(value);
                }
            },
            error(err) {
                error = err;
                if (rejectNext) {
                    const r = rejectNext;
                    resolveNext = null;
                    rejectNext = null;
                    r(err);
                }
                subscription.unsubscribe();
            },
            complete() {
                completed = true;
                if (resolveNext) {
                    const r = resolveNext;
                    resolveNext = null;
                    rejectNext = null;
                    r({ done: true, value: undefined });
                }
                subscription.unsubscribe();
            },
        });
        try {
            while (true) {
                if (error)
                    throw error;
                if (queue.length > 0) {
                    yield queue.shift();
                }
                else if (completed) {
                    break;
                }
                else {
                    const result = await new Promise((resolve, reject) => {
                        resolveNext = resolve;
                        rejectNext = reject;
                    });
                    if (result.done) {
                        break;
                    }
                    else {
                        yield result.value;
                    }
                }
            }
        }
        finally {
            subscription.unsubscribe();
        }
    }
    return generator();
}
/**
 * Wraps a Receiver so all callbacks are executed via the scheduler.
 *
 * Guarantees:
 * - All callbacks are async-scheduled (no sync re-entrancy)
 * - Errors thrown in `next` are forwarded to `error` if present
 * - Errors in `error` or `complete` are swallowed
 *
 * @template T
 * @param receiver Original receiver
 * @returns Wrapped receiver
 */
function wrapReceiver(receiver) {
    const wrapped = {};
    /**
     * Schedules a callback safely, ensuring scheduler errors
     * do not propagate into the stream core.
     */
    const safeSchedule = (cb) => scheduler.enqueue(cb).catch(() => { });
    if (receiver.next) {
        wrapped.next = (value) => safeSchedule(async () => {
            try {
                await receiver.next(value);
            }
            catch (err) {
                const error = err instanceof Error ? err : new Error(String(err));
                if (receiver.error) {
                    try {
                        await receiver.error(error);
                    }
                    catch {
                        /* swallowed by design */
                    }
                }
            }
        });
    }
    if (receiver.error) {
        wrapped.error = (err) => {
            const error = err instanceof Error ? err : new Error(String(err));
            return safeSchedule(() => {
                try {
                    return receiver.error(error);
                }
                catch {
                    /* swallowed */
                }
            });
        };
    }
    if (receiver.complete) {
        wrapped.complete = () => safeSchedule(() => {
            try {
                return receiver.complete();
            }
            catch {
                /* swallowed */
            }
        });
    }
    return wrapped;
}
/**
 * Consumes an async iterator and forwards emitted values to receivers.
 *
 * Semantics:
 * - Stops on iterator completion or abort
 * - Abort does NOT trigger `complete`
 * - Natural completion DOES trigger `complete`
 * - Generator-thrown errors are forwarded to receivers
 *
 * @template T
 * @param iterator Async iterator to drain
 * @param getReceivers Function returning active receivers
 * @param signal Abort signal controlling cancellation
 */
async function drainIterator(iterator, getReceivers, signal) {
    const abortPromise = waitForAbort(signal);
    try {
        while (true) {
            const winner = await Promise.race([
                abortPromise.then(() => ({ aborted: true })),
                iterator.next().then(result => ({ result })),
            ]);
            if ("aborted" in winner || signal.aborted)
                break;
            const { result } = winner;
            if (result.done)
                break;
            const receivers = getReceivers();
            for (const { receiver, subscription } of receivers) {
                if (!subscription.unsubscribed) {
                    receiver.next?.(result.value);
                }
            }
        }
    }
    catch (err) {
        if (!signal.aborted) {
            const error = err instanceof Error ? err : new Error(String(err));
            for (const { receiver, subscription } of getReceivers()) {
                if (!subscription.unsubscribed) {
                    receiver.error?.(error);
                }
            }
        }
    }
    finally {
        if (iterator.return) {
            try {
                await iterator.return();
            }
            catch { }
        }
        if (!signal.aborted) {
            for (const { receiver, subscription } of getReceivers()) {
                if (!subscription.unsubscribed) {
                    receiver.complete?.();
                }
            }
        }
    }
}
/**
 * Creates a multicast stream backed by a shared async generator.
 *
 * @template T
 * @param name Stream name (debugging / tooling)
 * @param generatorFn Factory producing an async generator
 * @returns Multicast Stream instance
 */
function createStream(name, generatorFn) {
    const id = generateStreamId();
    getRuntimeHooks()?.onCreateStream?.({ id, name });
    const activeSubscriptions = new Set();
    let isRunning = false;
    let abortController = new AbortController();
    const getActiveReceivers = () => Array.from(activeSubscriptions);
    /**
     * Starts the shared generator loop.
     * Called only when transitioning from zero to one subscriber.
     */
    const startMulticastLoop = () => {
        isRunning = true;
        abortController = new AbortController();
        (async () => {
            const signal = abortController.signal;
            const iterator = generatorFn(signal)[Symbol.asyncIterator]();
            try {
                await drainIterator(iterator, getActiveReceivers, signal);
            }
            finally {
                isRunning = false;
            }
        })();
    };
    /**
     * Registers a receiver and manages generator lifecycle.
     *
     * @param receiver Receiver to attach
     * @returns Subscription controlling the attachment
     */
    const registerReceiver = (receiver) => {
        const wrapped = wrapReceiver(receiver);
        let subscription;
        subscription = createSubscription(async () => {
            const entry = getActiveReceivers().find(s => s.subscription === subscription);
            if (entry) {
                activeSubscriptions.delete(entry);
                entry.receiver.complete?.();
            }
            if (activeSubscriptions.size === 0) {
                abortController.abort();
            }
        });
        activeSubscriptions.add({ receiver: wrapped, subscription });
        if (!isRunning) {
            startMulticastLoop();
        }
        return subscription;
    };
    let self;
    const pipe = ((...ops) => pipeSourceThrough(self, ops));
    self = {
        type: "stream",
        name,
        id,
        pipe,
        subscribe: cb => registerReceiver(createReceiver(cb)),
        query: () => firstValueFrom(self),
        [Symbol.asyncIterator]: () => createAsyncGenerator(registerReceiver),
    };
    return self;
}
/**
 * Pipes a source stream through a chain of operators,
 * producing a derived unicast stream.
 *
 * @template TIn
 * @template Ops
 * @param source Source stream
 * @param operators Operators applied to the source
 * @returns Derived unicast Stream
 */
function pipeSourceThrough(source, operators) {
    const pipedStream = {
        name: `${source.name}Sink`,
        id: generateStreamId(),
        type: "stream",
        pipe: ((...nextOps) => pipeSourceThrough(source, [...operators, ...nextOps])),
        subscribe(cb) {
            return registerReceiver(createReceiver(cb));
        },
        query() {
            return firstValueFrom(pipedStream);
        },
        [Symbol.asyncIterator]: () => createAsyncGenerator(registerReceiver),
    };
    /**
     * Registers a receiver for a derived (unicast) stream.
     *
     * @param receiver Receiver to attach
     * @returns Subscription controlling execution
     */
    function registerReceiver(receiver) {
        const wrapped = wrapReceiver(receiver);
        const subscriptionId = generateSubscriptionId();
        const hooks = getRuntimeHooks();
        let iterator = source[Symbol.asyncIterator]();
        let ops = operators;
        let finalWrap;
        if (hooks?.onPipeStream) {
            const patch = hooks.onPipeStream({
                streamName: source.name,
                streamId: source.id,
                subscriptionId,
                source: iterator,
                operators: ops,
            });
            if (patch?.source)
                iterator = patch.source;
            if (patch?.operators)
                ops = patch.operators;
            if (patch?.final)
                finalWrap = patch.final;
        }
        for (const op of ops) {
            iterator = op.apply(iterator);
        }
        if (finalWrap) {
            iterator = finalWrap(iterator);
        }
        const abortController = new AbortController();
        const signal = abortController.signal;
        const subscription = createSubscription(async () => {
            abortController.abort();
            wrapped.complete?.();
        });
        drainIterator(iterator, () => [{ receiver: wrapped, subscription }], signal).catch(() => { });
        return subscription;
    }
    return pipedStream;
}

/**
 * Creates a stream operator that emits a final, specified value after the source stream has completed.
 *
 * The operator first consumes all values from the upstream source. Once the source stream signals
 * its completion (`done`), this operator then emits the `finalValue` and immediately completes.
 *
 * @template T The type of the values in the stream.
 * @param finalValue The value to be emitted as the last item in the stream.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const endWith = (finalValue) => createOperator("endWith", function (source) {
    let sourceDone = false;
    let finalEmitted = false;
    let completed = false;
    return {
        next: async () => {
            while (true) {
                if (completed) {
                    return DONE;
                }
                if (!sourceDone) {
                    const result = await source.next();
                    if (!result.done) {
                        return result;
                    }
                    sourceDone = true;
                }
                if (!finalEmitted) {
                    finalEmitted = true;
                    return NEXT(finalValue);
                }
                completed = true;
                return DONE;
            }
        }
    };
});

/**
 * Creates a stream operator that invokes a finalizer callback upon stream termination.
 *
 * This operator is useful for performing cleanup tasks, such as closing resources
 * or logging, after a stream has completed or encountered an error. The provided
 * `callback` is guaranteed to be called exactly once, regardless of whether the
 * stream terminates gracefully or with an error.
 *
 * @template T The type of the values emitted by the stream.
 * @param callback The function to be called when the stream completes or errors.
 * It can be synchronous or return a Promise.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const finalize = (callback) => {
    // Shared state across all subscriptions - moved outside createOperator
    let finalized = false;
    let completed = false;
    let finalizationPromise = null;
    const doFinalize = async () => {
        if (!finalized) {
            finalized = true;
            completed = true;
            // Create finalization promise if it doesn't exist
            if (!finalizationPromise) {
                finalizationPromise = (async () => {
                    try {
                        await callback?.();
                    }
                    catch (error) {
                        // Log error but don't throw to prevent unhandled promise rejection
                        console.error('Finalization callback error:', error);
                    }
                })();
            }
            await finalizationPromise;
        }
        else if (finalizationPromise) {
            // Wait for existing finalization to complete
            await finalizationPromise;
        }
    };
    return createOperator("finalize", function (source) {
        return {
            next: async () => {
                while (true) {
                    if (completed) {
                        return DONE;
                    }
                    try {
                        const result = await source.next();
                        if (result.done) {
                            await doFinalize();
                            return DONE;
                        }
                        return result;
                    }
                    catch (err) {
                        await doFinalize();
                        throw err;
                    }
                }
            }
        };
    });
};

/**
 * Creates a stream operator that prepends a specified value to the beginning of the stream.
 *
 * The operator first emits the `initialValue` immediately upon being iterated.
 * After this initial emission, it begins to pull and emit values from the
 * source stream as they become available.
 *
 * @template T The type of the values in the stream.
 * @param initialValue The value to be emitted as the first item in the stream.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const startWith = (initialValue) => createOperator("startWith", function (source) {
    let emittedInitial = false;
    let completed = false;
    return {
        next: async () => {
            while (true) {
                if (completed) {
                    return DONE;
                }
                if (!emittedInitial) {
                    emittedInitial = true;
                    return NEXT(initialValue);
                }
                const result = await source.next();
                if (result.done) {
                    completed = true;
                    return DONE;
                }
                return result;
            }
        }
    };
});

// Assuming these imports are available from your project structure
/** Unique Symbol used to identify an ErrorMarker object within the buffer. */
const ERROR_SYMBOL = Symbol('__ERROR_MARKER');
/** Creates a sealed ErrorMarker object. */
const createErrorMarker = (err) => ({ [ERROR_SYMBOL]: err });
/** Type guard to check if an object is an ErrorMarker. */
const isErrorMarker = (x) => x && typeof x === 'object' && ERROR_SYMBOL in x;
// --- Notifier Implementation ---
/**
 * Simple condition variable implementation based on Promises.
 * Used to signal waiting readers when new data arrives or completion/error occurs.
 */
function createNotifier() {
    let waitingResolvers = [];
    return {
        /** Returns a Promise that resolves when signal() or signalAll() is called. */
        wait: () => new Promise(resolve => waitingResolvers.push(resolve)),
        /** Signals a single waiting reader. */
        signal: () => waitingResolvers.shift()?.(),
        /** Signals all waiting readers. */
        signalAll: () => {
            const resolvers = waitingResolvers;
            waitingResolvers = [];
            resolvers.forEach(r => r());
        }
    };
}
// --- Create Subject Buffer ---
/**
 * Creates a Subject Buffer. It acts as a queuing stream:
 * 1. Values are buffered only if active readers are present.
 * 2. New readers DO NOT receive past values (non-replaying).
 * 3. Multiple writes are delivered to readers in order (queued).
 */
function createSubjectBuffer() {
    const buffer = [];
    const readers = new Map();
    const notifier = createNotifier();
    const lock = createLock();
    let nextReaderId = 0;
    let isCompleted = false;
    let hasError = false;
    let baseIndex = 0;
    /** Removes consumed items from the buffer to reclaim memory. */
    const pruneBuffer = () => {
        if (buffer.length === 0)
            return;
        // If no readers, reset state
        if (readers.size === 0) {
            baseIndex += buffer.length;
            buffer.length = 0;
            return;
        }
        // Find the oldest unread index across all active readers
        let minNext = Infinity;
        for (const reader of readers.values()) {
            if (!reader.isActive)
                continue;
            if (reader.nextIndex < minNext) {
                minNext = reader.nextIndex;
            }
        }
        if (minNext === Infinity)
            return;
        const drop = minNext - baseIndex;
        if (drop > 0) {
            buffer.splice(0, drop);
            baseIndex += drop;
        }
    };
    const write = async (item) => {
        const release = await lock();
        try {
            if (isCompleted)
                throw new Error("Cannot write to completed buffer");
            if (hasError)
                throw new Error("Cannot write after error");
            if (readers.size === 0)
                return;
            buffer.push(item);
            notifier.signalAll();
        }
        finally {
            release();
        }
    };
    const writeError = async (err) => {
        const release = await lock();
        try {
            if (isCompleted)
                throw new Error("Cannot write error to completed buffer");
            hasError = true;
            if (readers.size > 0) {
                buffer.push(createErrorMarker(err));
            }
            notifier.signalAll();
        }
        finally {
            release();
        }
    };
    const attachReader = async () => {
        const release = await lock();
        try {
            const readerId = nextReaderId++;
            // Reader starts reading from the current end (no replay)
            readers.set(readerId, {
                nextIndex: baseIndex + buffer.length,
                isActive: true
            });
            return readerId;
        }
        finally {
            release();
        }
    };
    const detachReader = async (readerId) => {
        const release = await lock();
        try {
            const reader = readers.get(readerId);
            if (reader) {
                reader.isActive = false;
                readers.delete(readerId);
                pruneBuffer();
            }
        }
        finally {
            release();
        }
    };
    const read = async (readerId) => {
        while (true) {
            let release;
            let result;
            let shouldWait = false;
            release = await lock();
            try {
                const reader = readers.get(readerId);
                if (!reader || !reader.isActive) {
                    result = { done: true, value: undefined };
                    return result;
                }
                const availableEnd = baseIndex + buffer.length;
                if (reader.nextIndex < availableEnd) {
                    const relativeIndex = reader.nextIndex - baseIndex;
                    const item = buffer[relativeIndex];
                    reader.nextIndex++;
                    pruneBuffer();
                    if (isErrorMarker(item)) {
                        throw item[ERROR_SYMBOL];
                    }
                    result = { value: item, done: false };
                }
                else if (isCompleted) {
                    result = { done: true, value: undefined };
                }
                else {
                    shouldWait = true;
                }
            }
            finally {
                release();
            }
            if (result)
                return result;
            // Optimization: release lock before awaiting signal
            if (shouldWait)
                await notifier.wait();
        }
    };
    const peek = async (readerId) => {
        const release = await lock();
        try {
            const reader = readers.get(readerId);
            if (!reader || !reader.isActive) {
                return { done: true, value: undefined };
            }
            const availableEnd = baseIndex + buffer.length;
            if (reader.nextIndex < availableEnd) {
                const relativeIndex = reader.nextIndex - baseIndex;
                const item = buffer[relativeIndex];
                if (isErrorMarker(item)) {
                    throw item[ERROR_SYMBOL];
                }
                return { value: item, done: false };
            }
            if (isCompleted && reader.nextIndex >= availableEnd) {
                return { done: true, value: undefined };
            }
            return { value: undefined, done: false };
        }
        finally {
            release();
        }
    };
    const complete = async () => {
        const release = await lock();
        try {
            isCompleted = true;
            notifier.signalAll();
        }
        finally {
            release();
        }
    };
    const completed = (readerId) => {
        const reader = readers.get(readerId);
        if (!reader || !reader.isActive)
            return true;
        const allItemsRead = reader.nextIndex >= baseIndex + buffer.length;
        return allItemsRead && (isCompleted || hasError);
    };
    return {
        write,
        error: writeError,
        read,
        peek,
        complete,
        attachReader,
        detachReader,
        completed
    };
}
// --- Create BehaviorSubject Buffer ---
/**
 * Creates a BehaviorSubject Buffer. It extends the Subject Buffer by:
 * 1. Storing the single latest value (or error).
 * 2. Delivering the latest value to new readers upon attachment (replaying 1 item).
 * 3. Exposing the current value via the `.value` getter.
 */
function createBehaviorSubjectBuffer(initialValue) {
    // Uses the fixed Subject buffer for handling subsequent writes
    const subject = createSubjectBuffer();
    const hasInitial = arguments.length > 0;
    const state = {
        currentValue: undefined,
        hasCurrentValue: false,
        isCompleted: false,
        hasError: false,
        initPromise: null
    };
    const behaviorReaders = new Map();
    const lock = createLock();
    // Handle async initialization
    if (hasInitial && isPromiseLike(initialValue)) {
        state.initPromise = initialValue.then((resolved) => {
            state.currentValue = resolved;
            state.hasCurrentValue = true;
        }, (error) => {
            state.hasError = true;
            state.isCompleted = true;
            state.currentValue = createErrorMarker(error);
            state.hasCurrentValue = true;
        }).finally(() => {
            state.initPromise = null;
        });
    }
    else if (hasInitial) {
        state.currentValue = initialValue;
        state.hasCurrentValue = true;
    }
    const ensureInit = async () => {
        if (state.initPromise)
            await state.initPromise;
    };
    return {
        async write(value) {
            await ensureInit();
            const release = await lock();
            try {
                if (state.isCompleted)
                    throw new Error("Cannot write to completed buffer");
                if (state.hasError)
                    throw new Error("Cannot write after error");
                state.currentValue = value;
                state.hasCurrentValue = true;
                // Update pending initial values to latest
                behaviorReaders.forEach(readerState => {
                    if (readerState.initialPending) {
                        readerState.initialValue = value;
                    }
                });
                if (behaviorReaders.size > 0) {
                    await subject.write(value);
                }
            }
            finally {
                release();
            }
        },
        async error(err) {
            await ensureInit();
            const release = await lock();
            try {
                if (state.isCompleted)
                    throw new Error("Cannot error a completed buffer");
                state.hasError = true;
                state.isCompleted = true;
                const errorItem = createErrorMarker(err);
                state.currentValue = errorItem;
                state.hasCurrentValue = true;
                behaviorReaders.forEach(readerState => {
                    if (readerState.initialPending) {
                        readerState.initialValue = errorItem;
                    }
                });
                await subject.error(err);
            }
            finally {
                release();
            }
        },
        async attachReader() {
            await ensureInit();
            const release = await lock();
            try {
                const readerId = await subject.attachReader();
                const snapshot = state.hasCurrentValue ? state.currentValue : undefined;
                // Reader needs the initial value if we have one AND the stream hasn't already errored/completed
                const initialPending = state.hasCurrentValue && (!state.isCompleted || state.hasError);
                behaviorReaders.set(readerId, {
                    initialPending,
                    initialValue: snapshot
                });
                return readerId;
            }
            finally {
                release();
            }
        },
        async detachReader(readerId) {
            await ensureInit();
            const release = await lock();
            try {
                behaviorReaders.delete(readerId);
                await subject.detachReader(readerId);
            }
            finally {
                release();
            }
        },
        async read(readerId) {
            await ensureInit();
            const release = await lock();
            try {
                const readerState = behaviorReaders.get(readerId);
                if (readerState?.initialPending) {
                    readerState.initialPending = false;
                    if (readerState.initialValue !== undefined) {
                        if (isErrorMarker(readerState.initialValue)) {
                            throw readerState.initialValue[ERROR_SYMBOL];
                        }
                        return { value: readerState.initialValue, done: false };
                    }
                }
            }
            finally {
                release();
            }
            // If no initial value needed, delegate to the underlying subject queue
            return await subject.read(readerId);
        },
        async peek(readerId) {
            await ensureInit();
            const release = await lock();
            try {
                const readerState = behaviorReaders.get(readerId);
                if (readerState?.initialPending && readerState.initialValue !== undefined) {
                    if (isErrorMarker(readerState.initialValue)) {
                        throw readerState.initialValue[ERROR_SYMBOL];
                    }
                    return { value: readerState.initialValue, done: false };
                }
            }
            finally {
                release();
            }
            return await subject.peek(readerId);
        },
        async complete() {
            await ensureInit();
            const release = await lock();
            try {
                state.isCompleted = true;
                await subject.complete();
            }
            finally {
                release();
            }
        },
        completed(readerId) {
            const readerState = behaviorReaders.get(readerId);
            // A reader is NOT completed if it's still waiting to emit its initial value
            const awaitingInitial = readerState?.initialPending && readerState.initialValue !== undefined;
            if (awaitingInitial)
                return false;
            return subject.completed(readerId);
        },
        get value() {
            if (!state.hasCurrentValue)
                return undefined;
            if (isErrorMarker(state.currentValue))
                return undefined;
            return state.currentValue;
        }
    };
}
// --- Create Replay Buffer ---
/**
 * Creates a Replay Buffer with a fixed capacity. It acts as a history stream:
 * 1. Buffers the last 'capacity' number of items (circular buffer).
 * 2. New readers start from the oldest available item within the capacity window (replaying).
 * 3. Supports backpressure via a Semaphore when the buffer is full.
 */
function createReplayBuffer(capacity) {
    // State variables
    let resolvedCapacity = null;
    let buffer = [];
    let isInfinite = false;
    let writeIndex = 0; // The index in the circular buffer for the next write
    let totalWritten = 0; // Absolute count of all items ever written
    const readers = new Map();
    // Counts how many readers still need to read an item at absolute index 'abs'
    const slotCounters = new Map();
    const notifier = createNotifier();
    const lock = createLock();
    let nextReaderId = 0;
    let isCompleted = false;
    let hasError = false;
    let semaphore; // Used for backpressure
    let isInitialized = false;
    let initPromise = null;
    /** Ensures capacity and semaphore are set up, waiting if capacity is a promise. */
    const ensureCapacity = async () => {
        if (isInitialized)
            return;
        if (initPromise) {
            await initPromise;
            return;
        }
        // Logic for synchronous and asynchronous capacity resolution...
        const initializer = async (capVal) => {
            resolvedCapacity = capVal;
            isInfinite = !isFinite(resolvedCapacity);
            buffer = isInfinite ? [] : new Array(resolvedCapacity);
            if (!isInfinite) {
                semaphore = createSemaphore(resolvedCapacity);
            }
            isInitialized = true;
        };
        if (isPromiseLike(capacity)) {
            initPromise = (async () => {
                await initializer(await capacity);
                initPromise = null;
            })();
            await initPromise;
        }
        else {
            await initializer(capacity);
        }
    };
    /** Converts an absolute index to the index within the circular buffer array. */
    const getIndex = (abs) => {
        if (isInfinite)
            return abs;
        if (resolvedCapacity === null || resolvedCapacity === 0)
            return 0;
        return abs % resolvedCapacity;
    };
    /** Decrements slot counter for a consumed item and releases semaphore if needed. */
    const releaseSlot = (abs) => {
        const cnt = slotCounters.get(abs);
        if (!cnt)
            return;
        if (cnt <= 1) {
            slotCounters.delete(abs);
            if (semaphore) {
                semaphore.release();
            }
        }
        else {
            slotCounters.set(abs, cnt - 1);
        }
    };
    /** Internal function to perform the actual buffer write under the lock. */
    const writeInternal = (item) => {
        const abs = totalWritten;
        const idx = getIndex(abs);
        if (isInfinite) {
            buffer.push(item);
        }
        else {
            if (idx >= buffer.length) {
                buffer.length = idx + 1;
            }
            buffer[idx] = item;
            writeIndex = (writeIndex + 1) % (resolvedCapacity);
        }
        totalWritten++;
        if (readers.size > 0) {
            slotCounters.set(abs, readers.size);
        }
        notifier.signalAll();
    };
    const write = async (value) => {
        await ensureCapacity();
        let needsBackpressureWait = false;
        let release = null;
        release = await lock();
        try {
            if (isCompleted)
                throw new Error("Cannot write to completed buffer");
            if (hasError)
                throw new Error("Cannot write after error");
            // Check for backpressure condition (bounded buffer, full, and active readers)
            if (!isInfinite &&
                resolvedCapacity !== null &&
                totalWritten >= resolvedCapacity &&
                readers.size > 0) {
                needsBackpressureWait = true;
            }
            else {
                writeInternal(value);
            }
        }
        finally {
            release?.();
        }
        if (needsBackpressureWait) {
            // 1. Wait on semaphore (this is where backpressure occurs)
            const semRelease = await semaphore.acquire();
            // 2. Reacquire lock to safely check state and write
            const reacquire = await lock();
            try {
                if (isCompleted) {
                    semRelease(); // Immediately release permit since we won't write
                    throw new Error("Cannot write to completed buffer");
                }
                writeInternal(value);
            }
            finally {
                reacquire();
                // 3. Release semaphore permit after writing (handled by releaseSlot on read)
                semRelease();
            }
        }
    };
    const error = async (err) => {
        await ensureCapacity();
        const release = await lock();
        try {
            if (isCompleted)
                throw new Error("Cannot write error to completed buffer");
            hasError = true;
            writeInternal(createErrorMarker(err));
        }
        finally {
            release();
        }
    };
    const attachReader = async () => {
        await ensureCapacity();
        const release = await lock();
        try {
            const id = nextReaderId++;
            const cap = resolvedCapacity ?? Infinity;
            // Reader starts at the oldest item in the replay window
            const start = Math.max(0, totalWritten - (isInfinite ? totalWritten : cap));
            readers.set(id, { offset: start });
            return id;
        }
        finally {
            release();
        }
    };
    const detachReader = async (id) => {
        const release = await lock();
        try {
            const readerState = readers.get(id);
            if (!readerState)
                return;
            const { offset } = readerState;
            readers.delete(id);
            // Release all unconsumed slots for the detached reader
            for (let i = offset; i < totalWritten; i++) {
                releaseSlot(i);
            }
            notifier.signalAll();
        }
        finally {
            release();
        }
    };
    const read = async (id) => {
        await ensureCapacity();
        while (true) {
            let release;
            let result;
            let shouldWait = false;
            let slotToRelease;
            release = await lock();
            try {
                const readerState = readers.get(id);
                if (!readerState) {
                    result = { value: undefined, done: true };
                    return result;
                }
                const offset = readerState.offset;
                if (offset < totalWritten) {
                    const item = buffer[getIndex(offset)];
                    readerState.offset++;
                    slotToRelease = offset; // Mark slot consumed
                    if (isErrorMarker(item)) {
                        throw item[ERROR_SYMBOL];
                    }
                    result = { value: item, done: false };
                }
                else if (isCompleted) {
                    result = { value: undefined, done: true };
                }
                else {
                    shouldWait = true;
                }
            }
            finally {
                release();
            }
            // Release slot count/semaphore outside of the main buffer lock
            if (slotToRelease !== undefined) {
                releaseSlot(slotToRelease);
            }
            if (result)
                return result;
            // Optimization: release lock before awaiting signal
            if (shouldWait)
                await notifier.wait();
        }
    };
    const peek = async (id) => {
        await ensureCapacity();
        const release = await lock();
        try {
            const readerState = readers.get(id);
            if (!readerState) {
                return { value: undefined, done: true };
            }
            if (totalWritten === 0 || readerState.offset >= totalWritten) {
                return { value: undefined, done: true };
            }
            const item = buffer[getIndex(readerState.offset)];
            if (isErrorMarker(item)) {
                throw item[ERROR_SYMBOL];
            }
            return { value: item, done: false };
        }
        finally {
            release();
        }
    };
    const complete = async () => {
        await ensureCapacity();
        const release = await lock();
        try {
            isCompleted = true;
            notifier.signalAll();
            // Release all semaphore permits to unblock any waiting writers
            if (semaphore && resolvedCapacity) {
                for (let i = 0; i < resolvedCapacity; i++) {
                    semaphore.release();
                }
            }
        }
        finally {
            release();
        }
    };
    const completed = (id) => {
        const readerState = readers.get(id);
        return !readerState || (isCompleted && readerState.offset >= totalWritten);
    };
    const getBuffer = () => {
        const result = [];
        const cap = resolvedCapacity ?? Infinity;
        // Calculate the absolute index of the start of the replay window
        const start = Math.max(0, totalWritten - (isInfinite ? totalWritten : cap));
        for (let i = start; i < totalWritten; i++) {
            const item = buffer[getIndex(i)];
            if (!isErrorMarker(item)) {
                result.push(item);
            }
        }
        return result;
    };
    return {
        write,
        error,
        read,
        peek,
        attachReader,
        detachReader,
        complete,
        completed,
        get buffer() { return getBuffer(); }
    };
}

/**
 * Creates a simple asynchronous lock mechanism. Only one caller can hold the lock at a time.
 * Subsequent calls will queue up and wait for the lock to be released. This is useful
 * for synchronizing access to shared resources in an asynchronous environment.
 *
 * The function returns a promise that resolves with a `ReleaseFn`. The caller must
 * invoke this function to release the lock, allowing the next queued caller to proceed.
 *
 * @returns {SimpleLock} A function that, when called, returns a promise to acquire the lock.
 */
const createLock = () => {
    let locked = false;
    const queue = [];
    return () => new Promise((resolve) => {
        const acquire = () => {
            if (!locked) {
                locked = true;
                resolve(() => {
                    locked = false;
                    if (queue.length > 0) {
                        const next = queue.shift();
                        next(acquire);
                    }
                });
            }
            else {
                queue.push(acquire);
            }
        };
        acquire();
    });
};

/**
 * Creates an asynchronous queue that processes operations sequentially.
 * Operations are guaranteed to run in the order they are enqueued, one after another.
 * This is useful for preventing race conditions and ensuring that dependent
 * asynchronous tasks are executed in a specific order.
 *
 * @returns {{ enqueue: (operation: () => Promise<any>) => Promise<any>, pending: number, isEmpty: boolean }} An object representing the queue.
 * @property {(operation: () => Promise<any>) => Promise<any>} enqueue Enqueues an asynchronous operation to be executed sequentially.
 * @property {number} pending The number of operations currently in the queue (including the one running).
 * @property {boolean} isEmpty A boolean indicating whether the queue is empty.
 */
function createQueue() {
    let last = Promise.resolve();
    let pendingCount = 0;
    const enqueue = (operation) => {
        pendingCount++;
        let result;
        try {
            // Create the chained promise that will execute the operation
            result = last.then(() => operation());
        }
        catch (err) {
            result = Promise.reject(err);
        }
        // Ensure pendingCount decrements even if the operation throws synchronously
        result = result.finally(() => {
            pendingCount--;
        });
        // Chain the next operation (with error handling to prevent queue lock)
        // This maintains the sequential order regardless of operation success/failure
        last = result.catch(() => { });
        return result;
    };
    return {
        enqueue,
        // Utility methods for debugging/monitoring
        get pending() { return pendingCount; },
        get isEmpty() { return pendingCount === 0; }
    };
}

/**
 * Creates a semaphore for controlling access to a limited number of resources.
 *
 * A semaphore is a synchronization primitive that allows you to manage
 * concurrent access to resources by maintaining a count of available "permits."
 *
 * @param {number} initialCount The initial number of permits available. Must be a non-negative integer.
 * @returns {Semaphore} A semaphore object with `acquire`, `tryAcquire`, and `release` methods.
 */
const createSemaphore = (initialCount) => {
    let count = initialCount;
    const queue = [];
    const release = () => {
        if (queue.length > 0) {
            // Don't call the resolver immediately - schedule it as a microtask
            // to maintain the expected order of execution
            const nextResolver = queue.shift();
            Promise.resolve().then(() => {
                nextResolver();
            });
        }
        else {
            count++;
        }
    };
    const acquire = () => new Promise((resolve) => {
        const resolverFn = () => resolve(() => release());
        if (count > 0) {
            count--;
            resolverFn();
        }
        else {
            queue.push(resolverFn);
        }
    });
    const tryAcquire = () => {
        if (count > 0) {
            count--;
            return () => release();
        }
        return null;
    };
    return { acquire, tryAcquire, release };
};

/**
 * Creates a BehaviorSubject that holds a current value and emits it immediately to new subscribers.
 * It maintains the latest value internally and allows synchronous access via the `snappy` getter.
 *
 * The subject queues emitted values and delivers them to subscribers asynchronously,
 * supporting safe concurrent access and orderly processing.
 *
 * @template T The type of the values the subject will hold.
 * @param {T} initialValue The value that the subject will hold upon creation.
 * @returns {BehaviorSubject<T>} A new BehaviorSubject instance.
 */
function createBehaviorSubject(initialValue) {
    const buffer = createBehaviorSubjectBuffer(initialValue);
    let latestValue = initialValue;
    let isCompleted = false;
    let hasError = false;
    const next = (value) => {
        latestValue = value;
        scheduler.enqueue(async () => {
            if (isCompleted || hasError)
                return;
            await buffer.write(value);
        });
    };
    const complete = () => {
        scheduler.enqueue(async () => {
            if (isCompleted)
                return;
            isCompleted = true;
            await buffer.complete();
        });
    };
    const error = (err) => {
        scheduler.enqueue(async () => {
            if (isCompleted || hasError)
                return;
            hasError = true;
            isCompleted = true;
            await buffer.error(err);
            await buffer.complete();
        });
    };
    const registerReceiver = (receiver) => {
        let unsubscribing = false;
        let readerId = null;
        const subscription = createSubscription(() => {
            if (!unsubscribing) {
                unsubscribing = true;
                scheduler.enqueue(async () => {
                    if (readerId !== null) {
                        await buffer.detachReader(readerId);
                    }
                });
            }
        });
        scheduler.enqueue(() => buffer.attachReader()).then(async (id) => {
            readerId = id;
            try {
                while (true) {
                    const result = await buffer.read(readerId);
                    if (result.done)
                        break;
                    await receiver.next?.(result.value);
                }
            }
            catch (err) {
                await receiver.error?.(err);
            }
            finally {
                if (!unsubscribing && readerId !== null) {
                    await buffer.detachReader(readerId);
                }
                await receiver.complete?.();
            }
        });
        Object.assign(subscription, {
            value: () => latestValue
        });
        return subscription;
    };
    const subscribe = (callbackOrReceiver) => {
        const receiver = createReceiver(callbackOrReceiver);
        return registerReceiver(receiver);
    };
    const subject = {
        type: "subject",
        name: "behaviorSubject",
        id: generateStreamId(),
        get snappy() {
            return latestValue;
        },
        pipe(...operators) {
            return pipeSourceThrough(this, operators);
        },
        subscribe,
        async query() {
            return await firstValueFrom(this);
        },
        next,
        complete,
        completed: () => isCompleted,
        error,
        [Symbol.asyncIterator]: () => createAsyncGenerator(registerReceiver),
    };
    return subject;
}

/**
 * Creates a new ReplaySubject.
 *
 * A ReplaySubject is a variant of a Subject that stores a specified number of
 * the latest values it has emitted and "replays" them to any new subscribers.
 * This allows late subscribers to receive past values they may have missed.
 *
 * This subject provides asynchronous delivery and scheduling via a global scheduler.
 *
 * @template T The type of the values the subject will emit.
 * @param {number} [capacity=Infinity] The maximum number of past values to buffer and replay to new subscribers.
 * @returns {ReplaySubject<T>} A new ReplaySubject instance.
 */
function createReplaySubject(capacity = Infinity) {
    const buffer = createReplayBuffer(capacity);
    let isCompleted = false;
    let hasError = false;
    let latestValue = undefined;
    const next = (value) => {
        latestValue = value;
        scheduler.enqueue(async () => {
            if (isCompleted || hasError)
                return;
            await buffer.write(value);
        });
    };
    const complete = () => {
        scheduler.enqueue(async () => {
            if (isCompleted)
                return;
            isCompleted = true;
            await buffer.complete();
        });
    };
    const error = (err) => {
        scheduler.enqueue(async () => {
            if (isCompleted || hasError)
                return;
            hasError = true;
            isCompleted = true;
            await buffer.error(err);
            await buffer.complete();
        });
    };
    const registerReceiver = (receiver) => {
        let unsubscribing = false;
        let readerId = null;
        let readerLatestValue;
        const subscription = createSubscription(() => {
            if (!unsubscribing) {
                unsubscribing = true;
                scheduler.enqueue(async () => {
                    if (readerId !== null) {
                        await buffer.detachReader(readerId);
                    }
                });
            }
        });
        scheduler.enqueue(() => buffer.attachReader()).then(async (id) => {
            readerId = id;
            try {
                while (true) {
                    const result = await buffer.read(readerId);
                    if (result.done)
                        break;
                    readerLatestValue = result.value;
                    await receiver.next?.(readerLatestValue);
                }
            }
            catch (err) {
                await receiver.error?.(err);
            }
            finally {
                if (!unsubscribing && readerId !== null) {
                    await buffer.detachReader(readerId);
                }
                await receiver.complete?.();
            }
        });
        Object.assign(subscription, {
            value: () => readerLatestValue
        });
        return subscription;
    };
    const subscribe = (callbackOrReceiver) => {
        const receiver = createReceiver(callbackOrReceiver);
        return registerReceiver(receiver);
    };
    const replaySubject = {
        type: "subject",
        name: "replaySubject",
        id: generateStreamId(),
        pipe(...operators) {
            return pipeSourceThrough(this, operators);
        },
        subscribe,
        async query() {
            return await firstValueFrom(this);
        },
        get snappy() {
            return latestValue;
        },
        next,
        complete,
        completed: () => isCompleted,
        error,
        [Symbol.asyncIterator]: () => createAsyncGenerator(registerReceiver),
    };
    return replaySubject;
}

/**
 * Creates a new Subject instance.
 *
 * A Subject can be used to manually control a stream, emitting values
 * to all active subscribers. It is a fundamental building block for
 * reactive patterns like event bus systems or shared state management.
 *
 * @template T The type of the values that the subject will emit.
 * @returns {Subject<T>} A new Subject instance.
 */
function createSubject(scheduler$1 = scheduler) {
    const buffer = createSubjectBuffer();
    let latestValue = undefined;
    let isCompleted = false;
    let hasError = false;
    const next = (value) => {
        latestValue = value;
        scheduler$1.enqueue(async () => {
            if (isCompleted || hasError)
                return;
            await buffer.write(value);
        });
    };
    const complete = () => {
        scheduler$1.enqueue(async () => {
            if (isCompleted)
                return;
            isCompleted = true;
            await buffer.complete();
        });
    };
    const error = (err) => {
        scheduler$1.enqueue(async () => {
            if (isCompleted || hasError)
                return;
            hasError = true;
            isCompleted = true;
            await buffer.error(err);
            await buffer.complete();
        });
    };
    const registerReceiver = (receiver) => {
        let unsubscribing = false;
        let readerId = null;
        const subscription = createSubscription(() => {
            if (!unsubscribing) {
                unsubscribing = true;
                scheduler$1.enqueue(async () => {
                    if (readerId !== null)
                        await buffer.detachReader(readerId);
                });
            }
        });
        scheduler$1.enqueue(() => buffer.attachReader()).then(async (id) => {
            readerId = id;
            try {
                while (true) {
                    const result = await buffer.read(readerId);
                    if (result.done)
                        break;
                    await receiver.next?.(result.value);
                }
            }
            catch (err) {
                await receiver.error?.(err);
            }
            finally {
                if (!unsubscribing && readerId !== null) {
                    await buffer.detachReader(readerId);
                }
                await receiver.complete?.();
            }
        });
        Object.assign(subscription, {
            value: () => latestValue
        });
        return subscription;
    };
    const subscribe = (callbackOrReceiver) => {
        const receiver = createReceiver(callbackOrReceiver);
        return registerReceiver(receiver);
    };
    const subject = {
        type: "subject",
        name: "subject",
        id: generateStreamId(),
        get snappy() {
            return latestValue;
        },
        pipe(...steps) {
            return pipeSourceThrough(this, steps);
        },
        subscribe,
        async query() {
            return await firstValueFrom(this);
        },
        next,
        complete,
        completed: () => isCompleted,
        error,
        [Symbol.asyncIterator]: () => createAsyncGenerator(registerReceiver),
    };
    return subject;
}

/**
 * Combines multiple streams and emits a tuple containing the latest values
 * from each stream whenever any of the source streams emits a new value.
 *
 * This operator is useful for scenarios where you need to react to changes
 * in multiple independent data sources simultaneously. The output stream
 * will not emit a value until all source streams have emitted at least one
 * value. The output stream completes when all source streams have completed.
 *
 * @template {unknown[]} T A tuple type representing the combined values from the streams.
 * @param streams Streams/values to combine.
 * @returns {Stream<T>} A new stream that emits a tuple of the latest values from all source streams.
 */
function combineLatest(...sources) {
    async function* generator() {
        const resolvedInputs = [];
        for (const src of sources) {
            resolvedInputs.push(isPromiseLike(src) ? await src : src);
        }
        const resolvedStreamsInput = (resolvedInputs.length === 1 && Array.isArray(resolvedInputs[0])
            ? resolvedInputs[0]
            : resolvedInputs);
        if (resolvedStreamsInput.length === 0)
            return;
        const resolvedStreams = [];
        for (const s of resolvedStreamsInput) {
            resolvedStreams.push(isPromiseLike(s) ? await s : s);
        }
        const latestValues = [];
        const hasEmitted = new Array(resolvedStreams.length).fill(false);
        let completedStreams = 0;
        const iterators = resolvedStreams.map((stream) => eachValueFrom(fromAny(stream)));
        const promisesByIndex = new Array(resolvedStreams.length).fill(null);
        const createPromise = (index) => {
            const promise = iterators[index]
                .next()
                .then((result) => ({
                index,
                value: result.value,
                done: result.done,
            }));
            promisesByIndex[index] = promise;
            return promise;
        };
        // Initialize
        for (let i = 0; i < resolvedStreams.length; i++) {
            createPromise(i);
        }
        try {
            while (completedStreams < resolvedStreams.length) {
                const result = await Promise.race(promisesByIndex.filter((p) => p !== null));
                if (result.done) {
                    completedStreams++;
                    promisesByIndex[result.index] = null;
                    continue;
                }
                latestValues[result.index] = result.value;
                hasEmitted[result.index] = true;
                if (hasEmitted.every(Boolean)) {
                    yield [...latestValues];
                }
                createPromise(result.index);
            }
        }
        finally {
            for (const iterator of iterators) {
                if (iterator.return) {
                    try {
                        await iterator.return(undefined);
                    }
                    catch {
                        // Ignore cleanup errors
                    }
                }
            }
        }
    }
    return createStream("combineLatest", generator);
}

/**
 * Creates a stream that runs a computation task on a worker from a Coroutine pool,
 * yielding the result once the computation completes.
 *
 * This operator is designed for offloading CPU-intensive tasks to a background
 * thread, preventing the main thread from being blocked and keeping the UI
 * responsive. It uses a `Coroutine` to manage a pool of web workers.
 * The stream will emit a single value and then complete.
 *
 * @template T The type of the result from the computation.
 * @param {Coroutine | PromiseLike<Coroutine>} task The coroutine instance managing the worker pool.
 * @param {any | PromiseLike<any>} params The data to send to the worker for computation.
 * @returns {Stream<T>} A new stream that emits the result of the computation.
 */
function compute(task, params) {
    return createStream("compute", async function* () {
        const resolvedTask = isPromiseLike(task) ? await task : task;
        const resolvedParams = isPromiseLike(params) ? await params : params;
        // Use processTask to handle worker acquisition, messaging, and releasing automatically
        const result = await resolvedTask.processTask(resolvedParams);
        yield result;
    });
}

/**
 * Creates a stream that subscribes to multiple streams in sequence.
 *
 * This operator will subscribe to the first stream and yield all of its
 * values. Once the first stream completes, it will then subscribe to the
 * second stream, and so on, until all streams have completed. The resulting
 * stream will complete only after the last source stream has completed.
 *
 * If any of the source streams errors, the concatenated stream will also error and
 * stop processing the remaining streams.
 *
 * @template T The type of the values in the streams.
 * @param sources Streams/values (or a promise of an array) to concatenate.
 * @returns {Stream<T>} A new stream that emits values from all input streams in sequence.
 */
function concat(...sources) {
    async function* generator() {
        const resolvedInputs = [];
        for (const src of sources) {
            resolvedInputs.push(isPromiseLike(src) ? await src : src);
        }
        const resolvedSources = (resolvedInputs.length === 1 && Array.isArray(resolvedInputs[0])
            ? resolvedInputs[0]
            : resolvedInputs);
        for (const source of resolvedSources) {
            const resolvedSource = isPromiseLike(source) ? await source : source;
            const iterator = eachValueFrom(fromAny(resolvedSource));
            try {
                for await (const value of iterator) {
                    yield value;
                }
            }
            catch (error) {
                throw error;
            }
            finally {
                // Attempt to close iterator early on abort or completion
                if (iterator.return) {
                    try {
                        await iterator.return(undefined);
                    }
                    catch {
                        // ignore
                    }
                }
            }
        }
    }
    return createStream("concat", generator);
}

/**
 * Creates a stream that defers the creation of an inner stream until it is
 * subscribed to.
 *
 * This operator ensures that the `factory` function is called only when
 * a consumer subscribes to the stream, making it a good choice for
 * creating "cold" streams. Each new subscription will trigger a new
 * call to the `factory` and create a fresh stream instance.
 *
 * @template T The type of the values in the inner stream.
 * @param {() => (Stream<T> | MaybePromise<T> | Array<T>)} factory A function that returns the stream to be subscribed to.
 * @returns {Stream<T>} A new stream that defers subscription to the inner stream.
 */
function defer(factory) {
    async function* generator() {
        const produced = factory();
        const innerStream = isPromiseLike(produced) ? await produced : produced;
        try {
            const iterator = eachValueFrom(fromAny(innerStream));
            try {
                for await (const value of iterator) {
                    yield value;
                }
            }
            finally {
                if (iterator.return) {
                    try {
                        await iterator.return(undefined);
                    }
                    catch {
                        // ignore
                    }
                }
            }
        }
        catch (error) {
            throw error;
        }
    }
    return createStream('defer', generator);
}

/**
 * Creates an empty stream that emits no values and completes immediately.
 *
 * This function creates a stream that serves as a useful utility for
 * scenarios where a stream is expected but no values need to be produced.
 * It completes immediately upon subscription, allowing a sequence of
 * other streams to proceed without delay.
 *
 * @template T The type of the stream's values (will never be emitted).
 * @returns {Stream<T>} An empty stream.
 */
/**
 * A singleton instance of an empty stream.
 *
 * This constant provides a reusable, empty stream that immediately completes
 * upon subscription without emitting any values. It is useful in stream
 * compositions as a placeholder or to represent a sequence with no elements.
 *
 * @type {Stream<any>}
 */
const empty = () => {
    const stream = createStream('EMPTY', async function* () {
        // No emissions, just complete immediately
    });
    // Empty stream does not subscribe to any source
    const subscribe = (callbackOrReceiver) => {
        const receiver = createReceiver(callbackOrReceiver);
        // No data is emitted, immediately complete the receiver
        queueMicrotask(async () => receiver.complete && await receiver.complete());
        return {
            unsubscribed: false,
            unsubscribe: () => { },
        };
    };
    return Object.assign(stream, { subscribe, completed: () => true });
};
/**
 * A singleton instance of an empty stream.
 *
 * This constant provides a reusable, empty stream that immediately completes
 * upon subscription without emitting any values. It is useful in stream
 * compositions as a placeholder or to represent a sequence with no elements.
 */
const EMPTY = empty();

/**
 * Waits for all streams to complete and emits an array of their last values.
 *
 * @template T The type of the last values emitted by each stream.
 * @param streams Streams to join; arrays/iterables are also accepted for backward compatibility.
 * @returns Stream<T[]>
 */
function forkJoin(...sources) {
    async function* generator() {
        const resolvedInputs = [];
        for (const src of sources) {
            resolvedInputs.push(isPromiseLike(src) ? await src : src);
        }
        let streamsArray = [];
        if (resolvedInputs.length === 1) {
            const [first] = resolvedInputs;
            if (first && typeof first === "object" && Symbol.iterator in first) {
                streamsArray = Array.from(first);
            }
            else {
                streamsArray = [first];
            }
        }
        else {
            streamsArray = resolvedInputs;
        }
        const results = new Array(streamsArray.length);
        const promises = streamsArray.map(async (stream, index) => {
            const resolved = isPromiseLike(stream) ? await stream : stream;
            let last;
            let hasValue = false;
            for await (const value of resolved) {
                last = value;
                hasValue = true;
            }
            if (!hasValue) {
                throw new Error("forkJoin: one of the streams completed without emitting any value");
            }
            results[index] = last;
        });
        await Promise.all(promises);
        yield results;
    }
    return createStream("forkJoin", generator);
}

/**
 * Creates a stream from an asynchronous or synchronous iterable.
 *
 * This operator is a powerful way to convert any source that can be iterated
 * over (such as arrays, strings, `Map`, `Set`, `AsyncGenerator`, etc.) into
 * a reactive stream. The stream will emit each value from the source in order
 * before completing.
 *
 * @template T The type of the values in the iterable.
 * @param {AsyncIterable<T> | Iterable<T> | PromiseLike<AsyncIterable<T> | Iterable<T>>} source The iterable source to convert into a stream.
 * @returns {Stream<T>} A new stream that emits each value from the source.
 */
function from(source) {
    async function* generator() {
        const resolvedSource = isPromiseLike(source) ? await source : source;
        for await (const value of resolvedSource) {
            yield value;
        }
    }
    return createStream("from", generator);
}

/**
 * Creates a stream that emits events of the specified type from the given EventTarget.
 *
 * This function provides a reactive way to handle DOM events or other events,
 * such as mouse clicks, keyboard presses, or custom events. The stream
 * will emit a new event object each time the event is dispatched.
 *
 * @template {Event} T The type of the event to listen for. Defaults to a generic `Event`.
 * @param {EventTarget | PromiseLike<EventTarget>} target The event target to listen to (e.g., a DOM element, `window`, or `document`).
 * @param {string | PromiseLike<string>} event The name of the event to listen for (e.g., 'click', 'keydown').
 * @returns {Stream<T>} A stream that emits the event objects as they occur.
 */
function fromEvent(target, event) {
    const subject = createSubject(); // Create a subject to emit event values.
    const originalSubscribe = subject.subscribe; // Capture original subscribe method.
    subject.subscribe = (callback) => {
        const subscription = originalSubscribe.call(subject, callback);
        let resolvedTarget;
        let resolvedEvent;
        const listener = (ev) => {
            if (!subject.completed()) {
                subject.next(ev); // Emit the event directly into the subject's stream
            }
        };
        (async () => {
            resolvedTarget = isPromiseLike(target) ? await target : target;
            resolvedEvent = isPromiseLike(event) ? await event : event;
            resolvedTarget.addEventListener(resolvedEvent, listener);
        })();
        const originalOnUnsubscribe = subscription.onUnsubscribe;
        subscription.onUnsubscribe = () => {
            originalOnUnsubscribe?.call(subscription);
            if (resolvedTarget && resolvedEvent) {
                resolvedTarget.removeEventListener(resolvedEvent, listener); // Cleanup listener on unsubscribe
            }
        };
        return subscription;
    };
    subject.name = 'fromEvent';
    return subject;
}

function fromPromise(input) {
    return createStream('fromPromise', async function* (signal) {
        const valueOrPromise = typeof input === "function" ? input(signal) : input;
        yield isPromiseLike(valueOrPromise) ? await valueOrPromise : valueOrPromise;
    });
}

/**
 * Creates a stream that chooses between two streams based on a condition.
 *
 * The condition is evaluated lazily when the stream is subscribed to. This allows
 * for dynamic stream selection based on runtime state.
 *
 * @template T The type of the values in the streams.
 * @param {() => MaybePromise<boolean>} condition A function that returns a boolean to determine which stream to use. It is called when the iif stream is subscribed to.
 * @param {Stream<T> | MaybePromise<T> | Array<T>} trueStream The stream to subscribe to if the condition is `true`.
 * @param {Stream<T> | MaybePromise<T> | Array<T>} falseStream The stream to subscribe to if the condition is `false`.
 * @returns {Stream<T>} A new stream that emits values from either `trueStream` or `falseStream` based on the condition.
 */
function iif(condition, trueStream, falseStream) {
    async function* generator() {
        // Evaluate condition lazily when the stream starts
        const conditionResult = condition();
        const resolvedCondition = isPromiseLike(conditionResult) ? await conditionResult : conditionResult;
        const chosen = resolvedCondition ? trueStream : falseStream;
        const resolvedChosen = isPromiseLike(chosen) ? await chosen : chosen;
        const iterator = eachValueFrom(fromAny(resolvedChosen));
        try {
            while (true) {
                const result = await iterator.next();
                if (result.done)
                    break;
                yield result.value;
            }
        }
        finally {
            // Ensure proper cleanup of the iterator
            if (iterator.return) {
                try {
                    await iterator.return(undefined);
                }
                catch {
                    // Ignore any errors during cleanup
                }
            }
        }
    }
    return createStream('iif', generator);
}

/**
 * Creates a timer stream that emits numbers starting from 0.
 *
 * This stream is useful for scheduling events or generating periodic data.
 * It is analogous to `setInterval` but as an asynchronous stream.
 *
 * @param {number} [delayMs=0] - The time in milliseconds to wait before emitting the first value (0).
 * If 0, the first value is emitted immediately (in the next microtask).
 * @param {number} [intervalMs] - The time in milliseconds between subsequent emissions.
 * If not provided, it defaults to `delayMs`.
 * @returns {Stream<number>} A stream that emits incrementing numbers (0, 1, 2, ...).
 */
function timer(delayMs = 0, intervalMs) {
    async function* timerGenerator() {
        const resolvedDelay = isPromiseLike(delayMs) ? await delayMs : delayMs;
        const resolvedInterval = intervalMs !== undefined
            ? (isPromiseLike(intervalMs) ? await intervalMs : intervalMs)
            : resolvedDelay;
        let count = 0;
        let cancelled = false;
        let timeoutId = null;
        const sleep = (ms) => new Promise((resolve) => {
            timeoutId = setTimeout(() => {
                timeoutId = null;
                if (!cancelled)
                    resolve();
            }, ms);
        });
        const clearPending = () => {
            if (timeoutId !== null) {
                clearTimeout(timeoutId);
                timeoutId = null;
            }
        };
        try {
            const start = performance.now();
            let nextTime = start + (resolvedDelay > 0 ? resolvedDelay : 0);
            if (resolvedDelay > 0) {
                await sleep(Math.max(0, nextTime - performance.now()));
            }
            else {
                await Promise.resolve();
                nextTime = performance.now();
            }
            yield count++;
            nextTime += resolvedInterval;
            while (true) {
                const waitMs = Math.max(0, nextTime - performance.now());
                await sleep(waitMs);
                yield count++;
                nextTime += resolvedInterval;
            }
        }
        finally {
            cancelled = true;
            clearPending();
        }
    }
    return createStream('timer', timerGenerator);
}

/**
 * Creates a stream that emits incremental numbers starting from 0 at a regular
 * interval.
 *
 * This operator is a shorthand for `timer(0, intervalMs)`, useful for
 * creating a simple, repeating sequence of numbers. The stream emits a new
 * value every `intervalMs` milliseconds. It is analogous to `setInterval` but
 * as an asynchronous stream.
 *
 * @param {MaybePromise<number>} intervalMs The time in milliseconds between each emission.
 * @returns {Stream<number>} A stream that emits incrementing numbers (0, 1, 2, ...).
 */
function interval(intervalMs) {
    // Use the timer function to create a stream that emits at the specified interval
    const stream = timer(0, intervalMs);
    stream.name = 'interval';
    return stream;
}

/**
 * Creates a stream that performs a JSONP request and emits the resulting data once.
 *
 * This function provides a reactive way to handle JSONP requests, which are
 * often used to bypass the same-origin policy for loading data from a different
 * domain. It dynamically creates a `<script>` tag, handles the response via a
 * global callback, and then cleans up after itself. The stream emits a single
 * value and then completes.
 *
 * @template T The type of the JSONP data to be emitted.
 * @param {MaybePromise<string>} url The URL to make the JSONP request to.
 * @param {MaybePromise<string>} [callbackParam='callback'] The name of the query parameter for the callback function.
 * @returns {Stream<T>} A new stream that emits the JSONP data and then completes.
 */
function jsonp(url, callbackParam = 'callback') {
    return createStream('jsonp', async function* () {
        const resolvedUrl = isPromiseLike(url) ? await url : url;
        const resolvedCallbackParam = isPromiseLike(callbackParam) ? await callbackParam : callbackParam;
        const uniqueCallbackName = `${resolvedCallbackParam}_${Math.random().toString(36).slice(2)}`;
        const script = document.createElement('script');
        const fullUrl = `${resolvedUrl}${resolvedUrl.includes('?') ? '&' : '?'}${resolvedCallbackParam}=${encodeURIComponent(uniqueCallbackName)}`;
        // Promise that resolves when JSONP callback fires or rejects on error
        const dataPromise = new Promise((resolve, reject) => {
            window[uniqueCallbackName] = (data) => resolve(data);
            script.onerror = () => reject(new Error(`JSONP request failed: ${fullUrl}`));
        });
        script.src = fullUrl;
        document.head.appendChild(script);
        // Helper to cleanup
        const cleanup = () => {
            delete window[uniqueCallbackName];
            if (script.parentNode) {
                script.parentNode.removeChild(script);
            }
        };
        try {
            // Race the dataPromise against abort signal
            yield await dataPromise;
        }
        finally {
            cleanup();
        }
    });
}

/**
 * Creates a stream that emits values in a loop based on a condition and an
 * iteration function.
 *
 * This operator is useful for generating a sequence of values until a specific
 * condition is no longer met. It starts with an `initialValue` and, for each
 * iteration, it yields the current value and then uses `iterateFn` to
 * calculate the next value in the sequence.
 *
 * @template T The type of the values in the stream.
 * @param {MaybePromise<T>} initialValue The starting value for the loop.
 * @param {(value: T) => MaybePromise<boolean>} condition A function that returns `true` to continue the loop and `false` to stop.
 * @param {(value: T) => MaybePromise<T>} iterateFn A function that returns the next value in the sequence.
 * @returns {Stream<T>} A stream that emits the generated sequence of values.
 */
function loop(initialValue, condition, iterateFn) {
    return createStream('loop', async function* () {
        let currentValue = isPromiseLike(initialValue) ? await initialValue : initialValue;
        while (true) {
            const shouldContinue = condition(currentValue);
            const continueValue = isPromiseLike(shouldContinue) ? await shouldContinue : shouldContinue;
            if (!continueValue)
                break;
            yield currentValue;
            const nextValue = iterateFn(currentValue);
            currentValue = isPromiseLike(nextValue) ? await nextValue : nextValue;
        }
    });
}

/**
 * Merges multiple source streams into a single stream, emitting values as they arrive from any source.
 *
 * This is useful for combining data from multiple independent sources into a single,
 * unified stream of events. Unlike `zip`, it does not wait for a value from every
 * stream before emitting; it emits values on a first-come, first-served basis.
 *
 * The merged stream completes only after all source streams have completed. If any source stream
 * errors, the merged stream immediately errors.
 *
 * @template T The type of the values in the streams.
 * @param sources Streams/values (or promise of array) to merge.
 * @returns {Stream<T>} A new stream that emits values from all input streams.
 */
function merge(...sources) {
    return createStream('merge', async function* () {
        const resolvedInputs = [];
        for (const src of sources) {
            resolvedInputs.push(isPromiseLike(src) ? await src : src);
        }
        const resolvedSourcesRoot = (resolvedInputs.length === 1 && Array.isArray(resolvedInputs[0])
            ? resolvedInputs[0]
            : resolvedInputs);
        if (resolvedSourcesRoot.length === 0)
            return;
        const resolvedSources = [];
        for (const source of resolvedSourcesRoot) {
            resolvedSources.push(isPromiseLike(source) ? await source : source);
        }
        const iterators = resolvedSources.map(s => eachValueFrom(fromAny(s)));
        const nextPromises = iterators.map(it => it.next());
        let activeCount = iterators.length;
        const reflect = (promise, index) => promise.then(result => ({ ...result, index, status: 'fulfilled' }), error => ({ error, index, status: 'rejected' }));
        while (activeCount > 0) {
            const race = Promise.race(nextPromises
                .map((p, i) => (p ? reflect(p, i) : null))
                .filter(Boolean));
            const winner = await race;
            if (winner.status === 'rejected') {
                throw winner.error;
            }
            const { value, done, index } = winner;
            if (done) {
                nextPromises[index] = null;
                activeCount--;
            }
            else {
                yield value;
                nextPromises[index] = iterators[index].next();
            }
        }
        // Cleanup all iterators on abort or completion
        for (const iterator of iterators) {
            if (iterator.return) {
                try {
                    await iterator.return(undefined);
                }
                catch {
                    // ignore
                }
            }
        }
    });
}

/**
 * Creates a stream that emits a single value and then completes.
 *
 * This operator is useful for scenarios where you need to treat a static,
 * single value as a stream. It immediately yields the provided `value`
 * and then signals completion, which is a common pattern for creating a
 * "hot" stream from a predefined value.
 *
 * @template T The type of the value to be emitted.
 * @param {MaybePromise<T>} value The single value to emit.
 * @returns {Stream<T>} A new stream that emits the value and then completes.
 */
function of(value) {
    return createStream('of', async function* () {
        const resolved = isPromiseLike(value) ? await value : value;
        yield resolved;
    });
}

/**
 * Creates a reactive stream that emits the time delta (in milliseconds) between
 * consecutive `requestAnimationFrame` calls.
 *
 * This stream provides a convenient way to track frame updates in animations,
 * game loops, or other time-sensitive operations. Each subscriber receives
 * a stream of `number` values representing the elapsed time since the previous frame.
 *
 * **Behavior:**
 * - When a subscriber subscribes, a new RAF loop starts immediately.
 * - The first emitted value is the delta between the first and second RAF callbacks.
 * - Each subsequent frame emits the delta since the previous frame.
 * - When the subscriber unsubscribes, the RAF loop is canceled to avoid unnecessary CPU usage.
 *
 * @returns {Stream<number>} A stream emitting the time delta between frames.
 */
function onAnimationFrame() {
    const subject = createSubject();
    const raf = typeof requestAnimationFrame === "function"
        ? requestAnimationFrame
        : ((cb) => setTimeout(() => cb(performance.now()), 16));
    const caf = typeof cancelAnimationFrame === "function"
        ? cancelAnimationFrame
        : ((id) => clearTimeout(id));
    let rafId = null;
    let subscriberCount = 0;
    let stopped = true;
    let lastTime = performance.now();
    const startLoop = () => {
        if (!stopped)
            return;
        stopped = false;
        lastTime = performance.now();
        const tick = (now) => {
            if (stopped)
                return;
            const delta = now - lastTime;
            lastTime = now;
            subject.next(delta);
            rafId = raf(tick);
        };
        rafId = raf(tick);
    };
    const stopLoop = () => {
        if (stopped)
            return;
        stopped = true;
        if (rafId !== null) {
            caf(rafId);
            rafId = null;
        }
    };
    const originalSubscribe = subject.subscribe;
    subject.subscribe = (callback) => {
        const subscription = originalSubscribe.call(subject, callback);
        subscriberCount++;
        if (subscriberCount === 1) {
            startLoop();
        }
        const originalOnUnsubscribe = subscription.onUnsubscribe;
        subscription.onUnsubscribe = () => {
            subscriberCount = Math.max(0, subscriberCount - 1);
            if (subscriberCount === 0) {
                stopLoop();
            }
            originalOnUnsubscribe?.call(subscription);
        };
        return subscription;
    };
    // Ensure async iteration also starts/stops the shared loop
    subject[Symbol.asyncIterator] = () => createAsyncGenerator((receiver) => subject.subscribe(receiver));
    subject.name = 'onAnimationFrame';
    return subject;
}

/**
 * Creates a stream that emits `true` when a given element enters the
 * viewport and `false` when it leaves.
 *
 * This operator is a wrapper around the `IntersectionObserver` API,
 * making it easy to create reactive streams for "lazy loading" or
 * triggering events when an element becomes visible. The stream will
 * emit a value each time the intersection status changes.
 *
 * @param {Element | PromiseLike<Element>} element The DOM element to observe for intersection changes.
 * @param {IntersectionObserverInit | PromiseLike<IntersectionObserverInit>} [options] Optional configuration for the observer, such as root, root margin, and threshold.
 * @returns {Stream<boolean>} A stream that emits `true` if the element is intersecting the viewport, and `false` otherwise.
 */
function onIntersection(element, options) {
    const subject = createSubject();
    subject.name = 'onIntersection';
    const originalSubscribe = subject.subscribe;
    subject.subscribe = (callback) => {
        const subscription = originalSubscribe.call(subject, callback);
        let resolvedElement;
        let resolvedOptions;
        let observer;
        let mutationObserver;
        let disposed = false;
        (async () => {
            resolvedElement = isPromiseLike(element) ? await element : element;
            resolvedOptions = isPromiseLike(options) ? await options : options;
            if (disposed)
                return;
            observer = new IntersectionObserver((entries) => {
                subject.next(entries[0]?.isIntersecting ?? false);
            }, resolvedOptions);
            observer.observe(resolvedElement);
            mutationObserver = new MutationObserver(() => {
                if (resolvedElement && !document.body.contains(resolvedElement)) {
                    subscription.unsubscribe();
                    subject.complete?.();
                }
            });
            mutationObserver.observe(document.body, { childList: true, subtree: true });
        })();
        const cleanup = () => {
            disposed = true;
            if (observer && resolvedElement) {
                observer.unobserve(resolvedElement);
                observer.disconnect();
            }
            mutationObserver?.disconnect();
            subscription.unsubscribe();
        };
        const originalOnUnsubscribe = subscription.onUnsubscribe;
        subscription.onUnsubscribe = () => {
            originalOnUnsubscribe?.call(subscription);
            cleanup();
        };
        return subscription;
    };
    return subject;
}

/**
 * Creates a reactive stream that emits `true` or `false` whenever a CSS media query
 * matches or stops matching.
 *
 * This stream allows you to reactively track viewport changes, orientation, or
 * other media features in a consistent, subscription-based way.
 *
 * **Behavior:**
 * - The initial match status is emitted immediately upon subscription.
 * - Subsequent changes are emitted whenever the media query's match state changes.
 * - Each subscriber has its own listener, which is cleaned up when unsubscribing.
 *
 * @param mediaQueryString A valid CSS media query string (or promise) (e.g., "(min-width: 600px)").
 * @returns {Stream<boolean>} A stream emitting `true` if the query matches, `false` otherwise.
 */
function onMediaQuery(mediaQueryString) {
    if (typeof window === 'undefined' || !window.matchMedia) {
        console.warn('matchMedia is not supported in this environment');
        return createBehaviorSubject(false);
    }
    const isThenable = (val) => !!val && typeof val === 'object' && typeof val.then === 'function';
    let mql = null;
    let listenerPromise = null;
    const subject = createBehaviorSubject(isThenable(mediaQueryString) ? false : window.matchMedia(mediaQueryString).matches);
    subject.name = 'onMediaQuery';
    let listenerCount = 0;
    let listener = null;
    const originalSubscribe = subject.subscribe;
    subject.subscribe = (callback) => {
        listenerCount++;
        const subscription = originalSubscribe.call(subject, callback);
        // Set up listener on first subscription
        (async () => {
            if (!mql && !listenerPromise) {
                if (isThenable(mediaQueryString)) {
                    listenerPromise = mediaQueryString.then((query) => {
                        mql = window.matchMedia(query);
                        subject.next(mql.matches);
                    });
                }
                else {
                    mql = window.matchMedia(mediaQueryString);
                    listenerPromise = Promise.resolve();
                }
            }
            if (!mql && listenerPromise) {
                await listenerPromise;
            }
            if (listenerCount > 0 && mql && !listener) {
                listener = (event) => {
                    subject.next(event.matches);
                };
                if (typeof mql.addEventListener === 'function') {
                    mql.addEventListener('change', listener);
                }
                else if (typeof mql.addListener === 'function') {
                    mql.addListener(listener);
                }
            }
        })();
        const cleanup = () => {
            listenerCount--;
            subscription.unsubscribe();
            // Remove listener when last subscriber unsubscribes
            if (listenerCount === 0 && listener && mql) {
                if (typeof mql.removeEventListener === 'function') {
                    mql.removeEventListener('change', listener);
                }
                else if (typeof mql.removeListener === 'function') {
                    mql.removeListener(listener);
                }
                listener = null;
            }
        };
        const originalOnUnsubscribe = subscription.onUnsubscribe;
        subscription.onUnsubscribe = () => {
            originalOnUnsubscribe?.call(subscription);
            cleanup();
        };
        return subscription;
    };
    return subject;
}

/**
 * Creates a stream that emits an array of `MutationRecord` objects whenever
 * a change is detected on a given DOM element.
 *
 * Automatically unsubscribes if the element is removed from the DOM.
 *
 * @param element The DOM element (or promise) to observe for mutations.
 * @param options An optional object (or promise) specifying which DOM changes to observe.
 * @returns A Stream emitting arrays of `MutationRecord`s.
 */
function onMutation(element, options) {
    const subject = createSubject();
    subject.name = 'onMutation';
    const originalSubscribe = subject.subscribe;
    subject.subscribe = (callback) => {
        const subscription = originalSubscribe.call(subject, callback);
        let resolvedElement;
        let resolvedOptions;
        let observer;
        let removalObserver;
        let disposed = false;
        (async () => {
            resolvedElement = isPromiseLike(element) ? await element : element;
            resolvedOptions = isPromiseLike(options) ? await options : options;
            if (disposed)
                return;
            observer = new MutationObserver((mutations) => {
                subject.next([...mutations]);
            });
            observer.observe(resolvedElement, resolvedOptions);
            // Watch for DOM removal
            removalObserver = new MutationObserver(() => {
                if (resolvedElement && !document.body.contains(resolvedElement)) {
                    subject.complete?.();
                }
            });
            removalObserver.observe(document.body, { childList: true, subtree: true });
        })();
        const cleanup = () => {
            disposed = true;
            observer?.disconnect();
            removalObserver?.disconnect();
            subscription.unsubscribe();
        };
        const originalOnUnsubscribe = subscription.onUnsubscribe;
        subscription.onUnsubscribe = () => {
            originalOnUnsubscribe?.call(subscription);
            cleanup();
        };
        return subscription;
    };
    return subject;
}

/**
 * Creates a stream that emits the current screen orientation, either
 * "portrait" or "landscape", whenever it changes.
 *
 * Automatically unsubscribes when unsubscribed.
 *
 * @returns {Stream<"portrait" | "landscape">} A stream that emits a string indicating the screen's orientation.
 */
/**
 * Creates a stream that emits the current screen orientation, either
 * "portrait" or "landscape", whenever it changes.
 *
 * Automatically unsubscribes when unsubscribed.
 *
 * @returns {Stream<"portrait" | "landscape">} A stream that emits a string indicating the screen's orientation.
 */
function onOrientation() {
    if (!window.screen || !window.screen.orientation) {
        console.warn("Screen orientation API is not supported in this environment");
        return createSubject();
    }
    const subject = createSubject();
    subject.name = 'onOrientation';
    const getOrientation = () => window.screen.orientation.angle === 0 || window.screen.orientation.angle === 180
        ? "portrait"
        : "landscape";
    const listener = () => {
        subject.next(getOrientation());
    };
    let subscriberCount = 0;
    let isListenerAttached = false;
    // Emit initial orientation immediately when first subscriber connects
    const originalSubscribe = subject.subscribe;
    subject.subscribe = (callback) => {
        const subscription = originalSubscribe.call(subject, callback);
        subscriberCount++;
        // Attach listener on first subscriber
        if (!isListenerAttached) {
            window.screen.orientation.addEventListener("change", listener);
            isListenerAttached = true;
            // Emit initial orientation for new subscriber
            subject.next(getOrientation());
        }
        const cleanup = () => {
            subscriberCount--;
            // Remove listener when last subscriber unsubscribes
            if (subscriberCount === 0 && isListenerAttached) {
                window.screen.orientation.removeEventListener("change", listener);
                isListenerAttached = false;
            }
            subscription.unsubscribe();
        };
        const originalOnUnsubscribe = subscription.onUnsubscribe;
        subscription.onUnsubscribe = () => {
            originalOnUnsubscribe?.call(subscription);
            cleanup();
        };
        return subscription;
    };
    return subject;
}

/**
 * Creates a stream that emits the dimensions (width and height) of a given
 * DOM element whenever it is resized.
 *
 * Automatically unsubscribes and completes if the element is removed from the DOM.
 *
 * @param element The DOM element (or promise resolving to one) to observe for size changes.
 * @returns A Stream emitting objects with `width` and `height` properties.
 */
function onResize(element) {
    const subject = createSubject();
    subject.name = 'onResize';
    const originalSubscribe = subject.subscribe;
    subject.subscribe = (callback) => {
        const subscription = originalSubscribe.call(subject, callback);
        let resolvedElement;
        let resizeObserver;
        let removalObserver;
        let disposed = false;
        (async () => {
            resolvedElement = isPromiseLike(element) ? await element : element;
            if (disposed)
                return;
            const listener = (entries) => {
                const { width, height } = entries[0]?.contentRect ?? { width: 0, height: 0 };
                subject.next({ width, height });
            };
            resizeObserver = new ResizeObserver(listener);
            resizeObserver.observe(resolvedElement);
            // Watch for DOM removal
            removalObserver = new MutationObserver(() => {
                if (resolvedElement && !document.body.contains(resolvedElement)) {
                    subject.complete?.();
                }
            });
            removalObserver.observe(document.body, { childList: true, subtree: true });
        })();
        const cleanup = () => {
            disposed = true;
            if (resizeObserver && resolvedElement) {
                resizeObserver.unobserve(resolvedElement);
                resizeObserver.disconnect();
            }
            removalObserver?.disconnect();
            subscription.unsubscribe();
        };
        const originalOnUnsubscribe = subscription.onUnsubscribe;
        subscription.onUnsubscribe = () => {
            originalOnUnsubscribe?.call(subscription);
            cleanup();
        };
        return subscription;
    };
    return subject;
}

/**
 * Returns a stream that races multiple input streams.
 * It emits values from the first stream that produces a value,
 * then cancels all other streams.
 *
 * This operator is useful for scenarios where you only need the result from the fastest
 * of several asynchronous operations. For example, fetching data from multiple servers
 * and only taking the result from the one that responds first.
 *
 * Once the winning stream completes, the output stream also completes.
 * If the winning stream emits an error, the output stream will emit that error.
 *
 * @template {readonly unknown[]} T - A tuple type representing the combined values from the streams.
 * @param {MaybePromise<{ [K in keyof T]: Stream<T[K]> | Array<T[K]> | T[K] }>} streams - Streams (or a promise of them) to race against each other.
 * @returns {Stream<T[number]>} A new stream that emits values from the first stream to produce a value.
 */
function race(...streams) {
    return createStream('race', async function* () {
        const resolvedStreams = streams;
        if (!resolvedStreams || resolvedStreams.length === 0)
            return;
        const controllers = new Array(resolvedStreams.length).fill(null).map(() => new AbortController());
        const iterators = resolvedStreams.map((s) => eachValueFrom(fromAny(s)));
        try {
            while (true) {
                // Create promises for all iterators
                const promises = iterators.map((it, i) => it.next().then(result => ({ ...result, index: i })));
                // Race all iterators
                const { value, done, index } = await Promise.race(promises);
                if (done) {
                    // Cancel all other streams
                    controllers.forEach((c, i) => i !== index && c.abort());
                    return;
                }
                yield value;
                // Cancel losing streams
                controllers.forEach((c, i) => i !== index && c.abort());
            }
        }
        finally {
            // Cleanup all controllers
            controllers.forEach(c => c.abort());
        }
    });
}

/**
 * Creates a stream that emits a sequence of numbers, starting from `start`,
 * incrementing by `step`, and emitting a total of `count` values.
 *
 * This operator is a powerful way to generate a numerical sequence in a
 * reactive context. It's similar to a standard `for` loop but produces
 * values as a stream. It's built upon the `loop` operator for its
 * underlying logic.
 *
 * @param {MaybePromise<number>} start - The first number to emit in the sequence.
 * @param {MaybePromise<number>} count - The total number of values to emit. Must be a non-negative number.
 * @param {MaybePromise<number>} [step=1] - The amount to increment or decrement the value in each step.
 * @returns {Stream<number>} A stream that emits a sequence of numbers.
 */
function range(start, count, step = 1) {
    return createStream('range', async function* () {
        const resolvedStart = isPromiseLike(start) ? await start : start;
        const resolvedCount = isPromiseLike(count) ? await count : count;
        const resolvedStep = isPromiseLike(step) ? await step : step;
        const end = resolvedStart + resolvedCount * resolvedStep;
        let current = resolvedStart;
        while (resolvedStep > 0 ? current < end : current > end) {
            yield current;
            current += resolvedStep;
        }
    });
}

/**
 * Creates a stream that subscribes to a source factory and retries on error.
 *
 * This operator is useful for handling streams that may fail due to
 * temporary issues, such as network problems. It will attempt to
 * resubscribe to the source stream up to `maxRetries` times, with an
 * optional delay between each attempt. If the stream completes successfully
 * on any attempt, it will emit all of its values and then complete.
 * If all retry attempts fail, the final error is propagated.
 *
 * @template T The type of values emitted by the stream.
 * @param {() => (Stream<T> | MaybePromise<T>)} factory A function that returns a new stream instance for each subscription attempt.
 * @param {MaybePromise<number>} [maxRetries=3] The maximum number of times to retry the stream. A value of 0 means no retries.
 * @param {MaybePromise<number>} [delay=1000] The time in milliseconds to wait before each retry attempt.
 * @returns {Stream<T>} A new stream that applies the retry logic.
 */
function retry(factory, maxRetries = 3, delay = 1000) {
    return createStream("retry", async function* () {
        const resolvedMaxRetries = isPromiseLike(maxRetries) ? await maxRetries : maxRetries;
        const resolvedDelay = isPromiseLike(delay) ? await delay : delay;
        let retryCount = 0;
        while (retryCount <= resolvedMaxRetries) {
            try {
                const produced = factory();
                const sourceStream = fromAny(isPromiseLike(produced) ? await produced : produced);
                const values = [];
                let streamError = null;
                let completed = false;
                await new Promise((resolve, reject) => {
                    const subscription = sourceStream.subscribe({
                        next: (value) => {
                            values.push(value);
                        },
                        error: (err) => {
                            streamError = err;
                            reject(err);
                        },
                        complete: () => {
                            completed = true;
                            resolve();
                            subscription.unsubscribe();
                        },
                    });
                });
                if (streamError) {
                    throw streamError;
                }
                if (completed) {
                    for (const value of values) {
                        yield value;
                    }
                    break;
                }
            }
            catch (error) {
                retryCount++;
                if (retryCount > resolvedMaxRetries) {
                    throw error;
                }
                if (resolvedDelay !== undefined) {
                    await new Promise((resolve) => setTimeout(resolve, resolvedDelay));
                }
            }
        }
    });
}

/**
 * Creates a stream that "seizes" a single worker from the coroutine pool,
 * providing a persistent, manually-controlled communication channel.
 *
 * This operator is ideal for scenarios where you need to perform multiple,
 * sequential tasks on a specific, stateful worker. The worker remains
 * dedicated to the returned stream until the `release()` method is called
 * on the `SeizedWorker` object.
 *
 * The stream itself will only emit a single `SeizedWorker` object and then complete
 * after the worker has been released.
 *
 * @template T The type of data sent to the worker.
 * @template R The type of data returned from the worker.
 * @param {Coroutine<T, R> | PromiseLike<Coroutine<T, R>>} task The coroutine instance managing the worker pool.
 * @param {(message: CoroutineMessage) => MaybePromise<void>} onMessage A callback function to handle messages received from the seized worker.
 * @param {(error: Error) => MaybePromise<void>} onError A callback function to handle errors originating from the seized worker.
 * @returns {Stream<SeizedWorker<T, R>>} A stream that yields a single `SeizedWorker` object.
 */
function seize(task, onMessage, onError) {
    return createStream("seize", async function* () {
        const resolvedTask = isPromiseLike(task) ? await task : task;
        const { worker, workerId } = await resolvedTask.getIdleWorker();
        let disposed = false;
        const ac = new AbortController();
        const signal = ac.signal;
        const messageHandler = async (event) => {
            if (event.data.workerId === workerId) {
                await onMessage(event.data);
            }
        };
        const errorHandler = async (event) => {
            await onError(event.error);
            if (!disposed) {
                ac.abort();
            }
        };
        const cleanup = () => {
            if (!disposed) {
                disposed = true;
                worker.removeEventListener("message", messageHandler);
                worker.removeEventListener("error", errorHandler);
                resolvedTask.returnWorker(workerId);
                ac.abort();
            }
        };
        worker.addEventListener("message", messageHandler);
        worker.addEventListener("error", errorHandler);
        const seizedWorker = {
            workerId,
            sendTask: (data) => resolvedTask.assignTask(workerId, data),
            release: cleanup,
        };
        try {
            yield seizedWorker;
            // Wait until release or iterator is abandoned
            await new Promise((resolve) => signal.addEventListener("abort", () => resolve(), { once: true }));
        }
        finally {
            cleanup();
        }
    });
}

/**
 * Creates a WebSocket stream for bidirectional communication with a server.
 *
 * Incoming messages from the WebSocket are emitted as stream values.
 * Outgoing messages are sent via the `.send()` method.
 * Messages sent before the connection is open are queued automatically.
 *
 * @template T - Type of messages to send and receive.
 * @param url The WebSocket URL (can be a Promise).
 * @param factory Optional WebSocket factory for dependency injection (useful for testing, can be a Promise).
 * @returns {WebSocketStream<T>} A WebSocketStream that can be used to
 * send and receive messages of type T.
 */
function webSocket(url, factory = (u) => new WebSocket(u)) {
    const messageQueue = [];
    const sendQueue = [];
    let resolveNext = null;
    let rejectNext = null;
    let isOpen = false;
    let done = false;
    let socket = null;
    // Helper to initialize the WebSocket
    const initWebSocket = async () => {
        try {
            const resolvedUrl = isPromise(url) ? await url : url;
            const created = factory(resolvedUrl);
            socket = isPromise(created) ? await created : created;
            setupSocketHandlers();
        }
        catch (error) {
            done = true;
            if (rejectNext) {
                rejectNext(error);
                resolveNext = rejectNext = null;
            }
        }
    };
    const isPromise = (v) => v && typeof v.then === "function";
    const setupSocketHandlers = () => {
        if (!socket)
            return;
        const onOpen = () => {
            isOpen = true;
            while (sendQueue.length) {
                try {
                    socket.send(JSON.stringify(sendQueue.shift()));
                }
                catch (error) {
                    console.warn("Failed to send queued message:", error);
                }
            }
        };
        const onMessage = (ev) => {
            try {
                const data = JSON.parse(ev.data);
                messageQueue.push(data);
                if (resolveNext) {
                    resolveNext(messageQueue.shift());
                    resolveNext = rejectNext = null;
                }
            }
            catch (err) {
                if (rejectNext) {
                    rejectNext(err);
                    resolveNext = rejectNext = null;
                }
            }
        };
        const closeWithError = (err) => {
            done = true;
            isOpen = false;
            if (rejectNext) {
                rejectNext(err);
                resolveNext = rejectNext = null;
            }
        };
        const onClose = () => closeWithError(new Error("WebSocket closed"));
        const onError = () => closeWithError(new Error("WebSocket error"));
        socket.addEventListener("open", onOpen);
        socket.addEventListener("message", onMessage);
        socket.addEventListener("close", onClose);
        socket.addEventListener("error", onError);
        // Cleanup helper
        cleanupHandlers = () => {
            socket?.removeEventListener("open", onOpen);
            socket?.removeEventListener("message", onMessage);
            socket?.removeEventListener("close", onClose);
            socket?.removeEventListener("error", onError);
        };
    };
    let cleanupHandlers = null;
    // Start initialization (sync or async)
    initWebSocket();
    async function* generator() {
        try {
            // Wait for socket initialization if it's happening asynchronously
            if (!socket && !done) {
                await new Promise((resolve) => {
                    const checkSocket = () => {
                        if (socket || done) {
                            resolve();
                        }
                        else {
                            setTimeout(checkSocket, 0);
                        }
                    };
                    checkSocket();
                });
            }
            if (done) {
                throw new Error("WebSocket failed to initialize");
            }
            while (!done) {
                if (messageQueue.length) {
                    yield messageQueue.shift();
                }
                else {
                    yield await new Promise((resolve, reject) => {
                        resolveNext = resolve;
                        rejectNext = reject;
                    });
                }
            }
        }
        finally {
            cleanupHandlers?.();
            if (socket && socket.readyState === WebSocket.OPEN) {
                socket.close();
            }
        }
    }
    ;
    const stream = createStream("webSocket", generator);
    // Send method
    stream.send = (msg) => {
        if (done) {
            return;
        }
        if (isOpen && socket) {
            try {
                socket.send(JSON.stringify(msg));
            }
            catch (error) {
                console.warn("Failed to send message:", error);
            }
        }
        else if (socket && socket.readyState === WebSocket.CONNECTING) {
            sendQueue.push(msg);
        }
        else if (!socket) {
            // Socket not initialized yet - queue the message
            sendQueue.push(msg);
        }
        else {
            console.warn("Cannot send message: WebSocket is not open");
        }
    };
    stream.close = () => {
        done = true;
        isOpen = false;
        if (socket && socket.readyState === WebSocket.OPEN) {
            socket.close();
        }
        if (rejectNext) {
            rejectNext(new Error("WebSocket closed"));
            resolveNext = rejectNext = null;
        }
    };
    return stream;
}

/**
 * Combines multiple streams by emitting an array of values (a tuple),
 * only when all streams have a value ready (one-by-one, synchronized).
 *
 * It waits for the next value from all streams to form the next tuple.
 * The stream completes when any of the input streams complete.
 * Errors from any stream propagate immediately.
 *
 * @template T - A tuple type representing the combined values from the streams.
 * @param streams Streams to combine.
 * @returns {Stream<T>} A new stream that emits a synchronized tuple of values.
 */
function zip(...sources) {
    return createStream('zip', async function* () {
        const resolvedInputs = [];
        for (const src of sources) {
            resolvedInputs.push(isPromiseLike(src) ? await src : src);
        }
        const normalizedStreams = (resolvedInputs.length === 1 && Array.isArray(resolvedInputs[0])
            ? resolvedInputs[0]
            : resolvedInputs);
        if (normalizedStreams.length === 0)
            return;
        const iterators = await Promise.all(normalizedStreams.map(async (s) => {
            const streamSource = isPromiseLike(s) ? await s : s;
            return eachValueFrom(fromAny(streamSource));
        }));
        try {
            while (true) {
                const results = await Promise.all(iterators.map(it => it.next()));
                if (results.some(r => r.done))
                    break;
                yield results.map(r => r.value);
            }
        }
        finally {
            await Promise.all(iterators.map(it => (typeof it.return === 'function' ? it.return(undefined).catch(() => { }) : Promise.resolve())));
        }
    });
}

/**
 * Creates a stream operator that emits the latest value from the source stream
 * at most once per specified duration.
 *
 * Each incoming value is stored as the "latest"; a timer emits that latest value
 * when the duration elapses. If the source completes before emission, the last
 * buffered value is flushed before completing.
 *
 * @template T The type of the values in the stream.
 * @param duration The time in milliseconds (or a promise resolving to it) to wait
 * before emitting the latest value. The duration is resolved once when the operator starts.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const audit = (duration) => createOperator('audit', function (source) {
    const output = createSubject();
    let lastResult = undefined;
    let timerId = undefined;
    let resolvedDuration = undefined;
    const flush = () => {
        if (lastResult !== undefined) {
            output.next(lastResult.value);
            lastResult = undefined;
        }
        timerId = undefined;
    };
    const startTimer = () => {
        if (resolvedDuration === undefined) {
            return;
        }
        timerId = setTimeout(() => flush(), resolvedDuration);
    };
    (async () => {
        try {
            resolvedDuration = isPromiseLike(duration) ? await duration : duration;
            while (true) {
                const result = await source.next();
                // Stream completed
                if (result.done) {
                    if (lastResult !== undefined) {
                        flush();
                    }
                    break;
                }
                // Add new value to pending set and buffer it
                lastResult = result;
                // Start a new timer if not active
                if (timerId === undefined) {
                    startTimer();
                }
            }
        }
        catch (err) {
            output.error(err);
        }
        finally {
            if (timerId !== undefined) {
                clearTimeout(timerId);
                timerId = undefined;
            }
            output.complete();
        }
    })();
    return eachValueFrom(output);
});

/**
 * Buffers values from the source stream and emits them as arrays every `period` milliseconds,
 * while tracking pending and phantom values in the PipeContext.
 *
 * @template T The type of the values in the source stream.
 * @param period Time in milliseconds between each buffer flush.
 * @returns An Operator instance for use in a stream's `pipe` method.
 */
function buffer(period) {
    return createOperator("buffer", function (source) {
        const output = createSubject();
        let buffer = [];
        let completed = false;
        const flush = () => {
            if (buffer.length > 0) {
                // Emit an array of the actual values
                const values = buffer.map((r) => r.value);
                output.next(values);
                // Resolve all pending results for this flush
                buffer = [];
            }
        };
        const cleanup = () => {
            intervalSubscription.unsubscribe();
        };
        const flushAndComplete = () => {
            flush();
            if (!completed) {
                completed = true;
                output.complete();
            }
            cleanup();
        };
        const fail = (err) => {
            // resolve all pending before error
            if (buffer.length > 0) {
                buffer = [];
            }
            output.error(err);
            cleanup();
        };
        // Timer triggers periodic flush
        const intervalSubscription = timer(period, period).subscribe({
            next: () => flush(),
            error: (err) => fail(err),
            complete: () => flushAndComplete(),
        });
        (async () => {
            try {
                while (true) {
                    const result = await source.next();
                    if (result.done)
                        break;
                    // Add to buffer
                    buffer.push(result);
                }
            }
            catch (err) {
                cleanup();
                output.error(err);
            }
            finally {
                flushAndComplete();
            }
        })();
        return eachValueFrom(output);
    });
}

/**
 * Buffers a fixed number of values from the source stream and emits them as arrays,
 * tracking pending and phantom values in the PipeContext.
 *
 * @template T The type of values in the source stream.
 * @param bufferSize The maximum number of values per buffer (default: Infinity).
 * @returns An Operator instance for use in a stream's `pipe` method.
 */
const bufferCount = (bufferSize = Infinity) => createOperator("bufferCount", function (source) {
    let completed = false;
    let resolvedBufferSize;
    const resolveBufferSize = () => {
        if (resolvedBufferSize !== undefined) {
            return resolvedBufferSize;
        }
        if (isPromiseLike(bufferSize)) {
            return bufferSize.then((val) => {
                resolvedBufferSize = val;
                return val;
            });
        }
        resolvedBufferSize = bufferSize;
        return resolvedBufferSize;
    };
    return {
        next: async () => {
            if (completed)
                return DONE;
            const buffer = [];
            const sizeOrPromise = resolveBufferSize();
            const size = isPromiseLike(sizeOrPromise) ? await sizeOrPromise : sizeOrPromise;
            while (buffer.length < size) {
                const result = await source.next();
                if (result.done) {
                    completed = true;
                    // Flush any remaining buffered values
                    if (buffer.length > 0) {
                        return NEXT(buffer.map((r) => r.value));
                    }
                    return DONE;
                }
                buffer.push(result);
            }
            return NEXT(buffer.map((r) => r.value));
        },
    };
});

/**
 * Chains multiple coroutine tasks sequentially, creating a single `CoroutineLike` operator.
 *
 * Each coroutine in the sequence processes the output of the previous coroutine,
 * forming a data processing pipeline. This function is useful for composing
 * complex asynchronous operations from simpler, reusable building blocks.
 *
 * The final output type of the cascade is the output type of the last coroutine in the chain.
 *
 * @template T The input type of the first coroutine.
 * @template R The output type of the last coroutine.
 * @param tasks Coroutines to chain.
 * @returns {CoroutineLike<T, R>} A `CoroutineLike` operator representing the entire cascaded pipeline.
 */
function cascade(...tasks) {
    let cachedTasks = null;
    const getTasks = async () => {
        if (cachedTasks === null) {
            const resolvedTasks = await Promise.all(tasks.map(async (task) => {
                const resolved = isPromiseLike(task) ? await task : task;
                return Array.isArray(resolved) ? resolved : [resolved];
            }));
            cachedTasks = resolvedTasks.flat();
        }
        return cachedTasks;
    };
    const operator = createOperator("cascade", function (source) {
        let completed = false;
        return {
            async next() {
                while (true) {
                    if (completed) {
                        return DONE;
                    }
                    const result = await source.next();
                    if (result.done) {
                        completed = true;
                        return DONE;
                    }
                    let taskResult = result.value;
                    const resolvedTasks = await getTasks();
                    for (const task of resolvedTasks) {
                        taskResult = await task.processTask(taskResult);
                    }
                    return NEXT(taskResult);
                }
            },
            async return() {
                completed = true;
                return DONE;
            },
            async throw(err) {
                completed = true;
                throw err;
            }
        };
    });
    const coroutineLike = Object.assign(operator, {
        async processTask(data) {
            let result = data;
            const tasksList = await getTasks();
            for (const task of tasksList) {
                result = await task.processTask(result);
            }
            return result;
        },
        async finalize() {
            const tasksList = await getTasks();
            for (const task of tasksList) {
                await task.finalize();
            }
        }
    });
    return coroutineLike;
}

/**
 * Creates a stream operator that catches errors from the source stream and handles them.
 *
 * This operator listens for errors from the upstream source. When the first error is
 * caught, it invokes a provided `handler` callback and then immediately completes
 * the stream, preventing the error from propagating further down the pipeline.
 *
 * - **Error Handling:** The `handler` is executed only for the first error encountered.
 * - **Completion:** After an error is caught and handled, the operator completes,
 * terminating the stream's flow.
 * - **Subsequent Errors:** Any errors after the first will be re-thrown.
 *
 * This is useful for error-handling strategies where you want to perform a specific
 * cleanup action and then gracefully terminate the stream.
 *
 * @template T The type of the values emitted by the stream.
 * @param handler The function to call when an error is caught. It can return a `void` or a `Promise<void>`.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const catchError = (handler = () => { }) => createOperator('catchError', function (source) {
    let errorCaughtAndHandled = false;
    let completed = false;
    return {
        next: async () => {
            while (true) {
                // If an error was already caught and handled, or we're completed, this operator is done
                if (errorCaughtAndHandled || completed) {
                    return DONE;
                }
                try {
                    const result = await source.next();
                    if (result.done) {
                        completed = true; // Source completed without error
                        return DONE;
                    }
                    return result; // Emit value from source
                }
                catch (error) {
                    // An error occurred from the source
                    if (!errorCaughtAndHandled) { // Only handle the first error
                        const handlerResult = handler(error);
                        if (isPromiseLike(handlerResult))
                            await handlerResult;
                        errorCaughtAndHandled = true; // Mark as handled
                        completed = true;
                        // After handling, this operator completes
                        return DONE;
                    }
                    else {
                        // If subsequent errors occur (shouldn't happen with a proper upstream), re-throw
                        throw error;
                    }
                }
            }
        },
    };
});

/**
 * Creates a stream operator that maps each value from the source stream to a new
 * inner stream (or value/array/promise) and flattens all inner streams sequentially.
 *
 * For each value from the source:
 * 1. The `project` function is called with the value and its index.
 * 2. The returned value is normalized into a stream using {@link fromAny}.
 * 3. The inner stream is consumed fully before processing the next outer value.
 *
 * This ensures that all emitted values maintain their original sequential order.
 *
 * @template T The type of values in the source stream.
 * @template R The type of values emitted by the inner streams and the output.
 * @param project A function that takes a value from the source stream and its index,
 * and returns either:
 *   - a {@link Stream<R>},
 *   - a {@link MaybePromise<R>} (value or promise),
 *   - or an array of `R`.
 * @returns An {@link Operator} instance that can be used in a stream's `pipe` method.
 */
const concatMap = (project) => createOperator("concatMap", function (source) {
    let outerIndex = 0;
    let innerIterator = null;
    let result = null;
    return {
        next: async () => {
            while (true) {
                // If no active inner iterator, pull the next outer value
                if (!innerIterator) {
                    result = await source.next();
                    if (result.done)
                        return DONE;
                    const projected = project(result.value, outerIndex++);
                    const normalized = isPromiseLike(projected) ? await projected : projected;
                    innerIterator = eachValueFrom(fromAny(normalized));
                }
                // Pull next value from inner stream
                const innerResult = await innerIterator.next();
                if (innerResult.done) {
                    innerIterator = null;
                    // Otherwise continue to next outer value
                    continue;
                }
                // Mark that inner stream produced a value
                return NEXT(innerResult.value);
            }
        },
    };
});

/**
 * Default worker script template with placeholders.
 */
const DEFAULT_WORKER_TEMPLATE = `
{GLOBALS}
{HELPERS}
{DEPENDENCIES}
{INIT_CODE}
const __mainTask = {MAIN_TASK};

// A map to store promises for pending data requests from the worker
const __pendingWorkerRequests = new Map();

// A helper function for the worker to request data from the main thread
const __requestData = (workerId, taskId, payload) => {
  return new Promise(resolve => {
    __pendingWorkerRequests.set(taskId, resolve);
    postMessage({ workerId, taskId, type: 'request', payload });
  });
};

const __reportProgress = (workerId, taskId) => (progressData) => {
  postMessage({ workerId, taskId, payload: progressData, type: 'progress' });
};

onmessage = async (event) => {
  const { workerId, taskId, payload, type } = event.data;

  // If this is a response to a data request from the worker
  if (type === 'data') {
    const resolve = __pendingWorkerRequests.get(taskId);
    if (resolve) {
      __pendingWorkerRequests.delete(taskId);
      resolve(payload);
    }
    return;
  }

  // This is the initial task from the main thread
  if (type === 'task') {
    try {
      const utils = {
        requestData: (requestPayload) => __requestData(workerId, taskId, requestPayload),
        reportProgress: __reportProgress(workerId, taskId)
      };
      
      // Always call with both parameters - JavaScript will ignore extra parameters
      const result = await __mainTask(payload, utils);
      
      postMessage({ workerId, taskId, payload: result, type: 'response' });
    } catch (error) {
      postMessage({ workerId, taskId, error: error.message, type: 'error' });
    }
  }
};`;
/**
 * Minified helper script used inside Web Worker blobs.
 */
const HELPER_SCRIPT = `var __defProp=Object.defineProperty,__defProps=Object.defineProperties,__getOwnPropDescs=Object.getOwnPropertyDescriptors,__getOwnPropSymbols=Object.getOwnPropertySymbols,__hasOwnProp=Object.prototype.hasOwnProperty,__propIsEnum=Object.prototype.propertyIsEnumerable,__knownSymbol=(r,e)=>(e=Symbol[r])?e:Symbol.for("Symbol."+r),__defNormalProp=(r,e,o)=>e in r?__defProp(r,e,{enumerable:!0,configurable:!0,writable:!0,value:o}):r[e]=o,__spreadValues=(r,e)=>{for(var o in e||={})__hasOwnProp.call(e,o)&&__defNormalProp(r,o,e[o]);if(__getOwnPropSymbols)for(var o of __getOwnPropSymbols(e))__propIsEnum.call(e,o)&&__defNormalProp(r,o,e[o]);return r},__spreadProps=(r,e)=>__defProps(r,__getOwnPropDescs(e)),__async=(r,e,o)=>new Promise((t,n)=>{var a=r=>{try{s(o.next(r))}catch(e){n(e)}},p=r=>{try{s(o.throw(r))}catch(e){n(e)}},s=r=>r.done?t(r.value):Promise.resolve(r.value).then(a,p);s((o=o.apply(r,e)).next())}),__await=function(r,e){this[0]=r,this[1]=e},__asyncGenerator=(r,e,o)=>{var t=(r,e,n,a)=>{try{var p=o[r](e),s=(e=p.value)instanceof __await,l=p.done;Promise.resolve(s?e[0]:e).then(o=>s?t("return"===r?r:"next",e[1]?{done:o.done,value:o.value}:o,n,a):n({value:o,done:l})).catch(r=>t("throw",r,n,a))}catch(y){a(y)}},n=r=>a[r]=e=>new Promise((o,n)=>t(r,e,o,n)),a={};return o=o.apply(r,e),a[__knownSymbol("asyncIterator")]=()=>a,n("next"),n("throw"),n("return"),a};`;
/**
 * Unique worker identifier counter
 */
let workerIdentifierCounter = 0;
function coroutine(arg1, ...rest) {
    // This is the implementation function that does the heavy lifting
    const implementCoroutine = (config, main, functions) => {
        const maxWorkers = navigator.hardwareConcurrency || 4;
        const customMessageHandler = config?.customMessageHandler; // Use optional chaining
        const workerPool = [];
        const waitingQueue = [];
        const activeWorkers = new Map();
        const pendingMessages = new Map();
        let createdWorkersCount = 0;
        let blobUrlCache = null;
        let isFinalizing = false;
        const generateWorkerScript = (config) => {
            // Provide default empty config if config is undefined
            const safeConfig = config || {};
            const template = safeConfig.template || DEFAULT_WORKER_TEMPLATE;
            const globals = safeConfig.globals || '';
            const helpers = ([HELPER_SCRIPT, ...(safeConfig.helpers || [])]).join('\n');
            const dependencies = functions
                .map((fn) => fn.toString().replace(/function[\s]*\(/, `function ${fn.name || ""}(`))
                .join(';\n');
            const initCode = safeConfig.initCode || '';
            // Ensure the main task is properly stringified as a function
            const mainTaskBody = main.toString().replace(/function[\s]*\(/, `function ${main.name || ""}(`);
            return template
                .replace('{GLOBALS}', globals)
                .replace('{HELPERS}', helpers)
                .replace('{DEPENDENCIES}', dependencies)
                .replace('{INIT_CODE}', initCode)
                .replace('{MAIN_TASK}', mainTaskBody);
        };
        const defaultMessageHandler = (event, worker, pendingTasks) => {
            const msg = event.data;
            const { taskId, payload, error, type, workerId } = msg;
            const pending = pendingTasks.get(taskId);
            switch (type) {
                case 'response':
                    if (pending) {
                        pendingTasks.delete(taskId);
                        pending.resolve(payload);
                    }
                    break;
                case 'error':
                    console.warn(`Error received from worker ${workerId} for task ${taskId}:`, error);
                    if (pending) {
                        pendingTasks.delete(taskId);
                        pending.reject(new Error(error ?? 'Unknown worker error'));
                    }
                    break;
                case 'request':
                    console.warn(`Worker with ID ${workerId} requested data for taskId ${taskId}:`, payload);
                    // Send dummy data back to the worker to prevent it from hanging
                    worker.postMessage({ workerId, taskId, type: 'data', payload: { message: "This is dummy data from the main thread." } });
                    break;
                case 'progress':
                    console.warn(`Worker with ID ${workerId} progress update for taskId ${taskId}:`, payload);
                    break;
                default:
                    console.warn('Unknown message type from worker:', msg);
                    break;
            }
        };
        const createWorker = async () => {
            const workerId = ++workerIdentifierCounter;
            const workerBody = generateWorkerScript(config); // Pass config (which might be undefined)
            if (!blobUrlCache) {
                const blob = new Blob([workerBody], { type: "application/javascript" });
                blobUrlCache = URL.createObjectURL(blob);
            }
            const worker = new Worker(blobUrlCache, { type: "module" });
            const messageHandler = customMessageHandler
                ? (event) => customMessageHandler(event, worker, pendingMessages)
                : (event) => defaultMessageHandler(event, worker, pendingMessages);
            worker.addEventListener("message", messageHandler);
            worker.__id = workerId;
            activeWorkers.set(workerId, worker);
            return { worker, workerId };
        };
        const getIdleWorker = async () => {
            if (workerPool.length > 0)
                return workerPool.shift();
            if (createdWorkersCount < maxWorkers) {
                createdWorkersCount++;
                return await createWorker();
            }
            return new Promise((resolve) => waitingQueue.push(resolve));
        };
        const returnWorker = (workerId) => {
            const worker = activeWorkers.get(workerId);
            if (!worker) {
                console.warn(`Worker with id ${workerId} not found.`);
                return;
            }
            if (isFinalizing) {
                activeWorkers.delete(workerId);
                worker.terminate();
                return;
            }
            if (waitingQueue.length > 0) {
                const resolve = waitingQueue.shift();
                resolve({ worker, workerId });
            }
            else {
                workerPool.push({ worker, workerId });
            }
        };
        const assignTask = async (workerId, data) => {
            const worker = activeWorkers.get(workerId);
            if (!worker) {
                throw new Error(`Worker ${workerId} not found or is not active`);
            }
            const taskId = crypto.randomUUID();
            return new Promise((resolve, reject) => {
                pendingMessages.set(taskId, { resolve, reject });
                worker.postMessage({ workerId, taskId, payload: data, type: 'task' });
            });
        };
        const processTask = async (value) => {
            const { worker, workerId } = await getIdleWorker();
            const taskId = crypto.randomUUID();
            try {
                return await new Promise((resolve, reject) => {
                    pendingMessages.set(taskId, { resolve, reject });
                    worker.postMessage({ workerId, taskId, payload: value, type: 'task' });
                });
            }
            finally {
                returnWorker(workerId);
            }
        };
        const finalize = async () => {
            if (isFinalizing)
                return;
            isFinalizing = true;
            pendingMessages.clear();
            activeWorkers.forEach((worker) => worker.terminate());
            activeWorkers.clear();
            while (workerPool.length > 0) {
                const { worker } = workerPool.pop();
                worker.terminate();
            }
            waitingQueue.length = 0;
            if (blobUrlCache) {
                URL.revokeObjectURL(blobUrlCache);
                blobUrlCache = null;
            }
        };
        const operator = createOperator("coroutine", function (source) {
            let completed = false;
            return {
                next: async () => {
                    while (true) {
                        if (completed || isFinalizing) {
                            return DONE;
                        }
                        const result = await source.next();
                        if (result.done) {
                            completed = true;
                            await finalize();
                            return DONE;
                        }
                        const taskResult = await processTask(result.value);
                        return NEXT(taskResult);
                    }
                },
                async return() {
                    completed = true;
                    await finalize();
                    return DONE;
                },
                async throw(err) {
                    completed = true;
                    await finalize();
                    throw err;
                }
            };
        });
        return {
            ...operator,
            finalize,
            assignTask,
            processTask,
            getIdleWorker,
            returnWorker,
        };
    };
    // --- Overloaded function implementation logic
    if (typeof arg1 === 'function') {
        // Direct invocation: createCoroutine(mainTask, helper1, ...)
        const main = arg1;
        const functions = rest;
        const config = {}; // Provide empty config
        return implementCoroutine(config, main, functions);
    }
    else {
        // Higher-order function: createCoroutine(config)(mainTask, helper1, ...)
        const config = arg1;
        return (main, ...functions) => implementCoroutine(config, main, functions);
    }
}

/**
 * Creates a stream operator that counts the number of items emitted by the source stream.
 *
 * This operator consumes all values from the source stream without emitting anything.
 * Once the source stream completes, it emits a single value, which is the total
 * number of items that were in the source stream. It then completes.
 *
 * @template T The type of the values in the source stream.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const count = () => createOperator("count", function (source) {
    let counted = false;
    let total = 0;
    return {
        async next() {
            if (counted)
                return DONE;
            while (true) {
                const result = await source.next();
                if (result.done)
                    break;
                total++;
            }
            counted = true;
            return NEXT(total);
        },
    };
});

/**
 * Creates a stream operator that emits the most recent value from the source stream
 * only after a specified duration has passed without another new value.
 *
 * This version tracks pending results in the PipeContext and marks
 * superseded values as phantoms.
 *
 * @template T The type of the values in the source and output streams.
 * @param duration The debounce duration in milliseconds.
 * @returns An Operator instance for use in a stream pipeline.
 */
function debounce(duration) {
    return createOperator("debounce", function (source) {
        const output = createSubject();
        let timeoutId = undefined;
        let latestResult = undefined;
        let isCompleted = false;
        let resolvedDuration = undefined;
        const flush = () => {
            if (latestResult !== undefined) {
                // Emit the latest value
                output.next(latestResult.value);
                latestResult = undefined;
            }
            timeoutId = undefined;
            // If the source has completed, complete the output stream
            if (isCompleted) {
                output.complete();
            }
        };
        (async () => {
            try {
                resolvedDuration = isPromiseLike(duration) ? await duration : duration;
                while (true) {
                    const result = await source.next();
                    if (result.done) {
                        isCompleted = true;
                        // If a pending value exists, flush it before completing
                        if (timeoutId === undefined && latestResult !== undefined) {
                            flush();
                        }
                        break;
                    }
                    latestResult = result;
                    // Reset the timer
                    if (timeoutId !== undefined)
                        clearTimeout(timeoutId);
                    if (resolvedDuration !== undefined) {
                        timeoutId = setTimeout(flush, resolvedDuration);
                    }
                }
            }
            catch (err) {
                output.error(err);
            }
            finally {
                isCompleted = true;
                // Clear pending timer
                if (timeoutId !== undefined) {
                    clearTimeout(timeoutId);
                    timeoutId = undefined;
                }
                // Flush any remaining latest value
                if (latestResult !== undefined)
                    flush();
                output.complete();
            }
        })();
        return eachValueFrom(output);
    });
}

/**
 * Creates a stream operator that emits a default value if the source stream is empty.
 *
 * This operator monitors the source stream for any emitted values. If the source
 * stream completes without emitting any values, this operator will emit a single
 * `defaultValue` and then complete. If the source stream does emit at least one value,
 * this operator will pass all values through and will not emit the `defaultValue`.
 *
 * @template T The type of the values in the stream.
 * @param defaultValue The value to emit if the source stream is empty.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const defaultIfEmpty = (defaultValue) => createOperator("defaultIfEmpty", function (source) {
    let emitted = false;
    let completed = false;
    return {
        next: async () => {
            while (true) {
                if (completed) {
                    return DONE;
                }
                const result = await source.next();
                if (!result.done) {
                    emitted = true;
                    return result;
                }
                // Source completed
                if (!emitted) {
                    // Source was empty, emit default value
                    completed = true;
                    const value = isPromiseLike(defaultValue) ? await defaultValue : defaultValue;
                    return NEXT(value);
                }
                // Source had values, just complete
                completed = true;
                return DONE;
            }
        }
    };
});

/**
 * Creates a stream operator that delays the emission of each value from the source stream
 * while tracking pending and phantom states.
 *
 * Each value received from the source is added to `context.pendingResults` and is only
 * resolved once the delay has elapsed and the value is emitted downstream.
 *
 * @template T The type of the values in the source and output streams.
 * @param ms The time in milliseconds to delay each value.
 * @returns An Operator instance for use in a stream's `pipe` method.
 */
function delay(ms) {
    return createOperator('delay', function (source) {
        const output = createSubject();
        let resolvedMs = undefined;
        (async () => {
            try {
                resolvedMs = isPromiseLike(ms) ? await ms : ms;
                while (true) {
                    const result = await source.next();
                    if (result.done)
                        break;
                    // Delay emission
                    if (resolvedMs !== undefined) {
                        await new Promise((resolve) => setTimeout(resolve, resolvedMs));
                    }
                    // Emit downstream
                    output.next(result.value);
                }
            }
            catch (err) {
                output.error(err);
            }
            finally {
                output.complete();
            }
        })();
        return eachValueFrom(output);
    });
}

/**
 * Creates a stream operator that delays the emission of values from the source stream
 * until a separate `notifier` stream emits at least one value.
 *
 * This operator acts as a gate. It buffers all values from the source stream
 * until the `notifier` stream emits its first value. Once the notifier emits,
 * the operator immediately flushes all buffered values and then passes through
 * all subsequent values from the source without delay.
 *
 * If the `notifier` stream completes without ever emitting a value, the buffered
 * values are DISCARDED, and the operator simply waits for the source to complete.
 *
 * @template T The type of the values in the source and output streams.
 * @param notifier The stream that acts as a gatekeeper.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
function delayUntil(notifier) {
    return createOperator("delayUntil", function (source) {
        const output = createSubject();
        let canEmit = false;
        const buffer = [];
        let notifierSubscription;
        const setupNotifier = async () => {
            try {
                const resolvedNotifier = isPromiseLike(notifier) ? await notifier : notifier;
                notifierSubscription = fromAny(resolvedNotifier).subscribe({
                    next: () => {
                        // The gate is open. Flush the buffer and start live emission.
                        if (!canEmit) { // Only run the flush on the *first* emission
                            canEmit = true;
                            for (const v of buffer)
                                output.next(v);
                            buffer.length = 0;
                        }
                        // Unsubscribe from the notifier immediately after the first next()
                        notifierSubscription?.unsubscribe();
                    },
                    error: (err) => {
                        notifierSubscription?.unsubscribe();
                        output.error(err);
                        output.complete();
                    },
                    complete: () => {
                        notifierSubscription?.unsubscribe();
                        // If the notifier completes before emitting (i.e., !canEmit), 
                        // the buffered values are discarded, but the source can now emit.
                        if (!canEmit) {
                            canEmit = true;
                            buffer.length = 0;
                        }
                    },
                });
            }
            catch (err) {
                output.error(err instanceof Error ? err : new Error(String(err)));
                output.complete();
            }
        };
        setupNotifier();
        (async () => {
            try {
                while (true) {
                    const { done, value } = await source.next();
                    if (done)
                        break;
                    if (canEmit) {
                        output.next(value);
                    }
                    else {
                        buffer.push(value);
                    }
                }
            }
            catch (err) {
                output.error(err);
            }
            finally {
                output.complete();
                notifierSubscription?.unsubscribe();
            }
        })();
        return eachValueFrom(output);
    });
}

/**
 * Creates a stream operator that emits values from the source stream only if
 * they are different from the previous value.
 *
 * This operator filters out consecutive duplicate values, ensuring that the
 * output stream only contains values that have changed since the last emission.
 * It's particularly useful for preventing redundant updates in data streams.
 *
 * @template T The type of the values in the stream.
 * @param comparator An optional function that compares the previous and current values.
 * It should return `true` if they are considered the same, and `false` otherwise.
 * If not provided, a strict equality check (`===`) is used.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const distinctUntilChanged = (comparator) => createOperator('distinctUntilChanged', function (source) {
    // State variables to keep track of the last emitted value.
    let lastValue;
    let hasLast = false;
    // The next() method now contains all the logic for a single value.
    return {
        next: async () => {
            while (true) {
                // Await the next value from the source stream.
                const result = await source.next();
                // If the source stream is done, we are also done.
                if (result.done)
                    return DONE;
                if (!hasLast) {
                    lastValue = result.value;
                    hasLast = true;
                    return NEXT(result.value);
                }
                // Check if the value is different from the last one.
                const comparison = comparator ? comparator(lastValue, result.value) : (lastValue === result.value);
                const isSame = comparator
                    ? (isPromiseLike(comparison) ? await comparison : comparison)
                    : comparison;
                const isDistinct = !isSame;
                if (isDistinct) {
                    // If the value is distinct, we update our state and return it as a normal IteratorResult.
                    lastValue = result.value;
                    hasLast = true;
                    return NEXT(result.value);
                }
            }
        },
    };
});

/**
 * Creates a stream operator that filters out consecutive values from the source
 * stream if a specified key's value has not changed.
 *
 * This operator is a specialized version of `distinctUntilChanged`. It is designed
 * to work with streams of objects and checks for uniqueness based on the value
 * of a single property (`key`).
 *
 * @template T The type of the objects in the stream. Must extend `object`.
 * @param key The name of the property to check for changes.
 * @param comparator An optional function to compare the previous and current values of the `key`.
 * It should return `true` if the values are considered the same. If not provided,
 * strict inequality (`!==`) is used.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const distinctUntilKeyChanged = (key, comparator) => createOperator('distinctUntilKeyChanged', function (source) {
    let lastValue;
    let isFirst = true;
    let resolvedKey;
    const getKey = async () => {
        if (resolvedKey === undefined) {
            resolvedKey = isPromiseLike(key) ? await key : key;
        }
        return resolvedKey;
    };
    return {
        next: async () => {
            while (true) {
                const result = await source.next();
                if (result.done)
                    return result;
                const current = result.value;
                const currentKey = await getKey();
                if (isFirst) {
                    isFirst = false;
                    lastValue = current;
                    return NEXT(current);
                }
                const comparison = comparator
                    ? comparator(lastValue[currentKey], current[currentKey])
                    : lastValue[currentKey] === current[currentKey];
                const isSame = comparator
                    ? (isPromiseLike(comparison) ? await comparison : comparison)
                    : comparison;
                const isDistinct = !isSame;
                isFirst = false;
                if (isDistinct) {
                    lastValue = current;
                    return NEXT(current);
                }
            }
        }
    };
});

/**
 * Creates a stream operator that emits only the values at the specified indices from a source stream.
 *
 * This operator takes an `indexIterator` (which can be a synchronous or asynchronous iterator
 * of numbers) and uses it to determine which values from the source stream should be emitted.
 * It acts as a positional filter: each source value is inspected once, and if its zero-based
 * index matches the next index yielded by `indexIterator`, that value is emitted. No buffering
 * of past values occurs. If the iterator completes, the operator completes regardless of
 * remaining source values.
 *
 * @template T The type of the values in the source and output streams.
 * @param indexIterator An iterator or async iterator that provides the zero-based indices
 * of the elements to be emitted.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const select = (indexIterator) => createOperator("select", function (source) {
    function toAsyncIterator(iter) {
        if (typeof iter[Symbol.asyncIterator] === "function") {
            return iter;
        }
        const syncIter = iter;
        return {
            async next() {
                return syncIter.next();
            },
            [Symbol.asyncIterator]() {
                return this;
            }
        };
    }
    const asyncIndexIterator = toAsyncIterator(indexIterator);
    async function* generator() {
        let currentIndex = 0;
        let nextTargetIndexPromise = asyncIndexIterator.next();
        while (true) {
            const result = await source.next();
            if (result.done)
                break;
            const targetIndexResult = await nextTargetIndexPromise;
            if (targetIndexResult.done)
                return;
            const nextTargetIndex = targetIndexResult.value;
            if (currentIndex === nextTargetIndex) {
                yield result.value;
                // fetch next target index
                nextTargetIndexPromise = asyncIndexIterator.next();
            }
            currentIndex++;
        }
    }
    // Return the async iterator directly - operators work with AsyncIterator<T>
    return generator();
});

/**
 * Creates a stream operator that emits only the single value at the specified zero-based index
 * from the source stream.
 *
 * This operator consumes the source stream until it reaches the `targetIndex`. It then
 * emits the value at that position and immediately completes, effectively ignoring all
 * subsequent values. If the source stream completes before reaching the `targetIndex`,
 * the output stream will also complete without emitting any value.
 *
 * @template T The type of the values in the source stream.
 * @param targetIndex The zero-based index of the element to retrieve. Must be a non-negative number.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 * @throws {Error} Throws an error if `targetIndex` is a negative number.
 */
const elementAt = (targetIndex) => select(async function* () {
    const resolvedIndex = isPromiseLike(targetIndex) ? await targetIndex : targetIndex;
    if (resolvedIndex < 0) {
        throw new Error(`Invalid index: ${resolvedIndex}. Index must be non-negative.`);
    }
    yield resolvedIndex; // Yield only the target index
}());

/**
 * Creates a stream operator that emits elements from the source stream at dynamic indices specified
 * by the asynchronous index pattern function.
 *
 * This operator is a powerful tool for selective data retrieval. It uses an `indexPattern`
 * function to determine which elements to pull from the source stream. The function is
 * called repeatedly, with the current iteration count as an argument, and should return the
 * zero-based index of the next element to emit. The process stops when the function returns `undefined`.
 *
 * This is useful for tasks such as:
 * - Sampling a stream at a fixed interval (e.g., every 10th element).
 * - Picking a specific, non-sequential set of elements.
 * - Creating a custom, sparse output stream.
 *
 * @template T The type of the values in the source stream.
 * @param indexPattern The function that specifies the indices to emit. It receives the current
 * iteration count and should return the next index to emit or `undefined` to stop.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const elementNth = (indexPattern) => {
    const indexIterator = (async function* () {
        let iteration = 0;
        while (true) {
            const nextIndexResult = indexPattern(iteration);
            const nextIndex = isPromiseLike(nextIndexResult) ? await nextIndexResult : nextIndexResult;
            if (nextIndex === undefined)
                break;
            yield nextIndex;
            iteration++;
        }
    })();
    return select(indexIterator);
};

/**
 * Creates a stream operator that tests if all values from the source stream satisfy a predicate.
 *
 * This operator consumes the source stream and applies the provided `predicate` function
 * to each value.
 * - If the `predicate` returns a truthy value for every element until the source stream
 * completes, the operator emits `true`.
 * - If the `predicate` returns a falsy value for any element, the operator immediately
 * emits `false` and then completes, effectively "short-circuiting" the evaluation.
 *
 * This is a "pull-based" equivalent of `Array.prototype.every` and is useful for validating
 * data streams. The operator will emit only a single boolean value before it completes.
 *
 * @template T The type of the values in the source stream.
 * @param predicate The function to test each value. It receives the value and its index.
 * It can be synchronous or asynchronous.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const every = (predicate) => createOperator("every", function (source) {
    let index = 0;
    let emitted = false;
    return {
        next: async () => {
            if (emitted)
                return DONE;
            while (true) {
                const result = await source.next();
                if (result.done) {
                    emitted = true;
                    return NEXT(true);
                }
                const predicateResult = predicate(result.value, index++);
                const passes = isPromiseLike(predicateResult) ? await predicateResult : predicateResult;
                if (!passes) {
                    emitted = true;
                    return NEXT(false);
                }
            }
        },
    };
});

/**
 * Creates a stream operator that recursively processes values from a source stream.
 *
 * This operator is designed for traversing tree-like or hierarchical data structures.
 * For each value from the source, it checks if it meets a `condition`. If it does,
 * it applies a `project` function to get a new "inner" stream of children. These
 * children are then added to an internal queue and processed in the same recursive manner.
 *
 * The operator supports both depth-first and breadth-first traversal strategies and
 * can be configured with a maximum recursion depth to prevent runaway processing.
 *
 * @template T The type of the values in the source and output streams.
 * @param condition A function that returns a boolean indicating whether to recurse on a value.
 * @param project A function that takes a value and returns a stream of new values to be
 * recursively processed.
 * @param options An optional configuration object for traversal behavior.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const recurse = (condition, project, options = {}) => createOperator('recurse', function (source) {
    const queue = [];
    let sourceDone = false;
    const enqueueChildren = async (value, depth) => {
        if (options.maxDepth !== undefined && depth >= options.maxDepth)
            return;
        const shouldRecurse = condition(value);
        if (isPromiseLike(shouldRecurse) ? !(await shouldRecurse) : !shouldRecurse)
            return;
        const projected = project(value);
        const normalized = isPromiseLike(projected) ? await projected : projected;
        for await (const child of eachValueFrom(fromAny(normalized))) {
            const item = { value: child, depth: depth + 1 };
            if (options.traversal === 'breadth') {
                queue.push(item);
            }
            else {
                queue.unshift(item);
            }
        }
    };
    return {
        next: async () => {
            while (true) {
                // Refill queue from source if it's empty
                while (queue.length === 0 && !sourceDone) {
                    const result = await source.next();
                    if (result.done) {
                        sourceDone = true;
                        break;
                    }
                    queue.push({ value: result.value, depth: 0 });
                }
                // If the queue now has items, process them
                if (queue.length > 0) {
                    const item = options.traversal === 'breadth' ? queue.shift() : queue.pop();
                    await enqueueChildren(item.value, item.depth);
                    return NEXT(item.value);
                }
                // If queue is empty and source is done, we're done
                if (sourceDone && queue.length === 0) {
                    return DONE;
                }
                // Yield control briefly (avoid busy waiting)
                await new Promise((resolve) => setTimeout(resolve, 0));
            }
        },
    };
});

/**
 * Creates a stream operator that recursively expands each emitted value.
 *
 * This operator takes each value from the source stream and applies the `project`
 * function to it, which must return a new stream. It then recursively applies
 * the same logic to each value emitted by that new stream, effectively
 * flattening an infinitely deep, asynchronous data structure.
 *
 * This is particularly useful for traversing graph or tree-like data, such as
 * file directories or hierarchical API endpoints, where each item might lead
 * to a new collection of items that also need to be processed.
 *
 * @template T The type of the values in the source and output streams.
 * @param project A function that takes a value and returns a stream of new values
 * to be expanded.
 * @param options An optional configuration object for the underlying `recurse` operator.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const expand = (project, options = {}) => recurse(() => true, project, options);

/**
 * Creates a stream operator that filters values emitted by the source stream.
 *
 * This operator provides flexible filtering capabilities. It processes each value
 * from the source stream and passes it through to the output stream only if it meets
 * a specific criterion.
 *
 * The filtering can be configured in one of three ways:
 * - A **predicate function**: A function that returns `true` for values to be included.
 * - A **single value**: Only values that are strictly equal (`===`) to this value are included.
 * - An **array of values**: Only values that are present in this array are included.
 *
 * @template T The type of the values in the stream.
 * @param predicateOrValue The filtering criterion. Can be a predicate function, a single value, or an array of values.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const filter = (predicateOrValue) => createOperator('filter', function (source) {
    let index = 0;
    return {
        next: async () => {
            while (true) {
                const result = await source.next();
                if (result.done)
                    return result;
                const value = result.value;
                let shouldInclude = false;
                if (typeof predicateOrValue === 'function') {
                    const predicateResult = predicateOrValue(value, index);
                    shouldInclude = isPromiseLike(predicateResult) ? await predicateResult : predicateResult;
                }
                else if (Array.isArray(predicateOrValue)) {
                    shouldInclude = predicateOrValue.includes(value);
                }
                else {
                    shouldInclude = value === predicateOrValue;
                }
                if (shouldInclude) {
                    index++; // Increment index only if included
                    // If the value passes the filter, return it as a normal IteratorResult.
                    return NEXT(value);
                }
            }
        }
    };
});

/**
 * Creates a stream operator that emits only the first element from the source stream
 * that matches an optional predicate.
 *
 * This operator is designed to find a specific value and then immediately terminate.
 * - If a `predicate` function is provided, the operator will emit the first value for which
 * the predicate returns a truthy value.
 * - If no predicate is provided, it will simply emit the very first value from the source.
 *
 * After emitting a single value, the operator completes. If the source stream completes
 * before a matching value is found, an error is thrown.
 *
 * @template T The type of the values in the source stream.
 * @param predicate An optional function to test each value. It receives the value
 * and should return `true` to indicate a match.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 * @throws {Error} Throws an error with the message "No elements in sequence" if no matching
 * value is found before the source stream completes.
 */
const first = (predicate) => createOperator('first', function (source) {
    let found = false;
    let firstValue;
    let sourceDone = false;
    return {
        next: async () => {
            if (found) {
                return DONE;
            }
            if (sourceDone) {
                throw new Error("No elements in sequence");
            }
            while (!found) {
                const result = await source.next();
                if (result.done) {
                    sourceDone = true;
                    throw new Error("No elements in sequence");
                }
                const value = result.value;
                const predicateResult = predicate ? predicate(value) : true;
                const matches = predicate ? (isPromiseLike(predicateResult) ? await predicateResult : predicateResult) : predicateResult;
                if (matches) {
                    found = true;
                    firstValue = value;
                    return NEXT(firstValue);
                }
            }
            return DONE;
        }
    };
});

/**
 * Creates a stream operator that routes each source value through a specific handler
 * based on matching predicates defined in the provided `ForkOption`s.
 *
 * For each value from the source stream:
 * 1. Iterates over the `options` array.
 * 2. Executes the `on` predicate for each option until one returns `true`.
 * 3. Calls the corresponding `handler` for the first matching option.
 * 4. Flattens the result (stream, value, promise, or array) sequentially into the output stream.
 *
 * If no predicate matches a value, an error is thrown.
 *
 * This operator allows conditional branching in streams based on the content of each item.
 *
 * @template T The type of values in the source stream.
 * @template R The type of values emitted by the output stream.
 * @param options {@link ForkOption} objects defining predicates and handlers.
 * @returns An {@link Operator} instance suitable for use in a stream's `pipe` method.
 *
 * @throws {Error} If a source value does not match any predicate.
 */
const fork = (...options) => createOperator('fork', function (source) {
    const resolvedOptions = options.flatMap(option => Array.isArray(option) ? option : [option]);
    let outerIndex = 0;
    let innerIterator = null;
    let outerValue;
    return {
        next: async () => {
            while (true) {
                // If no active inner iterator, get next outer value
                if (!innerIterator) {
                    const result = await source.next();
                    if (result.done) {
                        return DONE;
                    }
                    let matched;
                    outerValue = result.value;
                    for (const option of resolvedOptions) {
                        const predicateResult = option.on(outerValue, outerIndex++);
                        if (isPromiseLike(predicateResult) ? await predicateResult : predicateResult) {
                            matched = option;
                            break;
                        }
                    }
                    if (!matched) {
                        throw new Error(`No handler found for value: ${outerValue}`);
                    }
                    innerIterator = eachValueFrom(fromAny(matched.handler(outerValue)));
                }
                // Pull next inner value
                const innerResult = await innerIterator.next();
                if (innerResult.done) {
                    innerIterator = null;
                    continue;
                }
                return NEXT(innerResult.value);
            }
        }
    };
});

/**
 * Creates a stream operator that groups values from the source stream by a computed key.
 *
 * This operator is a projection operator that transforms a stream of values into a
 * stream of `GroupItem` objects. For each value from the source, it applies the
 * `keySelector` function to determine a key and then emits an object containing both
 * the original value and the computed key.
 *
 * This operator is the first step in a typical grouping pipeline. The resulting stream
 * of `GroupItem` objects can then be processed further by other operators (e.g., `scan`
 * or `reduce`) to perform a true grouping into collections.
 *
 * @template T The type of the values in the source stream.
 * @template K The type of the key computed by `keySelector`.
 * @param keySelector A function that takes a value from the source stream and returns
 * a key. This function can be synchronous or asynchronous.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const groupBy = (keySelector) => createOperator("groupBy", function (source) {
    let completed = false;
    return {
        next: async () => {
            while (true) {
                if (completed) {
                    return DONE;
                }
                const result = await source.next();
                if (result.done) {
                    completed = true;
                    return DONE;
                }
                const keyResult = keySelector(result.value);
                const key = isPromiseLike(keyResult) ? await keyResult : keyResult;
                return NEXT({ key, value: result.value });
            }
        }
    };
});

/**
 * Creates a stream operator that ignores all values emitted by the source stream.
 *
 * This operator consumes the source stream but does not emit any values. It only
 * forwards the completion or error signal from the source stream. This is useful
 * when you only care about the "end" of an operation, not the intermediate results.
 * For example, waiting for a stream of side effects to complete before continuing.
 *
 * @template T The type of the values in the source stream (which are ignored).
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const ignoreElements = () => createOperator("ignoreElements", function (source) {
    return {
        next: async () => {
            while (true) {
                const result = await source.next();
                if (result.done) {
                    // If the source is done, we are also done.
                    return DONE;
                }
            }
        }
    };
});

/**
 * Creates a stream operator that emits only the last value from the source stream
 * that matches an optional predicate.
 *
 * This operator must consume the entire source stream to find the last matching
 * value. It caches the last value that satisfies the `predicate` (or the last
 * value of the stream if no predicate is provided) and emits it only when the
 * source stream completes.
 *
 * @template T The type of the values in the source stream.
 * @param predicate An optional function to test each value. It receives the value
 * and should return `true` to indicate a match.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 * @throws {Error} Throws an error with the message "No elements in sequence" if no
 * matching value is found before the source stream completes.
 */
const last = (predicate) => createOperator("last", function (source) {
    let lastValue = undefined;
    let hasMatch = false;
    let finished = false;
    return {
        next: async () => {
            while (true) {
                if (finished)
                    return DONE;
                const result = await source.next();
                if (result.done) {
                    finished = true;
                    if (!hasMatch)
                        throw new Error("No elements in sequence");
                    return NEXT(lastValue);
                }
                const value = result.value;
                const predicateResult = predicate ? predicate(value) : true;
                const matches = predicate ? (isPromiseLike(predicateResult) ? await predicateResult : predicateResult) : predicateResult;
                if (matches) {
                    if (hasMatch) {
                        lastValue = value;
                        continue;
                    }
                    else {
                        lastValue = value;
                        hasMatch = true;
                        continue;
                    }
                }
            }
        }
    };
});

/**
 * Creates a stream operator that applies a transformation function to each value
 * emitted by the source stream.
 *
 * This operator is a fundamental part of stream processing. It consumes each value
 * from the source, passes it to the `transform` function, and then emits the result
 * of that function. This is a one-to-one mapping, meaning the output stream will
 * have the same number of values as the source stream, but with potentially different
 * content and/or type.
 *
 * @template T The type of the values in the source stream.
 * @template R The type of the values in the output stream.
 * @param transform The transformation function to apply to each value. It receives
 * the value and its index. This function can be synchronous or asynchronous.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const map = (transform) => createOperator('map', function (source) {
    let index = 0;
    let completed = false;
    return {
        async next() {
            while (true) {
                if (completed) {
                    return DONE;
                }
                const result = await source.next();
                if (result.done) {
                    completed = true;
                    return DONE;
                }
                const transformedResult = transform(result.value, index++);
                const transformedValue = isPromiseLike(transformedResult) ? await transformedResult : transformedResult;
                return NEXT(transformedValue);
            }
        },
    };
});

/**
 * Creates a stream operator that emits the maximum value from the source stream.
 *
 * This is a terminal operator that consumes the entire source lazily,
 * emitting phantoms along the way and finally emitting the maximum value.
 *
 * @template T The type of the values in the source stream.
 * @param comparator Optional comparison function: positive if `a > b`, negative if `a < b`.
 * @returns An `Operator` instance usable in a stream's `pipe` method.
 */
const max = (comparator) => createOperator("max", function (source) {
    let maxValue;
    let hasMax = false;
    let emittedMax = false;
    return {
        next: async () => {
            while (true) {
                // If all values processed, emit max once and complete
                if (emittedMax && !hasMax)
                    return DONE;
                if (emittedMax && hasMax) {
                    emittedMax = true;
                    return DONE;
                }
                const result = await source.next();
                if (result.done) {
                    // Emit final max if exists
                    if (hasMax && !emittedMax) {
                        emittedMax = true;
                        return NEXT(maxValue);
                    }
                    return DONE;
                }
                const value = result.value;
                if (!hasMax) {
                    maxValue = value;
                    hasMax = true;
                    continue;
                }
                const cmpResult = comparator ? comparator(value, maxValue) : (value > maxValue ? 1 : -1);
                const cmp = isPromiseLike(cmpResult) ? await cmpResult : cmpResult;
                if (cmp > 0) {
                    // previous max becomes phantom
                    maxValue = value;
                }
            }
        },
    };
});

/**
 * Creates a stream operator that maps each value from the source stream to an "inner" stream
 * and merges all inner streams concurrently into a single output stream.
 *
 * For each value from the source stream:
 * 1. The `project` function is called with the value and its index.
 * 2. The returned value is normalized into a stream using {@link fromAny}.
 * 3. The inner stream is consumed concurrently with all other active inner streams.
 * 4. Emitted values from all inner streams are interleaved into the output stream
 *    in the order they are produced, without waiting for other inner streams to complete.
 *
 * This operator is useful for performing parallel asynchronous operations while
 * preserving all emitted values in a merged output.
 *
 * @template T The type of values in the source stream.
 * @template R The type of values emitted by the inner and output streams.
 * @param project A function that maps a source value and its index to either:
 *   - a {@link Stream<R>},
 *   - a {@link MaybePromise<R>} (value or promise),
 *   - or an array of `R`.
 * @returns An {@link Operator} instance that can be used in a stream's `pipe` method.
 */
function mergeMap(project) {
    return createOperator('mergeMap', function (source) {
        const output = createSubject();
        let index = 0;
        let activeInner = 0;
        let outerCompleted = false;
        let errorOccurred = false;
        // Process each inner stream concurrently.
        const processInner = async (innerStream) => {
            try {
                for await (const val of innerStream) {
                    if (errorOccurred)
                        break;
                    output.next(val);
                }
            }
            catch (err) {
                if (!errorOccurred) {
                    errorOccurred = true;
                    output.error(err);
                }
            }
            finally {
                activeInner--;
                if (outerCompleted && activeInner === 0 && !errorOccurred) {
                    output.complete();
                }
            }
        };
        (async () => {
            try {
                while (true) {
                    const result = await source.next();
                    if (result.done)
                        break;
                    if (errorOccurred)
                        break;
                    const projected = project(result.value, index++);
                    const normalized = isPromiseLike(projected) ? await projected : projected;
                    const inner = fromAny(normalized);
                    activeInner++;
                    processInner(inner);
                }
                outerCompleted = true;
                if (activeInner === 0 && !errorOccurred) {
                    output.complete();
                }
            }
            catch (err) {
                if (!errorOccurred) {
                    errorOccurred = true;
                    output.error(err);
                }
            }
        })();
        return eachValueFrom(output);
    });
}

/**
 * Creates a stream operator that emits the minimum value from the source stream.
 *
 * This is a terminal operator that must consume the entire source stream before
 * it can emit a single value. It iterates through all values, keeping track of
 * the smallest one seen so far.
 *
 * @template T The type of the values in the source stream.
 * @param comparator An optional function to compare two values. It should return a negative
 * number if `a` is less than `b`, a positive number if `a` is greater than `b`, and zero
 * if they are equal. Defaults to using the `<` operator for comparison.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
/**
 * Creates a stream operator that emits the minimum value from the source stream.
 *
 * This is a terminal operator that consumes the source lazily.
 * It keeps track of the smallest value seen so far and emits phantoms for intermediate values.
 *
 * @template T The type of the values in the source stream.
 * @param comparator Optional function to compare two values. Returns negative if `a < b`.
 * @returns An `Operator` instance usable in a stream's `pipe` method.
 */
const min = (comparator) => createOperator("min", function (source) {
    let minValue;
    let hasMin = false;
    let emittedMin = false;
    return {
        next: async () => {
            while (true) {
                const result = await source.next();
                if (result.done) {
                    // Emit the final minimum once
                    if (hasMin && !emittedMin) {
                        emittedMin = true;
                        return NEXT(minValue);
                    }
                    return DONE;
                }
                const value = result.value;
                if (!hasMin) {
                    minValue = value;
                    hasMin = true;
                    continue;
                }
                const cmpResult = comparator ? comparator(value, minValue) : (value < minValue ? -1 : 1);
                const cmp = isPromiseLike(cmpResult) ? await cmpResult : cmpResult;
                if (cmp < 0) {
                    minValue = value;
                }
            }
        },
    };
});

/**
 * Creates a stream operator that schedules the emission of each value from the source
 * stream on a specified JavaScript task queue.
 *
 * This operator is a scheduler. It decouples the timing of value production from
 * its consumption, allowing you to control when values are emitted to downstream
 * operators. This is essential for preventing long-running synchronous operations
 * from blocking the main thread and for prioritizing different types of work.
 *
 * The operator supports three contexts:
 * - `"microtask"`: Emits the value at the end of the current task using `queueMicrotask`.
 * - `"macrotask"`: Emits the value in the next event loop cycle using `setTimeout(0)`.
 * - `"idle"`: Emits the value when the browser is idle using `requestIdleCallback`.
 *
 * @template T The type of the values in the source and output streams.
 * @param context The JavaScript task queue context to schedule emissions on.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
/**
 * Creates a stream operator that schedules the emission of each value from the source
 * stream on a specified JavaScript task queue.
 *
 * This operator is a scheduler. It decouples the timing of value production from
 * its consumption, allowing you to control when values are emitted to downstream
 * operators. This is essential for preventing long-running synchronous operations
 * from blocking the main thread and for prioritizing different types of work.
 *
 * The operator supports three contexts:
 * - `"microtask"`: Emits the value at the end of the current task using `queueMicrotask`.
 * - `"macrotask"`: Emits the value in the next event loop cycle using `setTimeout(0)`.
 * - `"idle"`: Emits the value when the browser is idle using `requestIdleCallback`.
 *
 * @template T The type of the values in the source and output streams.
 * @param context The JavaScript task queue context to schedule emissions on.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const observeOn = (context) => {
    return createOperator('observeOn', function (source) {
        const output = createSubject();
        const scheduledPromises = [];
        (async () => {
            try {
                const contextValue = isPromiseLike(context) ? await context : context;
                const schedule = contextValue === 'microtask'
                    ? (fn) => queueMicrotask(fn)
                    : contextValue === 'macrotask'
                        ? (fn) => setTimeout(fn, 0)
                        : (fn) => requestIdleCallback(fn);
                while (true) {
                    const result = await source.next();
                    if (result.done)
                        break;
                    const p = new Promise((resolve) => {
                        schedule(() => {
                            try {
                                output.next(result.value);
                            }
                            finally {
                                resolve();
                            }
                        });
                    });
                    scheduledPromises.push(p);
                }
                // Wait for all scheduled emissions before completing
                await Promise.all(scheduledPromises);
            }
            catch (err) {
                output.error(err);
            }
            finally {
                output.complete();
            }
        })();
        const iterator = eachValueFrom(output);
        let completed = false;
        return {
            async next() {
                while (true) {
                    if (completed)
                        return DONE;
                    const result = await iterator.next();
                    if (result.done) {
                        completed = true;
                        return DONE;
                    }
                    return { type: 'next', value: result.value };
                }
            }
        };
    });
};

/**
 * Creates a stream operator that partitions the source stream into two groups based on a predicate.
 *
 * This operator is a specialized form of `groupBy`. For each value from the source stream,
 * it applies the provided `predicate` function. It then emits a new object, a `GroupItem`,
 * containing the original value and a key of `"true"` or `"false"`, indicating whether the
 * value satisfied the predicate.
 *
 * This operator does not create two physical streams, but rather tags each item with its
 * group membership, allowing for subsequent conditional routing or processing.
 *
 * @template T The type of the values in the source stream.
 * @param predicate A function that takes a value and its index and returns a boolean or
 * `Promise<boolean>`. `true` for one group, `false` for the other.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method,
 * emitting objects of type `GroupItem<T, "true" | "false">`.
 */
const partition = (predicate) => createOperator('partition', function (source) {
    let index = 0;
    let completed = false;
    return {
        next: async () => {
            while (true) {
                if (completed) {
                    return DONE;
                }
                const result = await source.next();
                if (result.done) {
                    completed = true;
                    return DONE;
                }
                const predicateResult = predicate(result.value, index++);
                const key = (isPromiseLike(predicateResult) ? await predicateResult : predicateResult) ? "true" : "false";
                return NEXT({ key, value: result.value });
            }
        }
    };
});

/**
 * Creates a stream operator that accumulates all values from the source stream
 * into a single value using a provided accumulator function.
 *
 * This operator consumes the source lazily and emits intermediate values as phantoms.
 * It will always emit at least the seed value if the stream is empty.
 *
 * @template T The type of the values in the source stream.
 * @template A The type of the accumulated value.
 * @param accumulator Function combining current accumulated value with a new value.
 * Can be synchronous or asynchronous.
 * @param seed Initial value for the accumulator.
 * @returns An `Operator` instance usable in a stream's `pipe` method.
 */
const reduce = (accumulator, seed) => createOperator("reduce", function (source) {
    let finalValue = seed;
    let emittedFinal = false;
    return {
        next: async () => {
            while (true) {
                const result = await source.next();
                if (result.done) {
                    if (!emittedFinal) {
                        emittedFinal = true;
                        return NEXT(finalValue);
                    }
                    return DONE;
                }
                const accumulated = accumulator(finalValue, result.value);
                finalValue = isPromiseLike(accumulated) ? await accumulated : accumulated;
            }
        },
    };
});

/**
 * Creates a stream operator that emits the most recent value from the source stream
 * at a fixed periodic interval while tracking pending and phantom states.
 *
 * Values that arrive faster than the period are considered phantoms if skipped,
 * and pending results are tracked in PipeContext until resolved or emitted.
 *
 * @template T The type of the values in the source and output streams.
 * @param period The time in milliseconds between each emission.
 * @returns An Operator instance for use in a stream's `pipe` method.
 */
const sample = (period) => createOperator('sample', function (source) {
    const output = createSubject();
    let lastResult;
    let skipped = false;
    let intervalId = null;
    let resolvedPeriod = undefined;
    const startSampling = () => {
        if (resolvedPeriod === undefined) {
            return;
        }
        intervalId = setInterval(async () => {
            if (!lastResult)
                return;
            if (!skipped) {
                output.next(lastResult.value);
            }
            skipped = true;
        }, resolvedPeriod);
    };
    const stopSampling = () => {
        if (intervalId !== null)
            clearInterval(intervalId);
        intervalId = null;
    };
    (async () => {
        try {
            resolvedPeriod = isPromiseLike(period) ? await period : period;
            startSampling();
            while (true) {
                const result = await source.next();
                if (result.done)
                    break;
                lastResult = result;
                skipped = false;
            }
            // Emit final value
            if (lastResult) {
                output.next(lastResult.value);
            }
        }
        catch (err) {
            output.error(err);
        }
        finally {
            stopSampling();
            output.complete();
        }
    })();
    return eachValueFrom(output);
});

/**
 * Creates a stream operator that accumulates values from the source stream,
 * emitting each intermediate accumulated result.
 *
 * This operator is stateful and is ideal for scenarios where you need to maintain
 * a running total or build a state object over the life of a stream. It takes a
 * `seed` value and an `accumulator` function. For each value from the source,
 * it applies the accumulator and emits the new result immediately.
 *
 * @template T The type of the values in the source stream.
 * @template R The type of the accumulated value and the output stream.
 * @param accumulator The function that combines the current accumulated value
 * with the new value from the source. This function can be synchronous or asynchronous.
 * @param seed The initial value for the accumulator.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const scan = (accumulator, seed) => createOperator("scan", function (source) {
    let acc = seed;
    let index = 0;
    let completed = false;
    return {
        next: async () => {
            while (true) {
                if (completed) {
                    return DONE;
                }
                const result = await source.next();
                if (result.done) {
                    completed = true;
                    return DONE;
                }
                const accumulated = accumulator(acc, result.value, index++);
                acc = isPromiseLike(accumulated) ? await accumulated : accumulated;
                return NEXT(acc);
            }
        },
    };
});

/**
 * Creates a stream operator that shares a single subscription to the source stream
 * and replays a specified number of past values to new subscribers.
 *
 * This operator multicasts the source stream, ensuring that multiple downstream
 * consumers can receive values from a single source connection. It uses an internal
 * `ReplaySubject` to cache the most recent values. When a new consumer subscribes,
 * it immediately receives these cached values before receiving new ones.
 *
 * This is useful for:
 * - Preventing redundant execution of a source stream (e.g., a network request).
 * - Providing a "state history" to late subscribers.
 *
 * @template T The type of the values in the stream.
 * @param bufferSize The number of last values to replay to new subscribers. Defaults to `Infinity`.
 *                   Can be a Promise that resolves to a number.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
function shareReplay(bufferSize = Infinity) {
    let isConnected = false;
    let output;
    let resolvedSize;
    const isSync = !isPromiseLike(bufferSize);
    if (isSync) {
        resolvedSize = bufferSize;
    }
    const connectSource = (source) => {
        isConnected = true;
        (async () => {
            try {
                while (true) {
                    const result = await source.next();
                    if (result.done)
                        break;
                    output.next(result.value);
                }
            }
            catch (err) {
                output.error(err);
            }
            finally {
                output.complete();
            }
        })();
    };
    return createOperator('shareReplay', function (source) {
        // Short path: plain value, return synchronously
        if (isSync) {
            if (!output)
                output = createReplaySubject(resolvedSize);
            if (!isConnected)
                connectSource(source);
            return eachValueFrom(output);
        }
        // Long path: Promise, wrap in async generator
        return (async function* () {
            if (resolvedSize === undefined) {
                resolvedSize = await bufferSize;
            }
            if (!output)
                output = createReplaySubject(resolvedSize);
            if (!isConnected)
                connectSource(source);
            yield* eachValueFrom(output);
        })();
    });
}

/**
 * Creates a stream operator that skips the first specified number of values from the source stream.
 *
 * This operator is useful for "fast-forwarding" a stream. It consumes the initial `count` values
 * from the source stream without emitting them to the output. Once the count is reached,
 * it begins to pass all subsequent values through unchanged.
 *
 * @template T The type of the values in the source and output streams.
 * @param count The number of values to skip from the beginning of the stream.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const skip = (count) => createOperator('skip', function (source) {
    let counter;
    const getCounter = () => {
        if (counter !== undefined) {
            return counter;
        }
        if (isPromiseLike(count)) {
            return count.then((val) => {
                counter = val;
                return val;
            });
        }
        counter = count;
        return counter;
    };
    return {
        next: async () => {
            while (true) {
                const result = await source.next();
                if (result.done)
                    return DONE;
                const counterOrPromise = getCounter();
                const currentCounter = isPromiseLike(counterOrPromise) ? await counterOrPromise : counterOrPromise;
                if (currentCounter > 0) {
                    counter = currentCounter - 1;
                    continue;
                }
                return NEXT(result.value);
            }
        },
    };
});

/**
 * Creates a stream operator that skips all values from the source stream until
 * a value is emitted by a `notifier` stream.
 *
 * This operator controls the flow of data based on an external signal. It initially
 * drops all values from the source stream. It also subscribes to a separate `notifier`
 * stream. When the notifier emits its first value, the operator's internal state
 * changes, allowing all subsequent values from the source stream to pass through.
 *
 * This is useful for delaying the start of a data-intensive process until a specific
 * condition is met, for example, waiting for a user to click a button or for
 * an application to finish loading.
 *
 * @template T The type of the values in the source and output streams.
 * @param notifier The stream that, upon its first emission, signals that the operator
 * should stop skipping values.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
function skipUntil(notifier) {
    return createOperator('skipUntil', function (source) {
        const output = createSubject();
        let canEmit = false;
        // Subscribe to notifier
        const notifierSubscription = fromAny(notifier).subscribe({
            next: () => {
                canEmit = true;
                notifierSubscription.unsubscribe();
            },
            error: (err) => {
                notifierSubscription.unsubscribe();
                output.error(err);
                output.complete();
            },
            complete: () => {
                notifierSubscription.unsubscribe();
            },
        });
        // Process source
        (async () => {
            try {
                while (true) {
                    const { done, value } = await source.next();
                    if (done)
                        break;
                    if (canEmit)
                        output.next(value);
                }
            }
            catch (err) {
                if (!output.completed())
                    output.error(err);
            }
            finally {
                output.complete();
                notifierSubscription.unsubscribe();
            }
        })();
        return eachValueFrom(output);
    });
}

/**
 * Creates a stream operator that skips values from the source stream while a predicate returns true.
 *
 * This operator is a powerful filtering tool for removing a contiguous prefix of a stream.
 * It consumes values from the source and applies the `predicate` function to each one.
 * As long as the predicate returns `true`, the values are ignored. As soon as the predicate
 * returns `false` for the first time, this operator begins to emit that value and all
 * subsequent values from the source, regardless of whether they satisfy the predicate.
 *
 * @template T The type of the values in the source and output streams.
 * @param predicate The function to test each value. `true` means to continue skipping,
 * and `false` means to stop skipping and begin emitting.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const skipWhile = (predicate) => createOperator('skipWhile', function (source) {
    let skipping = true;
    return {
        next: async () => {
            while (true) {
                const result = await source.next();
                if (result.done)
                    return DONE;
                if (skipping) {
                    const predicateResult = predicate(result.value);
                    const shouldSkip = isPromiseLike(predicateResult) ? await predicateResult : predicateResult;
                    if (!shouldSkip) {
                        skipping = false;
                        return NEXT(result.value);
                    }
                    // Still skipping, ignore this value
                }
                else {
                    return NEXT(result.value);
                }
            }
        }
    };
});

/**
 * Creates a stream operator that emits pairs of values from the source stream,
 * where each pair consists of the previous and the current value.
 *
 * This operator is a powerful tool for comparing consecutive values in a stream.
 * It maintains an internal state to remember the last value it received. For
 * each new value, it creates a tuple of `[previousValue, currentValue]` and
 * emits it to the output stream.
 *
 * The very first value emitted will have `undefined` as its "previous" value.
 *
 * @template T The type of the values in the source stream.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method,
 * emitting tuples of `[T | undefined, T]`.
 */
const slidingPair = () => createOperator('slidingPair', function (source) {
    let prev = undefined;
    let first = true;
    let completed = false;
    return {
        next: async () => {
            while (true) {
                if (completed) {
                    return DONE;
                }
                const result = await source.next();
                if (result.done) {
                    completed = true;
                    return DONE;
                }
                const value = [first ? undefined : prev, result.value];
                prev = result.value;
                first = false;
                return NEXT(value);
            }
        }
    };
});

/**
 * Creates a stream operator that tests if at least one value from the source stream satisfies a predicate.
 *
 * This operator consumes the source stream and applies the provided `predicate` function
 * to each value.
 * - If the `predicate` returns a truthy value for any element, the operator immediately
 * emits `true` and then completes, effectively "short-circuiting" the evaluation.
 * - If the source stream completes without the `predicate` ever returning a truthy value,
 * the operator emits `false`.
 *
 * This is a "pull-based" equivalent of `Array.prototype.some` and is useful for validating
 * data streams. The operator will emit only a single boolean value before it completes.
 *
 * @template T The type of the values in the source stream.
 * @param predicate The function to test each value. It receives the value and its index.
 * It can be synchronous or asynchronous.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const some = (predicate) => createOperator('some', function (source) {
    let evaluated = false;
    let found = false;
    let index = 0;
    return {
        next: async () => {
            if (evaluated) {
                return DONE;
            }
            try {
                while (true) {
                    const result = await source.next();
                    if (result.done)
                        break;
                    const predicateResult = predicate(result.value, index++);
                    if (isPromiseLike(predicateResult) ? await predicateResult : predicateResult) {
                        found = true;
                        break; // Predicate matched
                    }
                }
            }
            finally {
                evaluated = true;
            }
            return NEXT(found);
        }
    };
});

/**
 * Creates a stream operator that maps each value from the source stream to a new inner stream
 * and "switches" to emitting values from the most recent inner stream, canceling the previous one.
 *
 * For each value from the source:
 * 1. The `project` function is called with the value and its index.
 * 2. The returned value is normalized into a stream using {@link fromAny}.
 * 3. The operator subscribes to the new inner stream and immediately cancels any previous active inner stream.
 * 4. Only values from the latest inner stream are emitted.
 *
 * This operator is useful for scenarios such as:
 * - Type-ahead search where only the latest query results are relevant.
 * - Handling user events where new events invalidate previous operations.
 *
 * @template T The type of values in the source stream.
 * @template R The type of values emitted by the inner and output streams.
 * @param project A function that maps a source value and its index to either:
 *   - a {@link Stream<R>},
 *   - a {@link MaybePromise<R>} (value or promise),
 *   - or an array of `R`.
 * @returns An {@link Operator} instance suitable for use in a stream's `pipe` method.
 */
function switchMap(project) {
    return createOperator("switchMap", function (source) {
        const output = createSubject();
        let currentSubscription = null;
        let inputCompleted = false;
        let currentInnerStreamId = 0;
        let index = 0;
        const checkComplete = () => {
            if (inputCompleted && !currentSubscription) {
                output.complete();
            }
        };
        const subscribeToInner = async (innerStream, streamId) => {
            // Cancel previous inner stream
            if (currentSubscription) {
                currentSubscription.unsubscribe();
                currentSubscription = null;
            }
            currentSubscription = innerStream.subscribe({
                next: (value) => {
                    if (streamId === currentInnerStreamId) {
                        output.next(value);
                    }
                },
                error: (err) => {
                    if (streamId === currentInnerStreamId)
                        output.error(err);
                },
                complete: () => {
                    if (streamId === currentInnerStreamId) {
                        currentSubscription = null;
                        checkComplete();
                    }
                },
            });
        };
        (async () => {
            try {
                while (true) {
                    const result = await source.next();
                    if (result.done)
                        break;
                    const streamId = ++currentInnerStreamId;
                    const projected = project(result.value, index++);
                    const normalized = isPromiseLike(projected) ? await projected : projected;
                    const innerStream = fromAny(normalized);
                    await subscribeToInner(innerStream, streamId);
                }
                inputCompleted = true;
                checkComplete();
            }
            catch (err) {
                output.error(err);
            }
        })();
        return eachValueFrom(output);
    });
}

/**
 * Creates a stream operator that emits only the first `count` values from the source stream
 * and then completes.
 *
 * This operator is a powerful tool for controlling the length of a stream. It consumes values
 * from the source one by one, and as long as the total number of values emitted is less than
 * `count`, it passes them through to the output. Once the count is reached, it stops
 * processing the source and signals completion to its downstream consumers. This is especially
 * useful for managing finite segments of large or infinite streams.
 *
 * @template T The type of the values in the source and output streams.
 * @param count The maximum number of values to take from the beginning of the stream.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const take = (count) => createOperator("take", function (source) {
    let emitted = 0;
    let done = false;
    let resolvedCount;
    const getCount = () => {
        if (resolvedCount !== undefined) {
            return resolvedCount;
        }
        if (isPromiseLike(count)) {
            return count.then((val) => {
                resolvedCount = val;
                return val;
            });
        }
        resolvedCount = count;
        return resolvedCount;
    };
    return {
        next: async () => {
            while (true) {
                if (done) {
                    return DONE;
                }
                const result = await source.next();
                if (result.done) {
                    done = true;
                    return DONE;
                }
                emitted++;
                const countOrPromise = getCount();
                const limit = isPromiseLike(countOrPromise) ? await countOrPromise : countOrPromise;
                if (emitted > limit) {
                    done = true;
                    return DONE;
                }
                return NEXT(result.value);
            }
        },
    };
});

/**
 * Creates a stream operator that emits all values from the source stream until
 * a value is emitted by a `notifier` stream.
 *
 * This operator controls the lifespan of a stream based on an external signal.
 * It consumes and re-emits values from the source until the `notifier` stream
 * emits its first value. As soon as that happens, the operator completes the
 * output stream and unsubscribes from both the source and the notifier.
 *
 * This is useful for automatically stopping an operation when a certain condition
 * is met, such as waiting for a user to close a dialog or for an animation to complete.
 *
 * @template T The type of the values in the source and output streams.
 * @param notifier The stream that, upon its first emission, signals that the operator
 * should complete.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
function takeUntil(notifier) {
    return createOperator('takeUntil', function (source) {
        const output = createSubject();
        let stop = false;
        const notifierSubscription = fromAny(notifier).subscribe({
            next: () => { stop = true; notifierSubscription.unsubscribe(); output.complete(); },
            error: (err) => { stop = true; notifierSubscription.unsubscribe(); output.error(err); output.complete(); },
            complete: () => { notifierSubscription.unsubscribe(); },
        });
        (async () => {
            try {
                while (!stop) {
                    const { done, value } = await source.next();
                    if (done || stop)
                        break;
                    output.next(value);
                }
            }
            catch (err) {
                if (!output.completed())
                    output.error(err);
            }
            finally {
                output.complete();
                notifierSubscription.unsubscribe();
            }
        })();
        return eachValueFrom(output);
    });
}

/**
 * Creates a stream operator that emits values from the source stream as long as
 * a predicate returns true.
 *
 * This operator is a conditional limiter. It consumes values from the source stream
 * and applies the `predicate` function to each. As long as the predicate returns `true`,
 * the value is passed through to the output stream. The first time the predicate returns
 * a falsy value, the operator stops emitting and immediately completes the output stream.
 * The value that caused the predicate to fail is not emitted.
 *
 * This is useful for taking a contiguous block of data from a stream that meets a certain
 * condition, such as processing user input until an invalid entry is made.
 *
 * @template T The type of the values in the source and output streams.
 * @param predicate The function to test each value. `true` means to continue emitting,
 * and `false` means to stop and complete. It can be synchronous or asynchronous.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const takeWhile = (predicate) => createOperator("takeWhile", function (source) {
    let active = true;
    return {
        next: async () => {
            if (!active) {
                return DONE;
            }
            const result = await source.next();
            if (result.done)
                return DONE;
            const predicateResult = predicate(result.value);
            const pass = isPromiseLike(predicateResult) ? await predicateResult : predicateResult;
            if (!pass) {
                active = false;
                return DONE;
            }
            return NEXT(result.value);
        },
    };
});

/**
 * Creates a stream operator that performs a side-effect for each value from the source
 * stream without modifying the value.
 *
 * This operator is primarily used for debugging, logging, or other non-intrusive
 * actions that need to be performed on each value as it passes through the pipeline.
 * It is completely transparent to the data stream itself, as it does not transform,
 * filter, or buffer the values. The provided `tapFunction` is executed for each
 * value before the value is emitted to the next operator.
 *
 * @template T The type of the values in the source and output streams.
 * @param tapFunction The function to perform the side-effect. It receives the value
 * from the stream and can be synchronous or asynchronous.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const tap = (tapFunction) => createOperator('tap', function (source) {
    return {
        next: async () => {
            while (true) {
                const result = await source.next();
                if (result.done)
                    return result;
                const tapResult = tapFunction(result.value); // side-effect
                if (isPromiseLike(tapResult)) {
                    await tapResult;
                }
                return result;
            }
        }
    };
});

/**
 * Creates a throttle operator that emits the first value immediately, then ignores subsequent
 * values for the specified duration. If new values arrive during the cooldown, the
 * last one is emitted after the cooldown expires (trailing emit).
 *
 * This version tracks pending results and phantoms in PipeContext.
 *
 * @template T The type of values emitted by the source and output.
 * @param duration The throttle duration in milliseconds.
 * @returns An Operator instance that applies throttling to the source stream.
 */
const throttle = (duration) => createOperator('throttle', function (source) {
    const output = createSubject();
    let lastEmit = 0;
    let pendingResult;
    let timer = null;
    let resolvedDuration = undefined;
    const flushPending = () => {
        if (pendingResult !== undefined) {
            output.next(pendingResult.value);
            pendingResult = undefined;
        }
        timer = null;
        lastEmit = Date.now();
    };
    (async () => {
        try {
            resolvedDuration = isPromiseLike(duration) ? await duration : duration;
            while (true) {
                const result = await source.next();
                if (result.done)
                    break;
                const now = Date.now();
                if (resolvedDuration === undefined) {
                    pendingResult = result;
                    continue;
                }
                if (now - lastEmit >= resolvedDuration) {
                    // Emit immediately
                    output.next(result.value);
                    lastEmit = now;
                }
                else {
                    pendingResult = result;
                    // Schedule trailing emit
                    if (!timer) {
                        const delay = resolvedDuration - (now - lastEmit);
                        timer = setTimeout(flushPending, delay);
                    }
                }
            }
            // Source completed – flush trailing pending
            if (pendingResult !== undefined)
                flushPending();
        }
        catch (err) {
            output.error(err);
        }
        finally {
            if (timer) {
                clearTimeout(timer);
                timer = null;
            }
            output.complete();
        }
    })();
    return eachValueFrom(output);
});

/**
 * Creates a stream operator that immediately throws an error with the provided message.
 *
 * This operator is a source operator that is used to create a stream that immediately
 * fails. When a consumer requests a value by calling `next()`, the operator
 * will throw an `Error` with the given `message`, without emitting any values.
 *
 * This is useful for testing error handling logic in a stream pipeline or for
 * explicitly modeling a failed asynchronous operation.
 *
 * @template T The type of the values in the stream (this is a formality, as no values are emitted).
 * @param message The error message to be thrown.
 * @returns An `Operator` instance that creates a stream which errors upon its first request.
 */
const throwError = (message) => createOperator('throwError', function (source) {
    return {
        next: async () => {
            while (true) {
                const result = await source.next();
                if (result.done)
                    return DONE;
                break;
            }
            throw new Error(isPromiseLike(message) ? await message : message);
        }
    };
});

/**
 * Collects all emitted values from the source stream into an array
 * and emits that array once the source completes, tracking pending state.
 *
 * @template T The type of the values in the source stream.
 * @returns An Operator instance for use in a stream's `pipe` method.
 */
const toArray = () => createOperator("toArray", function (source) {
    const collected = [];
    let completed = false;
    let emitted = false;
    return {
        next: async () => {
            while (true) {
                // All done and final array emitted → complete
                if (completed && emitted) {
                    return DONE;
                }
                const result = await source.next();
                if (result.done) {
                    completed = true;
                    if (!emitted) {
                        emitted = true;
                        // Emit the final array of values
                        return NEXT(collected.map((r) => r.value));
                    }
                    continue;
                }
                collected.push(result);
            }
        },
    };
});

/**
 * Creates a stream operator that emits only distinct values from the source stream.
 *
 * This operator maintains an internal set of values or keys that it has already emitted.
 * For each new value from the source, it checks if it has been seen before. If not,
 * the value is emitted and added to the set; otherwise, it is skipped.
 *
 * The uniqueness check can be based on the value itself or on a key derived from
 * the value using a provided `keySelector` function. This makes it ideal for de-duplicating
 * streams of primitive values or complex objects.
 *
 * @template T The type of the values in the source stream.
 * @template K The type of the key used for comparison.
 * @param keySelector An optional function to derive a unique key from each value.
 * If not provided, the values themselves are used for comparison.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
const unique = (keySelector) => createOperator("unique", function (source) {
    const seen = new Set();
    return {
        next: async () => {
            while (true) {
                const result = await source.next();
                if (result.done)
                    return DONE;
                const selectedKey = keySelector ? keySelector(result.value) : result.value;
                const key = isPromiseLike(selectedKey) ? await selectedKey : selectedKey;
                if (!seen.has(key)) {
                    seen.add(key);
                    return NEXT(result.value);
                }
            }
        }
    };
});

/**
 * Creates a stream operator that combines the source stream with the latest values
 * from other provided streams.
 *
 * This operator is useful for merging a "trigger" stream with "state" streams.
 * It waits for a value from the source stream and, when one arrives, it emits a
 * tuple containing that source value along with the most recently emitted value
 * from each of the other streams.
 *
 * The operator is "gated" and will not emit any values until all provided streams
 * have emitted at least one value.
 * Inputs may be streams, plain values, arrays, or promises of those shapes; a single
 * array argument is treated the same as passing values variadically.
 *
 * @template T The type of the values in the source stream.
 * @template R The tuple type of the values from the other streams (e.g., [R1, R2, R3]).
 * @param streams Streams (or values/arrays/promises) to combine with the source stream.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 * The output stream emits tuples of `[T, ...R]`.
 */
function withLatestFrom(...streams) {
    return createOperator("withLatestFrom", function (source) {
        const output = createSubject();
        const abortController = new AbortController();
        const { signal } = abortController;
        let latestValues = [];
        let hasValue = [];
        const subscriptions = [];
        // The entire operator logic is wrapped in an async function to ensure auxiliary
        // stream subscriptions (and potential sync emissions) are handled before
        // the source stream iteration starts, preventing a race condition.
        (async () => {
            try {
                // --- 1. Setup Auxiliary Streams ---
                const resolvedInputs = await Promise.all(streams.map(async (stream) => (isPromiseLike(stream) ? await stream : stream)));
                // Logic to support both withLatestFrom(s1, s2) and withLatestFrom([s1, s2])
                const streamEntries = (resolvedInputs.length === 1 && Array.isArray(resolvedInputs[0])
                    ? resolvedInputs[0]
                    : resolvedInputs);
                latestValues = new Array(streamEntries.length).fill(undefined);
                hasValue = new Array(streamEntries.length).fill(false);
                for (let i = 0; i < streamEntries.length; i++) {
                    const subscription = fromAny(streamEntries[i]).subscribe({
                        next: (value) => {
                            latestValues[i] = value;
                            hasValue[i] = true;
                        },
                        error: (err) => {
                            // Immediately propagate errors from auxiliary streams and clean up
                            if (!signal.aborted) {
                                output.error(err instanceof Error ? err : new Error(String(err)));
                                abortController.abort(); // Signal the main loop to stop
                            }
                        },
                        // Note: Auxiliary stream completion does not complete the main stream
                        // but stops that specific auxiliary stream from providing updates.
                    });
                    subscriptions.push(subscription);
                }
                // --- 2. Iterate Source Stream ---
                const iterator = source;
                const abortPromise = new Promise((resolve) => {
                    if (signal.aborted) {
                        resolve();
                    }
                    else {
                        signal.addEventListener("abort", () => resolve(), { once: true });
                    }
                });
                while (true) {
                    const winner = await Promise.race([
                        abortPromise.then(() => ({ aborted: true })),
                        iterator.next().then(result => ({ result }))
                    ]);
                    if ('aborted' in winner || signal.aborted)
                        break;
                    const result = winner.result;
                    if (result.done)
                        break;
                    // Gate check: Only emit if ALL auxiliary streams have emitted a value
                    if (hasValue.length > 0 && hasValue.every(Boolean)) {
                        output.next([result.value, ...latestValues]);
                    }
                }
            }
            catch (err) {
                // Catch errors from source iteration
                if (!signal.aborted) {
                    output.error(err instanceof Error ? err : new Error(String(err)));
                }
            }
            finally {
                // --- 3. Cleanup on Completion/Error ---
                if (!signal.aborted) {
                    output.complete();
                }
                // Ensure all resources are closed
                subscriptions.forEach(sub => sub.unsubscribe());
                if (typeof source.return === "function") {
                    // Attempt to close the source iterator
                    source.return().catch(() => { });
                }
            }
        })(); // End of main async IIFE
        // --- 4. Custom Subscription Handling ---
        const originalSubscribe = output.subscribe;
        output.subscribe = (callbackOrReceiver) => {
            const receiver = createReceiver(callbackOrReceiver);
            const subscription = originalSubscribe.call(output, receiver);
            // Custom unsubscription logic ensures the main loop is aborted
            subscription.onUnsubscribe = () => {
                if (!signal.aborted) {
                    abortController.abort();
                }
                subscription.unsubscribe();
                // Auxiliary subscriptions are cleaned up in the `finally` block of the IIFE
                // once the abort signal propagates, but we call them here for immediate effect
                // if they haven't been resolved yet (less common, but safe).
                subscriptions.forEach(sub => sub.unsubscribe());
            };
            return subscription;
        };
        // Return the async iterator for stream piping compatibility
        return eachValueFrom(output);
    });
}

/*
 * Public API Surface of generator
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DONE, EMPTY, NEXT, audit, buffer, bufferCount, cascade, catchError, combineLatest, compute, concat, concatMap, coroutine, count, createAsyncGenerator, createBehaviorSubject, createBehaviorSubjectBuffer, createLock, createNotifier, createOperator, createQueue, createReceiver, createReplayBuffer, createReplaySubject, createScheduler, createSemaphore, createStream, createSubject, createSubjectBuffer, createSubscription, debounce, defaultIfEmpty, defer, delay, delayUntil, distinctUntilChanged, distinctUntilKeyChanged, eachValueFrom, elementAt, elementNth, empty, endWith, every, expand, filter, finalize, first, firstValueFrom, fork, forkJoin, from, fromAny, fromEvent, fromPromise, generateStreamId, generateSubscriptionId, getRuntimeHooks, groupBy, ignoreElements, iif, interval, isPromiseLike, isStreamLike, jsonp, last, lastValueFrom, loop, map, max, merge, mergeMap, min, observeOn, of, onAnimationFrame, onIntersection, onMediaQuery, onMutation, onOrientation, onResize, partition, pipeSourceThrough, race, range, recurse, reduce, registerRuntimeHooks, retry, sample, scan, scheduler, seize, select, shareReplay, skip, skipUntil, skipWhile, slidingPair, some, startWith, switchMap, take, takeUntil, takeWhile, tap, throttle, throwError, timer, toArray, unique, webSocket, withLatestFrom, zip };
//# sourceMappingURL=actioncrew-streamix.mjs.map
