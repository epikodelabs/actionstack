import { createPipelineContext, LogLevel, createStreamContext, firstValueFrom, createReceiver, eachValueFrom, createSubscription as createSubscription$1, createAsyncGenerator } from '@actioncrew/streamix';

/**
 * Wrap a stream to make it "inspectable".
 * All operators will receive a proper PipelineContext and StreamContext.
 */
function inspectable(source) {
    // One PipelineContext for the entire source pipeline
    const pipelineContext = createPipelineContext({
        logLevel: LogLevel.INFO,
        phantomHandler: (operator, streamContext, value) => {
            const result = streamContext.createResult({ value, type: 'phantom' });
            streamContext.logFlow('phantom', operator, result, 'Phantom value dropped');
        },
    });
    // Root StreamContext for the source stream itself
    const rootContext = createStreamContext(pipelineContext, source);
    // Helper to register operator with context
    function registerOperator(op, ctx) {
        if (!ctx.operators.includes(op)) {
            ctx.operators.push(op);
        }
    }
    // Create a no-op operator for logging when there are no operators
    const noopOperator = {
        name: 'noop',
        type: 'operator',
        apply: (source) => source
    };
    function createInspectableStream(upstream, operators, parentContext) {
        const streamContext = createStreamContext(parentContext, upstream);
        const pipedStream = {
            name: `${upstream.name}-sink`,
            type: "stream",
            context: parentContext,
            [Symbol.asyncIterator]() {
                return createAsyncGenerator(cb => pipedStream.subscribe(cb));
            },
            pipe(...nextOps) {
                return createInspectableStream(pipedStream, nextOps, parentContext);
            },
            subscribe(cb) {
                const receiver = createReceiver(cb);
                let iterator = eachValueFrom(upstream);
                // Register and apply operators
                for (const op of operators) {
                    registerOperator(op, parentContext);
                    iterator = op.apply(iterator);
                }
                const abortController = new AbortController();
                const { signal } = abortController;
                const abortPromise = new Promise((resolve) => {
                    if (signal.aborted)
                        resolve();
                    else
                        signal.addEventListener("abort", () => resolve(), { once: true });
                });
                (async () => {
                    try {
                        while (true) {
                            const winner = await Promise.race([
                                abortPromise.then(() => ({ aborted: true })),
                                iterator.next().then((result) => ({ result })),
                            ]);
                            if ("aborted" in winner || signal.aborted)
                                break;
                            const { result } = winner;
                            if (result.done)
                                break;
                            const streamResult = streamContext.createResult({ value: result.value });
                            const lastOp = operators.length > 0 ? operators[operators.length - 1] : noopOperator;
                            streamContext.logFlow('resolved', lastOp, streamResult, 'Emitted value');
                            await receiver.next?.(result.value);
                        }
                    }
                    catch (err) {
                        const lastOp = operators.length > 0 ? operators[operators.length - 1] : noopOperator;
                        streamContext.logFlow('error', lastOp, undefined, String(err));
                        await receiver.error?.(err);
                    }
                    finally {
                        await receiver.complete?.();
                        await streamContext.finalize();
                        parentContext.unregisterStream(streamContext.streamId);
                    }
                })();
                return createSubscription$1(async () => {
                    abortController.abort();
                    if (iterator.return) {
                        await iterator.return().catch(() => { });
                    }
                });
            },
            async query() {
                return firstValueFrom(pipedStream);
            },
        };
        return pipedStream;
    }
    const decorated = {
        ...source,
        context: pipelineContext,
        [Symbol.asyncIterator]() {
            return createAsyncGenerator(cb => decorated.subscribe(cb));
        },
        pipe(...operators) {
            return createInspectableStream(source, operators, pipelineContext);
        },
        subscribe(cb) {
            const receiver = createReceiver(cb);
            let iterator = eachValueFrom(source);
            const abortController = new AbortController();
            const { signal } = abortController;
            const abortPromise = new Promise((resolve) => {
                if (signal.aborted)
                    resolve();
                else
                    signal.addEventListener("abort", () => resolve(), { once: true });
            });
            (async () => {
                try {
                    while (true) {
                        const winner = await Promise.race([
                            abortPromise.then(() => ({ aborted: true })),
                            iterator.next().then((result) => ({ result })),
                        ]);
                        if ("aborted" in winner || signal.aborted)
                            break;
                        const { result } = winner;
                        if (result.done)
                            break;
                        const streamResult = rootContext.createResult({ value: result.value });
                        rootContext.logFlow('resolved', noopOperator, streamResult, 'Emitted value');
                        await receiver.next?.(result.value);
                    }
                }
                catch (err) {
                    rootContext.logFlow('error', noopOperator, undefined, String(err));
                    await receiver.error?.(err);
                }
                finally {
                    await receiver.complete?.();
                    await rootContext.finalize();
                    pipelineContext.unregisterStream(rootContext.streamId);
                }
            })();
            return createSubscription$1(async () => {
                abortController.abort();
                if (iterator.return) {
                    await iterator.return().catch(() => { });
                }
            });
        },
        query() {
            return firstValueFrom(source);
        },
    };
    return decorated;
}

/**
 * Enhanced subscription lifecycle states for comprehensive inspection.
 */
var SubscriptionState;
(function (SubscriptionState) {
    /** Subscription is newly created but not yet active */
    SubscriptionState["CREATED"] = "created";
    /** Subscription is actively listening for values */
    SubscriptionState["ACTIVE"] = "active";
    /** Subscription is in the process of unsubscribing */
    SubscriptionState["UNSUBSCRIBING"] = "unsubscribing";
    /** Subscription has been completely terminated */
    SubscriptionState["UNSUBSCRIBED"] = "unsubscribed";
    /** Subscription encountered an error during lifecycle */
    SubscriptionState["ERROR"] = "error";
})(SubscriptionState || (SubscriptionState = {}));
/**
 * Global subscription registry for pipeline-wide subscription management and inspection.
 */
class SubscriptionRegistry {
    constructor() {
        this.subscriptions = new Map();
        this.globalHooks = [];
    }
    static getInstance() {
        if (!SubscriptionRegistry.instance) {
            SubscriptionRegistry.instance = new SubscriptionRegistry();
        }
        return SubscriptionRegistry.instance;
    }
    register(subscription) {
        this.subscriptions.set(subscription.subscriptionId, subscription);
    }
    unregister(subscriptionId) {
        this.subscriptions.delete(subscriptionId);
    }
    addGlobalHook(hook) {
        this.globalHooks.push(hook);
    }
    removeGlobalHook(hook) {
        const index = this.globalHooks.indexOf(hook);
        if (index > -1) {
            this.globalHooks.splice(index, 1);
        }
    }
    getGlobalHooks() {
        return [...this.globalHooks];
    }
    getAllSubscriptions() {
        return [...this.subscriptions.values()];
    }
    getActiveSubscriptions() {
        return [...this.subscriptions.values()].filter(sub => sub.state === SubscriptionState.ACTIVE);
    }
    getSubscriptionsByStream(streamId) {
        return [...this.subscriptions.values()].filter(sub => sub.streamContext?.streamId === streamId);
    }
    getAggregatedStats() {
        const subscriptions = [...this.subscriptions.values()];
        const stats = subscriptions.map(sub => sub.getStats());
        return {
            totalSubscriptions: subscriptions.length,
            activeSubscriptions: stats.filter(s => s.state === SubscriptionState.ACTIVE).length,
            totalValuesReceived: stats.reduce((sum, s) => sum + s.valuesReceived, 0),
            totalErrorsReceived: stats.reduce((sum, s) => sum + s.errorsReceived, 0),
            averageSubscriptionDuration: stats.length > 0
                ? stats.reduce((sum, s) => sum + s.duration, 0) / stats.length
                : 0
        };
    }
}
/**
 * Creates a new subscription with comprehensive inspection capabilities.
 * Integrates with the existing context management and flow logging system.
 */
function createInspectableSubscription(onUnsubscribe, streamContext, options = {}) {
    const { enableInspection = true, subscriptionId = `sub_${Date.now()}_${Math.random().toString(36).slice(2)}`, metadata = {} } = options;
    let state = SubscriptionState.CREATED;
    let _unsubscribing = false;
    let _unsubscribed = false;
    const events = [];
    const inspectionHooks = [];
    const startTime = performance.now();
    let valuesReceived = 0;
    let errorsReceived = 0;
    let lastEmissionTime = 0;
    let totalEmissionInterval = 0;
    // Register with global registry if inspection is enabled
    const registry = enableInspection ? SubscriptionRegistry.getInstance() : null;
    /**
     * Log a subscription lifecycle event with flow integration.
     */
    const logEvent = (eventType, newState, eventData = {}) => {
        const event = {
            subscriptionId,
            timestamp: performance.now(),
            event: eventType,
            state: newState,
            streamId: streamContext?.streamId,
            ...eventData,
            metadata: { ...metadata, ...eventData.metadata }
        };
        events.push(event);
        state = newState;
        // Integrate with existing flow logging system
        if (streamContext?.pipeline.flowLoggingEnabled) {
            const emoji = {
                created: '🆕',
                activated: '▶️',
                value_received: '📦',
                error_received: '💥',
                completed: '🏁',
                unsubscribing: '⏹️',
                unsubscribed: '🛑'
            }[eventType];
            console.log(`${emoji} [SUBSCRIPTION] ${subscriptionId} (${streamContext.streamId}): ${eventType}`, eventData.value ?? eventData.error ?? '', event.metadata ? `- ${JSON.stringify(event.metadata)}` : '');
        }
        // Execute inspection hooks
        const allHooks = [...inspectionHooks, ...(registry?.getGlobalHooks() ?? [])];
        allHooks.forEach(hook => {
            try {
                hook(event, subscription);
            }
            catch (error) {
                console.warn(`Subscription inspection hook failed:`, error);
            }
        });
        // Update stream context if available
        if (streamContext && eventType === 'value_received') {
            streamContext.logFlow('resolved', { name: 'subscription' }, eventData.value, 'received by subscription');
        }
    };
    const unsubscribe = async () => {
        if (!_unsubscribing && state !== SubscriptionState.UNSUBSCRIBED) {
            _unsubscribing = true;
            logEvent('unsubscribing', SubscriptionState.UNSUBSCRIBING);
            try {
                await onUnsubscribe?.();
                _unsubscribed = true;
                logEvent('unsubscribed', SubscriptionState.UNSUBSCRIBED);
            }
            catch (err) {
                logEvent('unsubscribed', SubscriptionState.ERROR, {
                    error: err,
                    metadata: { unsubscribeError: true }
                });
                console.error("Error during unsubscribe callback:", err);
            }
            finally {
                registry?.unregister(subscriptionId);
            }
        }
    };
    const getStats = () => ({
        subscriptionId,
        streamId: streamContext?.streamId,
        state,
        valuesReceived,
        errorsReceived,
        duration: performance.now() - startTime,
        averageEmissionInterval: valuesReceived > 1
            ? totalEmissionInterval / (valuesReceived - 1)
            : undefined,
        hasActiveListeners: state === SubscriptionState.ACTIVE && !_unsubscribed
    });
    const addInspectionHook = (hook) => {
        inspectionHooks.push(hook);
    };
    const removeInspectionHook = (hook) => {
        const index = inspectionHooks.indexOf(hook);
        if (index > -1) {
            inspectionHooks.splice(index, 1);
        }
    };
    const subscription = {
        subscriptionId,
        streamContext,
        events,
        get state() { return state; },
        get unsubscribed() { return _unsubscribed; },
        unsubscribe,
        getStats,
        addInspectionHook,
        removeInspectionHook
    };
    // Log creation and register
    logEvent('created', SubscriptionState.CREATED, { metadata });
    registry?.register(subscription);
    // Add methods for external state updates (used by stream implementations)
    subscription._activate = () => {
        logEvent('activated', SubscriptionState.ACTIVE);
    };
    subscription._onValue = (value) => {
        valuesReceived++;
        const now = performance.now();
        if (lastEmissionTime > 0) {
            totalEmissionInterval += (now - lastEmissionTime);
        }
        lastEmissionTime = now;
        logEvent('value_received', state, { value });
    };
    subscription._onError = (error) => {
        errorsReceived++;
        logEvent('error_received', SubscriptionState.ERROR, { error });
    };
    subscription._onComplete = () => {
        logEvent('completed', state);
    };
    return subscription;
}
/**
 * Creates a basic subscription (legacy compatibility).
 */
function createSubscription(onUnsubscribe) {
    const inspectable = createInspectableSubscription(onUnsubscribe, undefined, {
        enableInspection: false
    });
    return {
        get unsubscribed() { return inspectable.unsubscribed; },
        unsubscribe: inspectable.unsubscribe
    };
}
/**
 * Utility functions for subscription inspection and monitoring.
 */
const SubscriptionInspector = {
    /**
     * Get the global subscription registry for pipeline-wide inspection.
     */
    getRegistry() {
        return SubscriptionRegistry.getInstance();
    },
    /**
     * Add a global inspection hook that applies to all subscriptions.
     */
    addGlobalHook(hook) {
        SubscriptionRegistry.getInstance().addGlobalHook(hook);
    },
    /**
     * Create a performance monitoring hook.
     */
    createPerformanceHook(thresholds = {}) {
        const { slowEmissionMs = 1000, maxValuesPerSecond = 100 } = thresholds;
        return (event, subscription) => {
            if (event.event === 'value_received') {
                const stats = subscription.getStats();
                // Check for slow emissions
                if (stats.averageEmissionInterval && stats.averageEmissionInterval > slowEmissionMs) {
                    console.warn(`Slow emission detected in subscription ${subscription.subscriptionId}: ${stats.averageEmissionInterval}ms average interval`);
                }
                // Check for high frequency emissions
                const valuesPerSecond = stats.valuesReceived / (stats.duration / 1000);
                if (valuesPerSecond > maxValuesPerSecond) {
                    console.warn(`High frequency emissions in subscription ${subscription.subscriptionId}: ${valuesPerSecond.toFixed(2)} values/sec`);
                }
            }
        };
    },
    /**
     * Create a memory monitoring hook.
     */
    createMemoryHook() {
        return (event, subscription) => {
            if (typeof performance.memory !== 'undefined') {
                const memory = performance.memory;
                const memoryUsed = memory.usedJSHeapSize / (1024 * 1024); // Convert to MB
                if (event.event === 'value_received' && memoryUsed > 100) {
                    console.warn(`High memory usage detected: ${memoryUsed.toFixed(2)}MB during subscription ${subscription.subscriptionId}`);
                }
            }
        };
    },
    /**
     * Export subscription timeline data for external analysis.
     */
    exportTimeline(subscriptionId, format = 'json') {
        const registry = SubscriptionRegistry.getInstance();
        const subscription = registry.getAllSubscriptions().find(s => s.subscriptionId === subscriptionId);
        if (!subscription) {
            throw new Error(`Subscription ${subscriptionId} not found`);
        }
        if (format === 'json') {
            return JSON.stringify(subscription.events, null, 2);
        }
        else {
            const headers = ['timestamp', 'event', 'state', 'streamId', 'value', 'error'];
            const rows = subscription.events.map(event => [
                event.timestamp,
                event.event,
                event.state,
                event.streamId || '',
                JSON.stringify(event.value || ''),
                JSON.stringify(event.error || '')
            ]);
            return [headers, ...rows].map(row => row.join(',')).join('\n');
        }
    },
    /**
     * Generate a comprehensive report of all subscription activity.
     */
    generateReport() {
        const registry = SubscriptionRegistry.getInstance();
        const subscriptions = registry.getAllSubscriptions();
        return {
            summary: registry.getAggregatedStats(),
            subscriptions: subscriptions.map(s => s.getStats()),
            timeline: subscriptions.flatMap(s => [...s.events]).sort((a, b) => a.timestamp - b.timestamp)
        };
    }
};

/*
 * Public API Surface of generator
 */

/**
 * Generated bundle index. Do not edit.
 */

export { SubscriptionInspector, SubscriptionState, createInspectableSubscription, createSubscription, inspectable };
//# sourceMappingURL=actioncrew-streamix-testing.mjs.map
