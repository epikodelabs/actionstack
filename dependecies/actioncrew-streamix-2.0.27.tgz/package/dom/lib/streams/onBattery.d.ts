import { type Stream } from "@actioncrew/streamix";
/**
 * Represents the current battery status.
 */
export type BatteryState = {
    charging: boolean;
    level: number;
    chargingTime: number;
    dischargingTime: number;
};
/**
 * Creates a reactive stream that emits battery state changes.
 *
 * Uses the Battery Status API when available.
 *
 * **Behavior:**
 * - Emits an initial battery snapshot on start.
 * - Emits on charging, level, and time changes.
 * - Starts listening on first subscriber.
 * - Stops listening when the last subscriber unsubscribes.
 * - Safe to import and subscribe in SSR (no-op).
 * - Fully compatible with async iteration.
 *
 * @returns {Stream<BatteryState>}
 */
export declare function onBattery(): Stream<BatteryState>;
