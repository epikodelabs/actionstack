import { type Stream } from "@actioncrew/streamix";
/**
 * Represents a snapshot of the visual viewport.
 */
export type ViewportState = {
    width: number;
    height: number;
    scale: number;
    offsetLeft: number;
    offsetTop: number;
};
/**
 * Creates a reactive stream that emits changes to the visual viewport.
 *
 * Uses `visualViewport` when available, falling back to `window`.
 *
 * **Behavior:**
 * - Emits initial viewport metrics on start.
 * - Emits on resize, scroll, and zoom.
 * - Starts listening on first subscriber.
 * - Stops listening when the last subscriber unsubscribes.
 * - Safe to import and subscribe in SSR (no-op).
 * - Fully compatible with async iteration.
 *
 * @returns {Stream<ViewportState>}
 */
export declare function onViewportChange(): Stream<ViewportState>;
