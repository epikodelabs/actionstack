import { MaybePromise, StreamContext } from "@actioncrew/streamix";
/**
 * Enhanced subscription lifecycle states for comprehensive inspection.
 */
export declare enum SubscriptionState {
    /** Subscription is newly created but not yet active */
    CREATED = "created",
    /** Subscription is actively listening for values */
    ACTIVE = "active",
    /** Subscription is in the process of unsubscribing */
    UNSUBSCRIBING = "unsubscribing",
    /** Subscription has been completely terminated */
    UNSUBSCRIBED = "unsubscribed",
    /** Subscription encountered an error during lifecycle */
    ERROR = "error"
}
/**
 * Represents a single subscription lifecycle event for inspection and debugging.
 */
export interface SubscriptionEvent {
    /** Unique identifier for this subscription */
    subscriptionId: string;
    /** Timestamp when the event occurred */
    timestamp: number;
    /** Type of lifecycle event */
    event: 'created' | 'activated' | 'value_received' | 'error_received' | 'completed' | 'unsubscribing' | 'unsubscribed';
    /** Current state of the subscription */
    state: SubscriptionState;
    /** Associated stream ID, if applicable */
    streamId?: string;
    /** Value associated with the event (for value_received events) */
    value?: any;
    /** Error associated with the event (for error_received events) */
    error?: any;
    /** Additional contextual metadata */
    metadata?: Record<string, any>;
}
/**
 * Statistics for subscription performance and behavior analysis.
 */
export interface SubscriptionStats {
    /** Unique identifier for this subscription */
    subscriptionId: string;
    /** Associated stream ID */
    streamId?: string;
    /** Current lifecycle state */
    state: SubscriptionState;
    /** Total number of values received */
    valuesReceived: number;
    /** Total number of errors received */
    errorsReceived: number;
    /** Duration since subscription creation in milliseconds */
    duration: number;
    /** Average time between value emissions (ms) */
    averageEmissionInterval?: number;
    /** Peak memory usage during subscription lifecycle */
    peakMemoryUsage?: number;
    /** Whether subscription has active listeners */
    hasActiveListeners: boolean;
}
/**
 * Enhanced subscription interface with comprehensive inspection capabilities.
 */
export interface InspectableSubscription extends Subscription {
    /** Unique identifier for this subscription */
    readonly subscriptionId: string;
    /** Current lifecycle state */
    readonly state: SubscriptionState;
    /** Associated stream context for pipeline integration */
    readonly streamContext?: StreamContext;
    /** Timeline of all subscription lifecycle events */
    readonly events: ReadonlyArray<SubscriptionEvent>;
    /** Get current subscription statistics */
    getStats(): SubscriptionStats;
    /** Add a custom inspection hook */
    addInspectionHook(hook: SubscriptionInspectionHook): void;
    /** Remove an inspection hook */
    removeInspectionHook(hook: SubscriptionInspectionHook): void;
}
/**
 * Hook function for custom subscription inspection and monitoring.
 */
export type SubscriptionInspectionHook = (event: SubscriptionEvent, subscription: InspectableSubscription) => MaybePromise;
/**
 * Represents a subscription to a stream-like source with enhanced inspection capabilities.
 */
export type Subscription = {
    /** A boolean flag indicating whether the subscription has been terminated */
    readonly unsubscribed: boolean;
    /** Terminates the subscription and any associated listening process */
    unsubscribe(): MaybePromise;
};
/**
 * Global subscription registry for pipeline-wide subscription management and inspection.
 */
declare class SubscriptionRegistry {
    private static instance;
    private subscriptions;
    private globalHooks;
    static getInstance(): SubscriptionRegistry;
    register(subscription: InspectableSubscription): void;
    unregister(subscriptionId: string): void;
    addGlobalHook(hook: SubscriptionInspectionHook): void;
    removeGlobalHook(hook: SubscriptionInspectionHook): void;
    getGlobalHooks(): ReadonlyArray<SubscriptionInspectionHook>;
    getAllSubscriptions(): ReadonlyArray<InspectableSubscription>;
    getActiveSubscriptions(): ReadonlyArray<InspectableSubscription>;
    getSubscriptionsByStream(streamId: string): ReadonlyArray<InspectableSubscription>;
    getAggregatedStats(): {
        totalSubscriptions: number;
        activeSubscriptions: number;
        totalValuesReceived: number;
        totalErrorsReceived: number;
        averageSubscriptionDuration: number;
    };
}
/**
 * Creates a new subscription with comprehensive inspection capabilities.
 * Integrates with the existing context management and flow logging system.
 */
export declare function createInspectableSubscription(onUnsubscribe?: () => MaybePromise, streamContext?: StreamContext, options?: {
    enableInspection?: boolean;
    subscriptionId?: string;
    metadata?: Record<string, any>;
}): InspectableSubscription;
/**
 * Creates a basic subscription (legacy compatibility).
 */
export declare function createSubscription(onUnsubscribe?: () => MaybePromise): Subscription;
/**
 * Utility functions for subscription inspection and monitoring.
 */
export declare const SubscriptionInspector: {
    /**
     * Get the global subscription registry for pipeline-wide inspection.
     */
    getRegistry(): SubscriptionRegistry;
    /**
     * Add a global inspection hook that applies to all subscriptions.
     */
    addGlobalHook(hook: SubscriptionInspectionHook): void;
    /**
     * Create a performance monitoring hook.
     */
    createPerformanceHook(thresholds?: {
        slowEmissionMs?: number;
        maxValuesPerSecond?: number;
    }): SubscriptionInspectionHook;
    /**
     * Create a memory monitoring hook.
     */
    createMemoryHook(): SubscriptionInspectionHook;
    /**
     * Export subscription timeline data for external analysis.
     */
    exportTimeline(subscriptionId: string, format?: 'json' | 'csv'): string;
    /**
     * Generate a comprehensive report of all subscription activity.
     */
    generateReport(): {
        summary: ReturnType<SubscriptionRegistry['getAggregatedStats']>;
        subscriptions: SubscriptionStats[];
        timeline: SubscriptionEvent[];
    };
};
export {};
