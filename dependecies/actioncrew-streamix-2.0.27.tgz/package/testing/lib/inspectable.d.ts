import { Operator, PipelineContext, Stream } from "@actioncrew/streamix";
export interface InspectableStream<T = any> extends Stream<T> {
    pipe<S>(...operators: Operator<T, S>[]): InspectableStream<S>;
    readonly context: PipelineContext;
}
/**
 * Wrap a stream to make it "inspectable".
 * All operators will receive a proper PipelineContext and StreamContext.
 */
export declare function inspectable<T>(source: Stream<T>): InspectableStream<T>;
