/**
 * Context object passed to `onPipeStream` runtime hook.
 *
 * Describes the stream being piped, its subscription,
 * the original source iterator, and the operator chain.
 */
export type PipeStreamHookContext = {
    /** Unique identifier of the stream instance */
    streamId: string;
    /** Optional human-readable stream name */
    streamName?: string;
    /** Unique identifier of the subscription */
    subscriptionId: string;
    /** Source async iterator before operators are applied */
    source: AsyncIterator<any>;
    /** List of operators applied to the stream */
    operators: any[];
};

/**
 * Result returned from `onPipeStream` runtime hook.
 *
 * Allows intercepting and replacing parts of the stream pipeline.
 */
export type PipeStreamHookResult = {
    /** Optionally replace the source iterator */
    source?: AsyncIterator<any>;
    /** Optionally replace or mutate the operator list */
    operators?: any[];
    /**
     * Optional final wrapper applied after operators
     * but before the stream is consumed.
     */
    final?: (iterator: AsyncIterator<any>) => AsyncIterator<any>;
};

/**
 * Runtime hooks for Streamix internal lifecycle events.
 *
 * These hooks are intended for tracing, debugging,
 * profiling, and developer tooling.
 */
export type StreamRuntimeHooks = {
    /**
     * Called when a stream is created.
     *
     * Useful for registering stream metadata
     * or initializing tracing structures.
     */
    onCreateStream?: (info: {
        /** Generated stream identifier */
        id: string;
        /** Optional stream name */
        name?: string;
    }) => void;
    /**
     * Called when a stream is piped.
     *
     * Allows observing or modifying the pipeline,
     * including source, operators, or final iterator.
     */
    onPipeStream?: (ctx: PipeStreamHookContext) => PipeStreamHookResult | void;
};

/**
 * Generates a unique stream identifier.
 *
 * IDs are stable within a single runtime session
 * and deterministic for tracing purposes.
 */
export declare function generateStreamId(): string;

/**
 * Generates a unique subscription identifier.
 *
 * Used to correlate subscriptions with
 * emitted values and lifecycle events.
 */
export declare function generateSubscriptionId(): string;

/**
 * Registers runtime hooks globally.
 *
 * Calling this function replaces any previously
 * registered hooks.
 */
export declare function registerRuntimeHooks(hooks: StreamRuntimeHooks): void;

/**
 * Retrieves the currently registered runtime hooks.
 *
 * Returns `null` if no hooks are registered.
 */
export declare function getRuntimeHooks(): StreamRuntimeHooks | null;

/**
 * Defines a receiver interface for handling a stream's lifecycle events.
 *
 * A receiver is an object that can be passed to a stream's `subscribe` method
 * to handle the three primary events in a stream's lifecycle: `next` for
 * new values, `error` for stream errors, and `complete` when the stream has finished.
 *
 * All properties are optional, allowing you to subscribe only to the events you care about.
 *
 * @template T The type of the value handled by the receiver's `next` method.
 */
export type Receiver<T = any> = {
    /**
     * A function called for each new value emitted by the stream.
     * @param value The value emitted by the stream.
     */
    next?: (value: T) => MaybePromise;
    /**
     * A function called if the stream encounters an error.
     * @param err The error that occurred.
     */
    error?: (err: Error) => MaybePromise;
    /**
     * A function called when the stream has completed successfully and will emit no more values.
     */
    complete?: () => MaybePromise;
};

/**
 * A fully defined, state-aware receiver with guaranteed lifecycle handlers.
 *
 * This type extends the `Receiver` interface by making all handler methods
 * (`next`, `error`, and `complete`) required. It also includes a `completed`
 * property to track the receiver's state, preventing it from processing
 * new events after it has completed. This is an internal type used to ensure
 * robust handling of all stream events.
 *
 * @template T The type of the value handled by the receiver.
 */
export type StrictReceiver<T = any> = Required<Receiver<T>> & {
    readonly completed: boolean;
};

/**
 * Normalizes a receiver input (a function or an object) into a strict,
 * fully-defined receiver.
 *
 * This factory function ensures that a consistent `StrictReceiver` object is
 * always returned, regardless of the input. It wraps the provided handlers
 * with logic that ensures events are not processed after completion and that
 * unhandled errors are logged.
 *
 * If the input is a function, it is treated as the `next` handler. If it's an
 * object, its `next`, `error`, and `complete` properties are used. If no input
 * is provided, a receiver with no-op handlers is created.
 *
 * @template T The type of the value handled by the receiver.
 * @param callbackOrReceiver An optional function to serve as the `next` handler,
 * or a `Receiver` object with one or more optional handlers.
 * @returns A new `StrictReceiver` instance with normalized handlers and completion tracking.
 */
export declare function createReceiver<T = any>(callbackOrReceiver?: ((value: T) => MaybePromise) | Receiver<T>): StrictReceiver<T>;

/**
 * Represents a subscription to a stream-like source.
 *
 * A `Subscription` is returned from a stream's `subscribe()` method and
 * represents an active connection between a producer and a consumer.
 *
 * Responsibilities:
 * - Tracks whether the subscription is active
 * - Provides an idempotent mechanism to unsubscribe
 * - Optionally executes cleanup logic on unsubscribe
 */
export type Subscription = {
    /**
     * Indicates whether the subscription has been terminated.
     *
     * - `false` → subscription is active
     * - `true`  → subscription has been unsubscribed and is inactive
     *
     * This flag becomes `true` immediately when `unsubscribe()` is invoked
     * for the first time.
     */
    readonly unsubscribed: boolean;
    /**
     * Terminates the subscription.
     *
     * Semantics:
     * - Idempotent: calling multiple times has no additional effect
     * - Marks the subscription as unsubscribed synchronously
     * - Executes cleanup logic (if provided) exactly once
     *
     * Errors thrown by cleanup logic are caught and logged.
     *
     * @returns A `MaybePromise<void>` that resolves when cleanup completes
     */
    unsubscribe(): MaybePromise;
    /**
     * Optional cleanup callback executed during unsubscription.
     *
     * Intended usage:
     * - Remove event listeners
     * - Cancel timers or async tasks
     * - Abort generators or observers
     *
     * Guarantees:
     * - Called at most once
     * - Executed only after `unsubscribed` becomes `true`
     * - May be synchronous or asynchronous
     *
     * Any errors thrown by this callback are caught internally.
     */
    onUnsubscribe?: () => MaybePromise;
};

/**
 * Creates a new `Subscription` instance.
 *
 * This factory encapsulates subscription state and ensures:
 * - Safe, idempotent unsubscription
 * - Proper execution of cleanup logic
 * - Consistent error handling during teardown
 *
 * @param onUnsubscribe Optional cleanup callback executed on first unsubscribe
 * @returns A new `Subscription` object
 */
export declare function createSubscription(onUnsubscribe?: () => MaybePromise): Subscription;

/**
 * A reactive stream representing a sequence of values over time.
 *
 * Streams support:
 * - **Subscription** to receive asynchronous values.
 * - **Operator chaining** through `.pipe()`.
 * - **Querying** the first emitted value.
 * - **Async iteration** via `for await...of`.
 *
 * Two variants exist:
 * - `"stream"`: automatically driven, typically created by `createStream()`.
 * - `"subject"`: manually driven (not implemented here but retained for API symmetry).
 *
 * @template T The value type emitted by the stream.
 */
export type Stream<T = any> = AsyncIterable<T> & {
    /** Identifies the underlying behavior of the stream. */
    type: "stream" | "subject";
    /** Human-readable name primarily for debugging and introspection. */
    name?: string;
    /**
     * Internal unique identifier of the stream instance.
     *
     * Used by runtime hooks (e.g. tracing, profiling, devtools).
     * Not part of the public reactive API.
     */
    id: string;
    /**
     * Creates a new derived stream by applying one or more `Operator`s.
     *
     * Operators compose into an async-iterator pipeline, transforming emitted values.
     */
    pipe: OperatorChain<T>;
    /**
     * Subscribes to the stream.
     *
     * A callback or Receiver will be invoked for each next/error/complete event.
     * Returns a `Subscription` that may be used to unsubscribe.
     */
    subscribe: (callback?: ((value: T) => MaybePromise) | Receiver<T>) => Subscription;
    /**
     * Convenience method for retrieving the first emitted value.
     *
     * Internally subscribes, resolves on the first `next`, and then unsubscribes.
     */
    query: () => Promise<T>;
    /** Allows direct async iteration: `for await (const value of stream) { ... }`. */
    [Symbol.asyncIterator](): AsyncGenerator<T>;
};

/**
 * Creates a pull-based async generator view over a stream.
 *
 * This bridges the push-based subscription model with
 * the pull-based async-iterator protocol.
 *
 * Characteristics:
 * - Buffers values when the producer is faster than the consumer
 * - Propagates errors via generator throws
 * - Guarantees subscription cleanup on completion, error, or early exit
 *
 * @template T
 * @param register Function registering a receiver and returning a subscription
 * @returns AsyncGenerator yielding stream values
 */
export declare function createAsyncGenerator<T = any>(register: (receiver: Receiver<T>) => Subscription): AsyncGenerator<T>;

/**
 * Creates a multicast stream backed by a shared async generator.
 *
 * @template T
 * @param name Stream name (debugging / tooling)
 * @param generatorFn Factory producing an async generator
 * @returns Multicast Stream instance
 */
export declare function createStream<T>(name: string, generatorFn: () => AsyncGenerator<T, void, unknown>): Stream<T>;

/**
 * Pipes a source stream through a chain of operators,
 * producing a derived unicast stream.
 *
 * @template TIn
 * @template Ops
 * @param source Source stream
 * @param operators Operators applied to the source
 * @returns Derived unicast Stream
 */
export declare function pipeSourceThrough<TIn, Ops extends Operator<any, any>[]>(source: Stream<TIn>, operators: [
    ...Ops
]): Stream<any>;

/**
 * Represents a value that can either be a synchronous return or a promise that
 * resolves to the value.
 *
 * This type is used to support both synchronous and asynchronous callbacks
 * within stream handlers, providing flexibility without requiring every
 * handler to be an async function.
 *
 * @template T The type of the value returned by the callback.
 */
export type MaybePromise<T = any> = (T | Promise<T>);

/**
 * Type guard that checks whether a value behaves like a promise.
 *
 * We avoid relying on `instanceof Promise` so that promise-like values from
 * different realms or custom thenables are still treated correctly.
 */
export declare const isPromiseLike: <T = any>(value: MaybePromise<T>) => value is Promise<T>;

/**
 * A constant representing a completed stream result.
 *
 * Always `{ done: true, value: undefined }`.
 * Used to signal the end of a stream.
 */
export declare const DONE: {
    readonly done: true;
    readonly value: undefined;
};

/**
 * Factory function to create a normal stream result.
 *
 * @template R The type of the emitted value.
 * @param value The value to emit downstream.
 * @returns A `IteratorResult<R>` object with `{ done: false, value }`.
 */
export declare const NEXT: <R = any>(value: R) => {
    readonly done: false;
    readonly value: R;
};

/**
 * A stream operator that transforms a value from an input stream to an output stream.
 *
 * Operators are the fundamental building blocks for composing stream transformations.
 * They are functions that take one stream and return another, allowing for a chain of operations.
 *
 * @template T The type of the value being consumed by the operator.
 * @template R The type of the value being produced by the operator.
 */
export type Operator<T = any, R = T> = {
    /**
     * An optional name for the operator, useful for debugging.
     */
    name?: string;
    /**
     * A type discriminator to identify this object as an operator.
     */
    type: 'operator';
    /**
     * The core function that defines the operator's transformation logic. It takes an
     * asynchronous iterator of type `T` and returns a new asynchronous iterator of type `R`.
     * @param source The source async iterator to apply the transformation to.
     */
    apply: (source: AsyncIterator<T>) => AsyncIterator<R>;
};

/**
 * Creates a reusable stream operator.
 *
 * This factory function simplifies the creation of operators by bundling a name and a
 * transformation function into a single `Operator` object.
 *
 * @template T The type of the value the operator will consume.
 * @template R The type of the value the operator will produce.
 * @param name The name of the operator, for identification and debugging.
 * @param transformFn The transformation function that defines the operator's logic.
 * @returns A new `Operator` object with the specified name and transformation function.
 */
export declare function createOperator<T = any, R = T>(name: string, transformFn: (source: AsyncIterator<T>) => AsyncIterator<R>): Operator<T, R>;

/**
 * A type representing a chain of stream operators.
 *
 * This type uses function overloading to provide strong type safety for a sequence
 * of operators. Each overload correctly infers the final stream's type by tracking the
 * output of one operator as the input of the next.
 *
 * @template T The initial type of the stream.
 * @internal This interface is primarily for internal type-checking and should not be
 * used directly by consumers.
 */
export interface OperatorChain<T> {
    (): Stream<T>;
    <A>(op1: Operator<T, A>): Stream<A>;
    <A, B>(op1: Operator<T, A>, op2: Operator<A, B>): Stream<B>;
    <A, B, C>(op1: Operator<T, A>, op2: Operator<A, B>, op3: Operator<B, C>): Stream<C>;
    <A, B, C, D>(op1: Operator<T, A>, op2: Operator<A, B>, op3: Operator<B, C>, op4: Operator<C, D>): Stream<D>;
    <A, B, C, D, E>(op1: Operator<T, A>, op2: Operator<A, B>, op3: Operator<B, C>, op4: Operator<C, D>, op5: Operator<D, E>): Stream<E>;
    <A, B, C, D, E, F>(op1: Operator<T, A>, op2: Operator<A, B>, op3: Operator<B, C>, op4: Operator<C, D>, op5: Operator<D, E>, op6: Operator<E, F>): Stream<F>;
    <A, B, C, D, E, F, G>(op1: Operator<T, A>, op2: Operator<A, B>, op3: Operator<B, C>, op4: Operator<C, D>, op5: Operator<D, E>, op6: Operator<E, F>, op7: Operator<F, G>): Stream<G>;
    <A, B, C, D, E, F, G, H>(op1: Operator<T, A>, op2: Operator<A, B>, op3: Operator<B, C>, op4: Operator<C, D>, op5: Operator<D, E>, op6: Operator<E, F>, op7: Operator<F, G>, op8: Operator<G, H>): Stream<H>;
    <A, B, C, D, E, F, G, H, I>(op1: Operator<T, A>, op2: Operator<A, B>, op3: Operator<B, C>, op4: Operator<C, D>, op5: Operator<D, E>, op6: Operator<E, F>, op7: Operator<F, G>, op8: Operator<G, H>, op9: Operator<H, I>): Stream<I>;
    <A, B, C, D, E, F, G, H, I, J>(op1: Operator<T, A>, op2: Operator<A, B>, op3: Operator<B, C>, op4: Operator<C, D>, op5: Operator<D, E>, op6: Operator<E, F>, op7: Operator<F, G>, op8: Operator<G, H>, op9: Operator<H, I>, op10: Operator<I, J>): Stream<J>;
    <A, B, C, D, E, F, G, H, I, J, K>(op1: Operator<T, A>, op2: Operator<A, B>, op3: Operator<B, C>, op4: Operator<C, D>, op5: Operator<D, E>, op6: Operator<E, F>, op7: Operator<F, G>, op8: Operator<G, H>, op9: Operator<H, I>, op10: Operator<I, J>, op11: Operator<J, K>): Stream<K>;
    <A, B, C, D, E, F, G, H, I, J, K, L>(op1: Operator<T, A>, op2: Operator<A, B>, op3: Operator<B, C>, op4: Operator<C, D>, op5: Operator<D, E>, op6: Operator<E, F>, op7: Operator<F, G>, op8: Operator<G, H>, op9: Operator<H, I>, op10: Operator<I, J>, op11: Operator<J, K>, op12: Operator<K, L>): Stream<L>;
    <A, B, C, D, E, F, G, H, I, J, K, L, M>(op1: Operator<T, A>, op2: Operator<A, B>, op3: Operator<B, C>, op4: Operator<C, D>, op5: Operator<D, E>, op6: Operator<E, F>, op7: Operator<F, G>, op8: Operator<G, H>, op9: Operator<H, I>, op10: Operator<I, J>, op11: Operator<J, K>, op12: Operator<K, L>, op13: Operator<L, M>): Stream<M>;
    <A, B, C, D, E, F, G, H, I, J, K, L, M, N>(op1: Operator<T, A>, op2: Operator<A, B>, op3: Operator<B, C>, op4: Operator<C, D>, op5: Operator<D, E>, op6: Operator<E, F>, op7: Operator<F, G>, op8: Operator<G, H>, op9: Operator<H, I>, op10: Operator<I, J>, op11: Operator<J, K>, op12: Operator<K, L>, op13: Operator<L, M>, op14: Operator<M, N>): Stream<N>;
    <A, B, C, D, E, F, G, H, I, J, K, L, M, N, O>(op1: Operator<T, A>, op2: Operator<A, B>, op3: Operator<B, C>, op4: Operator<C, D>, op5: Operator<D, E>, op6: Operator<E, F>, op7: Operator<F, G>, op8: Operator<G, H>, op9: Operator<H, I>, op10: Operator<I, J>, op11: Operator<J, K>, op12: Operator<K, L>, op13: Operator<L, M>, op14: Operator<M, N>, op15: Operator<N, O>): Stream<O>;
    <A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P>(op1: Operator<T, A>, op2: Operator<A, B>, op3: Operator<B, C>, op4: Operator<C, D>, op5: Operator<D, E>, op6: Operator<E, F>, op7: Operator<F, G>, op8: Operator<G, H>, op9: Operator<H, I>, op10: Operator<I, J>, op11: Operator<J, K>, op12: Operator<K, L>, op13: Operator<L, M>, op14: Operator<M, N>, op15: Operator<N, O>, op16: Operator<O, P>): Stream<P>;
    (...operators: Operator<any, any>[]): Stream<any>;
}

/**
 * Functional Scheduler
 *
 * Guarantees:
 * - FIFO execution (one task at a time)
 * - Supports synchronous and asynchronous tasks
 * - Errors reject the task promise but do NOT stop the queue
 * - `flush()` is microtask-stable:
 *   it resolves only after the queue stays empty
 *   across a microtask turn (prevents “flush lies”)
 *
 * Performance optimizations:
 * - Parallel arrays instead of per-task objects
 * - At most one pump in flight
 * - Compact storage for flush waiters
 */
export type Scheduler = {
    /**
     * Enqueue a task for serialized execution.
     *
     * The task may return a value or a promise.
     * The returned promise resolves or rejects with the task result.
     */
    enqueue: <T>(fn: () => Promise<T> | T) => Promise<T>;
    /**
     * Resolves when the scheduler becomes idle and
     * remains idle across a microtask boundary.
     */
    flush: () => Promise<void>;
};

export declare function createScheduler(): Scheduler;

/**
 * Global scheduler instance used by Streamix.
 */
export declare const scheduler: Scheduler;

/**
 * Converts a `Stream` into an async generator, yielding each emitted value.
 * Distinguishes between undefined values and stream completion.
 *
 * This function creates a bridge between the push-based nature of a stream and
 * the pull-based nature of an async generator. It relies on the stream's
 * async-iterable interface (backed by the same multicast machinery used for
 * subscriptions), so `for await...of eachValueFrom(stream)` is equivalent to
 * `for await...of stream`.
 *
 * The generator handles all stream events:
 * - Each yielded value corresponds to a `next` event, including undefined values.
 * - The generator terminates when the stream `complete`s.
 * - It throws an error if the stream emits an `error` event.
 *
 * It correctly handles situations where the stream completes or errors out
 * before any values are yielded, and ensures the subscription is
 * always cleaned up.
 *
 * @template T The type of the values emitted by the stream.
 * @param stream The source stream to convert.
 * @returns An async generator that yields the values from the stream.
 */
export declare function eachValueFrom<T = any>(stream: Stream<T>): AsyncGenerator<T>;

/**
 * Returns a promise that resolves with the first emitted value from a `Stream`.
 *
 * This utility function bridges the gap between the stream's push-based system and
 * JavaScript's standard promise-based asynchronous programming model. It's designed
 * for scenarios where you only care about the very first value a stream produces,
 * treating the stream like a single-value asynchronous source.
 *
 * The function's behavior is as follows:
 * - If the stream emits a value, the promise resolves with that value.
 * - If the stream emits an error, the promise rejects with that error.
 * - If the stream completes without ever emitting a value, the promise rejects with an `Error`.
 *
 * Once the promise is either resolved or rejected, the subscription to the stream is
 * automatically terminated, preventing any further resource consumption. This makes it
 * an efficient way to "query" a stream for a single result.
 *
 * @template T The type of the value that the promise will resolve with.
 * @param stream The source stream to listen to.
 * @returns A promise that resolves with the first value from the stream or rejects on error or completion without a value.
 */
export declare function firstValueFrom<T = any>(stream: Stream<T>): Promise<T>;

/**
 * Core interface for a buffer that supports concurrent reading and writing.
 * It models an asynchronous iterable stream.
 */
export type CyclicBuffer<T = any> = {
    /** Writes a value to the buffer, making it available for readers. */
    write(value: T): Promise<void>;
    /** Writes an error to the buffer, which will be thrown by readers. */
    error(err: Error): Promise<void>;
    /** Reads the next available item, waiting if the buffer is empty. */
    read(readerId: number): Promise<IteratorResult<T, void>>;
    /** Peeks at the next available item without consuming it. */
    peek(readerId: number): Promise<IteratorResult<T, void>>;
    /** Completes the buffer, signaling readers that no more items will arrive. */
    complete(): Promise<void>;
    /** Registers a new reader and returns its unique ID. */
    attachReader(): Promise<number>;
    /** Removes a reader and may trigger buffer pruning/memory cleanup. */
    detachReader(readerId: number): Promise<void>;
    /** Checks if the buffer has completed or errored for a specific reader. */
    completed(readerId: number): boolean;
};

/** Extends CyclicBuffer for "Subject" behavior, providing access to the current value. */
export type SubjectBuffer<T = any> = CyclicBuffer<T> & {
    /** Gets the latest non-error value written to the buffer, or undefined. */
    get value(): T | undefined;
};

/** Extends CyclicBuffer for "Replay" behavior, providing access to the history. */
export type ReplayBuffer<T = any> = CyclicBuffer<T> & {
    /** Gets an array containing all currently buffered values (the replay history). */
    get buffer(): T[];
};

/**
 * Simple condition variable implementation based on Promises.
 * Used to signal waiting readers when new data arrives or completion/error occurs.
 */
export declare function createNotifier(): {
    /** Returns a Promise that resolves when signal() or signalAll() is called. */
    wait: () => Promise<void>;
    /** Signals a single waiting reader. */
    signal: () => void | undefined;
    /** Signals all waiting readers. */
    signalAll: () => void;
};

/**
 * Creates a Subject Buffer. It acts as a queuing stream:
 * 1. Values are buffered only if active readers are present.
 * 2. New readers DO NOT receive past values (non-replaying).
 * 3. Multiple writes are delivered to readers in order (queued).
 */
export declare function createSubjectBuffer<T = any>(): CyclicBuffer<T>;

/**
 * Creates a BehaviorSubject Buffer. It extends the Subject Buffer by:
 * 1. Storing the single latest value (or error).
 * 2. Delivering the latest value to new readers upon attachment (replaying 1 item).
 * 3. Exposing the current value via the `.value` getter.
 */
export declare function createBehaviorSubjectBuffer<T = any>(initialValue?: MaybePromise<T>): SubjectBuffer<T>;

/**
 * Creates a Replay Buffer with a fixed capacity. It acts as a history stream:
 * 1. Buffers the last 'capacity' number of items (circular buffer).
 * 2. New readers start from the oldest available item within the capacity window (replaying).
 * 3. Supports backpressure via a Semaphore when the buffer is full.
 */
export declare function createReplayBuffer<T = any>(capacity: MaybePromise<number>): ReplayBuffer<T>;

/**
 * A function that releases a lock or a permit.
 * @callback ReleaseFn
 * @returns {void}
 */
export type ReleaseFn = () => void;

/**
 * An interface for a function that creates a simple asynchronous lock.
 *
 * @interface
 */
export type SimpleLock = () => Promise<ReleaseFn>;

/**
 * Creates a simple asynchronous lock mechanism. Only one caller can hold the lock at a time.
 * Subsequent calls will queue up and wait for the lock to be released. This is useful
 * for synchronizing access to shared resources in an asynchronous environment.
 *
 * The function returns a promise that resolves with a `ReleaseFn`. The caller must
 * invoke this function to release the lock, allowing the next queued caller to proceed.
 *
 * @returns {SimpleLock} A function that, when called, returns a promise to acquire the lock.
 */
export declare const createLock: () => SimpleLock;

/**
 * Creates an asynchronous queue that processes operations sequentially.
 * Operations are guaranteed to run in the order they are enqueued, one after another.
 * This is useful for preventing race conditions and ensuring that dependent
 * asynchronous tasks are executed in a specific order.
 *
 * @returns {{ enqueue: (operation: () => Promise<any>) => Promise<any>, pending: number, isEmpty: boolean }} An object representing the queue.
 * @property {(operation: () => Promise<any>) => Promise<any>} enqueue Enqueues an asynchronous operation to be executed sequentially.
 * @property {number} pending The number of operations currently in the queue (including the one running).
 * @property {boolean} isEmpty A boolean indicating whether the queue is empty.
 */
export declare function createQueue(): {
    enqueue: (operation: () => Promise<any>) => Promise<any>;
    readonly pending: number;
    readonly isEmpty: boolean;
};

/**
 * An interface for a semaphore, a synchronization primitive for controlling
 * access to a limited number of resources.
 *
 * @interface
 */
export type Semaphore = {
    /**
     * Acquires a permit from the semaphore. If no permits are available,
     * this promise-based method will block until a permit is released.
     *
     * @returns {Promise<ReleaseFn>} A promise that resolves with a function to call to release the permit.
     */
    acquire: () => Promise<ReleaseFn>;
    /**
     * Attempts to acquire a permit from the semaphore without blocking.
     *
     * @returns {ReleaseFn | null} A function to call to release the permit if one was acquired, otherwise `null`.
     */
    tryAcquire: () => ReleaseFn | null;
    /**
     * Releases a permit back to the semaphore. This unblocks the next waiting
     * `acquire` call in the queue or increments the available permit count.
     */
    release: () => void;
};

/**
 * Creates a semaphore for controlling access to a limited number of resources.
 *
 * A semaphore is a synchronization primitive that allows you to manage
 * concurrent access to resources by maintaining a count of available "permits."
 *
 * @param {number} initialCount The initial number of permits available. Must be a non-negative integer.
 * @returns {Semaphore} A semaphore object with `acquire`, `tryAcquire`, and `release` methods.
 */
export declare const createSemaphore: (initialCount: number) => Semaphore;

/**
 * A `Subject` is a special type of `Stream` that can be manually pushed new values.
 * It acts as both a source of values and a consumer, multicasting to multiple subscribers.
 * Unlike a standard stream which is "cold" and begins from scratch for each subscriber,
 * a Subject is "hot" and broadcasts the same values to all of its subscribers.
 * @template T The type of the values held and emitted by the subject.
 * @extends {Stream<T>}
 */
export type Subject<T = any> = Stream<T> & {
    /**
     * Pushes the next value to all active subscribers.
     * @param {T} value The value to emit.
     * @returns {void}
     */
    next(value: T): void;
    /**
     * Signals that the subject has completed and will emit no more values.
     * This completion signal is sent to all subscribers.
     * @returns {void}
     */
    complete(): void;
    /**
     * Signals that the subject has terminated with an error.
     * The error is sent to all subscribers, and the subject is marked as completed.
     * @param {any} err The error to emit.
     * @returns {void}
     */
    error(err: any): void;
    /**
     * Checks if the subject has been completed.
     * @returns {boolean} `true` if the subject has completed, `false` otherwise.
     */
    completed(): boolean;
    /**
     * Provides synchronous access to the most recently pushed value.
     * @type {T | undefined}
     */
    get snappy(): T | undefined;
};

/**
 * Creates a new Subject instance.
 *
 * A Subject can be used to manually control a stream, emitting values
 * to all active subscribers. It is a fundamental building block for
 * reactive patterns like event bus systems or shared state management.
 *
 * @template T The type of the values that the subject will emit.
 * @returns {Subject<T>} A new Subject instance.
 */
export declare function createSubject<T = any>(scheduler?: Scheduler): Subject<T>;

/**
 * A BehaviorSubject is a special type of Subject that maintains
 * a current value and emits that value immediately to new subscribers.
 * It allows synchronous retrieval of the latest emitted value via `.snappy`.
 *
 * It is "stateful" in that it remembers the last value it emitted.
 *
 * @template T The type of the values held and emitted by the subject.
 * @extends {Subject<T>}
 */
export type BehaviorSubject<T = any> = Subject<T> & {
    /**
     * Provides synchronous access to the most recently pushed value.
     * This value is the last value passed to the `next()` method, or the initial value if none have been emitted.
     *
     * @type {T}
     */
    get snappy(): T;
};

/**
 * Creates a BehaviorSubject that holds a current value and emits it immediately to new subscribers.
 * It maintains the latest value internally and allows synchronous access via the `snappy` getter.
 *
 * The subject queues emitted values and delivers them to subscribers asynchronously,
 * supporting safe concurrent access and orderly processing.
 *
 * @template T The type of the values the subject will hold.
 * @param {T} initialValue The value that the subject will hold upon creation.
 * @returns {BehaviorSubject<T>} A new BehaviorSubject instance.
 */
export declare function createBehaviorSubject<T = any>(initialValue: T): BehaviorSubject<T>;

/**
 * A type alias for a ReplaySubject, which is a type of Subject.
 *
 * A ReplaySubject stores a specified number of the latest values it has emitted
 * and "replays" them to any new subscribers. This allows late subscribers to
 * receive past values they may have missed.
 *
 * @template T The type of the values emitted by the subject.
 * @extends {Subject<T>}
 */
export type ReplaySubject<T = any> = Subject<T>;

/**
 * Creates a new ReplaySubject.
 *
 * A ReplaySubject is a variant of a Subject that stores a specified number of
 * the latest values it has emitted and "replays" them to any new subscribers.
 * This allows late subscribers to receive past values they may have missed.
 *
 * This subject provides asynchronous delivery and scheduling via a global scheduler.
 *
 * @template T The type of the values the subject will emit.
 * @param {number} [capacity=Infinity] The maximum number of past values to buffer and replay to new subscribers.
 * @returns {ReplaySubject<T>} A new ReplaySubject instance.
 */
export declare function createReplaySubject<T = any>(capacity?: number): ReplaySubject<T>;

/**
 * Combines multiple streams and emits a tuple containing the latest values
 * from each stream whenever any of the source streams emits a new value.
 *
 * This operator is useful for scenarios where you need to react to changes
 * in multiple independent data sources simultaneously. The output stream
 * will not emit a value until all source streams have emitted at least one
 * value. The output stream completes when all source streams have completed.
 *
 * @template {unknown[]} T A tuple type representing the combined values from the streams.
 * @param streams Streams/values to combine.
 * @returns {Stream<T>} A new stream that emits a tuple of the latest values from all source streams.
 */
export declare function combineLatest<T extends unknown[] = any[]>(...sources: Array<MaybePromise<Stream<T[number]> | Array<T[number]> | T[number]>>): Stream<T>;

/**
 * Creates a stream operator that emits the latest value from the source stream
 * at most once per specified duration.
 *
 * Each incoming value is stored as the "latest"; a timer emits that latest value
 * when the duration elapses. If the source completes before emission, the last
 * buffered value is flushed before completing.
 *
 * @template T The type of the values in the stream.
 * @param duration The time in milliseconds (or a promise resolving to it) to wait
 * before emitting the latest value. The duration is resolved once when the operator starts.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare const audit: <T = any>(duration: MaybePromise<number>) => Operator<T, T>;

/**
 * Buffers values from the source stream and emits them as arrays every `period` milliseconds,
 * while tracking pending and phantom values in the PipeContext.
 *
 * @template T The type of the values in the source stream.
 * @param period Time in milliseconds between each buffer flush.
 * @returns An Operator instance for use in a stream's `pipe` method.
 */
export declare function buffer<T = any>(period: MaybePromise<number>): Operator<T, T[]>;

/**
 * Buffers a fixed number of values from the source stream and emits them as arrays,
 * tracking pending and phantom values in the PipeContext.
 *
 * @template T The type of values in the source stream.
 * @param bufferSize The maximum number of values per buffer (default: Infinity).
 * @returns An Operator instance for use in a stream's `pipe` method.
 */
export declare const bufferCount: <T = any>(bufferSize?: MaybePromise<number>) => Operator<T, T[]>;

/**
 * @typedef {object} CoroutineMessage
 * Message structure exchanged between main thread and Web Workers in the Coroutine operator.
 * @property {number} workerId - The unique ID of the worker.
 * @property {string} taskId - The unique ID of the task.
 * @property {string} type - The type of message (e.g., 'task', 'response', 'error').
 * @property {any} [payload] - The optional message payload.
 * @property {string} [error] - The optional error message.
 */
export type CoroutineMessage = {
    workerId: number;
    taskId: string;
    type: string;
    payload?: any;
    error?: string;
};

/**
 * @typedef {object} CoroutineConfig
 * Configuration object for the Coroutine factory.
 * @property {string} [template] - Custom worker script template. Use {HELPERS}, {DEPENDENCIES}, {MAIN_TASK} as placeholders.
 * @property {string[]} [helpers] - Custom helper scripts to inject.
 * @property {string} [initCode] - Custom initialization code that runs when the worker starts.
 * @property {string} [globals] - Additional imports or global variables.
 * @property {function(MessageEvent<CoroutineMessage>, Worker, Map<string, { resolve: (value: any) => void; reject: (error: Error) => void }>): void} [customMessageHandler] - A custom message handler for all messages from the worker.
 */
export type CoroutineConfig = {
    template?: string;
    helpers?: string[];
    initCode?: string;
    globals?: string;
    customMessageHandler?: (event: MessageEvent<CoroutineMessage>, worker: Worker, pendingTasks: Map<string, {
        resolve: (value: any) => void;
        reject: (error: Error) => void;
    }>) => void;
};

/**
 * @typedef {Operator<T, R> & {
 * assignTask: (workerId: number, data: T) => Promise<R>;
 * processTask: (data: T) => Promise<R>;
 * getIdleWorker: () => Promise<{ worker: Worker; workerId: number }>;
 * returnWorker: (workerId: number) => void;
 * finalize: () => Promise<void>;
 * }} Coroutine
 * @template T
 * @template R
 * Extended Operator that manages a pool of Web Workers for concurrent task processing.
 */
export type Coroutine<T = any, R = T> = Operator<T, R> & {
    /**
     * Assigns a task to a specific worker in the pool.
     *
     * @param workerId The ID of the worker to which the task will be assigned.
     * @param data The input data for the task.
     * @returns A Promise that resolves with the result of the task.
     */
    assignTask: (workerId: number, data: T) => Promise<R>;
    /**
     * Processes a task by assigning it to the next available worker in the pool.
     * This is the primary method for offloading work.
     *
     * @param data The input data for the task.
     * @returns A Promise that resolves with the result of the task.
     */
    processTask: (data: T) => Promise<R>;
    /**
     * Retrieves a worker from the pool that is ready to accept a new task.
     * If no workers are available, a new one may be created, up to a maximum limit.
     *
     * @returns A Promise that resolves with an object containing the worker and its ID.
     */
    getIdleWorker: () => Promise<{
        worker: Worker;
        workerId: number;
    }>;
    /**
     * Returns a worker to the pool, making it available for subsequent tasks.
     *
     * @param workerId The ID of the worker to return.
     */
    returnWorker: (workerId: number) => void;
    /**
     * Terminates all active workers and cleans up all related resources,
     * including the object URL for the worker script.
     *
     * @returns A Promise that resolves when all cleanup is complete.
     */
    finalize: () => Promise<void>;
};

/**
 * @callback ProgressCallback
 * @param {any} progressData - The data object containing progress information.
 * Callback function to report progress updates from a task.
 */
export type ProgressCallback = (progressData: any) => void;

/**
 * @typedef {object} WorkerUtils
 * The utility functions passed to the worker's main task function.
 * @property {(payload: any) => Promise<any>} requestData - A function to request data from the main thread.
 * @property {(progressData: any) => void} reportProgress - A function to report progress updates to the main thread.
 */
export type WorkerUtils = {
    requestData: (payload: any) => Promise<any>;
    reportProgress: (progressData: any) => void;
};

/**
 * @typedef {(data: T) => Promise<R> | R | ((data: T, utils: WorkerUtils) => Promise<R> | R)} MainTask
 * @template T
 * @template R
 * Type for the main task function running inside the worker.
 */
export type MainTask<T = any, R = any> = ((data: T) => Promise<R> | R) | ((data: T, utils: WorkerUtils) => Promise<R> | R);

/**
 * Creates a coroutine operator for managing a pool of Web Workers.
 *
 * This function has two overloaded signatures:
 * 1. `coroutine(config)`: Returns a factory function that takes a main task and helper functions.
 * 2. `coroutine(mainTask, ...helpers)`: Directly creates a coroutine operator with a default configuration.
 *
 * This operator is a powerful tool for offloading computationally intensive tasks from the main
 * thread, allowing for concurrent processing of stream data without blocking the UI. It manages a pool
 * of workers, dynamically scaling up to `navigator.hardwareConcurrency` and reusing workers
 * to minimize overhead.
 *
 * @template T The type of the input data for the main task.
 * @template R The type of the return value from the main task.
 * @param {CoroutineConfig} config - The configuration object for the worker pool.
 * @returns {<T, R>(main: MainTask<T, R>, ...functions: Function[]) => Coroutine<T, R>} A higher-order function for creating a Coroutine operator.
 */
export declare function coroutine(config: CoroutineConfig): <T, R>(main: MainTask<T, R>, ...functions: Function[]) => Coroutine<T, R>;

/**
 * Creates a coroutine operator with a default configuration.
 * @template T The type of the input data for the main task.
 * @template R The type of the return value from the main task.
 * @param {MainTask<T, R>} main - The main task function to run inside the workers.
 * @param {Function[]} functions - Any helper functions required by the main task.
 * @returns {Coroutine<T, R>} A Coroutine operator.
 */
export declare function coroutine<T, R>(main: MainTask<T, R>, ...functions: Function[]): Coroutine<T, R>;

/**
 * A coroutine-like operator that can process tasks asynchronously in the background.
 * Extends the base Operator interface to provide task processing capabilities
 * with proper resource cleanup.
 *
 * This interface combines the properties of a stream `Operator` with the
 * functionality of a standalone coroutine, allowing it to be used for
 * both stream transformations and direct, one-off data processing.
 *
 * @template T The type of the input value.
 * @template R The type of the output value.
 */
export interface CoroutineLike<T = any, R = T> extends Operator<T, R> {
    /**
     * Processes a single piece of data asynchronously.
     * This method allows the coroutine's logic to be called directly, outside of a stream pipeline.
     *
     * @param data The input data to be processed.
     * @returns A Promise that resolves with the processed output.
     */
    processTask: (data: T) => Promise<R>;
    /**
     * Performs any necessary cleanup and finalization logic.
     * This method is called to release resources held by the coroutine.
     *
     * @returns A Promise that resolves when finalization is complete.
     */
    finalize: () => Promise<void>;
}

export declare function cascade<A, B>(...tasks: [
    MaybePromise<Coroutine<A, B>>
]): CoroutineLike<A, B>;

export declare function cascade<A, B, C>(...tasks: [
    MaybePromise<Coroutine<A, B>>,
    MaybePromise<Coroutine<B, C>>
]): CoroutineLike<A, C>;

export declare function cascade<A, B, C, D>(...tasks: [
    MaybePromise<Coroutine<A, B>>,
    MaybePromise<Coroutine<B, C>>,
    MaybePromise<Coroutine<C, D>>
]): CoroutineLike<A, D>;

export declare function cascade<T = any, R = any>(...tasks: Array<MaybePromise<Coroutine<any, any>>>): CoroutineLike<T, R>;

/**
 * Creates a stream operator that catches errors from the source stream and handles them.
 *
 * This operator listens for errors from the upstream source. When the first error is
 * caught, it invokes a provided `handler` callback and then immediately completes
 * the stream, preventing the error from propagating further down the pipeline.
 *
 * - **Error Handling:** The `handler` is executed only for the first error encountered.
 * - **Completion:** After an error is caught and handled, the operator completes,
 * terminating the stream's flow.
 * - **Subsequent Errors:** Any errors after the first will be re-thrown.
 *
 * This is useful for error-handling strategies where you want to perform a specific
 * cleanup action and then gracefully terminate the stream.
 *
 * @template T The type of the values emitted by the stream.
 * @param handler The function to call when an error is caught. It can return a `void` or a `Promise<void>`.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare const catchError: <T = any>(handler?: (error: any) => MaybePromise<void>) => Operator<T, T>;

/**
 * Creates a stream operator that maps each value from the source stream to a new
 * inner stream (or value/array/promise) and flattens all inner streams sequentially.
 *
 * For each value from the source:
 * 1. The `project` function is called with the value and its index.
 * 2. The returned value is normalized into a stream using {@link fromAny}.
 * 3. The inner stream is consumed fully before processing the next outer value.
 *
 * This ensures that all emitted values maintain their original sequential order.
 *
 * @template T The type of values in the source stream.
 * @template R The type of values emitted by the inner streams and the output.
 * @param project A function that takes a value from the source stream and its index,
 * and returns either:
 *   - a {@link Stream<R>},
 *   - a {@link MaybePromise<R>} (value or promise),
 *   - or an array of `R`.
 * @returns An {@link Operator} instance that can be used in a stream's `pipe` method.
 */
export declare const concatMap: <T = any, R = T>(project: (value: T, index: number) => MaybePromise<(Stream<R> | Promise<R> | Array<R>)>) => Operator<T, R>;

/**
 * Creates a stream operator that counts the number of items emitted by the source stream.
 *
 * This operator consumes all values from the source stream without emitting anything.
 * Once the source stream completes, it emits a single value, which is the total
 * number of items that were in the source stream. It then completes.
 *
 * @template T The type of the values in the source stream.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare const count: <T = any>() => Operator<T, number>;

/**
 * Creates a stream operator that emits the most recent value from the source stream
 * only after a specified duration has passed without another new value.
 *
 * This version tracks pending results in the PipeContext and marks
 * superseded values as phantoms.
 *
 * @template T The type of the values in the source and output streams.
 * @param duration The debounce duration in milliseconds.
 * @returns An Operator instance for use in a stream pipeline.
 */
export declare function debounce<T = any>(duration: MaybePromise<number>): Operator<T, T>;

/**
 * Creates a stream operator that emits a default value if the source stream is empty.
 *
 * This operator monitors the source stream for any emitted values. If the source
 * stream completes without emitting any values, this operator will emit a single
 * `defaultValue` and then complete. If the source stream does emit at least one value,
 * this operator will pass all values through and will not emit the `defaultValue`.
 *
 * @template T The type of the values in the stream.
 * @param defaultValue The value to emit if the source stream is empty.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare const defaultIfEmpty: <T = any>(defaultValue: MaybePromise<T>) => Operator<T, T>;

/**
 * Creates a stream operator that delays the emission of each value from the source stream
 * while tracking pending and phantom states.
 *
 * Each value received from the source is added to `context.pendingResults` and is only
 * resolved once the delay has elapsed and the value is emitted downstream.
 *
 * @template T The type of the values in the source and output streams.
 * @param ms The time in milliseconds to delay each value.
 * @returns An Operator instance for use in a stream's `pipe` method.
 */
export declare function delay<T = any>(ms: MaybePromise<number>): Operator<T, T>;

/**
 * Creates a stream operator that delays the emission of values from the source stream
 * until a separate `notifier` stream emits at least one value.
 *
 * This operator acts as a gate. It buffers all values from the source stream
 * until the `notifier` stream emits its first value. Once the notifier emits,
 * the operator immediately flushes all buffered values and then passes through
 * all subsequent values from the source without delay.
 *
 * If the `notifier` stream completes without ever emitting a value, the buffered
 * values are DISCARDED, and the operator simply waits for the source to complete.
 *
 * @template T The type of the values in the source and output streams.
 * @param notifier The stream that acts as a gatekeeper.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare function delayUntil<T = any, R = T>(notifier: MaybePromise<Stream<R> | Array<R> | R>): Operator<T, T>;

/**
 * Creates a stream operator that emits values from the source stream only if
 * they are different from the previous value.
 *
 * This operator filters out consecutive duplicate values, ensuring that the
 * output stream only contains values that have changed since the last emission.
 * It's particularly useful for preventing redundant updates in data streams.
 *
 * @template T The type of the values in the stream.
 * @param comparator An optional function that compares the previous and current values.
 * It should return `true` if they are considered the same, and `false` otherwise.
 * If not provided, a strict equality check (`===`) is used.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare const distinctUntilChanged: <T = any>(comparator?: (prev: T, curr: T) => MaybePromise<boolean>) => Operator<T, T>;

/**
 * Creates a stream operator that filters out consecutive values from the source
 * stream if a specified key's value has not changed.
 *
 * This operator is a specialized version of `distinctUntilChanged`. It is designed
 * to work with streams of objects and checks for uniqueness based on the value
 * of a single property (`key`).
 *
 * @template T The type of the objects in the stream. Must extend `object`.
 * @param key The name of the property to check for changes.
 * @param comparator An optional function to compare the previous and current values of the `key`.
 * It should return `true` if the values are considered the same. If not provided,
 * strict inequality (`!==`) is used.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare const distinctUntilKeyChanged: <T extends object = any, K extends keyof T = keyof T>(key: MaybePromise<K>, comparator?: (prev: T[K], curr: T[K]) => MaybePromise<boolean>) => Operator<T, T>;

/**
 * Creates a stream operator that emits only the values at the specified indices from a source stream.
 *
 * This operator takes an `indexIterator` (which can be a synchronous or asynchronous iterator
 * of numbers) and uses it to determine which values from the source stream should be emitted.
 * It acts as a positional filter: each source value is inspected once, and if its zero-based
 * index matches the next index yielded by `indexIterator`, that value is emitted. No buffering
 * of past values occurs. If the iterator completes, the operator completes regardless of
 * remaining source values.
 *
 * @template T The type of the values in the source and output streams.
 * @param indexIterator An iterator or async iterator that provides the zero-based indices
 * of the elements to be emitted.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare const select: <T = any>(indexIterator: Iterator<number> | AsyncIterator<number>) => Operator<T, T>;

/**
 * Creates a stream operator that emits only the single value at the specified zero-based index
 * from the source stream.
 *
 * This operator consumes the source stream until it reaches the `targetIndex`. It then
 * emits the value at that position and immediately completes, effectively ignoring all
 * subsequent values. If the source stream completes before reaching the `targetIndex`,
 * the output stream will also complete without emitting any value.
 *
 * @template T The type of the values in the source stream.
 * @param targetIndex The zero-based index of the element to retrieve. Must be a non-negative number.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 * @throws {Error} Throws an error if `targetIndex` is a negative number.
 */
export declare const elementAt: <T = any>(targetIndex: MaybePromise<number>) => Operator<T, T>;

/**
 * Creates a stream operator that emits elements from the source stream at dynamic indices specified
 * by the asynchronous index pattern function.
 *
 * This operator is a powerful tool for selective data retrieval. It uses an `indexPattern`
 * function to determine which elements to pull from the source stream. The function is
 * called repeatedly, with the current iteration count as an argument, and should return the
 * zero-based index of the next element to emit. The process stops when the function returns `undefined`.
 *
 * This is useful for tasks such as:
 * - Sampling a stream at a fixed interval (e.g., every 10th element).
 * - Picking a specific, non-sequential set of elements.
 * - Creating a custom, sparse output stream.
 *
 * @template T The type of the values in the source stream.
 * @param indexPattern The function that specifies the indices to emit. It receives the current
 * iteration count and should return the next index to emit or `undefined` to stop.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare const elementNth: <T = any>(indexPattern: (iteration: number) => (MaybePromise<number> | undefined)) => Operator<T, T>;

/**
 * Creates a stream operator that tests if all values from the source stream satisfy a predicate.
 *
 * This operator consumes the source stream and applies the provided `predicate` function
 * to each value.
 * - If the `predicate` returns a truthy value for every element until the source stream
 * completes, the operator emits `true`.
 * - If the `predicate` returns a falsy value for any element, the operator immediately
 * emits `false` and then completes, effectively "short-circuiting" the evaluation.
 *
 * This is a "pull-based" equivalent of `Array.prototype.every` and is useful for validating
 * data streams. The operator will emit only a single boolean value before it completes.
 *
 * @template T The type of the values in the source stream.
 * @param predicate The function to test each value. It receives the value and its index.
 * It can be synchronous or asynchronous.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare const every: <T = any>(predicate: (value: T, index: number) => MaybePromise<boolean>) => Operator<T, boolean>;

/**
 * Options to configure the recursive traversal behavior.
 */
export type RecurseOptions = {
    /**
     * The traversal strategy to use.
     * - `'depth'`: Processes deeper values first (LIFO queue).
     * - `'breadth'`: Processes values level by level (FIFO queue).
     * Defaults to depth-first.
     */
    traversal?: 'depth' | 'breadth';
    /**
     * The maximum depth to traverse. Prevents infinite recursion and limits the size
     * of the traversal. Defaults to no limit.
     */
    maxDepth?: number;
};

/**
 * Creates a stream operator that recursively processes values from a source stream.
 *
 * This operator is designed for traversing tree-like or hierarchical data structures.
 * For each value from the source, it checks if it meets a `condition`. If it does,
 * it applies a `project` function to get a new "inner" stream of children. These
 * children are then added to an internal queue and processed in the same recursive manner.
 *
 * The operator supports both depth-first and breadth-first traversal strategies and
 * can be configured with a maximum recursion depth to prevent runaway processing.
 *
 * @template T The type of the values in the source and output streams.
 * @param condition A function that returns a boolean indicating whether to recurse on a value.
 * @param project A function that takes a value and returns a stream of new values to be
 * recursively processed.
 * @param options An optional configuration object for traversal behavior.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare const recurse: <T = any>(condition: (value: T) => MaybePromise<boolean>, project: (value: T) => MaybePromise<Stream<T> | Array<T> | T>, options?: RecurseOptions) => Operator<T, T>;

/**
 * Creates a stream operator that recursively expands each emitted value.
 *
 * This operator takes each value from the source stream and applies the `project`
 * function to it, which must return a new stream. It then recursively applies
 * the same logic to each value emitted by that new stream, effectively
 * flattening an infinitely deep, asynchronous data structure.
 *
 * This is particularly useful for traversing graph or tree-like data, such as
 * file directories or hierarchical API endpoints, where each item might lead
 * to a new collection of items that also need to be processed.
 *
 * @template T The type of the values in the source and output streams.
 * @param project A function that takes a value and returns a stream of new values
 * to be expanded.
 * @param options An optional configuration object for the underlying `recurse` operator.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare const expand: <T = any>(project: (value: T) => MaybePromise<Stream<T> | Array<T> | T>, options?: RecurseOptions) => Operator<T, T>;

/**
 * Creates a stream operator that filters values emitted by the source stream.
 *
 * This operator provides flexible filtering capabilities. It processes each value
 * from the source stream and passes it through to the output stream only if it meets
 * a specific criterion.
 *
 * The filtering can be configured in one of three ways:
 * - A **predicate function**: A function that returns `true` for values to be included.
 * - A **single value**: Only values that are strictly equal (`===`) to this value are included.
 * - An **array of values**: Only values that are present in this array are included.
 *
 * @template T The type of the values in the stream.
 * @param predicateOrValue The filtering criterion. Can be a predicate function, a single value, or an array of values.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare const filter: <T = any>(predicateOrValue: ((value: T, index: number) => MaybePromise<boolean>) | T | T[]) => Operator<T, T>;

/**
 * Creates a stream operator that emits only the first element from the source stream
 * that matches an optional predicate.
 *
 * This operator is designed to find a specific value and then immediately terminate.
 * - If a `predicate` function is provided, the operator will emit the first value for which
 * the predicate returns a truthy value.
 * - If no predicate is provided, it will simply emit the very first value from the source.
 *
 * After emitting a single value, the operator completes. If the source stream completes
 * before a matching value is found, an error is thrown.
 *
 * @template T The type of the values in the source stream.
 * @param predicate An optional function to test each value. It receives the value
 * and should return `true` to indicate a match.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 * @throws {Error} Throws an error with the message "No elements in sequence" if no matching
 * value is found before the source stream completes.
 */
export declare const first: <T = any>(predicate?: (value: T) => MaybePromise<boolean>) => Operator<T, T>;

/**
 * Represents a conditional branch for the `fork` operator.
 *
 * Each `ForkOption` defines:
 * 1. A predicate function `on` to test source values.
 * 2. A handler function `handler` that produces a stream (or value/array/promise) when the predicate matches.
 *
 * @template T The type of values in the source stream.
 * @template R The type of values emitted by the handler and output stream.
 */
export interface ForkOption<T = any, R = any> {
    /**
     * Predicate function to determine if this option should handle a value.
     *
     * @param value The value from the source stream.
     * @param index The zero-based index of the value in the source stream.
     * @returns A boolean or a `Promise<boolean>` indicating whether this option matches.
     */
    on: (value: T, index: number) => MaybePromise<boolean>;
    /**
     * Handler function called for values that match the predicate.
     *
     * Can return:
     * - a {@link Stream<R>}
     * - a {@link MaybePromise<R>} (value or promise)
     * - an array of `R`
     *
     * @param value The source value that matched the predicate.
     * @returns A stream, value, promise, or array to be flattened and emitted.
     */
    handler: (value: T) => (Stream<R> | MaybePromise<R> | Array<R>);
}

/**
 * Creates a stream operator that routes each source value through a specific handler
 * based on matching predicates defined in the provided `ForkOption`s.
 *
 * For each value from the source stream:
 * 1. Iterates over the `options` array.
 * 2. Executes the `on` predicate for each option until one returns `true`.
 * 3. Calls the corresponding `handler` for the first matching option.
 * 4. Flattens the result (stream, value, promise, or array) sequentially into the output stream.
 *
 * If no predicate matches a value, an error is thrown.
 *
 * This operator allows conditional branching in streams based on the content of each item.
 *
 * @template T The type of values in the source stream.
 * @template R The type of values emitted by the output stream.
 * @param options {@link ForkOption} objects defining predicates and handlers.
 * @returns An {@link Operator} instance suitable for use in a stream's `pipe` method.
 *
 * @throws {Error} If a source value does not match any predicate.
 */
export declare const fork: <T = any, R = any>(...options: Array<MaybePromise<ForkOption<T, R>>>) => Operator<T, R>;

/**
 * Represents a grouped item with its original value and the associated key.
 * @template T The type of the original value.
 * @template K The type of the group key.
 */
export type GroupItem<T = any, K = any> = {
    value: T;
    key: K;
};

/**
 * Creates a stream operator that groups values from the source stream by a computed key.
 *
 * This operator is a projection operator that transforms a stream of values into a
 * stream of `GroupItem` objects. For each value from the source, it applies the
 * `keySelector` function to determine a key and then emits an object containing both
 * the original value and the computed key.
 *
 * This operator is the first step in a typical grouping pipeline. The resulting stream
 * of `GroupItem` objects can then be processed further by other operators (e.g., `scan`
 * or `reduce`) to perform a true grouping into collections.
 *
 * @template T The type of the values in the source stream.
 * @template K The type of the key computed by `keySelector`.
 * @param keySelector A function that takes a value from the source stream and returns
 * a key. This function can be synchronous or asynchronous.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare const groupBy: <T = any, K = any>(keySelector: (value: T) => MaybePromise<K>) => Operator<T, GroupItem<T, K>>;

/**
 * Creates a stream operator that ignores all values emitted by the source stream.
 *
 * This operator consumes the source stream but does not emit any values. It only
 * forwards the completion or error signal from the source stream. This is useful
 * when you only care about the "end" of an operation, not the intermediate results.
 * For example, waiting for a stream of side effects to complete before continuing.
 *
 * @template T The type of the values in the source stream (which are ignored).
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare const ignoreElements: <T>() => Operator<T, never>;

/**
 * Creates a stream operator that emits only the last value from the source stream
 * that matches an optional predicate.
 *
 * This operator must consume the entire source stream to find the last matching
 * value. It caches the last value that satisfies the `predicate` (or the last
 * value of the stream if no predicate is provided) and emits it only when the
 * source stream completes.
 *
 * @template T The type of the values in the source stream.
 * @param predicate An optional function to test each value. It receives the value
 * and should return `true` to indicate a match.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 * @throws {Error} Throws an error with the message "No elements in sequence" if no
 * matching value is found before the source stream completes.
 */
export declare const last: <T = any>(predicate?: (value: T) => MaybePromise<boolean>) => Operator<T, T>;

/**
 * Creates a stream operator that applies a transformation function to each value
 * emitted by the source stream.
 *
 * This operator is a fundamental part of stream processing. It consumes each value
 * from the source, passes it to the `transform` function, and then emits the result
 * of that function. This is a one-to-one mapping, meaning the output stream will
 * have the same number of values as the source stream, but with potentially different
 * content and/or type.
 *
 * @template T The type of the values in the source stream.
 * @template R The type of the values in the output stream.
 * @param transform The transformation function to apply to each value. It receives
 * the value and its index. This function can be synchronous or asynchronous.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare const map: <T = any, R = any>(transform: (value: T, index: number) => MaybePromise<R>) => Operator<T, R>;

/**
 * Creates a stream operator that emits the maximum value from the source stream.
 *
 * This is a terminal operator that consumes the entire source lazily,
 * emitting phantoms along the way and finally emitting the maximum value.
 *
 * @template T The type of the values in the source stream.
 * @param comparator Optional comparison function: positive if `a > b`, negative if `a < b`.
 * @returns An `Operator` instance usable in a stream's `pipe` method.
 */
export declare const max: <T = any>(comparator?: (a: T, b: T) => MaybePromise<number>) => Operator<T, T>;

/**
 * Creates a stream operator that maps each value from the source stream to an "inner" stream
 * and merges all inner streams concurrently into a single output stream.
 *
 * For each value from the source stream:
 * 1. The `project` function is called with the value and its index.
 * 2. The returned value is normalized into a stream using {@link fromAny}.
 * 3. The inner stream is consumed concurrently with all other active inner streams.
 * 4. Emitted values from all inner streams are interleaved into the output stream
 *    in the order they are produced, without waiting for other inner streams to complete.
 *
 * This operator is useful for performing parallel asynchronous operations while
 * preserving all emitted values in a merged output.
 *
 * @template T The type of values in the source stream.
 * @template R The type of values emitted by the inner and output streams.
 * @param project A function that maps a source value and its index to either:
 *   - a {@link Stream<R>},
 *   - a {@link MaybePromise<R>} (value or promise),
 *   - or an array of `R`.
 * @returns An {@link Operator} instance that can be used in a stream's `pipe` method.
 */
export declare function mergeMap<T = any, R = any>(project: (value: T, index: number) => MaybePromise<Stream<R> | Array<R> | R>): Operator<T, R>;

/**
 * Creates a stream operator that emits the minimum value from the source stream.
 *
 * This is a terminal operator that must consume the entire source stream before
 * it can emit a single value. It iterates through all values, keeping track of
 * the smallest one seen so far.
 *
 * @template T The type of the values in the source stream.
 * @param comparator An optional function to compare two values. It should return a negative
 * number if `a` is less than `b`, a positive number if `a` is greater than `b`, and zero
 * if they are equal. Defaults to using the `<` operator for comparison.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
/**
 * Creates a stream operator that emits the minimum value from the source stream.
 *
 * This is a terminal operator that consumes the source lazily.
 * It keeps track of the smallest value seen so far and emits phantoms for intermediate values.
 *
 * @template T The type of the values in the source stream.
 * @param comparator Optional function to compare two values. Returns negative if `a < b`.
 * @returns An `Operator` instance usable in a stream's `pipe` method.
 */
export declare const min: <T = any>(comparator?: (a: T, b: T) => MaybePromise<number>) => Operator<T, T>;

/**
 * Creates a stream operator that schedules the emission of each value from the source
 * stream on a specified JavaScript task queue.
 *
 * This operator is a scheduler. It decouples the timing of value production from
 * its consumption, allowing you to control when values are emitted to downstream
 * operators. This is essential for preventing long-running synchronous operations
 * from blocking the main thread and for prioritizing different types of work.
 *
 * The operator supports three contexts:
 * - `"microtask"`: Emits the value at the end of the current task using `queueMicrotask`.
 * - `"macrotask"`: Emits the value in the next event loop cycle using `setTimeout(0)`.
 * - `"idle"`: Emits the value when the browser is idle using `requestIdleCallback`.
 *
 * @template T The type of the values in the source and output streams.
 * @param context The JavaScript task queue context to schedule emissions on.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
/**
 * Creates a stream operator that schedules the emission of each value from the source
 * stream on a specified JavaScript task queue.
 *
 * This operator is a scheduler. It decouples the timing of value production from
 * its consumption, allowing you to control when values are emitted to downstream
 * operators. This is essential for preventing long-running synchronous operations
 * from blocking the main thread and for prioritizing different types of work.
 *
 * The operator supports three contexts:
 * - `"microtask"`: Emits the value at the end of the current task using `queueMicrotask`.
 * - `"macrotask"`: Emits the value in the next event loop cycle using `setTimeout(0)`.
 * - `"idle"`: Emits the value when the browser is idle using `requestIdleCallback`.
 *
 * @template T The type of the values in the source and output streams.
 * @param context The JavaScript task queue context to schedule emissions on.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare const observeOn: <T = any>(context: MaybePromise<"microtask" | "macrotask" | "idle">) => Operator<T, T>;

/**
 * Creates a stream operator that partitions the source stream into two groups based on a predicate.
 *
 * This operator is a specialized form of `groupBy`. For each value from the source stream,
 * it applies the provided `predicate` function. It then emits a new object, a `GroupItem`,
 * containing the original value and a key of `"true"` or `"false"`, indicating whether the
 * value satisfied the predicate.
 *
 * This operator does not create two physical streams, but rather tags each item with its
 * group membership, allowing for subsequent conditional routing or processing.
 *
 * @template T The type of the values in the source stream.
 * @param predicate A function that takes a value and its index and returns a boolean or
 * `Promise<boolean>`. `true` for one group, `false` for the other.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method,
 * emitting objects of type `GroupItem<T, "true" | "false">`.
 */
export declare const partition: <T = any>(predicate: (value: T, index: number) => MaybePromise<boolean>) => Operator<T, GroupItem<T, "true" | "false">>;

/**
 * Creates a stream operator that accumulates all values from the source stream
 * into a single value using a provided accumulator function.
 *
 * This operator consumes the source lazily and emits intermediate values as phantoms.
 * It will always emit at least the seed value if the stream is empty.
 *
 * @template T The type of the values in the source stream.
 * @template A The type of the accumulated value.
 * @param accumulator Function combining current accumulated value with a new value.
 * Can be synchronous or asynchronous.
 * @param seed Initial value for the accumulator.
 * @returns An `Operator` instance usable in a stream's `pipe` method.
 */
export declare const reduce: <T = any, A = any>(accumulator: (acc: A, value: T) => MaybePromise<A>, seed: A) => Operator<T, A>;

/**
 * Creates a stream operator that emits the most recent value from the source stream
 * at a fixed periodic interval while tracking pending and phantom states.
 *
 * Values that arrive faster than the period are considered phantoms if skipped,
 * and pending results are tracked in PipeContext until resolved or emitted.
 *
 * @template T The type of the values in the source and output streams.
 * @param period The time in milliseconds between each emission.
 * @returns An Operator instance for use in a stream's `pipe` method.
 */
export declare const sample: <T = any>(period: MaybePromise<number>) => Operator<T, T>;

/**
 * Creates a stream operator that accumulates values from the source stream,
 * emitting each intermediate accumulated result.
 *
 * This operator is stateful and is ideal for scenarios where you need to maintain
 * a running total or build a state object over the life of a stream. It takes a
 * `seed` value and an `accumulator` function. For each value from the source,
 * it applies the accumulator and emits the new result immediately.
 *
 * @template T The type of the values in the source stream.
 * @template R The type of the accumulated value and the output stream.
 * @param accumulator The function that combines the current accumulated value
 * with the new value from the source. This function can be synchronous or asynchronous.
 * @param seed The initial value for the accumulator.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare const scan: <T = any, R = any>(accumulator: (acc: R, value: T, index: number) => MaybePromise<R>, seed: R) => Operator<T, R>;

/**
 * Creates a stream operator that shares a single subscription to the source stream
 * and replays a specified number of past values to new subscribers.
 *
 * This operator multicasts the source stream, ensuring that multiple downstream
 * consumers can receive values from a single source connection. It uses an internal
 * `ReplaySubject` to cache the most recent values. When a new consumer subscribes,
 * it immediately receives these cached values before receiving new ones.
 *
 * This is useful for:
 * - Preventing redundant execution of a source stream (e.g., a network request).
 * - Providing a "state history" to late subscribers.
 *
 * @template T The type of the values in the stream.
 * @param bufferSize The number of last values to replay to new subscribers. Defaults to `Infinity`.
 *                   Can be a Promise that resolves to a number.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare function shareReplay<T = any>(bufferSize?: MaybePromise<number>): Operator<T, T>;

/**
 * Creates a stream operator that skips the first specified number of values from the source stream.
 *
 * This operator is useful for "fast-forwarding" a stream. It consumes the initial `count` values
 * from the source stream without emitting them to the output. Once the count is reached,
 * it begins to pass all subsequent values through unchanged.
 *
 * @template T The type of the values in the source and output streams.
 * @param count The number of values to skip from the beginning of the stream.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare const skip: <T = any>(count: MaybePromise<number>) => Operator<T, T>;

/**
 * Creates a stream operator that skips all values from the source stream until
 * a value is emitted by a `notifier` stream.
 *
 * This operator controls the flow of data based on an external signal. It initially
 * drops all values from the source stream. It also subscribes to a separate `notifier`
 * stream. When the notifier emits its first value, the operator's internal state
 * changes, allowing all subsequent values from the source stream to pass through.
 *
 * This is useful for delaying the start of a data-intensive process until a specific
 * condition is met, for example, waiting for a user to click a button or for
 * an application to finish loading.
 *
 * @template T The type of the values in the source and output streams.
 * @param notifier The stream that, upon its first emission, signals that the operator
 * should stop skipping values.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare function skipUntil<T = any, R = T>(notifier: MaybePromise<Stream<R> | R>): Operator<T, T>;

/**
 * Creates a stream operator that skips values from the source stream while a predicate returns true.
 *
 * This operator is a powerful filtering tool for removing a contiguous prefix of a stream.
 * It consumes values from the source and applies the `predicate` function to each one.
 * As long as the predicate returns `true`, the values are ignored. As soon as the predicate
 * returns `false` for the first time, this operator begins to emit that value and all
 * subsequent values from the source, regardless of whether they satisfy the predicate.
 *
 * @template T The type of the values in the source and output streams.
 * @param predicate The function to test each value. `true` means to continue skipping,
 * and `false` means to stop skipping and begin emitting.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare const skipWhile: <T = any>(predicate: (value: T) => MaybePromise<boolean>) => Operator<T, T>;

/**
 * Creates a stream operator that emits pairs of values from the source stream,
 * where each pair consists of the previous and the current value.
 *
 * This operator is a powerful tool for comparing consecutive values in a stream.
 * It maintains an internal state to remember the last value it received. For
 * each new value, it creates a tuple of `[previousValue, currentValue]` and
 * emits it to the output stream.
 *
 * The very first value emitted will have `undefined` as its "previous" value.
 *
 * @template T The type of the values in the source stream.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method,
 * emitting tuples of `[T | undefined, T]`.
 */
export declare const slidingPair: <T = any>() => Operator<T, [
    T | undefined,
    T
]>;

/**
 * Creates a stream operator that tests if at least one value from the source stream satisfies a predicate.
 *
 * This operator consumes the source stream and applies the provided `predicate` function
 * to each value.
 * - If the `predicate` returns a truthy value for any element, the operator immediately
 * emits `true` and then completes, effectively "short-circuiting" the evaluation.
 * - If the source stream completes without the `predicate` ever returning a truthy value,
 * the operator emits `false`.
 *
 * This is a "pull-based" equivalent of `Array.prototype.some` and is useful for validating
 * data streams. The operator will emit only a single boolean value before it completes.
 *
 * @template T The type of the values in the source stream.
 * @param predicate The function to test each value. It receives the value and its index.
 * It can be synchronous or asynchronous.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare const some: <T = any>(predicate: (value: T, index: number) => MaybePromise<boolean>) => Operator<T, boolean>;

/**
 * Creates a stream operator that maps each value from the source stream to a new inner stream
 * and "switches" to emitting values from the most recent inner stream, canceling the previous one.
 *
 * For each value from the source:
 * 1. The `project` function is called with the value and its index.
 * 2. The returned value is normalized into a stream using {@link fromAny}.
 * 3. The operator subscribes to the new inner stream and immediately cancels any previous active inner stream.
 * 4. Only values from the latest inner stream are emitted.
 *
 * This operator is useful for scenarios such as:
 * - Type-ahead search where only the latest query results are relevant.
 * - Handling user events where new events invalidate previous operations.
 *
 * @template T The type of values in the source stream.
 * @template R The type of values emitted by the inner and output streams.
 * @param project A function that maps a source value and its index to either:
 *   - a {@link Stream<R>},
 *   - a {@link MaybePromise<R>} (value or promise),
 *   - or an array of `R`.
 * @returns An {@link Operator} instance suitable for use in a stream's `pipe` method.
 */
export declare function switchMap<T = any, R = any>(project: (value: T, index: number) => MaybePromise<Stream<R> | Array<R> | R>): Operator<T, R>;

/**
 * Creates a stream operator that emits only the first `count` values from the source stream
 * and then completes.
 *
 * This operator is a powerful tool for controlling the length of a stream. It consumes values
 * from the source one by one, and as long as the total number of values emitted is less than
 * `count`, it passes them through to the output. Once the count is reached, it stops
 * processing the source and signals completion to its downstream consumers. This is especially
 * useful for managing finite segments of large or infinite streams.
 *
 * @template T The type of the values in the source and output streams.
 * @param count The maximum number of values to take from the beginning of the stream.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare const take: <T = any>(count: MaybePromise<number>) => Operator<T, T>;

/**
 * Creates a stream operator that emits all values from the source stream until
 * a value is emitted by a `notifier` stream.
 *
 * This operator controls the lifespan of a stream based on an external signal.
 * It consumes and re-emits values from the source until the `notifier` stream
 * emits its first value. As soon as that happens, the operator completes the
 * output stream and unsubscribes from both the source and the notifier.
 *
 * This is useful for automatically stopping an operation when a certain condition
 * is met, such as waiting for a user to close a dialog or for an animation to complete.
 *
 * @template T The type of the values in the source and output streams.
 * @param notifier The stream that, upon its first emission, signals that the operator
 * should complete.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare function takeUntil<T = any, R = T>(notifier: MaybePromise<Stream<R> | R>): Operator<T, T>;

/**
 * Creates a stream operator that emits values from the source stream as long as
 * a predicate returns true.
 *
 * This operator is a conditional limiter. It consumes values from the source stream
 * and applies the `predicate` function to each. As long as the predicate returns `true`,
 * the value is passed through to the output stream. The first time the predicate returns
 * a falsy value, the operator stops emitting and immediately completes the output stream.
 * The value that caused the predicate to fail is not emitted.
 *
 * This is useful for taking a contiguous block of data from a stream that meets a certain
 * condition, such as processing user input until an invalid entry is made.
 *
 * @template T The type of the values in the source and output streams.
 * @param predicate The function to test each value. `true` means to continue emitting,
 * and `false` means to stop and complete. It can be synchronous or asynchronous.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare const takeWhile: <T = any>(predicate: (value: T) => MaybePromise<boolean>) => Operator<T, T>;

/**
 * Creates a stream operator that performs a side-effect for each value from the source
 * stream without modifying the value.
 *
 * This operator is primarily used for debugging, logging, or other non-intrusive
 * actions that need to be performed on each value as it passes through the pipeline.
 * It is completely transparent to the data stream itself, as it does not transform,
 * filter, or buffer the values. The provided `tapFunction` is executed for each
 * value before the value is emitted to the next operator.
 *
 * @template T The type of the values in the source and output streams.
 * @param tapFunction The function to perform the side-effect. It receives the value
 * from the stream and can be synchronous or asynchronous.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare const tap: <T = any>(tapFunction: (value: T) => MaybePromise<any>) => Operator<T, T>;

/**
 * Creates a throttle operator that emits the first value immediately, then ignores subsequent
 * values for the specified duration. If new values arrive during the cooldown, the
 * last one is emitted after the cooldown expires (trailing emit).
 *
 * This version tracks pending results and phantoms in PipeContext.
 *
 * @template T The type of values emitted by the source and output.
 * @param duration The throttle duration in milliseconds.
 * @returns An Operator instance that applies throttling to the source stream.
 */
export declare const throttle: <T = any>(duration: MaybePromise<number>) => Operator<T, T>;

/**
 * Creates a stream operator that immediately throws an error with the provided message.
 *
 * This operator is a source operator that is used to create a stream that immediately
 * fails. When a consumer requests a value by calling `next()`, the operator
 * will throw an `Error` with the given `message`, without emitting any values.
 *
 * This is useful for testing error handling logic in a stream pipeline or for
 * explicitly modeling a failed asynchronous operation.
 *
 * @template T The type of the values in the stream (this is a formality, as no values are emitted).
 * @param message The error message to be thrown.
 * @returns An `Operator` instance that creates a stream which errors upon its first request.
 */
export declare const throwError: <T = any>(message: MaybePromise<string>) => Operator<T, never>;

/**
 * Collects all emitted values from the source stream into an array
 * and emits that array once the source completes, tracking pending state.
 *
 * @template T The type of the values in the source stream.
 * @returns An Operator instance for use in a stream's `pipe` method.
 */
export declare const toArray: <T = any>() => Operator<T, T[]>;

/**
 * Creates a stream operator that emits only distinct values from the source stream.
 *
 * This operator maintains an internal set of values or keys that it has already emitted.
 * For each new value from the source, it checks if it has been seen before. If not,
 * the value is emitted and added to the set; otherwise, it is skipped.
 *
 * The uniqueness check can be based on the value itself or on a key derived from
 * the value using a provided `keySelector` function. This makes it ideal for de-duplicating
 * streams of primitive values or complex objects.
 *
 * @template T The type of the values in the source stream.
 * @template K The type of the key used for comparison.
 * @param keySelector An optional function to derive a unique key from each value.
 * If not provided, the values themselves are used for comparison.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare const unique: <T = any, K = any>(keySelector?: (value: T) => MaybePromise<K>) => Operator<T, T>;

/**
 * Creates a stream operator that combines the source stream with the latest values
 * from other provided streams.
 *
 * This operator is useful for merging a "trigger" stream with "state" streams.
 * It waits for a value from the source stream and, when one arrives, it emits a
 * tuple containing that source value along with the most recently emitted value
 * from each of the other streams.
 *
 * The operator is "gated" and will not emit any values until all provided streams
 * have emitted at least one value.
 * Inputs may be streams, plain values, arrays, or promises of those shapes; a single
 * array argument is treated the same as passing values variadically.
 *
 * @template T The type of the values in the source stream.
 * @template R The tuple type of the values from the other streams (e.g., [R1, R2, R3]).
 * @param streams Streams (or values/arrays/promises) to combine with the source stream.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 * The output stream emits tuples of `[T, ...R]`.
 */
export declare function withLatestFrom<T = any, R extends readonly unknown[] = any[]>(...streams: {
    [K in keyof R]: MaybePromise<Stream<R[K]> | Array<R[K]> | R[K]>;
}): Operator<T, [
    T,
    ...R
]>;

/**
 * Creates a stream that runs a computation task on a worker from a Coroutine pool,
 * yielding the result once the computation completes.
 *
 * This operator is designed for offloading CPU-intensive tasks to a background
 * thread, preventing the main thread from being blocked and keeping the UI
 * responsive. It uses a `Coroutine` to manage a pool of web workers.
 * The stream will emit a single value and then complete.
 *
 * @template T The type of the result from the computation.
 * @param {Coroutine | PromiseLike<Coroutine>} task The coroutine instance managing the worker pool.
 * @param {any | PromiseLike<any>} params The data to send to the worker for computation.
 * @returns {Stream<T>} A new stream that emits the result of the computation.
 */
export declare function compute<T = any>(task: MaybePromise<Coroutine>, params: MaybePromise<any>): Stream<T>;

/**
 * Creates a stream that subscribes to multiple streams in sequence.
 *
 * This operator will subscribe to the first stream and yield all of its
 * values. Once the first stream completes, it will then subscribe to the
 * second stream, and so on, until all streams have completed. The resulting
 * stream will complete only after the last source stream has completed.
 *
 * If any of the source streams errors, the concatenated stream will also error and
 * stop processing the remaining streams.
 *
 * @template T The type of the values in the streams.
 * @param sources Streams/values (or a promise of an array) to concatenate.
 * @returns {Stream<T>} A new stream that emits values from all input streams in sequence.
 */
export declare function concat<T = any, R extends readonly unknown[] = any[]>(...sources: {
    [K in keyof R]: MaybePromise<Stream<R[K]> | Array<R[K]> | R[K]>;
}): Stream<T>;

/**
 * Creates a stream that defers the creation of an inner stream until it is
 * subscribed to.
 *
 * This operator ensures that the `factory` function is called only when
 * a consumer subscribes to the stream, making it a good choice for
 * creating "cold" streams. Each new subscription will trigger a new
 * call to the `factory` and create a fresh stream instance.
 *
 * @template T The type of the values in the inner stream.
 * @param {() => (Stream<T> | MaybePromise<T> | Array<T>)} factory A function that returns the stream to be subscribed to.
 * @returns {Stream<T>} A new stream that defers subscription to the inner stream.
 */
export declare function defer<T = any>(factory: () => MaybePromise<(Stream<T> | Array<T> | T)>): Stream<T>;

/**
 * Creates an empty stream that emits no values and completes immediately.
 *
 * This function creates a stream that serves as a useful utility for
 * scenarios where a stream is expected but no values need to be produced.
 * It completes immediately upon subscription, allowing a sequence of
 * other streams to proceed without delay.
 *
 * @template T The type of the stream's values (will never be emitted).
 * @returns {Stream<T>} An empty stream.
 */
/**
 * A singleton instance of an empty stream.
 *
 * This constant provides a reusable, empty stream that immediately completes
 * upon subscription without emitting any values. It is useful in stream
 * compositions as a placeholder or to represent a sequence with no elements.
 *
 * @type {Stream<any>}
 */
export declare const empty: <T = any>() => Stream<T>;

/**
 * A singleton instance of an empty stream.
 *
 * This constant provides a reusable, empty stream that immediately completes
 * upon subscription without emitting any values. It is useful in stream
 * compositions as a placeholder or to represent a sequence with no elements.
 */
export declare const EMPTY: Stream<any>;

/**
 * Waits for all streams to complete and emits an array of their last values.
 *
 * @template T The type of the last values emitted by each stream.
 * @param streams Streams to join; arrays/iterables are also accepted for backward compatibility.
 * @returns Stream<T[]>
 */
export declare function forkJoin<T = any, R extends readonly unknown[] = any[]>(...sources: {
    [K in keyof R]: MaybePromise<Stream<R[K]> | Array<R[K]> | R[K]>;
}): Stream<T[]>;

/**
 * Creates a stream from an asynchronous or synchronous iterable.
 *
 * This operator is a powerful way to convert any source that can be iterated
 * over (such as arrays, strings, `Map`, `Set`, `AsyncGenerator`, etc.) into
 * a reactive stream. The stream will emit each value from the source in order
 * before completing.
 *
 * @template T The type of the values in the iterable.
 * @param {AsyncIterable<T> | Iterable<T> | PromiseLike<AsyncIterable<T> | Iterable<T>>} source The iterable source to convert into a stream.
 * @returns {Stream<T>} A new stream that emits each value from the source.
 */
export declare function from<T = any>(source: MaybePromise<AsyncIterable<T> | Iterable<T>>): Stream<T>;

/**
 * Creates a stream that emits events of the specified type from the given EventTarget.
 *
 * This function provides a reactive way to handle DOM events or other events,
 * such as mouse clicks, keyboard presses, or custom events. The stream
 * will emit a new event object each time the event is dispatched.
 *
 * @template {Event} T The type of the event to listen for. Defaults to a generic `Event`.
 * @param {EventTarget | PromiseLike<EventTarget>} target The event target to listen to (e.g., a DOM element, `window`, or `document`).
 * @param {string | PromiseLike<string>} event The name of the event to listen for (e.g., 'click', 'keydown').
 * @returns {Stream<T>} A stream that emits the event objects as they occur.
 */
export declare function fromEvent(target: MaybePromise<EventTarget>, event: MaybePromise<string>): Stream<Event>;

/**
 * Creates a stream that emits the resolved value of a Promise and then completes.
 *
 * This is a simple but powerful operator for converting a single, asynchronous
 * value into a stream. If the promise is rejected, the stream will emit an
 * error. The stream will emit exactly one value before it completes.
 *
 * @template T The type of the value that the promise resolves to.
 * @param {MaybePromise<T>} promise The promise to convert into a stream.
 * @returns {Stream<T>} A new stream that emits the resolved value of the promise.
 */
export declare function fromPromise<T = any>(promise: MaybePromise<T>): Stream<T>;

/**
 * Creates a stream that chooses between two streams based on a condition.
 *
 * The condition is evaluated lazily when the stream is subscribed to. This allows
 * for dynamic stream selection based on runtime state.
 *
 * @template T The type of the values in the streams.
 * @param {() => MaybePromise<boolean>} condition A function that returns a boolean to determine which stream to use. It is called when the iif stream is subscribed to.
 * @param {Stream<T> | MaybePromise<T> | Array<T>} trueStream The stream to subscribe to if the condition is `true`.
 * @param {Stream<T> | MaybePromise<T> | Array<T>} falseStream The stream to subscribe to if the condition is `false`.
 * @returns {Stream<T>} A new stream that emits values from either `trueStream` or `falseStream` based on the condition.
 */
export declare function iif<T = any>(condition: () => MaybePromise<boolean>, trueStream: MaybePromise<Stream<T> | Array<T> | T>, falseStream: MaybePromise<Stream<T> | Array<T> | T>): Stream<T>;

/**
 * Creates a timer stream that emits numbers starting from 0.
 *
 * This stream is useful for scheduling events or generating periodic data.
 * It is analogous to `setInterval` but as an asynchronous stream.
 *
 * @param {number} [delayMs=0] - The time in milliseconds to wait before emitting the first value (0).
 * If 0, the first value is emitted immediately (in the next microtask).
 * @param {number} [intervalMs] - The time in milliseconds between subsequent emissions.
 * If not provided, it defaults to `delayMs`.
 * @returns {Stream<number>} A stream that emits incrementing numbers (0, 1, 2, ...).
 */
export declare function timer(delayMs?: MaybePromise<number>, intervalMs?: MaybePromise<number>): Stream<number>;

/**
 * Creates a stream that emits incremental numbers starting from 0 at a regular
 * interval.
 *
 * This operator is a shorthand for `timer(0, intervalMs)`, useful for
 * creating a simple, repeating sequence of numbers. The stream emits a new
 * value every `intervalMs` milliseconds. It is analogous to `setInterval` but
 * as an asynchronous stream.
 *
 * @param {MaybePromise<number>} intervalMs The time in milliseconds between each emission.
 * @returns {Stream<number>} A stream that emits incrementing numbers (0, 1, 2, ...).
 */
export declare function interval(intervalMs: MaybePromise<number>): Stream<number>;

/**
 * Creates a stream that performs a JSONP request and emits the resulting data once.
 *
 * This function provides a reactive way to handle JSONP requests, which are
 * often used to bypass the same-origin policy for loading data from a different
 * domain. It dynamically creates a `<script>` tag, handles the response via a
 * global callback, and then cleans up after itself. The stream emits a single
 * value and then completes.
 *
 * @template T The type of the JSONP data to be emitted.
 * @param {MaybePromise<string>} url The URL to make the JSONP request to.
 * @param {MaybePromise<string>} [callbackParam='callback'] The name of the query parameter for the callback function.
 * @returns {Stream<T>} A new stream that emits the JSONP data and then completes.
 */
export declare function jsonp<T = any>(url: MaybePromise<string>, callbackParam?: MaybePromise<string>): Stream<T>;

/**
 * Creates a stream that emits values in a loop based on a condition and an
 * iteration function.
 *
 * This operator is useful for generating a sequence of values until a specific
 * condition is no longer met. It starts with an `initialValue` and, for each
 * iteration, it yields the current value and then uses `iterateFn` to
 * calculate the next value in the sequence.
 *
 * @template T The type of the values in the stream.
 * @param {MaybePromise<T>} initialValue The starting value for the loop.
 * @param {(value: T) => MaybePromise<boolean>} condition A function that returns `true` to continue the loop and `false` to stop.
 * @param {(value: T) => MaybePromise<T>} iterateFn A function that returns the next value in the sequence.
 * @returns {Stream<T>} A stream that emits the generated sequence of values.
 */
export declare function loop<T = any>(initialValue: MaybePromise<T>, condition: (value: T) => MaybePromise<boolean>, iterateFn: (value: T) => MaybePromise<T>): Stream<T>;

/**
 * Merges multiple source streams into a single stream, emitting values as they arrive from any source.
 *
 * This is useful for combining data from multiple independent sources into a single,
 * unified stream of events. Unlike `zip`, it does not wait for a value from every
 * stream before emitting; it emits values on a first-come, first-served basis.
 *
 * The merged stream completes only after all source streams have completed. If any source stream
 * errors, the merged stream immediately errors.
 *
 * @template T The type of the values in the streams.
 * @param sources Streams/values (or promise of array) to merge.
 * @returns {Stream<T>} A new stream that emits values from all input streams.
 */
export declare function merge<T = any, R extends readonly unknown[] = any[]>(...sources: {
    [K in keyof R]: MaybePromise<Stream<R[K]> | Array<R[K]> | R[K]>;
}): Stream<T>;

/**
 * Creates a stream that emits a single value and then completes.
 *
 * This operator is useful for scenarios where you need to treat a static,
 * single value as a stream. It immediately yields the provided `value`
 * and then signals completion, which is a common pattern for creating a
 * "hot" stream from a predefined value.
 *
 * @template T The type of the value to be emitted.
 * @param {MaybePromise<T>} value The single value to emit.
 * @returns {Stream<T>} A new stream that emits the value and then completes.
 */
export declare function of<T = any>(value: MaybePromise<T>): Stream<T>;

/**
 * Creates a reactive stream that emits the time delta (in milliseconds) between
 * consecutive `requestAnimationFrame` calls.
 *
 * This stream provides a convenient way to track frame updates in animations,
 * game loops, or other time-sensitive operations. Each subscriber receives
 * a stream of `number` values representing the elapsed time since the previous frame.
 *
 * **Behavior:**
 * - When a subscriber subscribes, a new RAF loop starts immediately.
 * - The first emitted value is the delta between the first and second RAF callbacks.
 * - Each subsequent frame emits the delta since the previous frame.
 * - When the subscriber unsubscribes, the RAF loop is canceled to avoid unnecessary CPU usage.
 *
 * @returns {Stream<number>} A stream emitting the time delta between frames.
 */
export declare function onAnimationFrame(): Stream<number>;

/**
 * Creates a stream that emits `true` when a given element enters the
 * viewport and `false` when it leaves.
 *
 * This operator is a wrapper around the `IntersectionObserver` API,
 * making it easy to create reactive streams for "lazy loading" or
 * triggering events when an element becomes visible. The stream will
 * emit a value each time the intersection status changes.
 *
 * @param {Element | PromiseLike<Element>} element The DOM element to observe for intersection changes.
 * @param {IntersectionObserverInit | PromiseLike<IntersectionObserverInit>} [options] Optional configuration for the observer, such as root, root margin, and threshold.
 * @returns {Stream<boolean>} A stream that emits `true` if the element is intersecting the viewport, and `false` otherwise.
 */
export declare function onIntersection(element: MaybePromise<Element>, options?: MaybePromise<IntersectionObserverInit>): Stream<boolean>;

/**
 * Creates a reactive stream that emits `true` or `false` whenever a CSS media query
 * matches or stops matching.
 *
 * This stream allows you to reactively track viewport changes, orientation, or
 * other media features in a consistent, subscription-based way.
 *
 * **Behavior:**
 * - The initial match status is emitted immediately upon subscription.
 * - Subsequent changes are emitted whenever the media query's match state changes.
 * - Each subscriber has its own listener, which is cleaned up when unsubscribing.
 *
 * @param mediaQueryString A valid CSS media query string (or promise) (e.g., "(min-width: 600px)").
 * @returns {Stream<boolean>} A stream emitting `true` if the query matches, `false` otherwise.
 */
export declare function onMediaQuery(mediaQueryString: MaybePromise<string>): Stream<boolean>;

/**
 * Creates a stream that emits an array of `MutationRecord` objects whenever
 * a change is detected on a given DOM element.
 *
 * Automatically unsubscribes if the element is removed from the DOM.
 *
 * @param element The DOM element (or promise) to observe for mutations.
 * @param options An optional object (or promise) specifying which DOM changes to observe.
 * @returns A Stream emitting arrays of `MutationRecord`s.
 */
export declare function onMutation(element: MaybePromise<Element>, options?: MaybePromise<MutationObserverInit>): Stream<MutationRecord[]>;

/**
 * Creates a stream that emits the current screen orientation, either
 * "portrait" or "landscape", whenever it changes.
 *
 * Automatically unsubscribes when unsubscribed.
 *
 * @returns {Stream<"portrait" | "landscape">} A stream that emits a string indicating the screen's orientation.
 */
/**
 * Creates a stream that emits the current screen orientation, either
 * "portrait" or "landscape", whenever it changes.
 *
 * Automatically unsubscribes when unsubscribed.
 *
 * @returns {Stream<"portrait" | "landscape">} A stream that emits a string indicating the screen's orientation.
 */
export declare function onOrientation(): Stream<"portrait" | "landscape">;

/**
 * Creates a stream that emits the dimensions (width and height) of a given
 * DOM element whenever it is resized.
 *
 * Automatically unsubscribes and completes if the element is removed from the DOM.
 *
 * @param element The DOM element (or promise resolving to one) to observe for size changes.
 * @returns A Stream emitting objects with `width` and `height` properties.
 */
export declare function onResize(element: MaybePromise<HTMLElement>): Stream<{
    width: number;
    height: number;
}>;

/**
 * Returns a stream that races multiple input streams.
 * It emits values from the first stream that produces a value,
 * then cancels all other streams.
 *
 * This operator is useful for scenarios where you only need the result from the fastest
 * of several asynchronous operations. For example, fetching data from multiple servers
 * and only taking the result from the one that responds first.
 *
 * Once the winning stream completes, the output stream also completes.
 * If the winning stream emits an error, the output stream will emit that error.
 *
 * @template {readonly unknown[]} T - A tuple type representing the combined values from the streams.
 * @param {MaybePromise<{ [K in keyof T]: Stream<T[K]> | Array<T[K]> | T[K] }>} streams - Streams (or a promise of them) to race against each other.
 * @returns {Stream<T[number]>} A new stream that emits values from the first stream to produce a value.
 */
export declare function race<T extends readonly unknown[] = any[]>(...streams: Array<MaybePromise<Stream<T[number]> | Array<T[number]> | T[number]>>): Stream<T[number]>;

/**
 * Creates a stream that emits a sequence of numbers, starting from `start`,
 * incrementing by `step`, and emitting a total of `count` values.
 *
 * This operator is a powerful way to generate a numerical sequence in a
 * reactive context. It's similar to a standard `for` loop but produces
 * values as a stream. It's built upon the `loop` operator for its
 * underlying logic.
 *
 * @param {MaybePromise<number>} start - The first number to emit in the sequence.
 * @param {MaybePromise<number>} count - The total number of values to emit. Must be a non-negative number.
 * @param {MaybePromise<number>} [step=1] - The amount to increment or decrement the value in each step.
 * @returns {Stream<number>} A stream that emits a sequence of numbers.
 */
export declare function range(start: MaybePromise<number>, count: MaybePromise<number>, step?: MaybePromise<number>): Stream<number>;

/**
 * Creates a stream that subscribes to a source factory and retries on error.
 *
 * This operator is useful for handling streams that may fail due to
 * temporary issues, such as network problems. It will attempt to
 * resubscribe to the source stream up to `maxRetries` times, with an
 * optional delay between each attempt. If the stream completes successfully
 * on any attempt, it will emit all of its values and then complete.
 * If all retry attempts fail, the final error is propagated.
 *
 * @template T The type of values emitted by the stream.
 * @param {() => (Stream<T> | MaybePromise<T>)} factory A function that returns a new stream instance for each subscription attempt.
 * @param {MaybePromise<number>} [maxRetries=3] The maximum number of times to retry the stream. A value of 0 means no retries.
 * @param {MaybePromise<number>} [delay=1000] The time in milliseconds to wait before each retry attempt.
 * @returns {Stream<T>} A new stream that applies the retry logic.
 */
export declare function retry<T = any>(factory: () => MaybePromise<(Stream<T> | T)>, maxRetries?: MaybePromise<number>, delay?: MaybePromise<number>): Stream<T>;

/**
 * Interface for a worker that has been "seized" from the coroutine pool.
 * It provides a persistent, bidirectional communication channel and a method
 * to release the worker back to the pool.
 *
 * @template T The type of data sent to the worker.
 * @template R The type of data returned from the worker.
 * @interface
 */
export interface SeizedWorker<T = any, R = T> {
    /** The unique identifier of the seized worker. */
    workerId: number;
    /**
     * Sends a task to the seized worker.
     * @param {T} data The data to be processed by the worker.
     * @returns {Promise<R>} A promise that resolves with the result from the worker.
     */
    sendTask: (data: T) => Promise<R>;
    /**
     * Releases the worker back to the pool.
     * This method must be called to free up the worker for other tasks.
     * After calling this, the `sendTask` method and event listeners will be defunct.
     */
    release: () => void;
}

/**
 * Creates a stream that "seizes" a single worker from the coroutine pool,
 * providing a persistent, manually-controlled communication channel.
 *
 * This operator is ideal for scenarios where you need to perform multiple,
 * sequential tasks on a specific, stateful worker. The worker remains
 * dedicated to the returned stream until the `release()` method is called
 * on the `SeizedWorker` object.
 *
 * The stream itself will only emit a single `SeizedWorker` object and then complete
 * after the worker has been released.
 *
 * @template T The type of data sent to the worker.
 * @template R The type of data returned from the worker.
 * @param {Coroutine<T, R> | PromiseLike<Coroutine<T, R>>} task The coroutine instance managing the worker pool.
 * @param {(message: CoroutineMessage) => MaybePromise<void>} onMessage A callback function to handle messages received from the seized worker.
 * @param {(error: Error) => MaybePromise<void>} onError A callback function to handle errors originating from the seized worker.
 * @returns {Stream<SeizedWorker<T, R>>} A stream that yields a single `SeizedWorker` object.
 */
export declare function seize<T = any, R = T>(task: MaybePromise<Coroutine<T, R>>, onMessage: (message: CoroutineMessage) => MaybePromise<void>, onError: (error: Error) => MaybePromise<void>): Stream<SeizedWorker>;

/**
 * A stream that represents a WebSocket-like interface.
 * Extends a standard Stream with a `.send()` method to send messages.
 *
 * @template T The type of messages sent and received.
 */
export type WebSocketStream<T = any> = Stream<T> & {
    /** Sends a JSON-serializable message to the WebSocket server. */
    send: (message: T) => void;
    /** Close the WebSocket and stop the generator */
    close: () => void;
};

/**
 * Creates a WebSocket stream for bidirectional communication with a server.
 *
 * Incoming messages from the WebSocket are emitted as stream values.
 * Outgoing messages are sent via the `.send()` method.
 * Messages sent before the connection is open are queued automatically.
 *
 * @template T - Type of messages to send and receive.
 * @param url The WebSocket URL (can be a Promise).
 * @param factory Optional WebSocket factory for dependency injection (useful for testing, can be a Promise).
 * @returns {WebSocketStream<T>} A WebSocketStream that can be used to
 * send and receive messages of type T.
 */
export declare function webSocket<T = any>(url: MaybePromise<string>, factory?: (url: string) => MaybePromise<WebSocket>): WebSocketStream<T>;

/**
 * Combines multiple streams by emitting an array of values (a tuple),
 * only when all streams have a value ready (one-by-one, synchronized).
 *
 * It waits for the next value from all streams to form the next tuple.
 * The stream completes when any of the input streams complete.
 * Errors from any stream propagate immediately.
 *
 * @template T - A tuple type representing the combined values from the streams.
 * @param streams Streams to combine.
 * @returns {Stream<T>} A new stream that emits a synchronized tuple of values.
 */
export declare function zip<T extends readonly unknown[] = any[]>(...sources: Array<MaybePromise<Stream<T[number]> | Array<T[number]> | T[number]>>): Stream<T>;

/**
 * Converts a wide variety of input values into a {@link Stream}.
 *
 * This function normalizes different asynchronous or synchronous sources into a
 * unified `Stream<R>` so they can be processed uniformly in operators and pipelines.
 *
 * Supported inputs:
 * - A {@link Stream<R>} (returned as-is).
 * - A {@link MaybePromise<R>} (a value or a promise resolving to a value),
 *   wrapped into a single–emission stream.
 * - An array of `R`, converted into a stream using {@link from}.
 *
 * @template R The type of values emitted by the resulting stream.
 * @param value The input source to convert into a stream. Can be a stream, a value,
 * a promise, or an array of values.
 * @returns A {@link Stream<R>} representing the given input.
 */
export declare function fromAny<R = any>(value: MaybePromise<Stream<R> | Array<R> | R>): Stream<R>;

/**
 * Returns a promise that resolves with the last emitted value from a `Stream`.
 *
 * This function subscribes to the provided stream and buffers the last value
 * received. The returned promise is only settled once the stream completes or
 * errors.
 *
 * - **Successful resolution:** The promise resolves with the last value emitted
 * by the stream, but only after the stream has completed.
 * - **Rejection on error:** If the stream emits an error, the promise is rejected with that error.
 * - **Rejection on no value:** If the stream completes without emitting any values,
 * the promise is rejected with a specific error message.
 *
 * The subscription is automatically and immediately unsubscribed upon completion or
 * on error, ensuring proper resource cleanup.
 *
 * @template T The type of the value expected from the stream.
 * @param stream The source stream to listen to for the final value.
 * @returns A promise that resolves with the last value from the stream or rejects on completion without a value or on error.
 */
export declare function lastValueFrom<T = any>(stream: Stream<T>): Promise<T>;

/**
 * Creates a stream operator that emits a final, specified value after the source stream has completed.
 *
 * The operator first consumes all values from the upstream source. Once the source stream signals
 * its completion (`done`), this operator then emits the `finalValue` and immediately completes.
 *
 * @template T The type of the values in the stream.
 * @param finalValue The value to be emitted as the last item in the stream.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare const endWith: <T = any>(finalValue: T) => Operator<T, T>;

/**
 * Creates a stream operator that invokes a finalizer callback upon stream termination.
 *
 * This operator is useful for performing cleanup tasks, such as closing resources
 * or logging, after a stream has completed or encountered an error. The provided
 * `callback` is guaranteed to be called exactly once, regardless of whether the
 * stream terminates gracefully or with an error.
 *
 * @template T The type of the values emitted by the stream.
 * @param callback The function to be called when the stream completes or errors.
 * It can be synchronous or return a Promise.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare const finalize: <T = any>(callback: () => MaybePromise) => Operator<T, T>;

/**
 * Creates a stream operator that prepends a specified value to the beginning of the stream.
 *
 * The operator first emits the `initialValue` immediately upon being iterated.
 * After this initial emission, it begins to pull and emit values from the
 * source stream as they become available.
 *
 * @template T The type of the values in the stream.
 * @param initialValue The value to be emitted as the first item in the stream.
 * @returns An `Operator` instance that can be used in a stream's `pipe` method.
 */
export declare const startWith: <T = any>(initialValue: T) => Operator<T, T>;
